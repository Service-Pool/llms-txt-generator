## Payouts and Transfers

This section of the documentation covers how to manage the movement of funds from your Stripe account to external bank accounts, as well as how to transfer funds between Stripe accounts, particularly within the context of Stripe Connect.

### Core Payout Functionality

*   **Receive Payouts**: Understand how funds are paid out to your bank account, including typical timelines, initial payout delays, and how to manage your bank account details. (Page 47)
*   **Payout Reconciliation**: Learn how to match transactions to specific payouts and review the details of automatic and manual payouts. (Page 56)
*   **Payout Trace IDs**: Discover how to use Trace IDs to track late or missing payouts with your bank. (Page 55)
*   **Payout Statement Descriptors**: Manage how Stripe payouts appear on your connected account's bank statements. (Page 54)
*   **Multi-currency Settlement**: Configure your account to accrue balances and receive payouts in additional currencies without incurring foreign exchange fees. (Page 52)
*   **Next-day Settlement**: Access your funds from domestic transactions (excluding ACH direct debits) on the next business day. (Page 53)
*   **Customized Start of Day**: Set a custom start time for your day to align automatic payouts with your local timezone for easier reconciliation. (Page 46)
*   **Minimum Balances for Automatic Payouts**: Set a minimum balance to retain in your Stripe account after automatic payouts to cover potential refunds, disputes, and fees. (Page 51)

### Instant Payouts

*   **Instant Payouts for Stripe Dashboard Users**: Get immediate access to your Stripe balance following a successful charge, with funds typically settling within 30 minutes. (Page 50)
*   **Instant Payouts with Advance Funding**: Understand how Instant Payouts can access pending balances through advance funding for accurate bookkeeping. (Page 49)
*   **Institution Support for Instant Payouts**: Identify which financial institutions support Instant Payouts in various regions. (Page 48)

### Stripe Connect Payouts

*   **Payouts to Connected Accounts**: Manage payouts to your connected accounts, including setting up payout accounts and understanding payout schedules. (Covered within broader Connect documentation, but related to pages like Page 6)
*   **Manage Payout Accounts for Connected Accounts**: Configure and manage the bank accounts and debit cards that connected accounts can receive payouts to. (Covered within broader Connect documentation, but related to Page 5)
*   **Manage Payout Schedule**: Control the automatic payout schedule for your connected accounts. (Page 6)
*   **Manual Payouts**: Send manual payouts to your connected accounts when automatic payouts are not desired. (Page 7)
*   **Payout Reversals**: Learn how to reverse a payout sent to a connected account, under specific conditions. (Page 8)
*   **Cross-border Payouts**: Pay sellers, freelancers, and service providers in their local currencies, regardless of their location. (Page 2)
*   **Stablecoin Payouts**: Enable your Connect platform to make payouts in stablecoins, starting with USDC. (Page 1)
*   **Controlling Bank and Debit Card Transfers (Legacy)**: Understand the legacy method for platforms to control transfers for their Custom Connect accounts. (Page 5)

### Global Payouts

*   **Global Payouts Overview**: Send funds directly to any third party in their local currency, with options for no-code, API-driven, or Stripe-hosted form integrations. (Page 32)
*   **Get Started with Global Payouts**: Activate and configure your account, payout, and communication settings for Global Payouts. (Page 31)
*   **Create Recipients**: Learn how to create recipients for Global Payouts using the Dashboard, Stripe-hosted forms, or the API. (Page 34)
*   **API Recipient Creation**: Onboard recipients for Global Payouts programmatically using the Stripe API. (Page 30)
*   **Stripe-hosted Recipient Creation**: Utilize Stripe's hosted web forms to collect recipient information for payouts. (Page 38)
*   **Send Money**: Send payouts in local currency to recipients in over 90 countries, with varying speeds and costs depending on the payout method. (Page 37)
*   **Manage Payouts**: Monitor payout statuses, view reports, and reverse payouts within the Global Payouts system. (Page 33)
*   **Pricing**: Understand the fees associated with Global Payouts, including action-based costs and cross-border/FX fees. (Page 36)
*   **Compare with Connect**: Determine whether Global Payouts or Connect payouts best suits your business needs. (Page 35)
*   **Reuse Payment Credentials for Global Payouts**: Collect and reuse identity and credential information to enable payment methods as payout methods for Global Payouts. (Page 9)

### Financial Connections for Payouts

*   **Collect a Bank Account to Enhance Connect Payouts**: Use Financial Connections to instantly collect tokenized account and routing numbers for payouts to connected accounts, reducing failure rates and saving development time. (Page 13)
*   **Financial Connections Use Cases**: Explore how Financial Connections can be used for various purposes, including facilitating Connect payouts. (Page 25)
*   **Relink Financial Connections Accounts Used for Payments or Payouts**: Reactivate inactive accounts to restore data access, refresh tokenized account numbers, and update data permissions for payments or payouts. (Page 21)

### Other Related Concepts

*   **Funds Segregation for Separate Charges and Transfers**: Allocate funds from separate charges and transfers to a holding state before transferring them to connected accounts, preventing their use for other purposes. (Page 4)
*   **Transfer Payout Split (API Versioning)**: Understand the historical split of the `/v1/transfers` resource into `/v1/transfers` (for Stripe Connect) and `/v1/payouts` (for moving money to bank accounts). (Page 57)
*   **Pay with Stripe Balance**: As a Connect platform, create a payment method linked to a connected account's available Stripe balance to collect subscription payments. (Page 43)
*   **Stripe Treasury**: Securely manage money with a financial account, including storing funds, opening local accounts, converting currencies, and sending money. (Page 27)
*   **Use Stablecoins in Your Financial Account**: Learn how to receive, store, and send stablecoins using your financial account with Stripe Treasury. (Page 29)
*   **Instant Currency Conversion**: Instantly convert between currencies on Stripe using eligible funds in your payments balance or financial account. (Page 28)
*   **FX Quotes API**: Get current exchange rates, extended rate quotes, and FX fee information for currency conversions. (Page 10)
*   **Settle in Additional Currencies**: Understand how settling funds in currencies other than your primary currency affects processing fees and how to enable settlement in additional currencies. (Page 11)
*   **Pay out money with Accounts v1 (Deprecated)**: A guide for adding funds to your Stripe balance and paying out to sellers or service providers using a legacy version of Accounts. (Page 3)
*   **Pay out to people (No-code)**: A guide on adding funds to your Stripe balance and transferring them to users' bank accounts without processing payments through Stripe. (Page 41)
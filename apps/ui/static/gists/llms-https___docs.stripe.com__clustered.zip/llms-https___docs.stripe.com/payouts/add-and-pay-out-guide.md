## Payouts

This section of the documentation covers various aspects of handling payouts, from managing payout schedules and types to more advanced features like cross-border and stablecoin payouts.

### Payout Management

*   **Manage Payout Accounts for Connected Accounts**: Configure and manage the bank accounts and debit cards that connected accounts can receive payouts to.
*   **Manage Payout Schedule**: Define how frequently automatic payouts are made to your connected accounts. This includes setting intervals (e.g., daily, weekly, monthly) and specific payout days.
*   **Manual Payouts**: Understand how to initiate payouts to connected accounts manually, and the holding periods associated with these payouts.
*   **Payout Reversals**: Learn how to reverse a payout that has already been sent to a connected account, including the requirements and limitations for reversals.
*   **Payout Statement Descriptors**: Customize the information that appears on your connected accounts' bank statements for payouts.
*   **Payout Trace IDs**: Discover how to use Trace IDs to track late or missing payouts with your bank.
*   **Payout Reconciliation**: Understand how to reconcile transactions with their corresponding payouts to ensure accurate financial tracking.
*   **Customized Start of Day**: Set a custom start time for your day to align payout reconciliation with your local timezone.
*   **Minimum Balances for Automatic Payouts**: Configure a minimum balance to retain in your Stripe account after automatic payouts, ensuring funds are available for refunds, disputes, and fees.
*   **Receive Payouts**: General information on how funds are received via payouts and how to manage your bank account details for payouts.

### Advanced Payout Features

*   **Cross-Border Payouts**: Facilitate payouts to connected accounts in different countries, enabling you to pay sellers, freelancers, and service providers in their local currencies.
*   **Stablecoin Payouts**: Explore the option of making payouts in stablecoins, starting with USDC, for your Connect platform.
*   **Instant Payouts**: Provide users with immediate access to their Stripe balance, with funds typically settling within 30 minutes. This includes information on institution support and advance funding.
*   **Multi-currency Settlement**: Accept, settle, and pay out funds in multiple currencies without incurring foreign exchange fees.
*   **Next-Day Settlement**: Access funds from domestic transactions on the next business day.

### Connect-Specific Payouts

*   **Legacy: Add and Payout Guide**: Information on adding funds to your Stripe balance and paying out to sellers or service providers, specifically for older Connect integrations.
*   **Transfer Payout Split**: Understand the historical change in how Stripe distinguishes between moving money out of Stripe to a bank account (payouts) and moving money between Stripe accounts (transfers).
*   **Pay with Stripe Balance**: As a Connect platform, create payment methods linked to a connected account's available Stripe balance to collect subscription payments.
*   **Funds Segregation for Separate Charges and Transfers**: Allocate funds from specific charges and transfers to a holding state before transferring them to connected accounts, preventing their use for other purposes.
*   **Global Payouts**: A comprehensive solution for sending payouts directly to a recipient's bank account in their local currency, offering flexibility in integration and payout methods. This includes sections on:
    *   **Get Started with Global Payouts**: Initial setup and configuration.
    *   **Create Recipients**: Methods for creating recipients for payouts.
    *   **Send Money**: How to initiate payouts.
    *   **Manage Payouts**: Monitoring payout statuses and reports.
    *   **Stripe-hosted Recipient Creation**: Using Stripe-hosted forms to collect recipient information.
    *   **API Recipient Creation**: Programmatically creating recipients via the API.
    *   **Reuse Payment Credentials for Global Payouts**: Utilizing previously collected payment method information.
    *   **Compare with Connect**: Understanding the differences between Global Payouts and Connect payouts.
    *   **Pricing**: Fee structure for Global Payouts.
    *   **Testing**: How to test Global Payouts in a sandbox environment.

### Financial Connections and Payouts

*   **Collect a bank account to enhance Connect payouts**: Use Financial Connections to instantly collect tokenized account and routing numbers for payouts to connected accounts, reducing errors and saving development time.
*   **Financial Connections Use Cases**: Explore how Financial Connections can be used for various purposes, including facilitating Connect payouts.
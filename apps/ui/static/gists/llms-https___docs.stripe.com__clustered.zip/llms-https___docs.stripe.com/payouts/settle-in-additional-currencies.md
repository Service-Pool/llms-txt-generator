## Payouts and Currency Management

This section of the documentation covers various aspects of managing payouts and handling multiple currencies within Stripe, focusing on how platforms and businesses can control and optimize their financial flows.

### Payout Management

*   **Receive Payouts**: Understand how funds are received when Stripe or a platform makes payouts to a bank account. This includes information on payout availability, initial payout timing, and how to update bank account details. (Page 47)
*   **Manage Payout Schedule**: Learn how to configure the automatic payout schedule for connected accounts, including details on when funds become available and when automatic payouts occur. (Page 6)
*   **Manual Payouts**: Explore how to send manual payouts to connected accounts, understanding the holding periods and the process of triggering payouts via the Payouts API. (Page 7)
*   **Payout Reversals**: Discover how to reverse a payout sent to a connected account, including the requirements for a reversible payout and the webhook events associated with reversals. (Page 8)
*   **Instant Payouts**: Gain access to Stripe balance funds immediately after a successful charge. This section details how Instant Payouts work, their availability, and how to request them. (Page 50)
    *   **Institution Support for Instant Payouts**: Identify which financial institutions support Instant Payouts in various regions. (Page 48)
    *   **Instant Payouts with Advance Funding**: Understand how Instant Payouts can access pending balances, and how advance funding ensures accurate bookkeeping. (Page 49)
*   **Customized Start of Day**: Set a personalized start-of-day time to align automatic payout reconciliation with your local timezone. (Page 46)
*   **Minimum Balances for Automatic Payouts**: Configure a minimum balance to retain in your Stripe account after automatic payouts, helping manage cash flow and cover potential refunds, disputes, and fees. (Page 51)
*   **Payout Trace IDs**: Learn how to track late or missing payouts using unique Trace IDs provided by banking partners. (Page 55)
*   **Payout Reconciliation**: Understand how to identify which transactions are included in a given payout, with methods for reviewing transactions in the Dashboard, reports, or via API. (Page 56)
*   **Payout Statement Descriptors**: Manage how Stripe payouts appear on connected account bank statements, with options for account-level and payout-level descriptors. (Page 54)
*   **Transfer Payout Split (2017-04-06)**: Understand the API change that distinguished between moving money from Stripe to a bank account (payouts) and moving money between Stripe accounts (transfers). (Page 57)

### Multi-Currency and Settlement

*   **Settle in Additional Currencies**: Learn how settling funds in currencies other than your primary currency affects processing fees and how to enable settlement in additional currencies. (Page 11)
*   **Multi-currency Settlement**: Configure your account to accrue balances and receive payouts in multiple currencies without incurring foreign exchange fees. (Page 52)
*   **Next-day Settlement**: Access funds from domestic transactions (excluding ACH direct debits) on the next business day. (Page 53)
*   **Instant Currency Conversion**: Instantly convert between currencies within Stripe, available for eligible funds in your payments balance or financial account. (Page 28)
*   **FX Quotes API**: Utilize this API to display prices in a customer's local currency, lock in exchange rates, and understand FX fees. (Page 10)

### Stablecoins and Treasury

*   **Stablecoin Payouts for Connect**: Enable your Connect platform to make payouts in stablecoins, starting with USDC, while your platform balance remains in fiat. (Page 1)
*   **Use Stablecoins in Your Financial Account**: Learn how to receive, store, and send stablecoins using your financial account with Stripe Treasury. (Page 29)
*   **Manage Money with Stripe Treasury**: Securely store funds, open local accounts, convert currencies, send money, manage expenses, and borrow money directly in the Stripe Dashboard. (Page 27)

### Connect and Global Payouts

*   **Cross-border Payouts**: Pay sellers, freelancers, and service providers in their local currencies, regardless of their location, using Connect payouts or Global payouts. (Page 2)
*   **Pay out money with Accounts v1**: A guide for adding funds to your Stripe balance and paying out sellers or service providers, noting this is a deprecated feature. (Page 3)
*   **Funds Segregation**: Allocate funds from separate charges and transfers to a holding state on your platform account before transferring them to connected accounts. (Page 4)
*   **Controlling Bank and Debit Card Transfers**: Understand how platforms can control transfers for Custom Connect accounts, including setting destination accounts and managing payout frequency. (Page 5)
*   **Global Payouts**: Send funds directly to any third party in their local currency, with options for no-code, Stripe-hosted forms, or API integration. (Page 32)
    *   **Get Started with Global Payouts**: Activate and configure your account, payout, and communication settings for Global Payouts. (Page 31)
    *   **Create Recipients**: Learn how to create recipients with payout methods for Global Payouts using the Dashboard or API. (Page 34)
    *   **Stripe-hosted Recipient Creation**: Onboard recipients using a Stripe-hosted form that dynamically renders based on recipient capabilities, country, and payment methods. (Page 38)
    *   **API Recipient Creation**: Build an information collection flow for recipients to collect details and pass them to Stripe via APIs. (Page 30)
    *   **Send Money**: Send payouts in local currency to recipients in over 90 countries, with varying speed and cost based on payout methods. (Page 37)
    *   **Manage Payouts**: Monitor payout statuses and access reporting for Global Payouts. (Page 33)
    *   **Pricing**: Understand the fees associated with Global Payouts, including funding, payout, cross-border, and FX fees. (Page 36)
    *   **Compare with Connect**: Determine whether Global Payouts or Connect payouts best fit your business needs. (Page 35)
    *   **Test Global Payouts**: Simulate sending payouts in a test environment to confirm your integration works correctly. (Page 39)
    *   **Reuse Payment Credentials for Global Payouts**: Collect identity and credential information to enable payment methods and reuse them for Global Payouts. (Page 9)

### Financial Connections

*   **Financial Connections Fundamentals**: Understand the core components of Stripe Financial Connections: end-user bank account collection and data retrieval. (Page 15)
*   **Stripe Financial Connections**: Access permissioned data from your users' financial accounts to verify bank accounts, reduce underwriting risk, mitigate fraud, and build fintech products. (Page 16)
*   **Access Balances for a Financial Connections Account**: Retrieve up-to-date balances of a Financial Connections Account for applications like risk reduction or underwriting. (Page 12)
*   **Access Ownership Details for a Financial Connections Account**: Retrieve ownership details of a Financial Connections account for applications such as fraud reduction or underwriting. (Page 18)
*   **Collect an Account to Build Data-Powered Products**: Use Financial Connections to access user-permissioned financial data like tokenized account/routing numbers, balances, ownership, and transactions. (Page 17)
*   **Collect a Bank Account to Enhance Connect Payouts**: Instantly collect tokenized account and routing numbers for payouts to connected accounts, reducing errors and saving development time. (Page 13)
*   **Relink a Financial Connections Account with Your User's Permission**: Prompt customers to repair data access, refresh expiring tokenized account numbers, and consent to new data permissions. (Page 23)
    *   **Relink Financial Connections Accounts Used for Data Products**: Reactivate inactive accounts to retrieve data and update data permissions. (Page 19)
    *   **Use the Financial Connections API to Relink an Account**: Integrate the relink authentication flow directly into your website or application. (Page 20)
    *   **Relink Financial Connections Accounts Used for Payments or Payouts**: Reactivate inactive accounts to retrieve data, refresh tokenized account numbers, and update data permissions. (Page 21)
    *   **Hosted Relink**: Enable Stripe to repair broken connections to bank accounts linked with Financial Connections. (Page 22)
*   **Disconnect a Financial Connections Account**: Use the Disconnect API to unlink customer bank accounts when data access is no longer needed. (Page 14)
*   **Get Real-Time Updates from Financial Connections with Webhooks**: Use webhooks to receive notifications about activity on Financial Connections accounts, such as account creation, deactivation, or data refreshes. (Page 26)
*   **Test Financial Connections**: Learn how to test your integration with simulated Financial Connections accounts in a sandbox environment. (Page 24)
*   **Financial Connections Use Cases**: Explore options for integrating Financial Connections and common use cases, such as ACH payments, Connect payouts, and building financial data products. (Page 25)

### Other Payout and Balance Topics

*   **Balances and Settlement Time**: Understand balance states, settlement timing, and best practices for managing your Stripe account funds. (Page 42)
*   **Pay with Stripe Balance**: Collect subscription fees directly from the Stripe balances of your connected accounts. (Page 43)
*   **Reconciliation**: Learn how Stripe reconciles the customer balance to payments and invoices, with options for automatic or manual reconciliation. (Page 44)
*   **PayPal Payout Reconciliation**: Understand how to reconcile payments made through PayPal, focusing on transactions settled within or outside of Stripe's platform. (Page 45)
*   **Network Sponsor Reporting**: Access available reports for network sponsors, provided as CSV files over SFTP, including daily settlement and transaction detail reports. (Page 40)
## Payouts

This section covers how to manage and receive payouts from your Stripe account, including various options for settlement, speed, and customization.

### Payout Overview

*   **Receive Payouts**: Understand how funds are transferred from Stripe to your bank account, including typical timelines and how to manage your bank account details.
*   **Payout Reconciliation**: Learn how to match transactions to specific payouts for accurate record-keeping.
*   **Payout Trace IDs**: Discover how to track late or missing payouts using unique identifiers provided by banking partners.
*   **Payout Statement Descriptors**: Manage how your payouts appear on connected account bank statements.
*   **Multi-currency Settlement**: Configure your account to receive and pay out in multiple currencies without incurring foreign exchange fees.
*   **Next-day Settlement**: Access your funds as quickly as the next business day for domestic transactions.
*   **Instant Payouts**: Get immediate access to your Stripe balance following a successful charge, available day or night.
    *   **Institution Support for Instant Payouts**: Check if your financial institution supports Instant Payouts.
    *   **Instant Payouts with Advance Funding**: Utilize pending balances for instant payouts with accurate bookkeeping.
*   **Customized Start of Day**: Set a personalized start time for your day to align automatic payouts with your local timezone for easier reconciliation.
*   **Minimum Balances for Automatic Payouts**: Maintain a minimum balance to cover potential refunds, disputes, and fees, ensuring better cash flow management.

### Connect Payouts

This subsection details how platforms can manage payouts to their connected accounts.

*   **Payouts to Connected Accounts**: General information on paying out funds to connected accounts.
*   **Manage Payout Accounts for Connected Accounts**: Configure and manage the bank accounts and debit cards that connected accounts can receive payouts to.
*   **Manage Payout Schedule**: Control the automatic payout schedule for your connected accounts.
*   **Manual Payouts**: Send manual payouts to your connected accounts when automatic payouts are not desired.
*   **Payout Reversals**: Learn how to reverse a payout sent to a connected account, under specific conditions.
*   **Cross-border Payouts**: Facilitate payouts to connected accounts in different countries and local currencies.
*   **Stablecoin Payouts**: Enable payouts in stablecoins, starting with USDC, for your Connect platform.
*   **Funds Segregation for Separate Charges and Transfers**: Allocate funds from specific charges and transfers to a holding state before payout, ensuring they are reserved for connected accounts.
*   **Legacy: Add and Pay Out Guide**: Information on older methods for adding funds and paying out to sellers or service providers.
*   **Legacy: Controlling Bank and Debit Card Transfers**: Details on managing transfers for Custom Connect accounts using a legacy version.
*   **Transfer Payout Split**: Understand the historical change in API resources for transfers and payouts.

### Global Payouts

This subsection focuses on sending payouts directly to third parties outside of the Connect ecosystem.

*   **Global Payouts Overview**: An introduction to sending funds directly to third parties in their local currency.
*   **Get Started with Global Payouts**: Steps to activate and configure your account for Global Payouts.
*   **Create Recipients**: Learn how to create recipients for Global Payouts using the Dashboard or API.
    *   **Stripe-hosted Recipient Creation**: Utilize Stripe-hosted forms to collect recipient information.
    *   **API Recipient Creation**: Onboard recipients programmatically using the Stripe API.
*   **Send Money**: How to send money in local currency to recipients domestically and internationally.
*   **Manage Payouts**: Monitor payout statuses, view reports, and handle reversals for Global Payouts.
*   **Reuse Payment Credentials for Global Payouts**: Collect and reuse payment credentials to enable payout methods for Global Payouts.
*   **Compare with Connect**: Understand the differences between Global Payouts and Connect payouts to choose the best integration for your needs.
*   **Pricing**: Details on fees associated with Global Payouts.
*   **Test Global Payouts**: Simulate sending payouts in a test environment.

### Financial Connections

This subsection covers how to securely collect and use financial account data.

*   **Financial Connections Overview**: An introduction to accessing permissioned data from users' financial accounts.
*   **Financial Connections Fundamentals**: Learn how Financial Connections works, including the authentication flow and data retrieval.
*   **Use Cases**: Explore common use cases for Financial Connections, such as ACH payments, Connect payouts, and building financial data products.
*   **Collect Accounts for Data**: Gather user account information for various data-powered products.
    *   **ACH Direct Debit Payments**: Collect bank accounts for ACH payments using account data.
    *   **Connect Payouts**: Collect bank accounts to enhance Connect payouts.
    *   **Other Data-Powered Products**: Collect accounts to build products using balances, ownership, and transaction data.
*   **Access Account Data**: Retrieve up-to-date financial data for a Financial Connections Account.
    *   **Balances**: Access current and available balances.
    *   **Ownership**: Access account owners' names and mailing addresses.
    *   **Transactions**: Access an account's transaction history.
*   **Manage Accounts**: Functions related to managing linked financial accounts.
*   **Relink Financial Connections Accounts**: Prompt customers to repair broken connections to their bank accounts.
    *   **Hosted Relink**: Enable Stripe to repair broken connections via the Dashboard.
    *   **API Relink**: Integrate the relink authentication flow directly into your application.
        *   **Relink for Payments or Payouts**: Configure the authentication flow to relink accounts used for payments or payouts.
        *   **Relink for Data Products**: Configure the authentication flow to relink accounts used for data access.
*   **Tokenized Account Numbers**: Understand how tokenized account numbers are used.
*   **Disconnections**: Learn how to disconnect a Financial Connections account.
*   **Webhooks**: Get real-time updates from Financial Connections using webhooks.
*   **Testing**: How to test your Financial Connections integration with simulated accounts.

### Treasury

This subsection covers managing money with Stripe Treasury.

*   **Stripe Treasury Overview**: Securely manage money with a financial account, including storing funds, opening local accounts, and converting currencies.
*   **Stablecoins in Treasury**: Receive, store, and send stablecoins using your financial account with Stripe Treasury.
*   **Cards**: Information on using cards with Stripe Treasury.
*   **Instant Currency Conversion**: Instantly convert between currencies on Stripe using eligible funds.
*   **Global Payouts**: (Also covered in its own section) Send payouts to third parties.
*   **Issuing for your business**: Information on issuing cards.
*   **Capital**: Details on accessing business financing.

### FX Quotes API

*   **The FX Quotes API**: Get current exchange rates, extended rate quotes, and FX fee information for currency conversions.

### Balances

*   **Balances and Settlement Time**: Understand balance states, settlement timing, and best practices for managing your funds.
*   **Pay with Stripe Balance**: Collect subscription fees directly from the Stripe balances of your connected accounts.
*   **Customer Balance Reconciliation**: Learn how Stripe reconciles the customer balance to payments and invoices.
*   **PayPal Payout Reconciliation**: Understand how to reconcile payments made through PayPal.
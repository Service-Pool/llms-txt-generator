This documentation set focuses on **Stripe's payout capabilities**, particularly within the **Connect platform**. It details various methods and considerations for sending money to connected accounts and external recipients.

Here's a breakdown of the key themes and how the pages relate:

**Core Payout Functionality:**

*   **Managing Payouts:** Pages like `/connect/manage-payout-schedule` and `/connect/manual-payouts` explain how to control when and how payouts are made to connected accounts. `/connect/payout-reversals` covers how to undo a payout if the platform is responsible for risk.
*   **Payout Destinations:** `/connect/legacy/add-and-pay-out-guide` and `/connect/legacy-transfers` touch upon setting up bank accounts and debit cards for payouts. `/global-payouts/credential-reuse` and `/global-payouts/api-recipient-creation` discuss collecting and reusing recipient payment credentials for Global Payouts.
*   **Payout Reconciliation and Traceability:** `/payouts/reconciliation`, `/payouts/trace-id`, and `/payouts/statement-descriptors` provide tools and information to track payouts, understand what transactions are included, and how they appear on bank statements.

**Advanced Payout Features and Options:**

*   **Cross-Border and Global Payouts:** `/connect/cross-border-payouts` and the suite of `/global-payouts/` pages (e.g., `/global-payouts/get-started`, `/global-payouts/send-money`, `/global-payouts/pricing`) detail how to send payouts internationally to various countries and currencies, offering different integration methods (API, hosted forms).
*   **Stablecoin Payouts:** `/connect/stablecoin-payouts` introduces the ability to make payouts in stablecoins, starting with USDC, for Connect platforms.
*   **Instant Payouts:** `/payouts/instant-payouts` and `/payouts/instant-payouts-with-advance-funding` explain how users can get access to their Stripe balance immediately, with details on bank support and how pending balances are handled.
*   **Multi-currency Settlement:** `/payouts/multicurrency-settlement` and `/payments/currencies/settlement-payouts` discuss how to accept, settle, and pay out funds in multiple currencies without incurring foreign exchange fees.
*   **Next-Day Settlement:** `/payouts/next-day-settlement` offers faster access to funds for US-based Stripe Dashboard users.

**Connect Platform Specifics:**

*   **Connect Payouts vs. Global Payouts:** `/connect/cross-border-payouts` and `/global-payouts/compare-with-connect` clearly differentiate between Stripe Connect's payout capabilities and the more general Global Payouts feature, highlighting their respective use cases and best fits.
*   **Funds Segregation:** `/connect/funds-segregation` explains how platforms can allocate funds from specific charges to a holding state before transferring them to connected accounts, offering more control over fund flow.
*   **Financial Connections for Connect Payouts:** `/financial-connections/connect-payouts` and `/financial-connections/use-cases` highlight how Stripe Financial Connections can be used to collect bank account details for Connect payouts, improving onboarding and reducing failure rates.

**Related Financial Management Tools:**

*   **Stripe Treasury:** `/treasury` and `/treasury/stablecoins` introduce Stripe Treasury for managing money securely, including the ability to store and send stablecoins.
*   **Instant Currency Conversion:** `/instant-currency-conversion` and `/payments/currencies/localize-prices/fx-quotes-api` provide tools for converting currencies instantly or getting FX quotes.
*   **Balances:** `/payments/balances` explains different balance types and settlement timing. `/payments/pay-with-balance` and `/payments/customer-balance/reconciliation` discuss paying from a Stripe balance and reconciling customer balances.

**Technical and Operational Details:**

*   **API Changes:** `/transfer-payout-split` clarifies the historical split of the `/transfers` resource into `/transfers` and `/payouts`.
*   **Testing:** `/financial-connections/testing` and `/global-payouts/testing` provide guidance on testing integrations in sandbox environments.
*   **Webhooks:** `/financial-connections/webhooks` explains how to use webhooks for real-time updates from Financial Connections.
*   **No-Code Payouts:** `/no-code/payout` offers a guide for users who want to pay out money without writing code.

This collection of pages provides a comprehensive resource for understanding and implementing various payout strategies within Stripe, catering to different business models and technical requirements.
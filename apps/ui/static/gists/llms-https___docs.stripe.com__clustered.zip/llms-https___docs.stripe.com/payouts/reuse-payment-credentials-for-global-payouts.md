# Payouts

This section of the Stripe documentation covers various aspects of receiving and managing payouts, both for individual Stripe users and for platforms using Stripe Connect. It details how funds are settled, the different payout schedules and methods available, and how to troubleshoot issues with payouts.

## Key Topics:

*   **Receiving Payouts:** Understand how funds are transferred from Stripe to your bank account, including typical timelines and how to manage your bank account details.
*   **Payout Schedules:** Configure automatic or manual payout schedules to suit your business needs. This includes setting minimum balances to ensure funds are available for refunds, disputes, and fees.
*   **Instant Payouts:** Access your Stripe balance immediately after a successful charge, with funds typically settling within 30 minutes. This section covers institution support and how advance funding works.
*   **Multi-currency Settlement:** Accept, settle, and pay out funds in multiple currencies without incurring foreign exchange fees.
*   **Next-day Settlement:** For US-based Stripe Dashboard users, access funds from domestic transactions on the next business day.
*   **Payout Statement Descriptors:** Manage how Stripe payouts appear on your connected account's bank statements.
*   **Payout Trace IDs:** Track late or missing payouts by using unique identifiers provided by Stripe's banking partners.
*   **Payout Reconciliation:** Understand which transactions are included in a given payout, with methods for reviewing this information in the Dashboard, via reports, or through the API.
*   **Customized Start of Day:** Set a custom start time for your day to align with your local timezone for tracking payout reconciliation.
*   **Connect Payouts:** Specific guidance for platforms using Stripe Connect, including managing payouts to connected accounts, cross-border payouts, and stablecoin payouts.
*   **Global Payouts:** A dedicated solution for sending funds directly to third parties in their local currency, offering various integration options from no-code to API-driven solutions.
*   **Transfer Payout Split:** Understand the historical change in Stripe's API where `/v1/transfers` was split into `/v1/transfers` (for moving money between Stripe accounts) and `/v1/payouts` (for moving money from Stripe to a bank account).

## Related Concepts:

*   **Balances and Settlement Time:** Understanding how funds are held in different balance types and the timing of their availability.
*   **Stripe Treasury:** A service that allows businesses to securely manage money, including storing funds, opening local accounts, and converting currencies.
*   **Financial Connections:** A product that enables users to securely share their financial data by linking their external financial accounts, which can enhance Connect payouts and other data-powered products.
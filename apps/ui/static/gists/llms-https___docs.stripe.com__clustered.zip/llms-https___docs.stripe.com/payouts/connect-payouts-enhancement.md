## Payouts and Financial Connections

This section of the documentation covers various aspects of managing payouts and integrating with Stripe Financial Connections. It details how to send money to connected accounts, handle cross-border transactions, utilize stablecoins, and leverage financial data for enhanced payout processes.

### Payout Management

*   **Connect Payouts:** This is a core feature for platforms using Stripe Connect to pay out funds to their connected accounts.
    *   **Stablecoin Payouts:** Explore how to enable payouts in stablecoins, specifically USDC, for your Connect platform. This involves a private preview and specific onboarding steps. (Page 1)
    *   **Cross-Border Payouts:** Learn how to pay sellers, freelancers, and service providers in their local currencies, regardless of their location. This includes understanding the differences between Connect payouts and Global payouts. (Page 2)
    *   **Legacy Payouts (Accounts v1):** This section covers older methods of adding funds and paying out to sellers or service providers. It also touches upon cross-border transfers within supported regions. (Page 3)
    *   **Funds Segregation:** Understand how to allocate funds from specific charges and transfers to a holding state before disbursing them to connected accounts, preventing their use for other purposes. (Page 4)
    *   **Controlling Bank and Debit Card Transfers (Legacy):** This page describes a legacy method for platforms to control transfers for Custom Connect accounts, including managing destination accounts and payout frequency. (Page 5)
    *   **Manage Payout Schedule:** Learn how to configure the automatic payout schedule for your connected accounts, including settings for minimum balances and payout intervals. (Page 6)
    *   **Manual Payouts:** Discover how to hold funds in a connected account's balance until you manually initiate a payout, with specific holding periods based on country. (Page 7)
    *   **Payout Reversals:** Understand how to reverse a payout sent to a connected account, including requirements and conditions for reversals. (Page 8)
    *   **Payout Reconciliation:** Learn how to identify which transactions are included in a given payout, using methods like the Stripe Dashboard, API, or reconciliation reports. (Page 56)
    *   **Payout Trace IDs:** Discover how to track late or missing payouts using unique Trace IDs provided by banking partners. (Page 55)
    *   **Payout Statement Descriptors:** Manage how Stripe payouts appear on connected account bank statements, with options for account-level and payout-level descriptors. (Page 54)
    *   **Multi-currency Settlement:** Understand how to accept, settle, and pay out funds in multiple currencies without incurring foreign exchange fees. (Page 52)
    *   **Next-day Settlement:** Learn how to access funds from domestic transactions on the next business day in the US. (Page 53)
    *   **Customized Start of Day:** Set your start of day to align automatic payout reconciliation with your local timezone. (Page 46)
    *   **Minimum Balances for Automatic Payouts:** Set a minimum balance in your Stripe account to manage cash flow and cover potential refunds, disputes, and fees. (Page 51)
    *   **Instant Payouts:** Access your Stripe balance immediately following a successful charge, with funds typically settling within 30 minutes. (Page 50)
    *   **Instant Payouts with Advance Funding:** Understand how Instant Payouts can access pending balances with trackable balance activities for accurate bookkeeping. (Page 49)
    *   **Institution Support for Instant Payouts:** Identify which financial institutions support Instant Payouts in various regions. (Page 48)
    *   **Receive Payouts:** Set up your bank account to receive payouts, understanding typical timelines and how to update your banking information. (Page 47)
    *   **Transfer Payout Split:** Understand the historical change in Stripe's API where `/v1/transfers` was split into `/v1/transfers` (for moving money between Stripe accounts) and `/v1/payouts` (for moving money to bank accounts). (Page 57)

### Global Payouts

*   **Global Payouts Overview:** Send payouts directly to a recipient's bank account in their local currency to over 50 countries. (Page 32)
*   **Get Started with Global Payouts:** Activate and configure your account, payout, and communication settings to begin sending payouts. (Page 31)
*   **Create Recipients:** Learn how to create recipients for Global Payouts using the Stripe API or Stripe-hosted forms, including required information and supported countries. (Page 34)
*   **API Recipient Creation:** Onboard recipients for Global Payouts using the Stripe API, providing necessary parameters for recipient details and payout methods. (Page 30)
*   **Stripe-hosted Recipient Creation:** Onboard recipients using a Stripe-hosted form, which dynamically renders based on recipient capabilities and can be customized with your branding. (Page 38)
*   **Send Money:** Learn how to send money in local currency to recipients domestically and internationally using the Dashboard or API. (Page 37)
*   **Manage Payouts:** Monitor payout statuses, receive events for status changes, reverse payouts, and view reporting. (Page 33)
*   **Reuse Payment Credentials for Global Payouts:** Collect identity and credential information to enable payment methods and reuse them as payout methods for Global Payouts. (Page 9)
*   **Compare with Connect:** Understand the differences between Global Payouts and Connect payouts to determine which integration best fits your business needs. (Page 35)
*   **Pricing:** Review the fees associated with Global Payouts, including funding, payout, cross-border, and FX fees. (Page 36)
*   **Test Global Payouts:** Simulate sending payouts in a test environment using sandboxes and test API keys. (Page 39)

### Stripe Treasury and Stablecoins

*   **Manage Money with Stripe Treasury:** Securely store funds, open local accounts, convert currencies, send money, manage expenses, and borrow money directly in the Stripe Dashboard. (Page 27)
*   **Use Stablecoins in your Financial Account:** Learn how to receive, store, and send stablecoins using your financial account with Stripe Treasury. (Page 29)
*   **Instant Currency Conversion:** Instantly convert between currencies on Stripe using eligible funds in your payments balance or financial account. (Page 28)

### Stripe Financial Connections

*   **Stripe Financial Connections Overview:** Access permissioned data from your users' financial accounts to verify bank accounts, reduce underwriting risk, mitigate fraud, and build fintech products. (Page 16)
*   **Financial Connections Fundamentals:** Understand how Financial Connections works, including the authentication flow and data retrieval process. (Page 15)
*   **Financial Connections Use Cases:** Explore options for integrating Financial Connections and common use cases, such as ACH Direct Debit payments, Connect payouts, and building financial data products. (Page 25)
*   **Collect an Account to Build Data-Powered Products:** Use Financial Connections to access user-permissioned financial data like tokenized account numbers, balances, ownership details, and historical transactions. (Page 17)
*   **Access Balances for a Financial Connections Account:** Learn how to retrieve up-to-date balances of a Financial Connections Account for applications like risk reduction or financial management tools. (Page 12)
*   **Access Ownership Details for a Financial Connections Account:** Retrieve ownership details of a Financial Connections account for applications such as fraud reduction or underwriting. (Page 18)
*   **Collect a Bank Account to Enhance Connect Payouts:** Use Financial Connections to instantly collect tokenized account and routing numbers for payouts to connected accounts, reducing onboarding friction and payout failures. (Page 13)
*   **Relink a Financial Connections Account with Your User's Permission:** Prompt customers to repair data access, refresh expiring tokenized account numbers, and consent to new data permissions. (Page 23)
    *   **Relink Financial Connections Accounts Used for Data Products:** Reactivate inactive accounts to retrieve data and update data permissions. (Page 19)
    *   **Relink Financial Connections Accounts Used for Payments or Payouts:** Reactivate inactive accounts to retrieve data, reactivate tokenized account numbers, and update data permissions. (Page 21)
    *   **Use the Financial Connections API to Relink an Account:** Integrate the relink authentication flow directly into your website or application. (Page 20)
    *   **Hosted Relink:** Enable Stripe to repair broken connections to bank accounts linked with Financial Connections. (Page 22)
*   **Disconnect a Financial Connections Account:** Use the Disconnect API to unlink customer bank accounts when data access is no longer needed or requested by the user. (Page 14)
*   **Get Real-time Updates from Financial Connections with Webhooks:** Use webhooks to receive notifications about activity on Financial Connections accounts, such as account creation, deactivation, and data refreshes. (Page 26)
*   **Test Financial Connections:** Learn how to test your integration with simulated Financial Connections accounts in a sandbox environment. (Page 24)

### Other Payout-Related Features

*   **FX Quotes API:** Provides currency conversion capabilities, including current exchange rates, extended rate quotes, and FX fee information. (Page 10)
*   **Settle in Additional Currencies:** Learn how paying out funds in currencies other than your primary currency affects processing fees and how to enable settlement in additional currencies. (Page 11)
*   **Pay with Stripe Balance:** As a Connect platform, create a payment method linked to a connected account’s available Stripe balance to collect subscription payments. (Page 43)
*   **Reconciliation:** Understand how Stripe reconciles the customer balance to payments and invoices, with options for automatic or manual reconciliation. (Page 44)
*   **PayPal Payout Reconciliation:** Learn how to reconcile payments made through PayPal, focusing on scenarios where transactions settle outside of Stripe's platform. (Page 45)
*   **Network Sponsor Reporting:** Access available reports for network sponsors, provided as CSV files over SFTP, including daily settlement and transaction detail reports. (Page 40)
*   **Pay Out Money (No-Code):** Add funds to your Stripe balance and pay out to sellers or service providers without processing payments through Stripe. (Page 41)
*   **Balances and Settlement Time:** Understand balance states, settlement timing, and best practices for balance management, including payments balance and refunds/disputes balance. (Page 42)
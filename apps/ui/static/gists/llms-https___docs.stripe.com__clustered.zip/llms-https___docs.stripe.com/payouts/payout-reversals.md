# Payouts

Stripe provides flexible payout options to help you manage your funds and pay out to your recipients. This section covers various aspects of receiving and managing payouts, including:

## Receiving Payouts

*   **Receive payouts**: Learn how to set up your bank account to receive payouts from Stripe. Understand payout availability, initial payout timing, and how to update your bank account details.
*   **Customized start of day**: Set your start of day to align with your local timezone for more accurate tracking of automatic payout reconciliation.
*   **Minimum balances for automatic payouts**: Configure a minimum balance to retain in your Stripe account after automatic payouts to manage cash flow and cover potential refunds, disputes, and fees.
*   **Multi-currency settlement**: Accept, settle, and pay out funds in multiple currencies without incurring foreign exchange fees. This involves configuring settlement currencies and attaching corresponding bank accounts.
*   **Next-day settlement**: Access your funds from domestic transactions (excluding ACH direct debits) on the next business day. This feature is currently available for Stripe Dashboard users in the US.
*   **Payout statement descriptors**: Understand and manage how Stripe payouts appear on your connected account's bank statements. You can configure account-level or payout-level descriptors.
*   **Payout Trace IDs**: Track late or missing payouts with a unique identifier provided by Stripe's banking partners.
*   **Payout reconciliation**: Understand which transactions are included in a given payout and how to reconcile them.

## Instant Payouts

*   **Instant Payouts for Stripe Dashboard users**: Get immediate access to your Stripe balance following a successful charge. Funds typically settle within 30 minutes.
*   **Institution support for Instant Payouts**: Identify whether your institution supports Instant Payouts in your region.
*   **Instant Payouts with advance funding**: Utilize pending balances with trackable balance activities for accurate bookkeeping when fund availability changes.

## Connect Payouts

*   **Payouts to connected accounts**: Manage payouts to your connected accounts, including setting up payout accounts, schedules, and handling manual payouts.
*   **Manage payout accounts for connected accounts**: Configure the bank accounts and debit cards that connected accounts can use for payouts.
*   **Manage payout schedule**: Control the automatic payout schedule for your connected accounts.
*   **Manual payouts**: Send manual payouts to your connected accounts when automatic payouts are not desired.
*   **Payout reversals**: Reverse payouts sent to connected accounts when your platform is responsible for risk and negative balances.
*   **Cross-border payouts**: Pay sellers, freelancers, and service providers in their local currencies, regardless of their location.
*   **Stablecoin payouts**: Enable your Connect platform to make payouts in stablecoins, starting with USDC.

## Other Payout-Related Topics

*   **Transfer Payout Split: Stripe-Version 2017-04-06**: Understand the historical change that split the `/v1/transfers` resource into `/v1/transfers` (for moving money between Stripe accounts) and `/v1/payouts` (for moving money from Stripe to your bank account).
*   **Global Payouts**: A comprehensive solution for sending funds directly to any third party in their local currency, with options for no-code, API, and Stripe-hosted form integrations. This includes features like recipient creation, managing payouts, and testing.
*   **Global Payouts pricing**: Understand the fees associated with Global Payouts, including funding, sending money, and cross-border fees.
*   **Financial Connections**: Use Financial Connections to collect bank account details for payouts to connected accounts, enhancing onboarding and reducing payout failures.
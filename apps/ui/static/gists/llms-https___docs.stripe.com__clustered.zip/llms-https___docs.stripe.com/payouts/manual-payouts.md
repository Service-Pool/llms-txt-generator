## Payouts

This section of the documentation covers how to manage and process payouts from your Stripe account to external bank accounts or to connected accounts. It details various payout methods, schedules, and related functionalities.

### Core Payout Management

*   **Receive Payouts**: Understand how funds are paid out to your bank account, including typical timelines, first payout delays, and how to manage your bank account details.
*   **Payout Reconciliation**: Learn how to match transactions to specific payouts, review reconciliation reports, and understand the process for both automatic and manual payouts.
*   **Payout Trace IDs**: Discover how to use Trace IDs to track late or missing payouts by contacting your bank, and where to find this identifier in Stripe.
*   **Payout Statement Descriptors**: Manage how Stripe payouts appear on bank statements by configuring account-level or payout-level descriptors.

### Payout Schedules and Timing

*   **Manage Payout Schedule**: Configure automatic payout schedules (daily, weekly, monthly) and understand how settlement timing affects payout availability.
*   **Customized Start of Day**: Set a custom start time for your day to align payout reconciliation with your local timezone.
*   **Minimum Balances for Automatic Payouts**: Set a minimum balance to retain in your Stripe account after automatic payouts to cover potential refunds, disputes, and fees.
*   **Next-Day Settlement**: Access funds from domestic transactions (excluding ACH direct debits) on the next business day for faster availability.
*   **Multi-currency Settlement**: Configure your account to accrue balances and receive payouts in additional currencies without incurring foreign exchange fees.

### Advanced Payout Features

*   **Instant Payouts**: Get immediate access to your Stripe balance following a successful charge, with funds typically settling within 30 minutes.
*   **Instant Payouts with Advance Funding**: Utilize pending balances for Instant Payouts, with Stripe managing the advance and advance\_funding balance transactions for accurate bookkeeping.
*   **Institution Support for Instant Payouts**: Identify which financial institutions support Instant Payouts in various countries.

### Connect Payouts

*   **Payouts to Connected Accounts**: Understand the fundamentals of paying out funds to your connected accounts within the Stripe Connect ecosystem.
*   **Manage Payout Accounts for Connected Accounts**: Configure and manage the bank accounts and debit cards that connected accounts can use for payouts.
*   **Stablecoin Payouts**: Enable your Connect platform to make payouts in stablecoins, starting with USDC, with Stripe handling the conversion.
*   **Cross-Border Payouts**: Pay sellers, freelancers, and service providers in their local currencies, regardless of their location, using Connect or Global Payouts.
*   **Legacy: Add and Pay Out Guide**: Information on adding funds to your Stripe balance and paying out to sellers or service providers using older Connect versions.
*   **Legacy: Controlling Bank and Debit Card Transfers**: Details on managing transfers for Custom Connect accounts, including setting destination accounts and payout frequency.
*   **Pay with Stripe Balance**: As a Connect platform, create a payment method linked to a connected account's available Stripe balance to collect subscription payments.

### Funds Management and Transfers

*   **Funds Segregation**: Allocate funds from specific charges and transfers to a holding state before transferring them to connected accounts, preventing their use for other purposes.
*   **Transfer Payout Split**: Understand the historical change in API resources, separating `/v1/transfers` (between Stripe accounts) and `/v1/payouts` (to bank accounts).
*   **Manual Payouts**: Hold funds in a connected account's balance until you manually initiate a payout, with specific holding periods based on country.
*   **Payout Reversals**: Reverse a payout sent to a connected account if your platform is responsible for risk and negative balances.

### Global Payouts

*   **Global Payouts Overview**: Send funds directly to any third party in their local currency, with options for no-code, API-driven, or Stripe-hosted form integrations.
*   **Get Started with Global Payouts**: Activate and configure your account, payout, and communication settings for Global Payouts.
*   **Create Recipients**: Onboard recipients for Global Payouts by providing their country, business type, email, and desired payout methods.
*   **Stripe-Hosted Recipient Creation**: Use Stripe-hosted forms to collect recipient information, including payout credentials, dynamically based on their details.
*   **API Recipient Creation**: Build an information collection flow for recipients and pass that information to Stripe through the API.
*   **Send Money**: Send payouts in local currency to recipients in over 90 countries, with varying speeds and costs depending on the payout method.
*   **Manage Payouts**: Monitor payout statuses, receive events for status changes, reverse payouts, and access reporting for Global Payouts.
*   **Reuse Payment Credentials for Global Payouts**: Collect identity and credential information to enable payment methods and reuse them for Global Payouts.
*   **Compare with Connect**: Understand the differences between Global Payouts and Connect payouts to choose the best integration for your business.
*   **Pricing**: Review the fees associated with Global Payouts, including funding, payout, cross-border, and FX fees.
*   **Test Global Payouts**: Simulate sending payouts in a test environment using sandboxes and test API keys.

### Financial Connections and Payouts

*   **Collect a Bank Account to Enhance Connect Payouts**: Use Financial Connections to instantly collect tokenized account and routing numbers for payouts to connected accounts, reducing failure rates and saving development time.
*   **Financial Connections Use Cases**: Explore how Financial Connections can be used for ACH payments, Connect payouts, and building financial data products.
*   **Relink Financial Connections Accounts Used for Payments or Payouts**: Reactivate inactive accounts to restore data access, refresh tokenized account numbers, and update data permissions for payments or payouts.
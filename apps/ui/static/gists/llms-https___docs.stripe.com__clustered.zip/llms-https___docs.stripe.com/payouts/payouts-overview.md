# Payouts

Stripe allows you to manage how and when your funds are paid out, offering flexibility to suit your business needs. This section covers various aspects of receiving payouts, including managing your payout schedule, instant payouts, multi-currency settlements, and more.

## Key Payout Features

*   **Manage Payout Schedule:** Control when your automatic payouts occur. You can configure daily, weekly, or monthly payout schedules to align with your cash flow needs. (See: `/connect/manage-payout-schedule`)
*   **Manual Payouts:** For greater control, you can opt for manual payouts, where funds are held until you initiate a transfer. (See: `/connect/manual-payouts`)
*   **Instant Payouts:** Access your Stripe balance immediately after a successful charge. Funds typically settle in your associated payout account within 30 minutes. (See: `/payouts/instant-payouts`)
*   **Cross-Border Payouts:** Pay sellers, freelancers, and service providers in their local currencies, regardless of their location. (See: `/connect/cross-border-payouts`)
*   **Stablecoin Payouts:** For Connect platforms, enable payouts in stablecoins, starting with USDC. (See: `/connect/stablecoin-payouts`)
*   **Multi-Currency Settlement:** Accept, settle, and pay out funds in multiple currencies without incurring foreign exchange fees. (See: `/payouts/multicurrency-settlement`)
*   **Next-Day Settlement:** For US-based Stripe Dashboard users, funds from domestic transactions (excluding ACH direct debits) are available in your Stripe balance on the next business day. (See: `/payouts/next-day-settlement`)
*   **Payout Reconciliation:** Understand which transactions are included in a given payout. (See: `/payouts/reconciliation`)
*   **Payout Trace IDs:** Track late or missing payouts with a unique identifier provided by Stripe's banking partners. (See: `/payouts/trace-id`)
*   **Payout Statement Descriptors:** Configure how Stripe payouts appear on connected accounts' bank statements. (See: `/payouts/statement-descriptors`)
*   **Minimum Balances for Automatic Payouts:** Set a minimum balance in your Stripe account to manage cash flow and cover potential refunds, disputes, and fees. (See: `/payouts/minimum-balances-for-automatic-payouts`)
*   **Customized Start of Day:** Set your start of day to help you track automatic payout reconciliation in your local timezone. (See: `/payouts/customized-start-of-day`)
*   **Payout Reversals:** Reverse a payout sent to a connected account if your platform is responsible for risk and negative balances. (See: `/connect/payout-reversals`)
*   **Funds Segregation:** Allocate funds from separate charges and transfers to a holding state on your platform account before transferring them to connected accounts. (See: `/connect/funds-segregation`)
*   **Global Payouts:** Send funds directly to any third party in their local currency, programmatically or through Stripe-hosted forms. (See: `/global-payouts`)

## Payouts for Connect Platforms

Stripe Connect offers robust features for managing payouts to your connected accounts:

*   **Payouts to Connected Accounts:** Understand the default payout behavior and how to manage it. (See: `/connect/payouts-to-connected-accounts`)
*   **Manage Payout Accounts for Connected Accounts:** Control the bank accounts and debit cards where funds are transferred. (See: `/connect/manage-payout-accounts`)
*   **Legacy Payouts Guide:** Information on older payout methods for Connect v1. (See: `/connect/legacy/add-and-pay-out-guide`)
*   **Controlling Bank and Debit Card Transfers (Legacy):** Details on managing transfers for Custom Connect accounts using legacy methods. (See: `/connect/legacy-transfers`)

## Financial Connections and Payouts

Stripe Financial Connections can enhance your payout processes:

*   **Collect a Bank Account to Enhance Connect Payouts:** Use Financial Connections to instantly collect tokenized account and routing numbers for payouts to connected accounts, reducing failure rates and improving onboarding. (See: `/financial-connections/connect-payouts`)
*   **Relink Financial Connections Accounts Used for Payments or Payouts:** Reactivate inactive accounts to restore data access, refresh tokenized account numbers, and update data permissions for payments or payouts. (See: `/financial-connections/relink/api/payments-or-payouts`)

## Related Concepts

*   **Balances and Settlement Time:** Understand different balance types, settlement timing, and best practices for balance management. (See: `/payments/balances`)
*   **Stripe Treasury:** Securely manage money with a financial account, including receiving, storing, and sending stablecoins globally. (See: `/treasury`)
*   **Instant Currency Conversion:** Instantly convert between currencies on Stripe if you have eligible funds in your payments balance or financial account. (See: `/instant-currency-conversion`)
*   **Pay with Stripe Balance:** As a Connect platform, create a payment method linked to a connected account’s available Stripe balance to collect subscription payments. (See: `/payments/pay-with-balance`)
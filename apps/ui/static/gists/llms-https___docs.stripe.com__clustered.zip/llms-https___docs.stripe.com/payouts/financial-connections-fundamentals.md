This documentation section covers Stripe's **Payouts** functionality, detailing how businesses can receive funds from Stripe and how platforms can manage payouts to their connected accounts. It encompasses various aspects of payout management, including scheduling, instant payouts, cross-border and stablecoin payouts, and reconciliation.

## Payouts

Stripe provides a comprehensive suite of tools for managing the flow of funds to your bank accounts and to your connected accounts. This includes options for receiving payouts, initiating payouts to third parties, and configuring payout schedules and methods.

### Receiving Payouts

*   **Receive Payouts**: Understand how funds are transferred from Stripe to your bank account, including typical timelines and how to manage your bank account details. (Page 47)
*   **Customized Start of Day**: Set a custom start time for your day to align payout reconciliation with your local timezone. (Page 46)
*   **Minimum Balances for Automatic Payouts**: Configure a minimum balance to retain in your Stripe account to cover potential refunds, disputes, and fees, ensuring better cash flow management. (Page 51)
*   **Next-Day Settlement**: Access your funds from domestic transactions (excluding ACH direct debits) on the next business day. (Page 53)
*   **Multi-currency Settlement**: Accept, settle, and receive payouts in multiple currencies without incurring foreign exchange fees by configuring additional currencies and bank accounts. (Page 52)
*   **Instant Payouts**: Get immediate access to your Stripe balance, with funds typically settling within 30 minutes. This is available for eligible users in various countries and requires specific bank institution support. (Page 50)
*   **Institution Support for Instant Payouts**: Check which financial institutions support Instant Payouts in your region. (Page 48)
*   **Instant Payouts with Advance Funding**: Utilize pending balances for instant payouts, with Stripe managing the balance adjustments between available and pending funds. (Page 49)

### Payout Management and Reconciliation

*   **Payout Reconciliation**: Understand how to review the transactions included in a given payout, whether automatic or manual. (Page 56)
*   **Payout Trace IDs**: Track late or missing payouts by using unique identifiers provided by Stripe's banking partners. (Page 55)
*   **Payout Statement Descriptors**: Configure how Stripe payouts appear on bank statements for better recognition. (Page 54)

### Connect Payouts (Platform to Connected Accounts)

*   **Payouts to Connected Accounts**: Manage how and when payouts are made to your connected accounts. (Covered within broader Connect documentation)
*   **Manage Payout Accounts for Connected Accounts**: Configure the bank accounts and debit cards that connected accounts can use for payouts. (Covered within broader Connect documentation)
*   **Manage Payout Schedule**: Control the automatic payout schedule for your connected accounts. (Page 6)
*   **Manual Payouts**: Initiate payouts to your connected accounts manually, with specific holding periods based on country. (Page 7)
*   **Payout Reversals**: Learn how to reverse a payout sent to a connected account, with specific requirements for eligibility. (Page 8)
*   **Stablecoin Payouts**: Enable your Connect platform to make payouts in stablecoins (starting with USDC). (Page 1)
*   **Cross-border Payouts**: Pay sellers, freelancers, and service providers in their local currencies, regardless of their location. (Page 2)
*   **Legacy Add and Pay Out Guide**: A guide for adding funds to your balance and paying out to users, relevant for older Accounts v1 integrations. (Page 3)
*   **Controlling Bank and Debit Card Transfers (Legacy)**: Details on managing transfers for Custom Connect accounts using a legacy API version. (Page 5)
*   **Funds Segregation for Separate Charges and Transfers**: Allocate funds from specific charges and transfers to a holding state before disbursing them to connected accounts, preventing their use for other purposes. (Page 4)
*   **Pay with Stripe Balance**: As a Connect platform, charge subscription payments directly from your connected accounts' available Stripe balances. (Page 43)

### Global Payouts (Direct to Third Parties)

*   **Global Payouts**: Send funds directly to any third party in their local currency, with options for no-code, API-driven, or Stripe-hosted form integrations. (Page 32)
*   **Get Started with Global Payouts**: Activate and configure your account settings for sending global payouts. (Page 31)
*   **Create Recipients**: Set up recipients for Global Payouts using the Dashboard or API, specifying their country, business type, and preferred payout method. (Page 34)
*   **Stripe-hosted Recipient Creation**: Utilize Stripe-hosted forms to collect recipient information, which can be customized with your branding. (Page 38)
*   **API Recipient Creation**: Programmatically create Global Payout recipients using the Accounts API v2. (Page 30)
*   **Send Money**: Initiate payouts to recipients using the Dashboard or API, with varying speeds and costs depending on the payout method. (Page 37)
*   **Manage Payouts**: Monitor payout statuses, view reports, and reverse payouts within the Global Payouts feature. (Page 33)
*   **Reuse Payment Credentials for Global Payouts**: Collect and reuse identity and credential information to enable payment methods as payout methods for Global Payouts. (Page 9)
*   **Compare with Connect**: Understand the differences between Global Payouts and Connect payouts to choose the integration that best fits your business model. (Page 35)
*   **Pricing**: Review the fees associated with Global Payouts, including standard payout fees, cross-border fees, and FX fees. (Page 36)
*   **Test Global Payouts**: Simulate sending payouts in a sandbox environment to confirm your integration. (Page 39)

### Financial Connections Integration with Payouts

*   **Collect a Bank Account to Enhance Connect Payouts**: Use Financial Connections to instantly collect tokenized account and routing numbers for payouts to connected accounts, reducing onboarding friction and payout failures. (Page 13)
*   **Financial Connections Use Cases**: Explore how Financial Connections can be used for various purposes, including facilitating Connect payouts. (Page 25)
*   **Relink Financial Connections accounts used for payments or payouts**: Reactivate inactive accounts to restore data access, refresh tokenized account numbers, and consent to new data permissions for payments or payouts. (Page 21)

### Related Financial Services

*   **Manage Money with Stripe Treasury**: Securely store funds, open local accounts, convert currencies, send money, and manage expenses with Stripe Treasury. (Page 27)
*   **Use Stablecoins in Your Financial Account**: Receive, store, and send stablecoins globally using your financial account with Stripe Treasury. (Page 29)
*   **Instant Currency Conversion**: Instantly convert between currencies on Stripe using eligible funds in your payments balance or financial account. (Page 28)
*   **FX Quotes API**: Get current exchange rates, extended rate quotes, and FX fee information to help localize prices and manage currency conversions. (Page 10)
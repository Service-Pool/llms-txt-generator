# Payouts

Stripe provides flexible options for managing payouts, allowing you to send funds to your connected accounts or directly to third parties. This section covers various aspects of payouts, including scheduling, types, and reconciliation.

## Key Concepts

*   **Payouts:** The process of transferring funds from your Stripe balance to an external bank account or debit card.
*   **Connect Payouts:** Payouts made to connected accounts within the Stripe Connect ecosystem.
*   **Global Payouts:** A service for sending funds directly to third parties in their local currency, decoupled from Stripe Connect.
*   **Payout Schedule:** The frequency at which automatic payouts are made to your bank account (e.g., daily, weekly, monthly).
*   **Instant Payouts:** A feature that allows eligible users to access their Stripe balance immediately after a successful charge.
*   **Multi-currency Settlement:** The ability to accept, settle, and pay out funds in multiple currencies without incurring foreign exchange fees.
*   **Payout Reconciliation:** The process of matching and verifying payouts with the corresponding transactions.

## Payout Management

### Scheduling and Automation

*   **Manage Payout Schedule:** Configure the automatic payout schedule for your connected accounts. You can set intervals and specific days for payouts. (Page 6)
*   **Manual Payouts:** Initiate payouts to your connected accounts manually when needed. Funds are held until you initiate the payout. (Page 7)
*   **Minimum Balances for Automatic Payouts:** Set a minimum balance to retain in your Stripe account to cover potential refunds, disputes, and fees, ensuring better cash flow management. (Page 51)
*   **Customized Start of Day:** Define a custom start time for your day to align payout reconciliation with your local timezone. (Page 46)

### Payout Types and Features

*   **Cross-border Payouts:** Pay sellers, freelancers, and service providers in their local currencies, regardless of their location. This can be done through Connect payouts or Global Payouts. (Page 2)
*   **Stablecoin Payouts:** For Connect platforms, enable payouts in stablecoins, starting with USDC. Stripe handles the conversion and payout process. (Page 1)
*   **Instant Payouts:** Access your Stripe balance immediately after a successful charge. Funds typically settle within 30 minutes. (Page 50)
    *   **Institution Support for Instant Payouts:** Check if your financial institution supports Instant Payouts. (Page 48)
    *   **Instant Payouts with Advance Funding:** Utilize pending balances for Instant Payouts with explicit actions for accurate bookkeeping. (Page 49)
*   **Multi-currency Settlement:** Accept, settle, and pay out funds in multiple currencies without foreign exchange fees. This requires configuring settlement currencies and attaching corresponding bank accounts. (Page 52)
*   **Next-day Settlement:** Access funds from domestic transactions (excluding ACH direct debits) on the next business day. (Page 53)

### Controlling Payouts

*   **Controlling Bank and Debit Card Transfers:** For Custom Connect accounts, platforms can control destination bank accounts, payout frequency, and perform manual or instant transfers. (Page 5)
*   **Payout Reversals:** Reverse a payout sent to a connected account if your platform is responsible for risk and negative balances. This is possible for payouts to US and Canadian bank accounts that are not debit or Instant Payouts. (Page 8)
*   **Payout Statement Descriptors:** Configure how Stripe payouts appear on connected accounts' bank statements for better clarity. (Page 54)
*   **Payout Trace IDs:** Track late or missing payouts using a unique identifier provided by banking partners. (Page 55)

## Global Payouts

Global Payouts offers a streamlined way to send money directly to third parties without requiring them to have a Stripe account.

*   **Overview:** Send payouts to customers, affiliates, contractors, or other third parties in their local currency to over 50 countries. (Page 32)
*   **Get Started:** Activate and configure your account, payout, and communication settings to begin sending Global Payouts. (Page 31)
*   **Create Recipients:** Onboard recipients for Global Payouts using the Stripe API or Stripe-hosted forms. This involves collecting country, business type, email, and payout method details. (Page 30, Page 34, Page 38)
*   **Send Money:** Initiate payouts through the Dashboard or API, with varying speeds and costs depending on the payout method. (Page 37)
*   **Manage Payouts:** Monitor payout statuses, receive events for status changes, and view reporting. (Page 33)
*   **Pricing:** Understand the fees associated with Global Payouts, including funding, payout, cross-border, and FX fees. (Page 36)
*   **Compare with Connect:** Differentiate between Global Payouts (payouts-only, decoupled from payments) and Connect payouts (bundled payments and payouts, payee tools). (Page 35)
*   **Testing:** Simulate sending payouts in a test environment using sandboxes and test API keys. (Page 39)
*   **Reuse Payment Credentials:** Collect and reuse identity and credential information to enable payment methods as payout methods for Global Payouts. (Page 9)

## Financial Connections and Payouts

Financial Connections can enhance your payout processes by securely collecting and verifying bank account details.

*   **Collect a bank account to enhance Connect payouts:** Use Financial Connections to instantly collect tokenized account and routing numbers for payouts to connected accounts, reducing onboarding friction and payout failures. (Page 13)
*   **Connect Payouts Use Case:** Financial Connections allows you to collect a bank account to use for Connect payouts, leveraging account data like ownership details. (Page 25)

## Other Related Topics

*   **Funds Segregation:** Allocate funds from separate charges and transfers to a holding state before transferring them to connected accounts. This is useful when your platform is responsible for negative balances. (Page 4)
*   **Transfer Payout Split:** Understand the historical change in Stripe's API where `/v1/transfers` was split into `/v1/transfers` (for moving money between Stripe accounts) and `/v1/payouts` (for moving money from Stripe to bank accounts). (Page 57)
*   **Payout Reconciliation:** Review transactions included in a given payout, either through the Dashboard, API, or reconciliation reports. (Page 56)
*   **FX Quotes API:** Obtain real-time exchange rates and FX fee information to accurately localize prices and estimate settlement amounts. (Page 10)
*   **Settle in additional currencies:** Learn how settling funds in currencies other than your primary currency affects processing fees and how to enable settlement in additional currencies. (Page 11)
*   **Pay with Stripe balance:** As a Connect platform, charge subscription payments directly from your connected accounts' available Stripe balances. (Page 43)
*   **Balances and settlement time:** Understand different balance types (Payments balance, Refunds and disputes balance, Reserve balance) and how settlement timing affects fund availability. (Page 42)
*   **Network sponsor reporting:** Access CSV files over SFTP for daily settlement, clearing transaction details, dispute events, and transaction summaries. (Page 40)
*   **Treasury:** Securely manage money with Stripe Treasury, including storing funds, opening local accounts, converting currencies, and sending money. (Page 27)
    *   **Stablecoins in Treasury:** Receive, store, and send stablecoins using your financial account with Stripe Treasury. (Page 29)
*   **Instant Currency Conversion:** Instantly convert between currencies on Stripe using eligible funds in your payments balance or financial account. (Page 28)
*   **Pay out money with Accounts v1:** A deprecated guide for adding funds to your Stripe balance and paying out to sellers or service providers. (Page 3)
*   **Pay out to people (No-code):** A guide for adding funds to your Stripe balance and transferring them to users' bank accounts without processing payments through Stripe. (Page 41)
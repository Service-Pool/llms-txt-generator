## Managing Payout Schedules

This section details how to manage the automatic payout schedule for your connected accounts, ensuring funds are disbursed according to your platform's needs.

### Configuring Payout Schedules

Stripe allows you to define when and how often automatic payouts are made to your connected accounts. This is managed through the `payouts.schedule` hash within the Balance Settings API.

**Key Schedule Parameters:**

*   **`interval`**: Determines the frequency of payouts. Options include `daily`, `weekly`, or `manual`.
    *   If set to `manual`, funds are held in the account balance until explicitly paid out. (See [Using manual payouts](/connect/manual-payouts) for more details).
*   **`weekly_payout_days`**: For weekly schedules, specify an array of days (e.g., `["monday", "wednesday"]`) on which payouts should occur.
*   **`monthly_payout_days`**: For monthly schedules, specify an array of days of the month on which payouts should occur.

**Example Configuration (JSON):**

```json
{
  "object": "balance_settings",
  "payments": {
    "payouts": {
      "schedule": {
        "interval": "weekly",
        "weekly_payout_days": ["monday", "wednesday"],
        "monthly_payout_days": null
      },
      "minimum_balance_by_currency": {
        "usd": 1500,
        "cad": 8000
      },
      "statement_descriptor": null,
      "status": "enabled"
    }
  }
}
```

### Settlement Timing and Delay

The `settlement_timing.delay_days` property indicates how long it takes for funds from `on_behalf_of` charges or direct charges on a connected account to become available for payout.

*   You can edit this property if your platform assumes responsibility for fraud and dispute liability.
*   This delay can be overridden using `delay_days_override`, which accepts a value up to 31 days.
*   Setting `delay_days_override` to an empty string will revert to the default settlement delay for the account.

### Minimum Balance for Payouts

The `minimum_balance_by_currency` parameter allows you to set a minimum balance threshold for each currency. Automatic payouts will only disburse funds that exceed this specified minimum, helping to ensure sufficient funds are available for potential refunds, disputes, or fees.
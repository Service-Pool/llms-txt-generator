## Payouts

This section covers how to manage and control the flow of funds from your Stripe account to your connected accounts or external bank accounts. It details various payout methods, schedules, and reconciliation processes.

### Core Payout Concepts

*   **Payouts:** The process of transferring funds from your Stripe account to your external bank account or debit card. This is distinct from transfers between Stripe accounts (e.g., platform to connected account). (See: `/transfer-payout-split`)
*   **Connect Payouts:** Specifically refers to payouts made to connected accounts within the Stripe Connect ecosystem. (See: `/connect/payouts-to-connected-accounts`, `/connect/connect-payouts`)
*   **Balances:** Your Stripe account can have multiple balances (e.g., payments balance, financial account balance) holding funds for different products and currencies. Understanding these balances is crucial for effective fund management. (See: `/payments/balances`, `/treasury`)

### Payout Management

*   **Payout Schedule:** Configure when automatic payouts occur and manage manual payout triggers. (See: `/connect/manage-payout-schedule`, `/connect/manual-payouts`)
*   **Minimum Balances:** Set a minimum balance to retain in your Stripe account to cover potential refunds, disputes, and fees, ensuring smoother cash flow. (See: `/payouts/minimum-balances-for-automatic-payouts`)
*   **Statement Descriptors:** Customize how Stripe payouts appear on connected accounts' bank statements for better identification. (See: `/payouts/statement-descriptors`)
*   **Payout Trace IDs:** Track late or missing payouts by using unique identifiers provided by banking partners. (See: `/payouts/trace-id`)
*   **Payout Reconciliation:** Understand which transactions are included in a given payout for accurate financial tracking. (See: `/payouts/reconciliation`, `/payments/paypal/payout-reconciliation`)

### Advanced Payout Features

*   **Instant Payouts:** Provide users with immediate access to their Stripe balance, typically within 30 minutes, for a fee. (See: `/payouts/instant-payouts`, `/payouts/instant-payouts-with-advance-funding`, `/payouts/instant-payouts-banks`)
*   **Next-Day Settlement:** Access funds from domestic transactions (excluding ACH direct debits) in your Stripe balance on the next business day. (See: `/payouts/next-day-settlement`)
*   **Multi-currency Settlement:** Accept, settle, and pay out funds in multiple currencies without incurring foreign exchange fees by configuring additional currencies and bank accounts. (See: `/payouts/multicurrency-settlement`, `/payments/currencies/settlement-payouts`)
*   **Stablecoin Payouts:** For Connect platforms, enable payouts in stablecoins (starting with USDC) to connected accounts. (See: `/connect/stablecoin-payouts`, `/treasury/stablecoins`)
*   **Cross-Border Payouts:** Pay sellers, freelancers, or service providers in their local currencies, regardless of their location. (See: `/connect/cross-border-payouts`)
*   **Global Payouts:** Send funds directly to any third party in their local currency, offering a payouts-only solution decoupled from payments. (See: `/global-payouts`, `/global-payouts/get-started`, `/global-payouts/send-money`, `/global-payouts/manage-payouts`, `/global-payouts/pricing`, `/global-payouts/compare-with-connect`, `/global-payouts/stripe-hosted-recipient-creation`, `/global-payouts/recipient-creation-options`, `/global-payouts/testing`)

### Payout Reversals and Errors

*   **Payout Reversals:** Reverse a payout sent to a connected account if the platform is responsible for risk and negative balances. (See: `/connect/payout-reversals`)
*   **Customized Start of Day:** Set a custom start time for your day to align payout reconciliation with your local timezone. (See: `/payouts/customized-start-of-day`)

### Financial Connections for Payouts

*   **Financial Connections:** Enhance Connect payouts by collecting and verifying connected account bank details securely, reducing errors and saving development time. (See: `/financial-connections/connect-payouts`, `/financial-connections/use-cases`, `/financial-connections/fundamentals`, `/financial-connections/testing`, `/financial-connections/webhooks`, `/financial-connections/relink/api/payments-or-payouts`)
*   **Credential Reuse:** Reuse payment credentials collected from a customer to enable them as payout methods for Global Payouts. (See: `/global-payouts/credential-reuse`)

### Legacy and Deprecated Features

*   **Legacy Connect Payouts:** Information regarding older versions of Connect payouts. (See: `/connect/legacy/add-and-pay-out-guide`, `/connect/legacy-transfers`)
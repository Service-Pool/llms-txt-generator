This documentation section covers Stripe's **Payouts** functionality, detailing how businesses can manage and receive funds. It encompasses various aspects of payouts, from initial setup and scheduling to advanced features like instant payouts, multi-currency settlement, and stablecoin payouts. The content also touches upon related financial management tools like Stripe Treasury and Financial Connections, which can enhance payout processes and provide deeper financial insights.

## Key Topics Covered:

*   **Connect Payouts:** Managing payouts for connected accounts within the Stripe Connect ecosystem, including cross-border and stablecoin payouts.
*   **Payout Management:** Configuring payout schedules, performing manual payouts, handling payout reversals, and understanding statement descriptors.
*   **Global Payouts:** Sending funds directly to third-party bank accounts in various countries, with options for API-driven or no-code integrations.
*   **Financial Connections:** Leveraging user-permissioned financial data for enhanced payouts, including collecting bank account details, accessing balances, and managing account disconnections and relinking.
*   **Stripe Treasury:** Securely managing money with a financial account, including stablecoin support and instant currency conversion.
*   **Payout Reconciliation and Traceability:** Understanding how to reconcile payouts with transactions and track late or missing payouts using Trace IDs.
*   **Advanced Payout Features:** Exploring options like Instant Payouts, next-day settlement, customized start-of-day for payouts, and minimum balances for automatic payouts.

## Related Concepts:

*   **Balances:** Understanding different balance types (payments, refunds and disputes, reserve) and their implications for fund management.
*   **Currencies:** Managing payments and payouts in multiple currencies, including localization and FX quotes.
*   **Financial Account:** A dedicated financial account within Stripe Treasury for managing funds, distinct from the payments balance.
*   **Stablecoins:** Utilizing stablecoins (like USDC) for payouts, offering an alternative to traditional fiat currency.

This section is relevant for businesses looking to manage outgoing payments, whether to their own bank accounts, to connected accounts on their platform, or to third parties globally. It also provides context for how financial data services can integrate with and improve payout operations.
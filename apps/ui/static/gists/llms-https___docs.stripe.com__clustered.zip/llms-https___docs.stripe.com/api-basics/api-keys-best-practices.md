## API Keys

API keys are essential for authenticating your requests to the Stripe API. This section covers how to manage and use these keys securely and effectively.

### Managing API Keys

*   **Best Practices for Managing Secret API Keys**: This guide provides crucial advice on protecting your secret API keys, emphasizing that they should never be hardcoded in source code and should be managed using secure methods like secrets vaults or environment variables. It also outlines how to audit your code for exposed keys.
*   **API Keys**: This overview explains the different types of API keys Stripe offers (publishable, restricted, and secret) and their respective use cases. It guides you on how to create, reveal, delete, and rotate keys using the Developers Dashboard, and how to differentiate between test and live mode keys.
*   **Restricted API keys**: This document details how to use Restricted API Keys (RAKs) to grant specific permissions to your API keys, enhancing security by limiting the potential damage if a key is compromised. It explains how to configure resource access and permissions (Read, Write, None) for RAKs.

### Using API Keys

*   **Server-side integration**: This guide covers essential aspects of setting up a backend integration with Stripe, including authentication using API keys (secret and restricted keys are needed for server-side operations) and other best practices.
*   **Send your first Stripe API request**: This introductory guide walks you through making your initial API request, emphasizing the necessity of an API secret key for authentication and explaining the difference between test and live mode keys. It demonstrates creating a customer using the Stripe Shell.
## API v2 Overview

This section provides an overview of Stripe's API v2, highlighting its key differences from API v1 and detailing its features and functionalities.

### Key Differences from API v1

API v2 introduces a more consistent JSON-based request and response format, improving developer experience. It also enhances the idempotency behavior for retries, ensuring safer and more predictable API interactions.

### Core Features and Functionalities

*   **Request/Response Format:** API v2 exclusively uses JSON for both requests and responses, simplifying data handling.
*   **Idempotency:** The `Idempotency-Key` header is used to ensure that repeated requests have no extraneous side effects, making it safer to retry failed operations.
*   **Event Handling:** Events emitted from API v2 endpoints are "thin," meaning they contain minimal, unversioned payloads, which can streamline integration upgrades.

### Related Topics

*   **API v2 Overview:** A detailed comparison of API v1 and v2, including design patterns and differences.
*   **Include-dependent response values v2:** Learn how to retrieve specific, non-default response values in API v2.
*   **Rate limits:** Understand API rate limiting and how to work with it to ensure stable integration.
*   **Authentication:** Learn about API keys and how to authenticate your requests.
*   **Specify request context:** Understand how to use headers like `Stripe-Context` to perform API operations on related accounts.
*   **Domains and IP addresses:** Ensure your integration can reach Stripe's domains and IP addresses.
*   **Make requests:** General guidance on making API requests.
*   **Expand responses:** Learn how to retrieve nested objects in a single API call.
*   **Pagination:** Understand how to paginate through large lists of resources.
*   **Search objects:** Retrieve objects from your Stripe data using search queries.
*   **Testing and data:** Resources for testing your integration.
*   **Metadata:** Learn how to attach custom key-value pairs to objects for your own reference.
*   **Test your application:** Strategies for testing your Stripe integration.
*   **Error handling:** Interpret and handle errors returned by the Stripe API.
*   **Error codes:** A reference of common Stripe error codes.
*   **Testing:** General information about testing with Stripe.
*   **Stripe CLI:** Tools for interacting with Stripe from your command line.
*   **Sample projects:** Examples of how to integrate with Stripe.
## Domains and IP Addresses

This section details the fully qualified domain names (FQDNs) and IP addresses that your integration must be able to reach to communicate with Stripe securely and reliably. It covers standard Stripe domains, specific domains for Stripe Terminal, and provides guidance on allowlisting.

### Key Information:

*   **Stripe Domains:** A comprehensive list of FQDNs used by Stripe for general API interactions.
*   **Stripe Terminal Domains:** Specific FQDNs required if you are using Stripe Terminal.
*   **IP Address Verification:** Instructions on how to verify communication with `api.stripe.com` through listed IP addresses.
*   **Webhook IP Addresses:** Guidance on ensuring webhook events originate from Stripe's webhook IP addresses.
*   **Allowlisting:** Recommendations on adding these domains and IP addresses to your allowlist for seamless integration.
## API v2 and Related Features

This documentation section covers the Stripe API v2, its differences from v1, and related functionalities that enhance API interactions, testing, and data management.

### API v2 Overview

*   **API v2 Overview (`/api-v2-overview`)**: This page details the Stripe API v2 namespace, highlighting its key differences from v1, such as the use of JSON for both requests and responses, and its approach to idempotency and event handling.

### Core API Concepts and Functionality

*   **Stripe APIs (`/apis`)**: Provides a general overview of Stripe's unified REST APIs, including a comparison between v1 and v2 namespaces, and introduces key concepts like rate limits, authentication, request shaping, and error handling.
*   **Include-dependent response values (`/api-includable-response-values`)**: Explains how to use the `include` parameter in API v2 requests to retrieve specific properties that are otherwise omitted from response payloads by default, helping to reduce payload size.
*   **Expanding responses (`/expand`)**: Describes how to use the `expand` parameter to include nested or related objects in API responses, reducing the number of API calls needed to retrieve comprehensive data.
*   **Use cases for expanding responses (`/expand/use-cases`)**: Provides practical examples of how to leverage the `expand` parameter for common scenarios, such as retrieving payment fees within a payment intent response.
*   **Pagination (`/pagination`)**: Details how Stripe's list and search endpoints handle large datasets by returning results in pages, and how to use parameters like `limit` to control the number of results per page.
*   **Search (`/search`)**: Introduces the search API methods for retrieving Stripe objects more flexibly and efficiently than traditional pagination, with information on query language and limitations.
*   **Localization (`/localization`)**: Explains how to provide localized content for Stripe APIs that support it, enabling the display of information in users' preferred languages.

### Authentication and Security

*   **API keys (`/keys`)**: Covers the use of API keys for authenticating requests, differentiating between publishable, secret, and restricted keys, and directing users to the Developers Dashboard for key management.
*   **Best practices for managing secret API keys (`/keys-best-practices`)**: Offers crucial advice on securely handling and storing secret API keys to prevent exposure and compromise.
*   **Restricted API keys (`/keys/restricted-api-keys`)**: Explains how to use Restricted API Keys (RAKs) to grant specific permissions to API keys, thereby limiting potential damage if a key is exposed.
*   **Integration security guide (`/security/guide`)**: Provides guidance on ensuring PCI compliance and securing customer-server communications, emphasizing the shared responsibility between Stripe and businesses.
*   **TLS Certificates (`/tls-certificates`)**: Details how Stripe uses TLS to ensure secure communication over HTTPS and advises against certificate pinning.
*   **Python PGP key (`/security/python-client-pgp-key`)**: Provides the PGP key for the Python client library, useful for verifying the integrity of downloaded packages.

### Request Context and Domains

*   **Stripe-Context header (`/context`)**: Explains how to use the `Stripe-Context` header to perform API requests in the context of related accounts, expanding on the functionality of the `Stripe-Account` header.
*   **Domains and IP addresses (`/ips`)**: Lists the fully qualified domain names that your integration must be able to reach and provides guidance on allowlisting them for secure communication.

### Testing and Error Handling

*   **Automated testing (`/automated-testing`)**: Offers strategies for simulating API responses and error conditions to test your application's resilience and error-handling capabilities.
*   **Test your application (`/test-your-application`)**: This page is a placeholder, likely linking to more specific testing guides.
*   **Error handling (`/error-handling`)**: Provides an overview of Stripe's error types and how to parse error data returned in API responses.
*   **Advanced error handling (`/error-low-level`)**: Delves into low-level details of HTTP responses that represent errors, categorizing them into content, network, and server errors.
*   **Error codes (`/error-codes`)**: Lists and describes common Stripe API error codes, including card decline codes, to help with resolution.

### Webhooks and Event Handling

*   **Integrate with events (`/event-destinations`)**: Introduces event destinations as a way to send Stripe events to webhook endpoints, Amazon EventBridge, and Azure Event Grid.
*   **Send events to Amazon EventBridge (`/event-destinations/eventbridge`)**: Guides users on how to configure Stripe events to be sent to Amazon EventBridge.
*   **Send events to Azure Event Grid (`/event-destinations/eventgrid`)**: Explains how to route Stripe events to Azure Event Grid for processing within Azure infrastructure.
*   **Receive Stripe events in your webhook endpoint (`/webhooks`)**: Covers the fundamentals of setting up a webhook endpoint to receive and process events from Stripe.
*   **Handle payment events with webhooks (`/webhooks/handling-payment-events`)**: Focuses on using webhooks to respond to offline payment events.
*   **Process incoming webhooks with event notification handlers (`/webhooks/event-notification-handlers`)**: Details how to use specialized classes in Stripe SDKs to parse, validate, and route incoming webhooks.
*   **Handle webhook event generation failures (`/webhooks/handle-irrecoverable-events`)**: Explains how to handle rare cases where Stripe might fail to generate an Event object.
*   **Migrate from snapshot events to thin events (`/webhooks/migrate-snapshot-to-thin-events`)**: Provides a guide for migrating from snapshot events to lightweight thin events without disrupting production.
*   **Process undelivered webhook events (`/webhooks/process-undelivered-events`)**: Offers methods to manually process webhook events that were not successfully delivered.
*   **Resolve webhook signature verification errors (`/webhooks/signature`)**: Helps users fix common errors related to webhook signature verification.
*   **Handle webhook versioning (`/webhooks/versioning`)**: Guides users on how to safely upgrade the API version of their webhook endpoints.
*   **Webhooks for Climate Orders API (`/climate/orders/webhooks`)**: Specific webhook events related to Stripe Climate orders.

### Development Tools and Utilities

*   **Developers Dashboard (`/development/dashboard`)**: Introduces the Developers Dashboard (now largely replaced by Workbench) for viewing API request logs, events, and managing webhook endpoints.
*   **View events and event object payloads (`/development/dashboard/events`)**: Explains how to view and filter events triggered by your Stripe account.
*   **View API request logs (`/development/dashboard/request-logs`)**: Details how to filter and view API request logs within the Developers Dashboard.
*   **Add a webhook endpoint (`/development/dashboard/webhooks`)**: Guides users on how to create new webhook endpoints using the Developers Dashboard.
*   **Stripe CLI (`/stripe-cli`)**: A command-line tool for interacting with Stripe, including triggering webhook events.
*   **Trigger webhook events with the Stripe CLI (`/stripe-cli/triggers`)**: Explains how to use the Stripe CLI to simulate webhook events for testing.
*   **Workbench (`/workbench/overview`)**: Describes Workbench as a centralized tool for debugging, managing, and growing Stripe integrations.
*   **Manage event destinations (`/workbench/event-destinations`)**: Details how to set up event destinations using Workbench.
*   **Health alerts and insights (`/workbench/health`)**: Explains how to monitor integration health using alerts and insights within Workbench.
*   **Shell and API Explorer (`/workbench/shell`)**: Introduces the command-line interface and API Explorer within Workbench for managing integrations and exploring APIs.

### API Versioning and Upgrades

*   **API upgrades (`/upgrades`)**: Provides information on tracking changes and upgrades to the Stripe API, including backward-compatible and non-backward-compatible changes.
*   **Set a Stripe API version (`/sdks/set-version`)**: Guides users on how to target a specific API version, overriding the default or SDK-provided version.
*   **Stripe versioning and support policy (`/sdks/versioning`)**: Outlines Stripe's API and SDK versioning policies, including release cycles and support.

### Data Management and Metadata

*   **Metadata (`/metadata`)**: Explains how to use metadata to store additional key-value pair information on Stripe objects for your own reference.
*   **Metadata use cases (`/metadata/use-cases`)**: Provides examples of how to effectively use metadata for various scenarios, such as storing external system IDs.

### Batch Operations

*   **Batch jobs (`/batch-api`)**: Introduces the Batch Jobs API for performing bulk operations asynchronously.
*   **Running a batch job (`/batch-api/create`)**: Details the steps involved in creating, uploading, monitoring, and downloading results for a batch job.
*   **Best practices (`/batch-api/best-practices`)**: Offers recommendations for optimizing batch job performance and handling errors.

### Privacy and Data Redaction

*   **Handling customer deletion requests (`/privacy/deletion-requests`)**: Describes tools for removing data from Stripe for consumer data deletion requests.
*   **Redact personal data (`/privacy/redaction`)**: Explains how to use redaction jobs to remove personal data from Stripe objects and their related data.
*   **Complete a redaction job (`/privacy/redaction/example`)**: Provides an example of how to complete a redaction job.
*   **Redaction API integration guide (`/privacy/redaction-integration`)**: A guide for integrating with the Redaction API to programmatically remove user access to personal data.

### SDKs

*   **Introduction to server-side SDKs (`/sdks/server-side`)**: Provides an overview of installing and using Stripe's server-side SDKs for various programming languages.
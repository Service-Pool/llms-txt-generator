This documentation group focuses on using Stripe's platform for building and managing financial workflows, particularly with the integration of AI agents and enhanced developer tools.

Key themes include:

*   **Agentic Workflows:** Building automated, AI-driven workflows for tasks like SaaS billing, payment processing, and financial management using Stripe's Agent toolkit and Model Context Protocol (MCP).
*   **Developer Tools & SDKs:** Comprehensive resources for developers, covering SDKs for various platforms (web, mobile, server-side), the Stripe CLI for command-line management, and tools like Stripe for VS Code and Terraform for infrastructure as code.
*   **Stripe Dashboard & Console:** Information on managing accounts, analyzing data, and performing actions through the web dashboard, mobile app, and the AI-powered Stripe Console.
*   **Extensibility & Customization:** Details on how to extend Stripe's functionality through Stripe Apps, custom actions, scripts, and custom objects, allowing for tailored business logic and integrations.
*   **Testing & Sandboxes:** Guidance on thoroughly testing integrations in isolated sandbox environments using test card numbers, simulated events, and dedicated testing tools.
*   **Partnerships & Integrations:** Information for partners looking to integrate with Stripe, including different partner tracks (Services, SaaS platforms, Apps, Payment methods) and certification programs.
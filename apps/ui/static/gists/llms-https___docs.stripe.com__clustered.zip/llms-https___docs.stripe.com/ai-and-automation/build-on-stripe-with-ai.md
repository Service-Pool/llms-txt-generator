## Building with AI on Stripe

Stripe offers a comprehensive suite of tools and resources for developers looking to integrate AI into their workflows and build intelligent payment solutions. This documentation section covers how to leverage AI agents, the Model Context Protocol (MCP), and AI-assisted development platforms to enhance your Stripe integrations.

### AI Agents and Workflows

*   **Build agentic AI SaaS Billing workflows:** Automate recurring billing workflows using the Stripe API and AI-driven agents. This guide covers provisioning customers and subscriptions, responding to lifecycle events via webhooks, and invoking billing actions from AI agents.
*   **Add Stripe to your agentic workflows:** Integrate Stripe into your agent business and enhance agent functionality by enabling access to financial services. This involves using the Stripe agent toolkit, which supports various SDKs and LLM providers, to create and manage Stripe objects dynamically.
*   **Model Context Protocol (MCP):** The MCP server allows AI agents to interact with the Stripe API and search Stripe's knowledge base. It exposes various tools for retrieving account information, managing resources like customers and invoices, and searching Stripe documentation.

### AI-Assisted Development

*   **Build on Stripe with AI:** Utilize AI agents to assist in building Stripe integrations. Stripe provides tools and best practices for using LLMs during development, including the agent toolkit and MCP server.
*   **Stripe for Visual Studio Code:** This extension integrates Stripe into your VS Code editor, offering an AI Assistant that leverages Stripe documentation, API references, and code snippets to help you build integrations. It also provides features like generating sample code, viewing API logs, and forwarding webhook events.

### Related Concepts and Tools

*   **Stripe Dashboard:** The primary user interface for managing your Stripe account. Features like Stripe Console (a conversational interface for analyzing data) and the ability to search for resources are powered by AI.
*   **Stripe Apps and Extensions:** Extend Stripe's functionality with custom logic. This includes building custom actions for workflows and defining custom data models and business logic with custom objects.
*   **Stripe CLI:** A command-line interface for managing Stripe resources in a sandbox environment. It can be used in conjunction with AI tools for development and testing.
*   **Sandboxes:** Isolated test environments that allow you to simulate Stripe functionality without affecting your live integration. This is crucial for testing AI-driven workflows and integrations.
*   **Workflows:** Automate multi-step processes with a visual builder in the Dashboard. Workflows can be triggered by Stripe events or programmatically, and can be extended with custom actions, including those powered by AI.
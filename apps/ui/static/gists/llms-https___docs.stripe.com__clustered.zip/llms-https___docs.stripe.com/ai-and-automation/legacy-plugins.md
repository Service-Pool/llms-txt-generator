## Legacy Plugins

The concept of "plugins" in Stripe integrations is now considered **deprecated**. This means you can no longer request secret API keys from users for plugin integrations.

**Stripe Apps** is the recommended and modern approach for authenticating users and extending Stripe's functionality. This new method fully supports both restricted API keys and OAuth 2.0.

### What was a Plugin?

Plugins were any integration between a third-party solution and Stripe that required a user to authenticate using their secret API keys. Typically, plugins interacted with Stripe APIs by making direct API calls or responding to Stripe API events on behalf of the user. They often ran code to enable Stripe to interact with other software, such as processing payments on platforms like WordPress.

### Best Practices for Legacy Plugins (If Still in Use)

If you are still maintaining a legacy plugin integration, it's crucial to follow these best practices to ensure your users can continue to process on Stripe's platform without disruption, even as Stripe's API evolves:

*   **Register Your Plugin:** Create a Stripe account or use an existing one to register your plugin.
*   **Identify Your Plugin:** Use `setAppInfo` and `registerAppInfo` so Stripe can alert you to any potential issues they identify with your integration.
*   **Set Stripe's API Version:** Explicitly set Stripe's API version within your plugin to avoid unexpected behavior due to API upgrades or changes.

For any questions regarding legacy plugins, please contact Stripe directly at plugins@stripe.com.
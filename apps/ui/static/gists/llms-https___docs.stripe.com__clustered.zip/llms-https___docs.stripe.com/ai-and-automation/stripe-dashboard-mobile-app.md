## Stripe Dashboard Mobile App

This section details how to use the Stripe Dashboard mobile application for iOS and Android devices.

### Key Features and Capabilities

The mobile app provides access to essential Stripe Dashboard functionalities on the go, including:

*   **Business Monitoring:** View dashboard charts, payment and customer lists, and receive push notifications for new payments, alerts, and daily summaries.
*   **Payment and Customer Management:** Track and manage payments and customers, initiate payouts, and accept in-person payments (e.g., Tap to Pay).
*   **Payment Creation:** Create payment links, basic invoices, and subscriptions directly from the app.
*   **Manual Card Entry:** Enter card details manually for processing payments.
*   **Payment Actions:** Issue refunds and activate, deactivate, or share payment-related items.

### Device Compatibility and Language Support

The app is available for both iOS and Android devices and supports 14 languages, defaulting to the device's system language. For users managing a Connect business, the app is also accessible to connected accounts with full Stripe Dashboard access.

### Getting Started

To use the mobile app, users need to create a Stripe account or log into an existing one. For iOS users, account creation is also possible directly within the app. Two-factor authentication and phone number verification are required and can be enabled in the Dashboard.
## Stripe Dashboard: Web Dashboard

This documentation section focuses on the Stripe Web Dashboard, the primary user interface for managing and configuring your Stripe account. It covers how to navigate the dashboard, access key information, and customize your experience.

### Key Features and Functionality

*   **Account Management:** The Web Dashboard is where you manage and configure your Stripe account settings.
*   **Navigation:** It provides a primary navigation sidebar for accessing account resources such as balances, transactions, customers, and products.
*   **Home Page:** The Home page offers an overview of your business performance through analytics and charts, and surfaces important notifications.
*   **Customization:** Users can customize the Home page by adding or removing widgets.
*   **Balances:** This section allows you to view your Stripe balance, including top-ups, payouts, and transaction history.
*   **Transactions:** Here you can view all customer payments, including collected fees and transfers, with filtering and export options.
*   **Keyboard Shortcuts:** A comprehensive list of keyboard shortcuts for common actions is available by pressing the question mark key.
*   **Browser Support:** The Dashboard officially supports the latest 20 major versions of Chrome, Firefox, and Edge, and the last 4 major versions of Safari.

### Related Topics

*   **Stripe Console:** For analyzing and acting on Stripe data through a conversational interface.
*   **Stripe Dashboard Mobile App:** For accessing Stripe Dashboard features on iOS and Android devices.
*   **Perform searches in the Dashboard:** For efficiently finding specific resources within the Dashboard.
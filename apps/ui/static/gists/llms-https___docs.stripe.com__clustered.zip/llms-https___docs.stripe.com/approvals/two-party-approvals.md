# Two-Party Approvals

Approvals allow administrators to require a second person to review sensitive actions before they take effect. Rules apply to human users acting through the Dashboard, CLI, or MCP, and to autonomous agents using agent-tagged API keys through the API, CLI, or MCP.

When an action triggers an approval rule, it is paused and an approval request is created. A designated reviewer then approves or denies the request. Approved actions are completed automatically, while denied actions are discarded with no changes made.

## Supported Actions

You can require approval for the following actions:

*   Bank account is added or updated
*   Bank account is deleted
*   Payment intent is created
*   Invoice is created
*   Refund is created
*   Subscription is created
*   Subscription is cancelled

## Creating an Approval Rule

1.  Navigate to **Settings > Approvals**.
2.  Click **Create rule**, then select the action that triggers the approval.
3.  Optionally, click **Add condition** to add one or more trigger conditions. For example, you can require approval for a refund only if the amount exceeds a threshold. If you add multiple conditions, you can choose whether to combine them with `and` or `or`.
4.  Set the control:
    *   **Require approval**: The action is paused until a reviewer approves it.
    *   **Block**: The action is rejected outright.
5.  Choose who can review requests: specific team members, or anyone with the Administrator role.
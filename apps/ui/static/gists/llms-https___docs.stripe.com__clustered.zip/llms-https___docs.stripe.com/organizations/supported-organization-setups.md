## Supported Organization Setups

Organizations provide a flexible way to manage multiple Stripe accounts under a single umbrella. Stripe supports several account structures that can be incorporated into an organization, catering to diverse business needs.

### Organizations vs. Connect Platforms

While both Organizations and Stripe Connect platforms allow for the management of multiple accounts, they serve distinct purposes:

*   **Ownership:** Connect platforms are designed for third-party integrations, where a platform extends its Stripe integration to others. Organizations, on the other hand, centralize the management of multiple accounts under common ownership for a single business entity.
*   **Operation:** A Connect platform is an active Stripe account that processes payments and has its own balances, customers, and subscriptions. An organization is a structural container; it does not conduct its own business through Stripe but rather provides a unified view and management layer for its constituent accounts.
*   **Structure:** A Connect platform can be an account within an organization. For example, a company might have multiple Connect platforms operating in different regions, all managed under a single organization.

### Multiple Standalone Accounts

A common use case for Organizations is to manage multiple independent Stripe accounts. This is particularly useful when a business operates:

*   Across different business lines.
*   In various countries or regions.
*   With distinct legal entities.
*   Through company acquisitions.

By adding these standalone accounts to an organization, you gain the ability to search and download consolidated reports across all of them, simplifying financial oversight and operational management.
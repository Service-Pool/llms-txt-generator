# Organizations

Stripe Organizations provide a powerful way to unify and manage multiple Stripe accounts under a single, consolidated view. This feature is designed for businesses operating across various entities, regions, or business lines, enabling centralized reporting, operations, and team management.

## Key Benefits of Using Organizations

*   **Centralized Management:** Manage separate business entities, subsidiaries, or business lines from a single location within the Stripe Dashboard.
*   **Consolidated Reporting:** Gauge your entire business's performance by viewing and downloading unified reports across all accounts, including transactions, disputes, invoices, connected accounts, and customers. Reports can be generated across different currencies.
*   **Streamlined Team Management:** Simplify user access and permissions for your teams from a centralized location.
*   **Enhanced Security:** Manage Single Sign-On (SSO) for all accounts within your organization from a single point.
*   **Advanced Analytics:** Perform custom SQL queries with Sigma across all accounts for deeper insights.

## Use Cases for Organizations

Organizations are particularly beneficial for businesses in the following scenarios:

*   **Global Expansion:** Create separate Stripe accounts for each country or region to leverage local acquiring and compliance, then manage them under a single organization.
*   **Separate Business Units:** Isolate operations and finances for distinct business units by using separate Stripe accounts, all managed within one organization.
*   **Franchise Groups:** Centrally manage numerous franchise locations, often represented as connected accounts, under a unified organizational structure.
*   **Company Acquisitions:** Integrate newly acquired businesses that use Stripe into your existing Stripe infrastructure by adding their accounts to your organization.

## Supported Setups

Organizations support several account structures, including:

*   **Multiple Standalone Accounts:** Manage various Stripe accounts that represent different business lines, countries of operation, legal entities, or acquisitions.
*   **Platforms and Connected Accounts:** While Organizations and Connect platforms both manage multiple accounts, they serve distinct purposes. An organization centralizes management under common ownership, whereas a Connect platform extends Stripe integration to third parties. A Connect platform can itself be an account within an organization.

## Organization Overview

An organization acts as a container structure, allowing you to view and manage the operations of its separate businesses without conducting its own business directly through Stripe. This structure facilitates centralized reporting and management across all associated accounts.
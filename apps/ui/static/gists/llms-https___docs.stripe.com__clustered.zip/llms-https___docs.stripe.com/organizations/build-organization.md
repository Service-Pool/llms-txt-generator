## Building and Managing Stripe Organizations

Stripe Organizations provide a powerful way to unify and manage multiple Stripe accounts from a single location. This is particularly beneficial for businesses operating across different regions, business units, or those undergoing acquisitions. Organizations allow for centralized reporting, streamlined team management, and consolidated access control.

### Key Concepts:

*   **Organizations:** A container structure that groups multiple Stripe accounts under common ownership for centralized management and reporting. An organization itself does not conduct business or process payments.
*   **Multiple Standalone Accounts:** Organizations can house multiple independent Stripe accounts, each representing different business lines, legal entities, or geographical operations.
*   **Connect Platforms:** Organizations can also include Stripe Connect platforms, which are themselves accounts that extend Stripe integrations to third parties. While both organizations and Connect platforms manage multiple accounts, organizations focus on internal management under common ownership, whereas Connect platforms are designed for third-party integrations.

### Core Features and Functionality:

*   **Centralized Management:** Manage all your business lines or subsidiaries from a single view in the Stripe Dashboard.
*   **Consolidated Reporting:** View and download unified reports across currencies and all accounts within the organization. This includes transactions, disputes, invoices, connected accounts, and customers.
*   **Team Management:** Streamline team management and access control across all associated accounts.
*   **Single Sign-On (SSO):** Centrally configure and manage SSO for all accounts within an organization, consolidating authentication apps.
*   **Customer and Payment Method Sharing:** Organizations can facilitate sharing of customers and payment methods across accounts (depending on the setup).
*   **Sandbox Environments:** Create and manage organization sandboxes to test integrations across multiple sandboxes and experiment with Stripe Organizations features before deploying to production.

### Building and Setting Up an Organization:

1.  **Prerequisites:** The user creating the organization must have Super Administrator privileges in each account being added.
2.  **Creation Process:**
    *   Navigate to the account picker in the Stripe Dashboard.
    *   Select "Create" and then "Create organization."
    *   Enter a name for your organization.
    *   Select the accounts you wish to add (up to 75).
    *   Agree to the Terms of Service.
    *   Click "Create."
3.  **SSO Consolidation:** If accounts within the organization have SSO enabled, their individual SSO settings will be consolidated under the organization's SSO settings. These individual account SSO settings will become read-only.

### Managing Access and Roles:

*   **Organization-Level vs. Account-Level Roles:** Users can be granted access at the organization level (inheriting access to all accounts) or at individual account levels.
*   **Administrator Roles:** The Administrator role provides extensive access, similar to the account owner, allowing management of most aspects of an account.
*   **Team Management:** Administrators can invite, remove, and manage permission levels for team members within the organization and its associated accounts.

### Supported Setups:

Organizations support various account structures, including:

*   Multiple standalone accounts.
*   Platforms (Connect platforms).
*   Connected accounts.

It's important to note that a Connect platform can itself be an account within an organization.

By leveraging Stripe Organizations, businesses can significantly simplify the management of complex, multi-account Stripe infrastructures, leading to improved operational efficiency and better financial oversight.
## Managing Access to Your Stripe Organization

Stripe Organizations provide a centralized way to manage multiple Stripe accounts. To effectively manage these accounts and ensure security, you can control access for your team members. This involves assigning roles at both the organization and individual account levels.

### Key Concepts:

*   **Organization-Level Roles:** Grant users access to all accounts within the organization, including the organization itself.
*   **Account-Level Roles:** Grant users access to a specific account within the organization.
*   **Role Inheritance:** Organization-level roles are automatically inherited at the account level. This means if a user has admin rights for the entire organization, they will also have admin rights for any account within that organization. You cannot assign a broader organization-level role and then restrict access at the account level.

### Managing Team Members:

From your organization's **Team and security settings**, administrators can:

*   **Add and Remove Members:** Invite new users to your organization or remove existing members.
*   **View Members:** See all members across the organization or within specific accounts.
*   **Change User Roles:** Assign or modify the roles of team members.
*   **Invite Users:** Invite up to ten users to a specific role.
*   **Manage Two-Factor Authentication (2FA):** Configure 2FA settings for individual members or the entire organization.
*   **View Security History:** Access audit logs for the security history of all members.

### Understanding Role Permissions:

When assigning roles, it's crucial to understand the permissions associated with each. For instance, an **Administrator** role grants extensive access, similar to the account owner, allowing them to manage most aspects of an account. However, certain critical actions, like deleting the default bank account or changing the account owner, are restricted.

By carefully managing user roles and understanding the inheritance of permissions, you can ensure that your team members have the appropriate access to manage your Stripe accounts effectively and securely.
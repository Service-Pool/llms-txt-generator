## Managing Multiple Stripe Accounts and Organizations

This section covers how to manage multiple Stripe accounts, whether they are for entirely separate businesses or different facets of a single enterprise. It details the use of Stripe Organizations to centralize management, reporting, and team access across these accounts.

### Multiple Separate Accounts

You must use separate Stripe accounts for projects, websites, or businesses that operate independently. When you activate a new account, it's subject to Stripe's standard policies and pricing; it doesn't inherit any special status from existing accounts.

*   **Creating New Accounts:** You can create additional Stripe accounts associated with your email address. To do this, click your current Stripe account name in the upper-left corner of the Dashboard and select "New account."
*   **Benefits:** Using additional accounts allows for separate tax and legal entity information, as each account can only be associated with one business's tax ID and legal entity.

### Stripe Organizations

Stripe Organizations provide a way to unify and manage your business across multiple accounts from a single location in the Stripe Dashboard. This is particularly useful for businesses operating globally, with separate business units, franchise groups, or those undergoing company acquisitions.

*   **Purpose:** Organizations centralize reporting, operations, and team management across your enterprise. They allow you to gauge your entire business's performance, view transactions, disputes, invoices, and more across all associated accounts.
*   **Building an Organization:**
    *   The person creating the organization must be a Super Administrator in each account being added.
    *   You can consolidate up to 75 accounts into an organization.
    *   To create an organization, navigate to the account picker in the Dashboard, select "Create," and then "Create organization." Enter a name, select the accounts to add, and agree to the Terms of Service.
*   **Supported Setups:** Organizations support multiple standalone accounts, platforms, and connected accounts.
    *   **Organizations vs. Connect Platforms:** While both allow management of multiple accounts, Organizations centralize management under common ownership, whereas Connect platforms extend Stripe integration to third parties. A Connect platform can belong to an organization.
*   **Managing Access:**
    *   Team member permission levels can be managed from "Team and security settings."
    *   Administrators can add/remove members, view all members, change user roles, and manage two-factor authentication.
    *   **Organization vs. Account Roles:** Users can be assigned roles at the organization level (granting access to all accounts) or at the individual account level. Organization-level roles are inherited at the account level.
*   **Organization-Level SSO:**
    *   If you use Single Sign-On (SSO) across multiple Stripe accounts, you can centrally configure it with Stripe Organizations.
    *   When an organization is created, Stripe consolidates SSO settings. Multiple authentication apps must be consolidated into a single app for the organization.
    *   Individual account SSO settings become read-only after being added to an organization, with edits managed at the organization level.
*   **Organization Sandboxes:**
    *   You can create organization sandboxes to test integrations across multiple sandboxes, mirror your live organization for staging changes, or provide development environments for team members.
    *   To create an organization sandbox, you need specific roles (Sandbox Administrator, Administrator, Developer, or Sandbox User) in your live organization. Navigate to your organization Dashboard, click the account picker, switch to "sandbox," and then "Create sandbox," selecting "Organization" as the type.
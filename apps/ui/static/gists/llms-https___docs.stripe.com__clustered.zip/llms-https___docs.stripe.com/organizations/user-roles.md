## User Roles

This section details the different user roles available within Stripe, allowing for granular control over team member access to your Stripe account.

### Understanding User Roles

Stripe offers various roles to manage permissions for your team members. Assigning the correct roles ensures that individuals have the necessary access to perform their tasks without granting excessive privileges.

*   **Combined Roles:** If a user is assigned multiple roles, they will inherit all the permissions from each individual role. It's crucial to be mindful of potential conflicts and unintended authority when assigning multiple roles.

### Admin Roles

*   **Administrator:** This role grants comprehensive access, similar to the account owner, allowing users to view and manage almost all aspects of the Stripe account.

    *   **Permissions:**
        *   Create, view, and refund payments.
        *   Issue credit notes on invoices.
        *   Create, view, edit, and delete products.
        *   Create, view, edit, and delete customers.
        *   Create, view, edit, and reject connected accounts.
        *   Receive email notifications for connected account rejections and risk requirements.
        *   View balance and transfer balances to connected accounts.
        *   Reverse transfers and pay out balances to external bank accounts.
        *   Invite, edit, and remove team members.
        *   Create, view, edit, and delete API keys.
        *   Add and edit bank account details (for both the primary account and connected accounts).
        *   Edit payout schedules.
        *   Edit account details (address and contact information).
        *   Configure all product settings (e.g., payment methods, Radar, Connect settings).
        *   Connect accounts to Connect platforms.
        *   Perform bulk exports of payments, customers, products, and connected accounts.
        *   View support message history and manage support requests.
        *   Change the default payout currency.
        *   View the account in the mobile app.
        *   View security history audit logs.

    *   **Limitations:**
        *   Cannot delete the default bank account.
        *   Cannot change the account owner.

    *   **SSO Role ID:** `admin`
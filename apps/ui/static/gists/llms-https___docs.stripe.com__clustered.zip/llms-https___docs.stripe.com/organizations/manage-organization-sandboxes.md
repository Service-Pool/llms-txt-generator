## Managing Multiple Stripe Accounts and Organizations

This section provides guidance on managing multiple Stripe accounts, whether they represent distinct businesses, regional operations, or different business units. It covers the creation and management of Stripe Organizations, a feature designed to centralize the administration, reporting, and team management of these separate accounts.

### Key Concepts:

*   **Multiple Separate Accounts:** Stripe requires distinct accounts for independent projects, websites, or businesses. Each account is subject to standard Stripe policies and pricing.
*   **Stripe Organizations:** A feature that allows you to unify and manage multiple Stripe accounts from a single location in the Stripe Dashboard. This is ideal for businesses operating across different entities, regions, or business lines.
*   **Organization vs. Connect Platforms:** While both manage multiple accounts, Organizations centralize management under common ownership, whereas Connect platforms extend Stripe integration to third parties. An Organization can contain Connect platforms.
*   **User Roles:** Granular permissions can be assigned to team members at both the organization and individual account levels, controlling their access and capabilities within the Stripe ecosystem.
*   **Single Sign-On (SSO):** Organizations enable centralized SSO configuration for all associated accounts, streamlining authentication and security.
*   **Sandboxes:** Organizations can have dedicated sandboxes for testing integrations and staging changes across multiple accounts before deploying to production.

### Core Tasks:

*   **Creating and Managing Multiple Accounts:** Understand when and how to create separate Stripe accounts for different business needs.
*   **Building and Managing Organizations:** Learn how to create an organization, add existing Stripe accounts to it, and manage its settings.
*   **Managing Access and Team Members:** Assign roles and permissions to team members for both the organization and individual accounts within it.
*   **Configuring Organization-Level SSO:** Centralize your SSO settings for all accounts within an organization.
*   **Utilizing Organization Sandboxes:** Set up and manage sandboxes for testing and development purposes across your organization's accounts.

### Use Cases:

*   **Global Expansion:** Create separate accounts for each country or region to leverage local acquiring.
*   **Separate Business Units:** Isolate operations and finances for distinct business units.
*   **Franchise Groups:** Centrally manage franchise locations.
*   **Company Acquisitions:** Integrate acquired businesses that use Stripe.
*   **Consolidated Reporting:** Gauge overall business performance, download unified reports across currencies, and perform cross-account SQL queries with Sigma.
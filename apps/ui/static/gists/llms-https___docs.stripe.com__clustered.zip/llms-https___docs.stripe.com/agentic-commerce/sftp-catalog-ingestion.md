# SFTP Catalog Ingestion

This guide explains how to receive and ingest business product catalogs from Stripe over SFTP. Stripe provides daily full-catalog snapshots to your SFTP server.

## Overview

Stripe offers a feature for agentic commerce where business product catalogs are delivered to your SFTP server. This allows you to integrate and manage product data efficiently.

## Connectivity and Directory Structure

Stripe uses SFTP (SSH File Transfer Protocol) over port 22 for data transfer. Authentication is performed using SSH key-based authentication with Ed25519 keys. Password authentication is disabled.

### Metadata

Each business directory includes a `merchant_metadata.json` file. This file contains essential information about the business, such as:

*   `stripe_profile_id`: The unique identifier for the Stripe profile.
*   `business_url`: The URL of the business.
*   `return_policy`: The URL for the return policy.
*   `privacy_policy`: The URL for the privacy policy.
*   `terms_of_service`: The URL for the terms of service.
*   `last_updated`: The timestamp of the last data update.

**Example `merchant_metadata.json`:**

```json
{
  "stripe_profile_id": "profile_12345",
  "business_url": "https://www.acmewidgets.com",
  "return_policy": "https://www.acmewidgets.com/returns",
  "privacy_policy": "https://www.acmewidgets.com/privacy",
  "terms_of_service": "https://www.acmewidgets.com/tos",
  "last_updated": "2026-03-30T10:00:00Z"
}
```

### Directory Structure

Stripe organizes the SFTP root by business profile ID. Each business has a unique top-level directory. Data is further separated by feed type within each business directory.

```
/root
  stripe-verification.txt  # Uploaded by agent during onboarding
  /[stripe_profile_id]/
    merchant_metadata.json
    /catalog/  # Full daily snapshots
      full_catalog_part1_of_2.csv.gz
      full_catalog_part2_of_2.csv.gz
      manifest.json
    /updates/  # High-frequency deltas (opt-in)
      delta_part1_of_1.csv.gz
      manifest.json
```

## SFTP Server Verification

During the agent onboarding process in the Stripe Dashboard, you will provide your SFTP host details. Stripe will then generate a unique challenge token. You must upload this token to the root directory of your SFTP server to verify your server's identity.
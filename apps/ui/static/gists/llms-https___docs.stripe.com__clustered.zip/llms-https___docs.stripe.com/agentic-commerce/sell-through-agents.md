# Agentic Commerce

This section of the documentation covers Stripe's Agentic Commerce Suite (ACS), a set of tools and protocols designed to enable AI agents to facilitate commercial transactions. It outlines how sellers can integrate their products and services to be discoverable and purchasable through AI agents, and how agents can embed commerce capabilities into their interfaces to manage purchases on behalf of buyers.

## Key Concepts and Integrations

### Agentic Commerce Protocol (ACP)

The Agentic Commerce Protocol (ACP) defines the methods and data structures for creating, updating, and completing checkout flows between AI agents, buyers, and sellers. It allows for machine-to-machine communication to handle commerce transactions.

*   **Build the Agentic Commerce Protocol checkout endpoints:** Learn how to implement the ACP specification to enable AI agents to manage commerce transactions.

### Selling Through Agents

Sellers can leverage ACS to make their products available through AI agents, expanding their sales channels.

*   **Sell through agents:** An overview of how to use ACS to sell products through agents, making them discoverable and enabling agentic payments.
*   **Custom integration:** For sellers who want to build their own checkout API endpoints and process agentic payments with a third-party payment processor. This involves implementing a reverse API that Stripe calls on your behalf.

### Embedding Commerce into AI Interfaces

AI agents can integrate commerce capabilities directly into their interfaces, allowing users to browse, select, and purchase products without leaving the conversational experience.

*   **Embed commerce into your AI interface:** Learn how to use ACS to embed commerce capabilities into your AI interface, enabling product discovery, payment information collection, and purchase completion.

### Shared Payment Tokens (SPTs)

Shared Payment Tokens (SPTs) are a crucial component for secure and scoped payment authorization in agentic commerce. They represent a grant to use a customer's payment method with defined usage and expiration limits.

*   **Shared payment tokens:** Understand how SPTs work, how sellers receive them from agents, and how to use test helpers to simulate receiving an SPT.

### Machine Payments

This feature allows for programmatic, machine-to-machine payments, enabling agents to pay for resources like API calls or services.

*   **Machine payments:** An overview of how to enable machine-to-machine payments, including accepting crypto payments directly into your Stripe balance.
*   **MPP payments:** Details on the Machine Payments Protocol (MPP), a protocol for internet payments where servers return an HTTP 402 response for paid resources.
*   **MPP quickstart:** A guide to implementing MPP for machine-to-machine payments.
*   **x402 payments:** Information on the x402 protocol for internet payments, similar to MPP, focusing on HTTP 402 responses for payment authorization.
*   **x402 quickstart:** A guide to implementing x402 for machine-to-machine payments.

## Stripe Climate

Stripe Climate offers two primary ways for businesses to contribute to carbon removal:

### Climate Commitments

*   **Climate Commitments:** Direct a fraction of your revenue to help advance carbon removal technologies. This is suitable for businesses primarily focused on supporting the carbon removal field without needing to meet specific ton-purchase targets.

### Climate Orders

*   **Climate Orders overview:** Purchase carbon removal tons from Frontier's offtake portfolio for future delivery. This is for businesses that need to buy a specific number of tons to meet climate targets or offer carbon removal to their customers.
*   **How Climate Orders work:** Learn about the process of creating, monitoring, and managing carbon removal orders, including how Frontier procures supply, monitors progress, and manages deliveries.
*   **Carbon removal inventory:** Explore the available carbon removal products from Frontier's portfolio, including their expected delivery year, price per metric ton, and minimum order quantities.
*   **Order carbon removal:** Details on how to pre-order carbon removal tons from Frontier's offtake portfolio, including funding options and how to create and track orders.
*   **Accept carbon removal payments:** A quickstart guide for integrating carbon removal payments.
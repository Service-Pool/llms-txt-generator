# Agentic Commerce

This section of the documentation covers Stripe's Agentic Commerce Suite (ACS), a set of tools and protocols designed to enable AI agents to facilitate commerce transactions. It provides resources for both sellers looking to offer their products through AI agents and for agents looking to embed commerce capabilities into their AI interfaces.

## Key Concepts and Integrations

*   **Agentic Commerce Protocol (ACP):** This specification defines the methods and data structures for creating, updating, and completing checkout flows managed by AI agents. It allows for machine-to-machine commerce transactions.
*   **Shared Payment Tokens (SPTs):** These are scoped grants that agents receive from customers, allowing them to use a customer's payment method with defined usage and expiration limits. SPTs are crucial for secure and controlled agentic payments.
*   **Selling Through Agents:** For sellers, ACS offers a single integration to make products discoverable and accept agentic payments across multiple commerce protocols. This involves sharing product, price, and availability information with agents.
    *   **Custom Integration:** For sellers who want to build their own checkout API endpoints and process agentic payments with a third-party payment processor.
*   **Embedding Commerce into AI Interfaces:** For agents, ACS allows for the integration of commerce capabilities directly into AI interfaces, enabling them to browse products, collect payment information, and complete purchases on behalf of sellers.
    *   **Embedded Integration:** Manages the full checkout lifecycle through Stripe, handling routing, authentication, and SPT creation.

## Machine Payments

This suite of features enables programmatic payments, allowing AI agents to pay for resources and services.

*   **Machine Payments:** A general feature for enabling machine-to-machine payments, allowing agents to pay for resources programmatically.
*   **MPP (Machine Payments Protocol):** A protocol for internet payments where a server returns an HTTP 402 response for paid resources. Clients then authorize and complete the payment. MPP supports both crypto and fiat payments via SPTs.
*   **x402 Payments:** Another protocol for internet payments, similar to MPP, where servers respond with an HTTP 402. Stripe handles deposit addresses and payment intent capture for on-chain crypto payments.

## Stripe Climate

Stripe Climate offers ways for businesses to support carbon removal technologies.

*   **Climate Commitments:** Allows businesses to direct a fraction of their revenue to help advance carbon removal technologies, suitable for businesses focused on supporting the field.
*   **Climate Orders:** Enables businesses to purchase specific quantities of carbon removal from Frontier's portfolio, suitable for businesses needing to meet climate targets or offer carbon removal to customers.
    *   **Carbon Removal Inventory:** Details the available carbon removal products from Frontier's portfolio.
    *   **How Climate Orders Work:** Explains the process of procuring, monitoring, and managing carbon removal orders.
    *   **Order Carbon Removal:** Guides users on how to create and fund carbon removal orders.

---

## Documentation Pages:

*   **/agentic-commerce/protocol:** Build the Agentic Commerce Protocol checkout endpoints
*   **/agentic-commerce/concepts/shared-payment-tokens:** Shared payment tokens
*   **/agentic-commerce/for-agents:** Embed commerce into your AI interface
*   **/agentic-commerce/for-sellers/custom:** Build a custom integration
*   **/agentic-commerce/for-sellers:** Sell through agents
*   **/agentic-commerce:** Agentic commerce overview
*   **/climate/commitments:** Climate Commitments
*   **/climate/orders/carbon-removal-inventory:** Carbon removal inventory
*   **/climate/orders/how-it-works:** How Climate Orders work
*   **/climate/orders:** Climate Orders overview
*   **/climate/orders/order-carbon-removal:** Order carbon removal
*   **/climate:** Stripe Climate overview
*   **/climate/orders/quickstart:** Accept carbon removal payments
*   **/payments/machine:** Machine payments
*   **/payments/machine/mpp:** MPP payments
*   **/payments/machine/mpp/quickstart:** MPP quickstart
*   **/payments/machine/x402:** x402 payments
*   **/payments/machine/x402/quickstart:** x402 quickstart
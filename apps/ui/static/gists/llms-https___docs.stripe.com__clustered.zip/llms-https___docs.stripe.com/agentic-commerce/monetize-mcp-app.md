### Monetize your Model Context Protocol (MCP) App

This section outlines how to integrate payment processing into your Model Context Protocol (MCP) application, enabling you to monetize your AI-driven services. MCP apps can expose new capabilities and workflows directly within MCP hosts like ChatGPT and Claude, allowing users to complete transactions without leaving the chat interface.

**Key Monetization Strategies:**

*   **Redirect Checkout:**
    *   **Description:** Redirects customers to a prebuilt Stripe-hosted checkout page in a new browser tab to complete their purchase.
    *   **Integration Effort:** Low coding.
    *   **Recommended When:** You want to leverage a prebuilt, customizable form for payments and are comfortable with customers opening a new tab. This method supports features like promo codes, tax collection, localized pricing, and subscriptions with minimal additional code, making it suitable for common use cases.
    *   **UI Components:** Integrated.
    *   **Availability:** Publicly available.

*   **Instant Checkout:**
    *   **Description:** Integrates with platforms like ChatGPT Instant Checkout to allow customers to complete their purchase without leaving the chat interface.
    *   **Integration Effort:** Most coding.
    *   **Recommended When:** You need to keep customers within the same chat session and require fine-grained control over the checkout flow. This is best suited for complex flows with custom business logic, and you have the resources to build and maintain a custom integration.
    *   **UI Components:** Custom.
    *   **Availability:** Currently in Open AI private beta.

**Payment Method Flexibility:**

Stripe allows you to dynamically display over 40 payment methods, which can be managed through your Stripe account. This ensures a seamless payment experience for your global user base.

**Related Topics:**

*   [Accept a Payment with your MCP App](/agentic-commerce/apps/accept-payment)
*   [Embed Commerce into your AI Interface](/agentic-commerce/apps/embed-commerce)
*   [Concepts of Agentic Commerce](/agentic-commerce/concepts)
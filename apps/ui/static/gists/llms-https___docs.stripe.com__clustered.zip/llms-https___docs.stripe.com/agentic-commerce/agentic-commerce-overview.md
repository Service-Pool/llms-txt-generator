# Agentic Commerce

Agentic commerce leverages AI agents to facilitate transactions between buyers and sellers. This allows sellers to offer their products and services through AI-driven interfaces, while buyers can discover products, receive personalized recommendations, and complete purchases seamlessly within conversational AI environments.

## Key Concepts and Integrations

### Agentic Commerce Protocol (ACP)

The Agentic Commerce Protocol (ACP) is a specification that defines the methods and data structures for creating, updating, and completing checkout flows, enabling AI agents to manage commerce transactions.

*   **Build Checkout Endpoints:** Learn how to implement ACP to enable AI agents to manage commerce transactions.

### For Agents

AI agents act as intermediaries, presenting product feeds, managing carts and checkouts, and accepting payments on behalf of buyers.

*   **Embed Commerce into AI Interface:** Integrate commerce capabilities directly into your AI interface to allow users to browse products, collect payment information, and complete purchases.
*   **Accept Machine Payments:** Enable your agents to pay for resources programmatically, such as API calls or services, using various payment methods including cryptocurrency.

### For Sellers

Sellers can utilize AI agents as a new sales channel to offer their goods, subscriptions, digital content, or APIs.

*   **Sell Through Agents:** Make your products discoverable and accept agentic payments across multiple commerce protocols with a single integration.
*   **Custom Integration:** Build your own checkout API endpoints and process agentic payments with a third-party payment processor.
*   **Monetize Your MCP App:** (Details not provided in the provided content, but implied as a seller-focused integration.)

### Shared Payment Tokens (SPTs)

Shared Payment Tokens (SPTs) are scoped grants that agents provide to sellers, allowing them to use a customer's payment method with defined usage and expiration limits.

*   **Shared Payment Tokens:** Understand how SPTs facilitate secure and limited payment method usage between agents and sellers.

### Machine Payments

Machine payments enable programmatic, machine-to-machine transactions.

*   **Machine Payments:** Allow agents to pay for resources programmatically, with payments landing directly in your Stripe balance and settling in fiat.
*   **MPP Payments:** Utilize the Machine Payments Protocol (MPP) for internet payments, supporting both crypto and fiat payment methods.
*   **x402 Payments:** Implement the x402 protocol for machine-to-machine payments, where servers respond with HTTP 402 errors for payment details.

## Related Features

*   **Stripe Climate:** While not directly part of agentic commerce, Stripe Climate offers tools to support carbon removal technologies.
    *   **Climate Commitments:** Direct a fraction of your revenue to advance carbon removal.
    *   **Climate Orders:** Purchase carbon removal tons from Frontier's offtake portfolio for future delivery.
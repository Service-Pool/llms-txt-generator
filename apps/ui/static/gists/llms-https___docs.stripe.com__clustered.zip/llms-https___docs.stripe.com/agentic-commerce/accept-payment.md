# Accept a payment

This guide shows how to securely accept payments with your Model Context Protocol (MCP) App.

## Overview

You can collect payments outside your app with a prebuilt Stripe-hosted Checkout page. This guide demonstrates how to:

*   Define Model Context Protocol (MCP) tools to display products and let customers select items to buy.
*   Collect payment details with a prebuilt Stripe-hosted Checkout page.
*   Monitor webhooks after a successful payment.

## Set up Stripe

To set up Stripe, add the Stripe API library to your back end.

**Command Line**

```bash
sudo gem install stripe
```

**Gemfile**

```ruby
gem 'stripe'
```

## Create products and prices

In this example, you can display a group of products in the MCP app. Learn how to create products and prices in the Dashboard or with the Stripe CLI.

## Register a Checkout MCP tool

Register an MCP tool that creates a Checkout Session for a set of Prices. You call this tool from the MCP app in a later step.

```javascript
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { registerAppTool, registerAppResource, RESOURCE_MIME_TYPE, } from "@modelcontextprotocol/ext-apps/server";
import { readFileSync } from "node:fs";
import Stripe from "stripe";
import { z } from "zod";
```
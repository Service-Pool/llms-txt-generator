# Product Feed

This document outlines how to share structured product and inventory data with Stripe for AI agent discovery and commerce.

## Overview

The product feed allows you to provide Stripe with detailed information about your products and their current inventory levels. This data can then be used by AI agents to discover, search, and facilitate purchases of your products.

## Key Concepts

*   **Product Feed Specification:** A defined structure for providing your complete, structured product data. This includes details such as titles, descriptions, identifiers, pricing, fulfillment information, and media.
*   **Inventory Feed Updates:** Incremental updates to your product feed to keep stock levels and availability current.
*   **AI Agent Discovery:** Enabling AI agents to find and recommend your products based on the provided feed data.
*   **SFTP Catalog Ingestion:** A secure method for submitting your product and inventory data.

## Getting Started

1.  **Understand the Product Feed Specification:** Familiarize yourself with the required, recommended, and optional fields, along with their validation rules and sample values.
2.  **Format Your Data:** Structure your product data according to the specification, with each row representing a product or variant.
3.  **Submit Your Initial Feed:** Send a full product feed submission to the sandbox endpoint to ensure your data parses correctly and meets all field requirements.
4.  **Keep Your Data Current:** Regularly update your feed with changes to product attributes, pricing, or fulfillment details to maintain accuracy and customer trust.

## Data Submission

*   **Format:** CSV
*   **Method:** Stripe API (via SFTP catalog ingestion)
*   **Frequency:** Frequent updates are recommended to reflect real-time inventory and availability.

## Benefits

*   **Enhanced Product Discoverability:** Make your products easily discoverable by AI agents.
*   **Improved Customer Experience:** Provide accurate and up-to-date product information, leading to better purchasing decisions.
*   **Streamlined Commerce:** Facilitate seamless transactions through AI-powered shopping experiences.
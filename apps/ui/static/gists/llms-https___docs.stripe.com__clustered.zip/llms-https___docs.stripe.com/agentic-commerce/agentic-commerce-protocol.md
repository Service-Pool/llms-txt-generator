## Agentic Commerce

This section details Stripe's offerings for enabling AI agents to facilitate commercial transactions. It covers the Agentic Commerce Protocol (ACP) for direct checkout endpoint integration, and the Agentic Commerce Suite (ACS) for embedding commerce into AI interfaces and selling through agents. It also includes information on machine-to-machine payments, including MPP and x402 protocols, and Stripe Climate for carbon removal initiatives.

### Agentic Commerce Protocol (ACP)

The Agentic Commerce Protocol (ACP) is a specification that defines the methods and data structures for AI agents to manage commerce transactions. It allows for the creation, updating, and completion of checkout flows between buyers and sellers.

*   **Build the Agentic Commerce Protocol checkout endpoints**: Learn how to implement the ACP to enable AI agents to manage commerce transactions. This includes creating agentic checkout sessions with buyer details, line items, and shipping information.

### Agentic Commerce Suite (ACS)

The Agentic Commerce Suite (ACS) provides a way to embed commerce capabilities into AI interfaces and to sell products through AI agents.

*   **Embed commerce into your AI interface**: Use ACS to allow AI interfaces to discover products, collect payment information, and complete purchases on behalf of sellers. This integration manages the full checkout lifecycle through Stripe.
*   **Sell through agents**: Utilize ACS to make your products discoverable and accept agentic payments across multiple commerce protocols with a single integration.
*   **Build a custom integration**: For sellers who want to build their own checkout API endpoints and process agentic payments with a third-party payment processor, ACS offers a custom integration. This involves implementing a reverse API that Stripe calls on your behalf.

### Concepts in Agentic Commerce

*   **Shared payment tokens (SPTs)**: These are scoped grants that agents provide to sellers, allowing them to use a customer's payment method with defined usage and expiration limits. SPTs are currently available in the US.
*   **Product feed**: Agents use product feeds to help buyers make purchasing decisions.

### Machine Payments

Stripe facilitates machine-to-machine payments, allowing agents to pay for resources programmatically.

*   **Machine payments**: Enables agents to pay for resources like API calls or services programmatically. Businesses can accept these payments in crypto directly into their Stripe balance.
*   **MPP (Machine Payments Protocol)**: A protocol for internet payments where servers return an HTTP 402 response for paid resources. Clients then authorize, retry, and pay for access. MPP supports both crypto and fiat payments (via SPTs).
*   **x402 payments**: Another protocol for internet payments where servers return an HTTP 402 response. Stripe handles deposit addresses and automatically captures PaymentIntents for on-chain settlements.

### Stripe Climate

Stripe Climate offers solutions for businesses to support carbon removal technologies.

*   **Stripe Climate**: The easiest way to help emerging permanent carbon removal technologies scale.
*   **Climate Commitments**: Direct a fraction of your revenue to help advance carbon removal technologies. This is suitable for businesses that prioritize advancing the carbon removal field without needing to meet specific ton-based climate targets.
*   **Climate Orders**: Purchase carbon removal from Frontier's portfolio of advanced permanent carbon removal solutions. This is ideal for businesses that need to buy a specific number of tons to meet climate targets or want to offer carbon removal to their customers.
    *   **How Climate Orders work**: Learn how to create, monitor, and manage your carbon removal orders. Frontier procures supply, monitors supplier progress, and manages deliveries.
    *   **Carbon removal inventory**: Discover available carbon removal products from Frontier's portfolio.
    *   **Order carbon removal**: Learn how to create and fund climate orders programmatically via the API or manually through the Dashboard.
    *   **Accept carbon removal payments**: A quickstart guide for integrating carbon removal payments.
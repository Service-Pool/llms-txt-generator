```markdown
### Request a Payment Data Import

This page outlines the process of securely importing existing customer and payment data into Stripe. It details how Stripe works with your team and current payment provider to ensure a smooth and secure migration with no downtime for your customers. The guide covers migrating from other payment processors or custom solutions and emphasizes building and testing a Stripe integration in a sandbox environment before handling live payments. It also highlights the importance of completing a Data Migration Request form for transferring sensitive payment information in a PCI-compliant manner and briefly touches upon Stripe's client-side and server-side security measures for payment collection.

**Key Information:**

*   **Purpose:** Securely import existing customer and payment data into Stripe.
*   **Process:** Stripe collaborates with your team and current payment provider.
*   **Benefits:** Retain existing data, no customer downtime, ability to charge new customers on Stripe while migrating existing ones.
*   **Prerequisites:** Review Stripe pricing, build and test a Stripe integration in a sandbox.
*   **Sensitive Data Transfer:** Requires a completed Data Migration Request form for PCI compliance.
*   **Security:** Employs client-side and server-side steps to simplify security requirements.
```
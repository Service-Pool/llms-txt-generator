## Data Migrations

This section provides comprehensive documentation for migrating your payment and customer data to Stripe. It covers the entire process, from understanding the migration strategy to securely importing and exporting sensitive payment information.

### Key Areas:

*   **Overview:** Get a high-level understanding of the Stripe migration process, including timelines, required integrations, and strategies for minimizing disruption to your users.
*   **Importing Payment Methods:** Learn how to import payment method data from your existing payment processor into Stripe. This includes considerations for different payment types like cards, ACH, and more.
*   **Exporting Data:** Discover how to export your payment data from Stripe. This section details the available file formats (CSV, JSON) for various payment types and how to request specific data exports.
*   **Mapping Payment Data:** Understand how to map your imported payment data to existing Stripe Customers to avoid duplicate entries. This includes instructions on creating mapping files and how data is handled during the process.
*   **Copying PAN Data:** Learn how to securely copy sensitive Primary Account Number (PAN) data between Stripe accounts using the self-serve data copy service.
*   **Requesting Imports/Exports:** Find out how to initiate requests for both importing sensitive payment data into Stripe and exporting it to another processor, ensuring PCI compliance.
*   **BACS Debit Data Export:** Specific guidance on exporting Bacs data from Stripe, including the process, required information, and estimated timelines.

By utilizing these resources, you can ensure a smooth and secure transition of your payment data to Stripe.
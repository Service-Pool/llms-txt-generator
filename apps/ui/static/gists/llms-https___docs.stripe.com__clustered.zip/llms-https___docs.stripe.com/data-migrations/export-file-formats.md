## Export File Formats

This section details the file formats Stripe uses for exporting payment data, enabling seamless integration with new processors.

### Supported Export Formats

Stripe maintains a consistent export format. New processors can filter, map, and adjust these files as needed. The standard Service Level Agreement (SLA) for completing an export is 10 days after all valid data is received (excluding BACS).

*   **ACH, SEPA, BACS, and PADs/ACSS:** Exported as CSV files.
*   **Card Data:** Can be exported in both CSV and JSON formats.

### Card Export Fields

The following fields are included in card exports:

| Field                  | Description

<!-- truncated by AI -->
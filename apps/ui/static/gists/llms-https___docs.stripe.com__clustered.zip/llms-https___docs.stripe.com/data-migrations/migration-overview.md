```markdown
### Migrating Payment Data to Stripe

This section outlines the process of migrating your existing customer and payment data to Stripe. It covers understanding the migration process, scoping timelines, identifying necessary integration elements, and migrating payment details with minimal disruption to your users.

#### Key Sub-topics:

*   **Overview of Stripe Migration:** Understand the general process and goals of migrating to Stripe.
*   **Importing Payment Methods:** Learn how to bring your existing payment method data into Stripe.
*   **Mapping Payment Data:** Discover how to associate imported payment data with existing Stripe Customers to avoid duplicates.
*   **Exporting Payment Data:** Understand how to export your payment data from Stripe, including different file formats.
*   **Copying PAN Data:** Learn how to securely copy sensitive Primary Account Number (PAN) data between Stripe accounts.
*   **Requesting Data Imports/Exports:** Details on how to initiate requests for importing or exporting sensitive payment data.
*   **Export File Formats:** Information on the formats Stripe uses for exported data.

#### Related Pages:

*   **Import payment method data:** `/get-started/data-migrations/payment-method-imports`
*   **Export file formats:** `/get-started/data-migrations/export-file-formats`
*   **Map payment data:** `/get-started/data-migrations/map-payment-data`
*   **Copy PAN data across Stripe accounts:** `/get-started/data-migrations/pan-copy-self-serve`
*   **Request a payment data export:** `/get-started/data-migrations/pan-export`
*   **Request a payment data import:** `/get-started/data-migrations/pan-import`
*   **Export Bacs data from Stripe:** `/payments/bacs-debit/export-data`
```
```markdown
---
title: Request a Payment Data Export
description: Learn how to securely export sensitive payment data from Stripe to another payment processor. This guide outlines the process, requirements, and limitations for migrating your card data.
---

# Request a Payment Data Export

Stripe believes you own the sensitive data you entrust to us. We ensure you have access to this data, even if you decide to move to another payment processor. If you are leaving Stripe, we will work with your new processor's team to securely transfer your credit card data.

## Requirements for Data Transfer

To meet PCI compliance obligations, Stripe can only transfer your card data to another PCI DSS Level 1-compliant payment processor. The receiving processor must provide the following:

*   **PCI Attestation of Compliance (AOC)**: The processor's current AOC, or their listing on Visa's Global Registry of Service Providers.
*   **PGP Public Encryption Key**: A 4096-bit or greater PGP public encryption key. This key must be hosted over HTTPS on one of the processor's domain names referenced in their AOC or Visa Registry listing.

Stripe will typically confirm if a new processor meets these requirements after you provide us with their details.

## Link Transactions

Please note that payment credentials saved with Link cannot be transferred between payment processors. Any credentials saved through Link are excluded from our exports.

## Migratable Data

Stripe can assist in migrating your customer card information to a new payment processor. To ensure this is done securely, Stripe prepares an export of your data.
```
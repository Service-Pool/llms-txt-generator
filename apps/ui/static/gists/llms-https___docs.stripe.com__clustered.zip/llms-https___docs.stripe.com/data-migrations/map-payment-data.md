## Migrating Payment Data to Stripe

This section provides comprehensive guidance on migrating your existing payment data to Stripe, ensuring a smooth transition with minimal disruption to your business and customers.

### Key Migration Processes:

*   **Importing Payment Methods:** Learn how to import your customers' payment method data from your previous processor into Stripe. This includes understanding the different payment method objects (`pm_`, `card_`, `src_`) and their compatibility with Stripe's APIs.
    *   [Import payment method data](/get-started/data-migrations/payment-method-imports)

*   **Mapping Payment Data:** Discover how to map your imported payment data to existing Stripe Customers to prevent duplicate customer records. This process involves providing a CSV file with `old_customer_id` and `stripe_customer_id` to ensure accurate data association.
    *   [Map payment data](/get-started/data-migrations/map-payment-data)

*   **Exporting Payment Data:** Understand how to export your payment data from Stripe, including various file formats like CSV and JSON. This is crucial for migrating to a new processor or for your own record-keeping.
    *   [Export file formats](/get-started/data-migrations/export-file-formats)
    *   [Request a payment data export](/get-started/data-migrations/pan-export)
    *   [Export Bacs data from Stripe](/payments/bacs-debit/export-data)

*   **Copying PAN Data:** Securely copy sensitive Primary Account Number (PAN) data between Stripe accounts using Stripe's self-serve data copy service. This is useful for consolidating data or setting up new accounts.
    *   [Copy PAN data across Stripe accounts](/get-started/data-migrations/pan-copy-self-serve)

*   **Requesting Data Imports:** Learn how to securely import sensitive payment data into Stripe, ensuring your existing customers and payment information are retained.
    *   [Request a payment data import](/get-started/data-migrations/pan-import)

### General Migration Information:

*   **Overview:** Get a high-level understanding of the Stripe migration process, including timelines, required integrations, and strategies for minimizing user disruption.
    *   [Overview](/get-started/data-migrations/overview)

### Important Considerations:

*   **Data Formats:** Familiarize yourself with Stripe's standard export file formats and how new processors can adapt them.
*   **Customer Data:** Understand how Stripe handles customer data during migration, including avoiding duplicates and the overwrite policy for default cards.
*   **PCI Compliance:** Be aware of Stripe's requirements for securely transferring sensitive payment data, especially when moving to a new processor.
*   **Link Transactions:** Note that payment credentials saved with Link are excluded from exports.
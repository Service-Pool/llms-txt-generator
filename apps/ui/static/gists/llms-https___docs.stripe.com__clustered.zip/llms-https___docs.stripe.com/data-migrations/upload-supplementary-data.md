# Upload Supplementary Data

This guide explains how to upload supplementary data to Stripe when migrating your payment data. This data can include additional information that complements your core payment records.

## Data Encryption for PCI Data

For sensitive PCI data, such as credit card information, it is crucial to encrypt the data using the Stripe PGP key before uploading.

### Prerequisites

*   **OpenPGP Familiarity:** If you are new to the OpenPGP standard, download and install the GnuPG software.
*   **Command-Line Interface (CLI):** You can use Terminal (Mac/iTerm) or Windows Terminal (PC).

### Steps

1.  **Save Non-Encrypted Data:** Place your non-encrypted data file on your desktop.
2.  **Compress Data File:** Zip the data file. Stripe supports `.zip` or `.tar.gz` compression.
3.  **Download Stripe Public Key:**
    *   Copy the Stripe public key.
    *   Paste the key into a `.txt` file.
    *   Save the file as `Stripe_Import_Key.txt` on your desktop.
4.  **Add Key to Known Keys:**
    *   Open your CLI.
    *   Navigate to your desktop: `cd ~/Desktop`
    *   Import the key: `gpg --import Stripe_Import_Key.txt`
    *   Verify the output matches:
        ```
        gpg: key 9C78B7620C1E99AD: public key "Stripe Import Key (PCI) <support-migrations@stripe.com>" imported
        gpg: Total number processed: 1
        gpg: imported: 1
        ```
5.  **Verify the Key:** Use the command `gpg --list-keys` to confirm the key has been added.
6.  **Encrypt Data File:**
    *   Use the following command to encrypt your data file (replace `your_data_file.csv` with your actual filename):
        ```bash
        gpg --recipient "Stripe Import Key (PCI)" --encrypt your_data_file.csv
        ```
    *   This action will generate an encrypted GPG file (e.g., `your_data_file.csv.gpg`). The output will look similar to:
        ```
        gpg: 8A3B0AC7944266D9: There is no assurance this key belongs to the named
        ```
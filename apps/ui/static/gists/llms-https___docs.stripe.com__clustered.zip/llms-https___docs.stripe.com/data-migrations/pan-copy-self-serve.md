```markdown
### Copy PAN Data Across Stripe Accounts

This document outlines the process of securely copying sensitive Primary Account Number (PAN) data between Stripe accounts. It details the self-serve data copy service available within the Stripe Dashboard.

**Key Features:**

*   **Self-Serve Data Copy:** Utilize a user-friendly service within the Stripe Dashboard to transfer customer and payment data.
*   **Sender and Recipient Accounts:** The process involves a sender account (source of data) and a recipient account (destination of data).
*   **Account ID Sharing:** Both sender and recipient parties must exchange their respective Stripe account IDs to initiate the process. Account IDs can be found in the User settings of the Stripe Dashboard.

**Considerations for Data Copying:**

*   **One-Way Copying:** Data can only be copied from one account to another; merging or moving data is not supported.
*   **Data Duplication:** After a successful copy, the data will reside in both the source and destination accounts.
*   **Data Scope:** Only raw Customer objects and their associated payment data are copied.
```
```markdown
# Revoke a SharedPaymentIssuedToken

This document outlines how to revoke a `SharedPaymentIssuedToken` using the Stripe API.

## API Endpoint

```
POST /v1/shared_payment/issued_tokens/:id/revoke
```

## Request

Revoking a `SharedPaymentIssuedToken` does not require any parameters in the request body.

### Example Request (cURL)

```bash
curl -X POST https://api.stripe.com/v1/shared_payment/issued_tokens/spt_1RgaZcFPC5QUO6ZCDVZuVA8q/revoke \
  -u "sk_test_RXHltS2...7i001oa6x7o4sk_test_RXHltS2OKzISvxWQ7NmRN57i001oa6x7o4:"
```

## Response

The API will return the revoked `SharedPaymentIssuedToken` object.

### Example Response

```json
{
  "id": "spt_1RgaZcFPC5QUO6ZCDVZuVA8q",
  "object": "shared_payment.issued_token",
  "livemode": false,
  "created": 1751500820,
  "deactivated_at": 1751587220,
  "deactivated_reason": "revoked",
  "payment_method": "pm_1RgaZbFPC5QUO6ZCe2ekOCNX",
  "seller_details": {
    "external_id": "{{EXTERNAL_ID}}",
    "network_business_profile": "{{NETWORK_BUSINESS_PROFILE}}"
  },
  "setup_future_usage": null,
  "shared_metadata": {},
  "status": "revoked",
  "usage_details": {
    "amount_captured": {
      "value": 0,
      "currency": "usd"
    }
  },
  "usage_limits": {
    "currency": "usd",
    "expires_at": 1751587220,
    "max_amount": 1000
  }
}
```
```
# Shared Payment Granted Token Object

The Shared Payment Granted Token object represents a view-only resource of a `SharedPaymentIssuedToken`. It's a limited-use reference to a `PaymentMethod` that has been shared with you by another Stripe merchant. You can use this granted token with a `PaymentIntent` to process payments against the shared `PaymentMethod`.

## Attributes

| Attribute              | Type    | Description

<!-- truncated by AI -->
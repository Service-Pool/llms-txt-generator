```markdown
# Shared Payment Tokens

This section covers the Stripe API for managing Shared Payment Tokens, which enable secure sharing of payment information between Stripe accounts.

## Shared Payment Issued Token

A `SharedPaymentIssuedToken` is a limited-use reference to a `PaymentMethod` that can be created with a secret key. When shared with another Stripe account (Seller), it enables that account to either process a payment on Stripe against a `PaymentMethod` that your Stripe account owns, or to forward a usable credential created against the original `PaymentMethod` to then process the payment off-Stripe.

### Create a SharedPaymentIssuedToken

Creates a new `SharedPaymentIssuedToken` object.

**Endpoint:** `POST /v1/shared_payment/issued_tokens`

**Parameters:**

*   `payment_method` (string, required): The `PaymentMethod` that is going to be shared by the `SharedPaymentIssuedToken`.
*   `seller_details` (object, required): Seller details of the `SharedPaymentIssuedToken`, including `network_id` and `external_id`.
    *   `external_id` (string)
    *   `network_business_profile` (string)
*   `usage_limits` (object, required): Limits on how this `SharedPaymentToken` can be used.
    *   `currency` (string)
    *   `expires_at` (timestamp)
    *   `max_amount` (integer)
*   `setup_future_usage` (enum, optional): Indicates that you intend to save the `PaymentMethod` of this `SharedPaymentToken` to a customer later. Possible values: `on_session`.
*   `shared_metadata` (object, optional): Set of key-value pairs that you can attach to the `SharedPaymentIssuedToken`. The values here are visible by default with the party that you share this `SharedPaymentIssuedToken` with.

### Retrieve a SharedPaymentIssuedToken

Retrieves an existing `SharedPaymentIssuedToken` object.

**Endpoint:** `GET /v1/shared_payment/issued_tokens/:id`

### Revoke a SharedPaymentIssuedToken

Revokes a `SharedPaymentIssuedToken`.

**Endpoint:** `POST /v1/shared_payment/issued_tokens/:id/revoke`

### The Shared Payment Issued Token object

Attributes of a `SharedPaymentIssuedToken`:

*   `id` (string): Unique identifier for the object.
*   `object` (string): String representing the object’s type.
*   `created` (timestamp): Time at which the object was created.
*   `deactivated_at` (timestamp, nullable): Time at which this `SharedPaymentIssuedToken` was deactivated.
*   `deactivated_reason` (enum, nullable): The reason why the `SharedPaymentIssuedToken` has been deactivated. Possible values: `consumed`, `expired`, `resolved`, `revoked`.
*   `livemode` (boolean): If the object exists in live mode, the value is true. If the object exists in test mode, the value is false.
*   `next_action` (object, nullable): If present, describes the action required to make this `SharedPaymentIssuedToken` usable for payments. Present when the token is in `requires_action` state.
*   `payment_method` (string): ID of an existing `PaymentMethod`.
*   `risk_details` (object, nullable): Risk details of the `SharedPaymentIssuedToken`.
*   `seller_details` (object, nullable): Seller details of the `SharedPaymentIssuedToken`, including `network_id` and `external_id`.
*   `setup_future_usage` (enum, nullable): Indicates that you intend to save the `PaymentMethod` of this `SharedPaymentToken` to a customer later. Possible values: `on_session`.
*   `shared_metadata` (object, nullable): Metadata about the `SharedPaymentIssuedToken`.
*   `status` (string): The status of the `SharedPaymentIssuedToken`.
*   `usage_details` (object, nullable): Some details about how the `SharedPaymentIssuedToken` has been used already.
*   `usage_limits` (object, nullable): Limits on how this `SharedPaymentIssuedToken` can be used.

## Shared Payment Granted Token

A `SharedPaymentGrantedToken` is the view-only resource of a `SharedPaymentIssuedToken`, which is a limited-use reference to a `PaymentMethod`. When another Stripe merchant shares a `SharedPaymentIssuedToken` with you, you can view attributes of the shared token using the `SharedPaymentGrantedToken` API, and use it with a `PaymentIntent`.

### Retrieve a SharedPaymentGrantedToken

Retrieves an existing `SharedPaymentGrantedToken` object.

**Endpoint:** `GET /v1/shared_payment/granted_tokens/:id`

### Create a test SharedPaymentGrantedToken

Creates a new test `SharedPaymentGrantedToken` object. This endpoint is only available in test mode.

**Endpoint:** `POST /v1/test_helpers/shared_payment/granted_tokens`

**Parameters:**

*   `payment_method` (string, required): The `PaymentMethod` that is going to be shared by the `SharedPaymentGrantedToken`.
*   `usage_limits` (object, required): Limits on how this `SharedPaymentGrantedToken` can be used.
    *   `currency` (string)
    *   `expires_at` (timestamp)
    *   `max_amount` (integer)
*   `customer` (string, optional): The Customer that the `SharedPaymentGrantedToken` belongs to.
*   `shared_metadata` (object, optional): Set of key-value pairs that you can attach to the `SharedPaymentGrantedToken`.

### Revoke a test SharedPaymentGrantedToken

Revokes a test `SharedPaymentGrantedToken` object. This endpoint is only available in test mode.

**Endpoint:** `POST /v1/test_helpers/shared_payment/granted_tokens/:id/revoke`

### The Shared Payment Granted Token object

Attributes of a `SharedPaymentGrantedToken`:

*   `id` (string): Unique identifier for the object.
*   `object` (string): String representing the object’s type.
*   `agent_details` (object, nullable): Details about the agent that issued this `SharedPaymentGrantedToken`.
*   `created` (timestamp): Time at which the object was created.
*   `deactivated_at` (timestamp, nullable): Time at which this `SharedPaymentGrantedToken` expires and can no longer be used to confirm a `PaymentIntent`.
*   `deactivated_reason` (enum, nullable): The reason why the `SharedPaymentGrantedToken` has been deactivated. Possible values: `consumed`, `expired`, `resolved`, `revoked`.
*   `livemode` (boolean): If the object exists in live mode, the value is true. If the object exists in test mode, the value is false.
*   `payment_method_details` (object, nullable): Details of the `PaymentMethod` that was shared via this token.
*   `risk_details` (object, nullable): Risk details of the `SharedPaymentGrantedToken`.
*   `shared_metadata` (object, nullable): Metadata about the `SharedPaymentGrantedToken`.
*   `usage_details` (object, nullable): Some details about how the `SharedPaymentGrantedToken` has been used already.
*   `usage_limits` (object, nullable): Limits on how this `SharedPaymentGrantedToken` can be used.
```
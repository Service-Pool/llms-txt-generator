# Shared Payment Issued Token

A `SharedPaymentIssuedToken` is a limited-use reference to a `PaymentMethod` that can be created with a secret key. When shared with another Stripe account (Seller), it enables that account to either process a payment on Stripe against a `PaymentMethod` that your Stripe account owns, or to forward a usable credential created against the original `PaymentMethod` to then process the payment off-Stripe.

## Endpoints

### Create a SharedPaymentIssuedToken

Creates a new `SharedPaymentIssuedToken` object.

**POST** `/v1/shared_payment/issued_tokens`

**Parameters:**

*   `payment_method` (string, required): The PaymentMethod that is going to be shared by the SharedPaymentIssuedToken.
*   `seller_details` (object, required): Seller details of the SharedPaymentIssuedToken, including `network_id` and `external_id`.
    *   `external_id` (string)
    *   `network_business_profile` (string)
*   `usage_limits` (object, required): Limits on how this SharedPaymentToken can be used.
    *   `currency` (string)
    *   `expires_at` (timestamp)
    *   `max_amount` (integer)
*   `setup_future_usage` (enum, optional): Indicates that you intend to save the PaymentMethod of this SharedPaymentToken to a customer later. Possible values: `on_session`.
*   `shared_metadata` (object, optional): Set of key-value pairs that you can attach to the SharedPaymentIssuedToken. The values here are visible by default with the party that you share this SharedPaymentIssuedToken with.

**Returns:** The newly created `SharedPaymentIssuedToken`.

### Retrieve a SharedPaymentIssuedToken

Retrieves an existing `SharedPaymentIssuedToken` object.

**GET** `/v1/shared_payment/issued_tokens/:id`

**Returns:** The specified `SharedPaymentIssuedToken`.

### Revoke a SharedPaymentIssuedToken

Revokes a `SharedPaymentIssuedToken`.

**POST** `/v1/shared_payment/issued_tokens/:id/revoke`

**Returns:** The revoked `SharedPaymentIssuedToken`.

## The Shared Payment Issued Token Object

The `SharedPaymentIssuedToken` object represents a token that can be used to facilitate shared payments.

### Attributes

*   `id` (string): Unique identifier for the object.
*   `object` (string): String representing the object’s type. Objects of the same type share the same value.
*   `created` (timestamp): Time at which the object was created. Measured in seconds since the Unix epoch.
*   `deactivated_at` (timestamp, nullable): Time at which this `SharedPaymentIssuedToken` was deactivated.
*   `deactivated_reason` (enum, nullable): The reason why the `SharedPaymentIssuedToken` has been deactivated. Possible enum values: `consumed`, `expired`, `resolved`, `revoked`.
*   `livemode` (boolean): If the object exists in live mode, the value is true. If the object exists in test mode, the value is false.
*   `next_action` (object, nullable): If present, describes the action required to make this `SharedPaymentIssuedToken` usable for payments. Present when the token is in `requires_action` state.
*   `payment_method` (string): ID of an existing `PaymentMethod`.
*   `risk_details` (object, nullable): Risk details of the `SharedPaymentIssuedToken`.
*   `seller_details` (object, nullable): Seller details of the `SharedPaymentIssuedToken`, including `network_id` and `external_id`.
*   `setup_future_usage` (enum, nullable): Indicates that you intend to save the `PaymentMethod` of this `SharedPaymentToken` to a customer later. Possible enum values: `on_session`.
*   `shared_metadata` (object, nullable): Metadata about the `SharedPaymentIssuedToken`.
*   `status` (string): The status of the SharedPaymentIssuedToken.
*   `usage_details` (object, nullable): Some details about how the `SharedPaymentIssuedToken` has been used already.
*   `usage_limits` (object, nullable): Limits on how this `SharedPaymentIssuedToken` can be used.
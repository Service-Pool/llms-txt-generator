# Shared Payment Issued Token

A `SharedPaymentIssuedToken` is a limited-use reference to a `PaymentMethod` that can be created with a secret key. When shared with another Stripe account (Seller), it enables that account to either process a payment on Stripe against a `PaymentMethod` that your Stripe account owns, or to forward a usable credential created against the original `PaymentMethod` to then process the payment off-Stripe.

## Create a SharedPaymentIssuedToken

Creates a new `SharedPaymentIssuedToken` object.

**POST** `/v1/shared_payment/issued_tokens`

### Parameters

| Parameter         | Type   | Required | Description

<!-- truncated by AI -->
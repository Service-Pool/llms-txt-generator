# Shared Payment Granted Token

The Shared Payment Granted Token API allows you to interact with view-only resources of a `SharedPaymentIssuedToken`. This is a limited-use reference to a `PaymentMethod` that has been shared with you by another Stripe merchant. You can use these granted tokens to view attributes of the shared token and utilize them with a `PaymentIntent`.

## Create a test SharedPaymentGrantedToken

This endpoint creates a new test `SharedPaymentGrantedToken` object. It is only available in test mode and is useful for testing your integration.

**Endpoint:** `POST /v1/test_helpers/shared_payment/granted_tokens`

**Parameters:**

*   `payment_method` (string, required): The `PaymentMethod` that will be shared by the `SharedPaymentGrantedToken`.
*   `usage_limits` (object, required): Defines the limits for how this `SharedPaymentGrantedToken` can be used.
    *   `currency` (string): The currency for the usage limits.
    *   `expires_at` (timestamp): The Unix timestamp when the token expires.
    *   `max_amount` (integer): The maximum amount that can be captured using this token.
*   `customer` (string, optional): The Customer the `SharedPaymentGrantedToken` belongs to. This should match the Customer the `PaymentMethod` is attached to, if applicable.
*   `shared_metadata` (object, optional): A set of key-value pairs that you can attach to the `SharedPaymentGrantedToken`.

**Response:** Returns the newly created `SharedPaymentGrantedToken` object.

**Example Request:**

```bash
curl https://api.stripe.com/v1/test_helpers/shared_payment/granted_tokens \
  -u "sk_test_..." \
  -d payment_method={{PAYMENT_METHOD_ID}} \
  -d "usage_limits[currency]=usd" \
  -d "usage_limits[expires_at]=1751587220" \
  -d "usage_limits[max_amount]=1000"
```
## Revoke a Test SharedPaymentGrantedToken

This endpoint allows you to revoke a test `SharedPaymentGrantedToken` object. This is useful for testing scenarios where a token needs to be invalidated before its natural expiration or consumption. This endpoint is only available in test mode.

### API Endpoint

```
POST /v1/test_helpers/shared_payment/granted_tokens/:id/revoke
```

### Parameters

This endpoint does not accept any parameters. The token to be revoked is identified by its ID in the URL.

### Response

The API will return the revoked `SharedPaymentGrantedToken` object, reflecting its deactivated state and the reason for deactivation.

**Example Response:**

```json
{
  "id": "spt_1RgaZcFPC5QUO6ZCDVZuVA8q",
  "object": "shared_payment.granted_token",
  "agent_details": {
    "network_business_profile": "profile_test_61U92KWAstyE3VYhXA6U91t01FSQ3ByrZzKJOCR0y5ey"
  },
  "created": 1751500820,
  "deactivated_at": 1751587220,
  "deactivated_reason": "revoked",
  "livemode": false,
  "payment_method_details": {
    "type": "card",
    "billing_details": {
      "address": {
        "city": null,
        "country": null,
        "line1": null,
        "line2": null,
        "postal_code": null,
        "state": null
      },
      "email": null,
      "name": "John Doe",
      "phone": null
    },
    "card": {
      "brand": "visa",
      "country": "US",
      "display_brand": "visa",
      "exp_month": 9,
      "exp_year": 2029,
      "fingerprint": "dyRcYjZNxnHpC51l",
      "funding": "credit",
      "last4": "4242",
      "networks": {
        "available": [
          "visa"
        ],
        "preferred": null
      },
      "wallet": null
    }
  },
  "shared_metadata": {},
  "usage_details": {
    "amount_captured": {
      "value": 0,
      "currency": "usd"
    }
  },
  "usage_limits": {
    "currency": "usd",
    "expires_at": 1751587220,
    "max_amount": 1000
  }
}
```
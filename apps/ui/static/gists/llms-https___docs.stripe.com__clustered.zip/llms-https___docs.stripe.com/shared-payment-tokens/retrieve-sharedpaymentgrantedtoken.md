# Shared Payment Granted Token

The Shared Payment Granted Token API allows you to interact with view-only resources of a `SharedPaymentIssuedToken`. This is a limited-use reference to a `PaymentMethod`. When another Stripe merchant shares a `SharedPaymentIssuedToken` with you, you can view its attributes using the `SharedPaymentGrantedToken` API and use it with a `PaymentIntent`.

## Retrieve a SharedPaymentGrantedToken

Retrieves an existing `SharedPaymentGrantedToken` object.

**Endpoint:** `GET /v1/shared_payment/granted_tokens/:id`

**Parameters:**
This endpoint does not require any parameters.

**Returns:**
The specified `SharedPaymentGrantedToken` object.

**Example Request:**

```bash
curl https://api.stripe.com/v1/shared_payment/granted_tokens/spt_1RgaZcFPC5QUO6ZCDVZuVA8q \
  -u "sk_test_..."
```

**Example Response:**

```json
{
  "id": "spt_1RgaZcFPC5QUO6ZCDVZuVA8q",
  "object": "shared_payment.granted_token",
  "agent_details": {
    "network_business_profile": "profile_test_61U92KWAstyE3VYhXA6U91t01FSQ3ByrZzKJOCR0y5ey"
  },
  "created": 1751500820,
  "deactivated_at": null,
  "deactivated_reason": null,
  "livemode": false,
  "payment_method_details": {
    "type": "card",
    "billing_details": {
      "address": {
        "city": null,
        "country": null,
        "line1": null,
        "line2": null,
        "postal_code": null,
        "state": null
      },
      "email": null,
      "name": "John Doe",
      "phone": null
    },
    "card": {
      "brand": "visa",
      "country": "US",
      "display_brand": "visa",
      "exp_month": 9,
      "exp_year": 2029,
      "fingerprint": "dyRcYjZNxnHpC51l",
      "funding": "credit",
      "last4": "4242",
      "networks": {
        "available": [
          "visa"
        ],
        "preferred": null
      },
      "wallet": null
    }
  },
  "shared_metadata": {},
  "usage_details": {
    "amount_captured": {
      "value": 0,
      "currency": "usd"
    }
  },
  "usage_limits": {
    "currency": "usd",
    "expires_at": 1751587220,
    "max_amount": 1000
  }
}
```
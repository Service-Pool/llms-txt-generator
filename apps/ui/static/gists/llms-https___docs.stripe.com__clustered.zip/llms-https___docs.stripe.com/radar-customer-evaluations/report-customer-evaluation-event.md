# Report an Event on a Customer Evaluation

This endpoint allows you to report an event on a specific Customer Evaluation object. This is useful for tracking customer behavior and providing context for fraud detection.

## Reporting an Event

To report an event, you will make a `POST` request to the `/v1/radar/customer_evaluations/:id/report` endpoint. You need to specify the `type` of event you are reporting.

### Request

```
POST /v1/radar/customer_evaluations/:id/report
```

#### Parameters

| Parameter | Type   | Required | Description

<!-- truncated by AI -->
## Mapping Stripe Transactions to Your General Ledger

This section details how to customize Stripe Revenue Recognition to align with your organization's unique accounting structure. It covers mapping Stripe's default accounts to your General Ledger (GL) chart of accounts, enabling more accurate financial reporting and analysis.

### Key Concepts:

*   **General Ledger (GL) Chart of Accounts:** A comprehensive list of all financial accounts used by a company to record transactions.
*   **Stripe Default Accounts:** Predefined accounts within Stripe that categorize financial activities.
*   **Mapping:** The process of associating Stripe's default accounts with your specific GL accounts.

### Customizing Revenue Recognition Reporting:

You can tailor Stripe Revenue Recognition reports to reflect your GL chart of accounts instead of relying solely on Stripe's default accounts. This customization can be applied to:

*   **Downloaded CSV reports:** Ensures that exported financial data aligns with your internal accounting system.
*   **Revenue Audits:** Provides a consistent view of revenue numbers across both Stripe and your GL.

### Mapping Rule Components:

A mapping rule is defined by the following attributes:

*   **Stripe Account:** The default Stripe account you wish to override (e.g., "Revenue", "AccountsReceivable").
*   **GL Account:** The name of the corresponding account in your General Ledger.
*   **GL Account Number:** The numerical identifier for the GL account.
*   **Time Period:** The effective date range for the mapping.
    *   For invoice line items, the mapping applies if the invoice's finalization time falls within this period.
    *   For charges, the mapping applies if the creation time of the associated balance transaction falls within this period.
*   **Condition (Optional):** Specific criteria to refine the mapping. This allows you to map transactions based on:
    *   Product
    *   Shipping Region
    *   Invoice Metadata

If no condition is specified, all transactions associated with the configured Stripe account will be mapped to the designated GL account.

### Status of Mapping Rules:

*   **Active:** The mapping rule is currently in effect.
*   **Inactive:** The mapping rule is not currently applied.
## Invite Your Accountant

Invite your internal or external accountant to access Stripe Revenue Recognition directly to help ensure your books are audit-ready.

Accountants are the primary users of financial statements, but might lack the specific access needed to configure the accounting logic and settings. Providing accountant access overcomes the limitations of view-only access, and mitigates the risks of offering full administrator access.

*   **Firsthand evaluation:** Allows accountants to directly test the platform’s suitability for your business’ month-end book closure process.
*   **Operational autonomy:** Accountants can independently modify amortization settings, create custom charts of accounts, and update recognition rules.
*   **Prevents sensitive changes:** Unlike an administrator role, this access prevents accountants from modifying sensitive business data, changing product plans, or managing payouts.

### Permissions

Accountant access provides a tailored balance of high-level edit permissions within Stripe Revenue Recognition and a restricted view-only access elsewhere on the Stripe dashboard. Learn more about user roles.

Accountants can set up a custom chart of accounts, create accounting rules and modify revenue amortization settings. They can also view payments, balances, invoices, customers, and connected accounts, and so on, but can’t edit any of them.

They can’t create connected accounts, transfer funds, payout money, choose pricing plans, or edit any account and other product settings.
## Financial Reporting and Reconciliation

This documentation section covers how to generate and utilize Stripe's financial reports for reconciliation and accounting purposes. It details various reports available, how to configure them, and how to integrate Stripe data with external accounting tools.

### Key Concepts

*   **Bank Reconciliation:** The process of comparing Stripe payouts with your bank account to ensure accuracy and track cash flow. Stripe offers a dedicated **Bank reconciliation report** for this purpose.
*   **Payout Reconciliation:** A report that helps match Stripe payouts with the specific batches of transactions they settle. This is particularly useful for users with automatic payouts.
*   **Balance Summary Report:** This report acts like a bank statement for your Stripe account, providing an itemized view of your transaction history and helping you reconcile your Stripe balance.
*   **Accounting Integrations:** Stripe offers integrations with popular accounting software like QuickBooks and NetSuite, as well as a general "Integrate an accounting tool" guide, to streamline data import and bookkeeping.
*   **Reporting Categories:** Understanding how Stripe categorizes transactions is crucial for accurate reporting. The **Reporting categories and types** page explains the `reporting_category` field on `BalanceTransaction` objects.
*   **Standalone Fees:** Fees that are applied separately from the initial transaction, typically within 36 hours. The **Standalone fees** report helps track these.
*   **Stripe Fee Credits:** Information on how fee credits are applied, their expiration, and how to view them.
*   **Revenue Recognition:** A comprehensive feature that automates accrual accounting, helping businesses comply with standards like ASC 606 and IFRS 15. This includes detailed reports, data import capabilities, and customizable rules.

### Reports and Their Uses

Stripe offers a variety of reports to cater to different financial needs:

*   **Balance Report:** Reconcile your Stripe balance like a bank account.
*   **Payout Reconciliation Report:** Break down individual transactions included in each payout.
*   **Bank Reconciliation Report:** Reconcile Stripe payouts with bank deposits.
*   **Fees Report:** View all fees charged by Stripe, networks, and external partners.
*   **Stripe Fee Credits:** Track and manage applied fee credits.
*   **Standalone Fees:** Understand and assess the impact of standalone fees.
*   **Balance Summary Report:** Reconcile your Stripe balance and download categorized transaction history.
*   **Revenue Recognition Reports:**
    *   Monthly Summary
    *   Trial Balance
    *   Income Statement
    *   Balance Sheet
    *   Accounts Receivable Aging
    *   Debits and Credits
    *   Revenue Waterfall
    *   Activity Breakdown

### Configuring and Accessing Reports

*   **How Report Configuration Works:** Understand common report configuration settings, including filters for date range, currency, and connect accounts.
*   **How to Select a Report:** A guide to choosing the right report based on your specific task.
*   **Running Reports via API:** Retrieve reports programmatically using the Stripe API.
*   **Creating Custom Reports:** Utilize Stripe Sigma for custom report generation with SQL.

### Revenue Recognition Specifics

*   **Revenue Recognition Overview:** Automate accrual accounting with Stripe Revenue Recognition, including setup, methodology, and use cases.
*   **Data Import:** Import data from various sources (CSV, Apple App Store, Google Play) to manage all revenue recognition in Stripe.
*   **Data Freshness:** Understand when data becomes available for Revenue Recognition reports.
*   **Data Reconciliation:** Reconcile revenue recognition data with other financial reports.
*   **Examples:** Explore various examples of how Revenue Recognition works for different scenarios like FX and currency, subscriptions, and contra examples.
*   **Rules:** Customize rules to define specific revenue treatments for your business.
*   **Settings:** Adjust the behavior of Stripe Revenue Recognition with customizable settings, including accounting period control and amortization granularity.
*   **Invite Accountant:** Grant accountants direct access to Stripe Revenue Recognition for streamlined audits.
*   **Performance Obligations API:** Model performance obligation fulfillment for accurate revenue recognition.
*   **Audit Your Numbers:** Examine the details of your revenue numbers directly within the Stripe Dashboard.

### Integrating with Accounting Tools

*   **Integrate an Accounting Tool:** General guidance on integrating accounting solutions with Stripe, including specific instructions for QuickBooks and NetSuite.
*   **Accounting with Stripe Apps:** Utilize Stripe Apps to automate bookkeeping and keep financial data updated.
## Reporting and Reconciliation

Stripe offers a suite of reporting tools designed to help you understand your financial activity, reconcile your accounts, and integrate with your accounting systems. These tools provide detailed insights into your transactions, payouts, fees, and overall balance.

### Understanding Your Financial Data

*   **Balance Summary Report (`/reports/balance`)**: This report acts as a bank statement for your Stripe account, allowing you to reconcile your Stripe balance at the end of each month. It provides an itemized CSV export of your transaction history, including any custom metadata. This is particularly useful if you treat your Stripe account as a bank account for accounting purposes.
*   **Payout Reconciliation Report (`/reports/payout-reconciliation`)**: This report helps you match the payouts you receive in your bank account with the specific batches of transactions they settle. It's designed for users with automatic payouts who prefer to reconcile transactions on a per-payout basis.
*   **Bank Reconciliation (`/bank-reconciliation`)**: This feature enables you to reconcile your Stripe payouts with the cash in your bank account, providing a monthly summary of activity and helping you track funds from Stripe to your bank. It's currently available for direct US-based Stripe accounts with automated payouts.
*   **Fees Report**: This report details all fees charged by Stripe, networks, and external partners across your products and services.
*   **Standalone Fees (`/standalone-fees`)**: Understand how Stripe applies transaction fees separately from the initial transaction, with fees credited later. This report is available for all standalone fee users.
*   **Stripe Fee Credits (`/stripe-fee-credits`)**: Learn how to apply, view, and reconcile fee credits to offset your service costs.

### Selecting the Right Report

Stripe provides a guide to help you choose the most suitable report for your specific task:

*   **How to Select a Report (`/reports/select-a-report`)**: This page offers a table to identify the best report based on your task, whether it's downloading monthly transaction history, reconciling your Stripe balance, or viewing payout details.

### Configuring and Customizing Reports

*   **How Report Configuration Works (`/reports/options`)**: This page details common report configuration settings and controls, including filters for date range, currency, and connected accounts. You can customize your reports to view the data most relevant to your analysis.
*   **Reporting Categories and Types (`/reports/reporting-categories`)**: Understand the `reporting_category` field on BalanceTransaction objects, which provides a more useful grouping for finance and reporting purposes compared to the `type` field.

### Integrating with Accounting Tools

*   **Integrate an Accounting Tool (`/accounting-integrations`)**: Connect your accounting solution with Stripe to automate bookkeeping, keep financial data updated, and eliminate manual data entry. This includes options for QuickBooks, NetSuite, and other Stripe apps.

### Revenue Recognition

Stripe's Revenue Recognition feature automates your accrual accounting process, helping you comply with global accounting standards.

*   **Revenue Recognition (`/revenue-recognition`)**: This is the central hub for understanding and implementing Stripe's revenue recognition capabilities.
*   **How Revenue Recognition Works (`/revenue-recognition/methodology`)**: Learn the fundamental principles of how Stripe calculates, defers, and reports your revenue according to GAAP.
*   **Revenue Recognition Reports (`/revenue-recognition/reports`)**: Generate and export various reports, such as monthly summaries, trial balances, income statements, balance sheets, and revenue waterfalls, to analyze your revenue and prepare financial statements.
    *   **Activity Breakdown (`/revenue-recognition/reports/activity-breakdown`)**: Audit transaction and invoice-level activity with advanced grouping and filtering.
    *   **Accounts Receivable Aging (`/revenue-recognition/reports/accounts-receivable-aging`)**: Monitor outstanding invoices and assess credit risk.
    *   **Audit Your Numbers (`/revenue-recognition/reports/audit-numbers`)**: Examine the details of your revenue numbers directly within the Stripe Dashboard.
    *   **Balance Sheet (`/revenue-recognition/reports/balance-sheet`)**: Review your company's financial position at a specific point in time.
    *   **Debits and Credits (`/revenue-recognition/reports/debits-and-credits`)**: View detailed transaction entries for reconciliation and auditing.
    *   **Income Statement (`/revenue-recognition/reports/income-statement`)**: Analyze revenue, expenses, and net income for a specified period.
    *   **Revenue Waterfall (`/revenue-recognition/reports/waterfall`)**: View and analyze monthly revenue with a detailed waterfall breakdown.
    *   **Trial Balance (`/revenue-recognition/reports/trial-balance`)**: Review account balances and ensure your books are balanced.
*   **Data Management**:
    *   **Revenue Recognition Data Freshness (`/revenue-recognition/data-freshness`)**: Understand when data becomes available for your revenue recognition reports.
    *   **Revenue Recognition Data Import (`/revenue-recognition/data-import`)**: Import data from other sources to manage all your revenue recognition in Stripe.
        *   **Stripe Connector for Apple App Store (`/revenue-recognition/data-import/apple-app-store`)**: Automatically import subscription purchases from the Apple App Store.
        *   **Stripe Connector for Google Play (`/revenue-recognition/data-import/google-play`)**: Automatically import subscription purchases from Google Play.
        *   **Manage Imported Data (`/revenue-recognition/data-import/manage-imported-data`)**: Search for and manage your imported revenue recognition data.
        *   **Error Handling for Data Import (`/revenue-recognition/data-import/error-handling`)**: Learn how to handle and recover from errors during data import.
        *   **Data Import Examples (`/revenue-recognition/data-import/examples`)**: Apply data import to common use cases.
*   **Configuration and Customization**:
    *   **Revenue Recognition Settings (`/revenue-recognition/revenue-settings`)**: Customize how revenue is recognized for your business.
        *   **Revenue Recognition Accounting Period Control (`/revenue-recognition/revenue-settings/accounting-period-control`)**: Manage and customize your accounting calendar and period closing.
        *   **Revenue Recognition Settings Examples (`/revenue-recognition/revenue-settings/examples`)**: Learn about revenue settings through practical examples.
    *   **Revenue Recognition Rules (`/revenue-recognition/rules`)**: Configure custom rules to define revenue treatments specific to your business needs.
        *   **Create a Rule (`/revenue-recognition/rules/create-a-rule`)**: Learn how to create and manage Revenue Recognition rules.
    *   **Map to Your Chart of Accounts (`/revenue-recognition/chart-of-accounts`)**: Map transactions from Stripe's default accounts to your general ledger.
    *   **Bulk Account Mapping (`/revenue-recognition/chart-of-accounts/bulk-account-mapping`)**: Simultaneously upload multiple chart of accounts mappings.
    *   **Standalone Selling Prices (`/revenue-recognition/standalone-selling-price`)**: Accurately allocate revenue for bundled products.
    *   **Revenue Recognition with Multiple Currencies (`/revenue-recognition/methodology/multi-currency`)**: Understand the roles of presentment and settlement currencies.
*   **Connect Platforms**:
    *   **Revenue Recognition for Connect Platforms (`/revenue-recognition/connect`)**: Learn how revenue recognition works with Connect platforms.
    *   **Revenue Recognition for Destination Charges (`/revenue-recognition/connect/destination-charges`)**: Understand revenue recognition with the destination charge model.
    *   **Revenue Recognition for Direct Charges (`/revenue-recognition/connect/direct-charges`)**: Learn how revenue recognition works with direct charges.
    *   **Revenue Recognition for Separate Charges and Transfers (`/revenue-recognition/connect/charges-transfers`)**: Understand revenue recognition with separate charges and transfers.
*   **Advanced Features**:
    *   **Revenue Recognition Contracts (`/revenue-recognition/revenue-contracts`)**: Model enterprise B2B sales contracts.
    *   **Revenue Recognition Performance Obligations API (`/revenue-recognition/performance-obligations-api`)**: Model performance obligation fulfillment.
    *   **Invite Your Accountant (`/revenue-recognition/invite-accountant`)**: Grant your accountant direct access to Stripe Revenue Recognition.
    *   **Revenue Recognition Examples (`/revenue-recognition/examples`)**: Explore common scenarios and use cases for revenue recognition.
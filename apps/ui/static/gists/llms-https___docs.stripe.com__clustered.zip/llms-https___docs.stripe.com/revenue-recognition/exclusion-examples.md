## Managing Financial Data and Revenue Recognition

This section of the documentation provides comprehensive guidance on managing your financial data within Stripe, focusing on reconciliation, reporting, and advanced revenue recognition functionalities.

### Bank Reconciliation and Payout Management

*   **Bank Reconciliation (`/bank-reconciliation`)**: Learn how to reconcile your Stripe payouts with the cash in your bank account. This report helps you track funds from Stripe to your bank, understand monthly activity summaries, and ensure accurate bookkeeping. It's currently available for US-based Stripe accounts with automated payouts.
*   **Payout Reconciliation (`/reports/payout-reconciliation`)**: This report allows you to match individual payouts with the specific batches of transactions they settle. It's designed for users with automatic payouts who prefer to reconcile payouts as settlement batches.
*   **Balance Summary Report (`/reports/balance`)**: Similar to a bank statement, this report helps you reconcile your Stripe balance at the end of the month. It provides an itemized CSV export of your transaction history and associated metadata.

### Financial Reporting and Configuration

*   **How to Select a Report (`/reports/select-a-report`)**: This guide helps you choose the most suitable Stripe report based on your specific financial tasks, whether it's downloading transaction history, reconciling balances, or analyzing fees.
*   **How Report Configuration Works (`/reports/options`)**: Understand the common settings and controls available across Stripe's financial reports, including date range selection, time zone customization, and data availability.
*   **Reporting Categories and Types (`/reports/reporting-categories`)**: Gain insights into the `reporting_category` field on BalanceTransaction objects, which provides a more granular grouping for financial and reporting purposes compared to the `type` field.
*   **Standalone Fees (`/standalone-fees`)**: Understand how standalone fees are applied separately from transactions and how they impact your account. This includes information on when fees are applied and how they differ from inline fees.
*   **Stripe Fee Credits (`/stripe-fee-credits`)**: Learn how Stripe fee credits are applied to offset service costs, including their expiration, eligibility, and application order.

### Accounting Integrations

*   **Integrate an Accounting Tool (`/accounting-integrations`)**: Discover how to integrate your accounting solution with Stripe, including exporting data to QuickBooks and using Stripe apps to automate bookkeeping. This page also details the default accounts created in QuickBooks when using Stripe exports.

### Revenue Recognition

Stripe Revenue Recognition automates your accrual accounting process, helping you comply with global accounting standards.

*   **Revenue Recognition Overview (`/revenue-recognition`)**: Get a comprehensive introduction to Stripe Revenue Recognition, its benefits, use cases, and how it simplifies revenue recognition for various business models.
*   **How Revenue Recognition Works (`/revenue-recognition/methodology`)**: Understand the fundamental principles of revenue recognition, including how Stripe calculates, defers, and reports revenue according to GAAP and IFRS standards.
*   **Getting Started (`/revenue-recognition/get-started`)**: Learn how to set up and utilize Stripe Revenue Recognition, including importing transaction data, defining rules, generating reports, and testing your model.
*   **Revenue Recognition Settings (`/revenue-recognition/revenue-settings`)**: Customize how revenue is recognized for your business by adjusting settings such as accounting period control and amortization granularity.
    *   **Accounting Period Control (`/revenue-recognition/revenue-settings/accounting-period-control`)**: Manage your accounting calendar, including switching to a 4-4-5 calendar, and controlling how accounting periods are closed or reopened.
    *   **Revenue Recognition Settings Examples (`/revenue-recognition/revenue-settings/examples`)**: Explore practical examples demonstrating the impact of different amortization methods on revenue recognition.
*   **Revenue Recognition Rules (`/revenue-recognition/rules`)**: Configure custom rules to define specific revenue treatments for your business, such as categorizing line items, excluding transactions, or amortizing revenue over custom periods.
    *   **Create a Rule (`/revenue-recognition/rules/create-a-rule`)**: Step-by-step guide on creating and managing Revenue Recognition rules within the Stripe Dashboard.
*   **Revenue Recognition Reports (`/revenue-recognition/reports`)**: Generate and export various revenue reports from the Stripe Dashboard or via CSV to analyze revenue, deferred revenue, and booked revenue.
    *   **Activity Breakdown (`/revenue-recognition/reports/activity-breakdown`)**: Audit transaction and invoice-level activity with advanced grouping and filtering capabilities for detailed analysis.
    *   **Accounts Receivable Aging (`/revenue-recognition/reports/accounts-receivable-aging`)**: Monitor outstanding invoices, assess credit risk, and understand collections performance.
    *   **Audit Your Numbers (`/revenue-recognition/reports/audit-numbers`)**: Examine the details of your revenue numbers directly within the Stripe Dashboard, broken down by customer or transaction.
    *   **Balance Sheet (`/revenue-recognition/reports/balance-sheet`)**: Review your company's financial position at a specific point in time, listing assets and liabilities.
    *   **Debits and Credits (`/revenue-recognition/reports/debits-and-credits`)**: View detailed transaction entries for reconciliation and auditing purposes.
    *   **Income Statement (`/revenue-recognition/reports/income-statement`)**: Analyze revenue, expenses, and net income for a specified period.
    *   **Trial Balance (`/revenue-recognition/reports/trial-balance`)**: Review account balances and ensure the equality of debits and credits for period-end closing.
    *   **Revenue Waterfall (`/revenue-recognition/reports/waterfall`)**: Analyze monthly revenue, including booked, recognized, and remaining amounts.
*   **Data Management**:
    *   **Revenue Recognition Data Freshness (`/revenue-recognition/data-freshness`)**: Understand when data becomes available for Stripe Revenue Recognition reports and APIs.
    *   **Revenue Recognition Data Import (`/revenue-recognition/data-import`)**: Import data from other sources to manage all your revenue recognition in Stripe, including general imports, exclusion imports, and journal entry imports.
        *   **Stripe Connector for the Apple App Store (`/revenue-recognition/data-import/apple-app-store`)**: Automatically import subscription purchases from the Apple App Store into Stripe Revenue Recognition.
        *   **Error Handling for Data Import (`/revenue-recognition/data-import/error-handling`)**: Learn how to handle and recover from errors encountered during revenue recognition data import.
        *   **Data Import Examples (`/revenue-recognition/data-import/examples`)**: See practical examples of applying data import to common use cases.
        *   **Stripe Connector for Google Play (`/revenue-recognition/data-import/google-play`)**: Automatically import subscription purchases from Google Play into Stripe Revenue Recognition.
        *   **Manage Imported Data (`/revenue-recognition/data-import/manage-imported-data`)**: Search for and manage existing imported data within the Stripe Dashboard.
*   **Advanced Features**:
    *   **Revenue Recognition Contracts (`/revenue-recognition/revenue-contracts`)**: Model enterprise B2B sales contracts and customize revenue schedules independent of billing periods.
    *   **Standalone Selling Prices (`/revenue-recognition/standalone-selling-price`)**: Accurately allocate revenue for bundled products based on custom values or percentages.
    *   **Revenue Recognition with Multiple Currencies (`/revenue-recognition/methodology/multi-currency`)**: Understand the roles of presentment and settlement currencies in revenue recognition.
    *   **Revenue Recognition with Refunds and Disputes (`/revenue-recognition/methodology/refunds-and-disputes`)**: Learn how refunds and disputes impact your revenue recognition numbers.
    *   **Revenue Recognition with Subscriptions and Invoicing (`/revenue-recognition/methodology/subscriptions-and-invoicing`)**: Understand how Stripe Revenue Recognition accurately defers and recognizes revenue for subscriptions and invoices.
    *   **Revenue Recognition Performance Obligations API (`/revenue-recognition/performance-obligations-api`)**: Model performance obligation fulfillment for accurate revenue recognition.
    *   **Invite Your Accountant (`/revenue-recognition/invite-accountant`)**: Grant accountants direct access to Stripe Revenue Recognition for audit-ready books.
    *   **Revenue Recognition for Connect Platforms (`/revenue-recognition/connect`)**: Learn how revenue recognition works with Connect platforms, including destination charges, direct charges, and separate charges and transfers.
        *   **Revenue Recognition for Destination Charges (`/revenue-recognition/connect/destination-charges`)**
        *   **Revenue Recognition for Direct Charges (`/revenue-recognition/connect/direct-charges`)**
        *   **Revenue Recognition for Separate Charges and Transfers (`/revenue-recognition/connect/charges-transfers`)**
    *   **Revenue Recognition Transaction Overrides (`/revenue-recognition/overrides`)**: Make manual corrections to your revenue recognition reports (note: this feature is being deprecated in favor of data import).
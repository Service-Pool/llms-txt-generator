## Standalone Fees

Standalone fees offer an alternative method for Stripe to apply transaction fees. Instead of deducting fees in real-time during a transaction (inline fees), standalone fees credit the entire transaction amount to your account first, with fees applied later, typically within 36 hours.

### How Standalone Fees Work

*   **Transaction Credit First:** When a transaction occurs, the full amount is credited to your Stripe account.
*   **Fee Application Later:** Stripe then applies its transaction fees separately, usually within 36 hours of the initial transaction.
*   **Example:** For a $100 transaction with a $3 Stripe fee:
    *   **Inline Fees:** You receive $97 immediately, with the $3 fee applied in real-time.
    *   **Standalone Fees:** You initially receive the full $100. The $3 fee is then deducted from your account balance later.

### Fee Application and Reporting

*   **Default Behavior:** New Stripe accounts typically default to inline fees. However, accounts may transition to standalone fees for greater flexibility, particularly for custom pricing (e.g., tiered pricing) or when Stripe fee credits are applied.
*   **Per-Transaction Fees:** Fees for transactions are separated from the transaction itself and reported in aggregate per product at the end of the day. While the aggregated amounts are accurate, they are not directly tied to individual transactions, unlike inline fees.
*   **Fees Report:** All users utilizing standalone fees are enabled for the Fees report, which provides a consolidated view of these charges.
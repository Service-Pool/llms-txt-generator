## Revenue Recognition: Subscription Examples

This section details how Stripe Revenue Recognition handles subscription-based revenue, providing examples for monthly and annual subscriptions, as well as upgrades.

### Monthly Subscription

This example illustrates the revenue recognition for a standard monthly subscription.

**Assumptions:**

*   A customer starts a monthly subscription on January 15th at 00:00:00 UTC.
*   The subscription costs 31 USD.
*   The subscription generates an invoice, which finalizes and is paid on the same day.
*   The invoice and revenue periods are from January 15, 2026, to February 14, 2026.

**Revenue Recognition Breakdown:**

The 31 USD is recognized daily over the subscription period:

*   **January:** 17 days (January 15th to January 31st)
*   **February:** 14 days (February 1st to February 14th)

**Account Summary (End of January):**

| Account         | Revenue | Deferred Revenue |
| :-------------- | :------ | :--------------- |
| Revenue         | +17.00  |                  |
| DeferredRevenue |         | +14.00           |

This indicates that 17 USD of revenue was recognized for the days in January, and 14 USD is deferred to be recognized in February.

### Annual Subscription

This example demonstrates revenue recognition for a full-year subscription.

**Assumptions:**

*   A customer starts an annual subscription on January 1st at 00:00:00 UTC.
*   The subscription costs 365 USD.
*   The subscription generates an invoice, which finalizes and is paid on the same day.
*   The invoice and revenue periods are from January 1, 2026, to December 31, 2026.

**Revenue Recognition Breakdown:**

The 365 USD is recognized daily throughout the year.

**Account Summary (End of March):**

| Account         | Jan 2026 | Feb 2026 | Mar 2026 |
| :-------------- | :------- | :------- | :------- |
| Revenue         | +31.00   | +28.00   | +31.00   |
| DeferredRevenue | +334.00  | -28.00   | -31.00   |

This shows the recognized revenue for each month and the remaining deferred revenue to be recognized in subsequent months.

### Upgrade

This example illustrates how revenue recognition is handled when a customer upgrades their subscription.

**Assumptions:**

*   On April 1st at 00:00 UTC, a customer upgrades their subscription.

*(Note: The example for "Upgrade" is incomplete in the provided text. Further details would be needed to illustrate the revenue recognition treatment for subscription upgrades.)*
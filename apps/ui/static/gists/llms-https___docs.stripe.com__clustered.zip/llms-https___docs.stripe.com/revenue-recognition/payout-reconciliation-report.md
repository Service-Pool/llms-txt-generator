## Payout Reconciliation Report

The Payout Reconciliation report helps you match the payouts you receive in your bank account with the batches of transactions they settle.

### Key Features and Benefits:

*   **Match Payouts to Transactions:** Easily reconcile the payouts deposited into your bank account with the specific batches of Stripe transactions they represent.
*   **For Automatic Payouts:** This report is specifically designed for users who have automatic payouts enabled.
*   **Settlement Batch Reconciliation:** Optimized for users who prefer to reconcile transactions within each payout as a settlement batch.

### When to Use This Report:

*   **Automatic Payouts:** If you receive automatic payouts from Stripe, this report is your primary tool for reconciliation.
*   **Reconciling by Settlement Batch:** If your accounting process involves matching payouts to groups of transactions, this report is ideal.

### When to Consider Other Reports:

*   **Manual or Instant Payouts:** If you use manual or instant payouts, Stripe cannot automatically identify the transactions included in each payout. You will need to reconcile these manually against your transaction history.
*   **Treating Stripe as a Bank Account:** If you prefer to track and reconcile your entire Stripe balance like a traditional bank account, the **Balance report** is a better fit.

### Getting Started:

Use the controls at the top of the screen to select a date range for your report.

### Report Sections:

*   **Balance Summary:** Provides a high-level overview of your Stripe balance (available, pending, and reserved funds) for the selected date range.
*   **Payout Reconciliation:** Details the automatic payouts received in your bank account within the selected date range. Transactions within these settlement batches are grouped by reporting category.
*   **Failed Payouts:** Breaks down any payouts that failed.
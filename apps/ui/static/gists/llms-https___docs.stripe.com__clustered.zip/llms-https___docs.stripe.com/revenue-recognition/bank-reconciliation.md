## Bank Reconciliation

The Bank Reconciliation report in Stripe allows you to reconcile your Stripe payouts with the cash in your bank account. This helps you track the flow of funds from your Stripe account to your bank and ensures accurate bookkeeping.

**Key Features:**

*   **Monthly Summary:** Understand the overall activity on your Stripe account and its impact on payouts and your bank balance.
*   **Cash Realization Tracking:** Monitor the amount of cash that has been transferred from Stripe to your bank account.
*   **Payout Status:** Track all Stripe payouts and their reconciliation status in a single, centralized location.
*   **Book Closing:** Ensure you have the necessary data to accurately close your financial books.

**Availability:**

This feature is currently available for users with direct US-based Stripe accounts using an automated payout schedule. It is not accessible for:

*   Stripe Connect accounts
*   Users based outside the United States
*   Manual or instant payouts

**How it Works:**

Stripe reconciles your payouts with bank deposits by linking your bank account to Stripe and granting access for reconciliation. Once linked, Stripe automatically matches payouts with bank deposits.

**Important Note:** Stripe's reconciliation features are tools to assist your financial processes and are not a substitute for professional financial services or advice.
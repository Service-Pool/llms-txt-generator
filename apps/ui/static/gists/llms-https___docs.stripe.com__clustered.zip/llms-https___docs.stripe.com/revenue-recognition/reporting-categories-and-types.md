## Reporting Categories and Types

This section details the `reporting_category` field on `BalanceTransaction` objects and how it enhances transaction categorization for financial reporting.

### Understanding `reporting_category`

The `reporting_category` field provides a more granular and useful grouping of balance transactions compared to the `type` field, making it more suitable for most financial and reporting purposes.

### Key Improvements and Distinctions

*   **Detailed Breakdown of `type=adjustment`**: The `reporting_category` field separates transactions with `type=adjustment` into more specific categories, such as:
    *   `dispute`
    *   `dispute_reversal`
    *   `failed_refund`
    *   `fee` (for various types of fees and Connect platform fee refunds)

*   **Separate Category for Partial Capture Reversals**: When a payment is authorized and then captured for a lesser amount than the authorization, a specific balance transaction is created to reverse the uncaptured portion. This transaction, while having `type=refund`, is categorized with `reporting_category=partial_capture_reversal` to allow for distinct handling, potentially for accounting against the initial sale rather than as a separate refund.

*   **Consolidation of Multiple Types**: The `reporting_category` field consolidates various transaction `type` values into common, more intuitive categories for reporting.
## Revenue Recognition

Stripe Revenue Recognition automates your accrual accounting process, ensuring compliance with global accounting standards like ASC 606 and IFRS 15. This feature helps businesses, particularly public companies, large enterprises, and subscription-based businesses, accurately recognize and defer revenue, providing clear insights into profitability and financial health.

### Key Features and Benefits:

*   **Automated Revenue Calculation:** Processes all Stripe transactions (subscriptions, invoices, payments, refunds, disputes) in real-time.
*   **Accurate Deferral and Recognition:** Simplifies the complex process of deferring and recognizing revenue according to GAAP.
*   **Comprehensive Reporting:** Generates downloadable accounting reports and waterfall charts for detailed analysis and audit transparency.
*   **Customizable Rules and Settings:** Allows for tailored revenue treatments through configurable rules, accounting period controls, and amortization settings.
*   **Integration with Stripe Objects:** Leverages existing Stripe data for intelligent default settings.
*   **Multi-currency Support:** Handles presentment and settlement currencies, with options for a functional currency.
*   **Connect Platform Compatibility:** Supports revenue recognition for destination charges, direct charges, and separate charges and transfers.
*   **Data Import Capabilities:** Enables importing data from non-Stripe sources for a consolidated view of revenue.

### Getting Started:

1.  **Set up Revenue Recognition:** Available through the Stripe Dashboard. Some business use cases are automated, while others require additional setup.
2.  **Configure Rules and Settings:** Customize how revenue is recognized to match your business model.
3.  **Generate Reports:** Access and export detailed revenue reports from the Dashboard.
4.  **Test Your Model:** Utilize a sandbox environment for a 30-day free trial to explore features and test your transaction model.

### Core Concepts:

*   **Recognized Revenue:** Revenue that has been earned and recorded according to accounting principles.
*   **Deferred Revenue:** Revenue that has been received but not yet earned, recognized over time as services are delivered or goods are used.
*   **Performance Obligation:** A promise in a contract to transfer distinct goods or services to a customer. Revenue is recognized when these obligations are fulfilled.
*   **Accounting Periods:** Customizable periods (calendar months, 4-4-5 calendar) for closing books and reporting.
*   **Amortization:** The process of gradually recognizing revenue over the duration of a service period (supported by the second, day, or month).

### Use Cases:

*   **Subscription and Service-Based Businesses:** Accurately recognize recurring revenue.
*   **Businesses with Upfront Payments:** Manage deferred revenue for services or goods paid for in advance.
*   **Public Companies and Large Enterprises:** Comply with ASC 606 and GAAP/IFRS standards.
*   **Connect Platforms:** Track revenue from application fees across different charge models.
*   **Multi-currency Transactions:** Handle revenue recognition with varying presentment and settlement currencies.

### Reports and Data Management:

*   **Data Freshness:** Understand the estimated times for data availability in reports and APIs.
*   **Data Import:** Import data from external sources like the Apple App Store and Google Play, or via CSV files.
*   **Data Reconciliation:** Reconcile revenue recognition data with other financial reports like the Balance Summary.
*   **Reporting:** Access various reports including Monthly Summary, Trial Balance, Income Statement, Balance Sheet, Accounts Receivable Aging, Debits and Credits, Revenue Waterfall, and Activity Breakdown.
*   **Audit Your Numbers:** Examine detailed transaction and customer-level data within the Dashboard.
*   **Overrides:** Make manual corrections to revenue recognition reports (though data import is the recommended method moving forward).

### Advanced Features:

*   **Revenue Recognition Rules:** Define custom rules for specific revenue treatments, such as categorizing taxes, booking passthrough fees, or excluding certain transactions.
*   **Revenue Contracts:** Model enterprise B2B sales contracts and manage revenue schedules independent of billing periods.
*   **Standalone Selling Prices (SSP):** Accurately allocate revenue for bundled products.
*   **Performance Obligations API:** Model performance obligation fulfillment programmatically.
*   **Invite Your Accountant:** Grant accountants tailored access to Revenue Recognition features for collaboration.
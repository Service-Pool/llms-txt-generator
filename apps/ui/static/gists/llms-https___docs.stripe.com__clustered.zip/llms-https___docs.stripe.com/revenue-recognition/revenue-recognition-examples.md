## Reporting and Reconciliation

This section covers how to understand and reconcile your financial data within Stripe, including various reports and integration options.

### Understanding Your Financial Data

*   **/reports/balance**: Provides a detailed breakdown of your Stripe balance, similar to a bank statement, helping you reconcile your monthly activity.
*   **/reports/payout-reconciliation**: Helps you match individual Stripe payouts with the specific transactions they settle, ideal for users with automatic payouts.
*   **/reports/bank-reconciliation**: Enables reconciliation of Stripe payouts with cash in your bank account, focusing on the movement of funds from Stripe to your bank.
*   **/reports/fees**: Details all fees charged by Stripe, networks, and external partners.
*   **/reports/standalone-fees**: Explains how standalone fees are applied separately from transactions, typically within 36 hours.
*   **/stripe-fee-credits**: Describes how Stripe fee credits are applied to offset service costs, including their expiration and application order.
*   **/reports/reporting-categories**: Clarifies the `reporting_category` field on `BalanceTransaction` objects, offering a more granular grouping for financial reporting than the `type` field.

### Integrating with Accounting Tools

*   **/accounting-integrations**: Guides you on integrating Stripe data with accounting solutions like QuickBooks and NetSuite, including details on account mapping and automated bookkeeping.
*   **/revenue-recognition/chart-of-accounts**: Explains how to map Stripe's default accounts to your own General Ledger (GL) chart of accounts for customized revenue recognition reporting.
*   **/revenue-recognition/chart-of-accounts/bulk-account-mappings**: Allows for the simultaneous upload of multiple chart of accounts mappings via CSV to streamline your Stripe to GL setup.

### Revenue Recognition

Stripe Revenue Recognition helps automate your accrual accounting process, ensuring compliance with accounting standards and providing accurate financial insights.

*   **/revenue-recognition**: An overview of Stripe Revenue Recognition, its benefits, and how it simplifies revenue recognition for various business models.
*   **/revenue-recognition/methodology**: Details how Stripe Revenue Recognition calculates, defers, and reports revenue based on GAAP principles.
*   **/revenue-recognition/get-started**: A guide to setting up and using Stripe Revenue Recognition, including generating reports and testing your transaction model.
*   **/revenue-recognition/rules**: Explains how to configure custom rules to define specific revenue treatments for your business.
*   **/revenue-recognition/rules/create-a-rule**: Step-by-step instructions on creating custom revenue recognition rules.
*   **/revenue-recognition/revenue-settings**: How to adjust Stripe Revenue Recognition behavior through settings like accounting period control and amortization granularity.
*   **/revenue-recognition/revenue-settings/accounting-period-control**: Customizing your accounting calendar and controlling the closing of accounting periods.
*   **/revenue-recognition/revenue-settings/examples**: Demonstrates the impact of different amortization methods on revenue recognition.
*   **/revenue-recognition/standalone-selling-price**: How to set up standalone selling prices for bundled products to accurately allocate revenue.
*   **/revenue-recognition/performance-obligations-api**: Details on modeling performance obligation fulfillment for revenue recognition.
*   **/revenue-recognition/connect**: How Revenue Recognition works for Connect platforms, covering destination charges, direct charges, and separate charges/transfers.
*   **/revenue-recognition/connect/destination-charges**: Specifics on revenue recognition for destination charges in Stripe Connect.
*   **/revenue-recognition/connect/direct-charges**: Specifics on revenue recognition for direct charges in Stripe Connect.
*   **/revenue-recognition/connect/charges-transfers**: Specifics on revenue recognition for separate charges and transfers in Stripe Connect.
*   **/revenue-recognition/data-import**: Importing data from other sources to manage all your revenue recognition in Stripe.
*   **/revenue-recognition/data-import/apple-app-store**: Using the Stripe Connector to automatically import subscription purchases from the Apple App Store.
*   **/revenue-recognition/data-import/google-play**: Using the Stripe Connector to automatically import subscription purchases from Google Play.
*   **/revenue-recognition/data-import/manage-imported-data**: Managing imported data through the Stripe Dashboard, including status and error handling.
*   **/revenue-recognition/data-import/error-handling**: How to handle and recover from errors encountered during revenue recognition data import.
*   **/revenue-recognition/data-import/examples**: Practical examples of applying data import for various revenue recognition use cases.
*   **/revenue-recognition/data-freshness**: Understanding when data becomes available for Stripe Revenue Recognition reports.
*   **/revenue-recognition/data-reconciliation**: Reconciling revenue recognition data with other Stripe financial reports.
*   **/revenue-recognition/reports**: Overview of the various reports available within Stripe Revenue Recognition.
*   **/revenue-recognition/reports/monthly-summary**: A monthly summary of revenue recognition activity.
*   **/revenue-recognition/reports/trial-balance**: Viewing and analyzing account balances over specific periods to ensure debits equal credits.
*   **/revenue-recognition/reports/income-statement**: Analyzing revenue, expenses, and net income for a specified period.
*   **/revenue-recognition/reports/balance-sheet**: Reviewing your company's financial position (assets, liabilities) at a specific point in time.
*   **/revenue-recognition/reports/accounts-receivable-aging**: Monitoring outstanding invoices and assessing credit risk.
*   **/revenue-recognition/reports/debits-and-credits**: Viewing detailed transaction entries for reconciliation and auditing.
*   **/revenue-recognition/reports/revenue-waterfall**: Analyzing monthly revenue booked and recognized over time.
*   **/revenue-recognition/reports/activity-breakdown**: Detailed, transaction-level data for analyzing accounting activity.
*   **/revenue-recognition/reports/audit-numbers**: Examining the details of your revenue numbers through the Stripe Dashboard.
*   **/revenue-recognition/examples**: A collection of examples demonstrating various revenue recognition scenarios.
*   **/revenue-recognition/examples/contra**: Examples illustrating contra revenue recognition.
*   **/revenue-recognition/examples/credit-notes**: Examples of how credit notes impact revenue recognition.
*   **/revenue-recognition/examples/fx-and-currency**: Examples demonstrating revenue recognition with foreign exchange and multiple currencies.
*   **/revenue-recognition/examples/exclusion**: Examples of excluding transactions from revenue recognition.
*   **/revenue-recognition/examples/subscriptions**: Examples of revenue recognition for subscription-based businesses.
*   **/revenue-recognition/examples/other-examples**: Additional examples for revenue recognition scenarios.
*   **/revenue-recognition/revenue-contracts**: Configuring revenue contracts to model enterprise B2B sales.
*   **/revenue-recognition/invite-accountant**: Granting accountants direct access to Stripe Revenue Recognition for easier auditing and configuration.

### Report Configuration

*   **/reports/options**: Details common report configuration settings, including filters for date range, currency, and connect accounts.
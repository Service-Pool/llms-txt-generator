## Stripe Reporting and Revenue Recognition

This documentation set covers Stripe's reporting capabilities and its Revenue Recognition feature. It's designed for users who need to reconcile their Stripe transactions with their bank accounts, integrate Stripe data with accounting software, and automate their accrual accounting processes.

---

### Core Concepts: Reconciliation and Reporting

*   **/bank-reconciliation**: Learn how to reconcile your Stripe payouts with the cash in your bank account. This report helps you understand your monthly Stripe activity and its impact on your bank balance, ensuring accurate bookkeeping.
*   **/reports/balance**: Understand the Balance summary report, which functions like a bank statement to help you reconcile your Stripe balance at the end of each month. It provides an itemized export of your transaction history.
*   **/reports/payout-reconciliation**: This report helps you match Stripe payouts with the specific batches of transactions they settle. It's particularly useful for users with automatic payouts who prefer to reconcile by settlement batch.
*   **/reports/select-a-report**: A guide to help you choose the most suitable Stripe report for your specific financial tasks, whether it's downloading transaction history, reconciling your balance, or analyzing fees.
*   **/reports/options**: Details on common report configuration settings and controls, including date range selection and time zone customization, to help you filter and view your financial data effectively.
*   **/reports/reporting-categories**: Explains the `reporting_category` field on `BalanceTransaction` objects, providing a more granular and useful grouping of transactions for financial reporting compared to the `type` field.
*   **/accounting-integrations**: Information on integrating your accounting solution with Stripe, including exporting data to QuickBooks and using Stripe apps to automate bookkeeping.
*   **/standalone-fees**: Understand how standalone fees are applied separately from transactions and how they are reported, which differs from real-time inline fees.
*   **/stripe-fee-credits**: Learn how Stripe fee credits are applied to offset service costs, including their expiration and application order.

---

### Revenue Recognition

Stripe Revenue Recognition automates your accrual accounting process, helping you comply with global accounting standards like ASC 606 and IFRS 15.

*   **/revenue-recognition**: An overview of Stripe Revenue Recognition, its benefits, and how it simplifies revenue recognition for various business models.
*   **/revenue-recognition/methodology**: Understand the core principles of how Stripe Revenue Recognition calculates, defers, and reports your revenue, aligning with GAAP.
*   **/revenue-recognition/get-started**: A guide to setting up and using Stripe Revenue Recognition, including generating reports and understanding common billing models.
*   **/revenue-recognition/revenue-settings**: Customize how revenue is recognized for your business through settings like accounting period control and amortization granularity.
*   **/revenue-recognition/revenue-settings/accounting-period-control**: Configure your accounting calendar, including using calendar months or a 4-4-5 structure, and manage the closing of accounting periods.
*   **/revenue-recognition/revenue-settings/examples**: Examples illustrating different amortization methods and how to record recovered revenue.
*   **/revenue-recognition/rules**: Define custom rules to handle specific revenue treatments unique to your business, such as categorizing taxes, booking passthrough fees, or amortizing revenue over custom periods.
*   **/revenue-recognition/rules/create-a-rule**: Step-by-step instructions on creating and managing custom Revenue Recognition rules within the Stripe Dashboard.
*   **/revenue-recognition/invite-accountant**: Grant your accountant direct access to Stripe Revenue Recognition, allowing them to configure settings and review data without compromising sensitive business information.
*   **/revenue-recognition/data-import**: Import data from external sources to manage non-Stripe transactions, adjust recognition schedules, or exclude transactions from revenue.
*   **/revenue-recognition/data-import/examples**: Practical examples of how to use data import for common scenarios, such as adding service periods to payments or overriding invoice line item details.
*   **/revenue-recognition/data-import/apple-app-store**: Automate the import of subscription purchases from the Apple App Store into Stripe Revenue Recognition for improved accuracy and efficiency.
*   **/revenue-recognition/data-import/google-play**: Automatically import subscription purchases from Google Play into Stripe Revenue Recognition, simplifying management and reducing manual work.
*   **/revenue-recognition/data-import/error-handling**: Learn how to identify and resolve errors encountered during data import for revenue recognition.
*   **/revenue-recognition/data-import/manage-imported-data**: Manage your imported revenue recognition data through the Stripe Dashboard, tracking import status and reviewing imported files.
*   **/revenue-recognition/data-reconciliation**: Reconcile cash accounts from Stripe Revenue Recognition with the Balance Summary report, ensuring accuracy in your financial reporting.
*   **/revenue-recognition/reports**: Generate and export various revenue reports from Stripe Revenue Recognition to analyze revenue, deferred revenue, and booked revenue.
*   **/revenue-recognition/reports/activity-breakdown**: Audit transaction and invoice-level activity with advanced grouping and filtering capabilities for detailed accounting analysis.
*   **/revenue-recognition/reports/accounts-receivable-aging**: Monitor outstanding invoices and assess credit risk with the accounts receivable aging report, which groups overdue invoices by age.
*   **/revenue-recognition/reports/audit-numbers**: Use the Stripe Dashboard to examine the details of your revenue numbers by customer or transaction for various reports.
*   **/revenue-recognition/reports/balance-sheet**: Review your company's financial position at a specific time with the balance sheet report, listing assets and liabilities.
*   **/revenue-recognition/reports/debits-and-credits**: View detailed debit and credit entries for reconciliation and auditing, ensuring your general ledger balances.
*   **/revenue-recognition/reports/income-statement**: Analyze your company's financial performance over a period with the income statement report, detailing revenue, expenses, and net income.
*   **/revenue-recognition/reports/trial-balance**: Prepare for accounting period closure by reviewing account balances and ensuring total debits equal total credits with the trial balance report.
*   **/revenue-recognition/reports/waterfall**: Analyze monthly revenue with the waterfall report, showing booked revenue and how it's recognized over time.
*   **/revenue-recognition/methodology/multi-currency**: Understand how presentment and settlement currencies, along with functional currency settings, impact revenue recognition.
*   **/revenue-recognition/methodology/refunds-and-disputes**: Learn how refunds and disputes affect your revenue numbers, including contra revenue and the clearing of deferred revenue.
*   **/revenue-recognition/methodology/subscriptions-and-invoicing**: See how Stripe Revenue Recognition accurately defers and recognizes revenue for subscriptions and invoices, treating each item as a performance obligation.
*   **/revenue-recognition/overrides**: Make manual corrections to your revenue recognition reports using the transaction override feature (note: this feature is being deprecated in favor of data import).
*   **/revenue-recognition/performance-obligations-api**: Model performance obligation fulfillment for accurate revenue recognition, particularly for scenarios involving goods delivery, service performance, and prepayments.
*   **/revenue-recognition/standalone-selling-price**: Accurately allocate revenue for bundled products using standalone selling prices, allowing for customizable bundle allocations and different revenue schedules for individual components.
*   **/revenue-recognition/examples**: Explore common scenarios and how Stripe Revenue Recognition handles them, including contra entries, credit notes, FX, subscriptions, and taxes.
*   **/revenue-recognition/examples/contra**: Examples demonstrating how contra revenue is handled in various scenarios.
*   **/revenue-recognition/examples/credit-notes**: Examples illustrating how credit notes impact revenue recognition before and after payment.
*   **/revenue-recognition/examples/currency**: Examples showing how foreign exchange rates and multi-currency transactions affect revenue recognition.
*   **/revenue-recognition/examples/exclusion**: Examples of how transactions are excluded from revenue recognition and the resulting accounting entries.
*   **/revenue-recognition/examples/other-examples**: Additional examples covering scenarios like external assets and Stripe fees.
*   **/revenue-recognition/examples/subscriptions**: Examples demonstrating revenue recognition for monthly and annual subscriptions, including upgrades.
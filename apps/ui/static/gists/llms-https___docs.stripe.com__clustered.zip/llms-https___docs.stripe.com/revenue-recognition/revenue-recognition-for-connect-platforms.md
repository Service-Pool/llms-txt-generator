## Revenue Recognition for Connect Platforms

This section of the Stripe documentation provides guidance on how to leverage Stripe's Revenue Recognition features when operating as a Connect platform. It details how revenue is recognized based on different application fee collection methods within the Connect ecosystem.

### Key Topics Covered:

*   **Connect Platform Fee Collection Methods:** Explains the three primary ways platforms can collect application fees:
    *   **Destination Charges:** The platform account receives the full charge amount and then transfers a portion to the connected account, retaining the platform fees.
    *   **Direct Charges:** The platform makes charges directly on the connected account and takes application fees in the process.
    *   **Separate Charges and Transfers:** The platform makes charges on its own account on behalf of connected accounts, performs transfers separately, and retains funds.
*   **Revenue Recognition for Each Method:** For each fee collection method, the documentation details how Stripe Revenue Recognition processes and recognizes the platform fees. This includes:
    *   **Destination Charges:** How application fees are recognized when collected separately or deducted from transfers.
    *   **Direct Charges:** How application fees are recognized immediately when charged directly on a connected account, including how refunds are treated as contra revenue.
    *   **Separate Charges and Transfers:** How revenue is recognized for charges made on the platform account and how transfers are booked as contra revenue.
*   **API Access:** Information on accessing features for direct charges and separate charges and transfers via a support ticket.

### Related Topics:

*   **Revenue Recognition Overview:** A general introduction to Stripe's Revenue Recognition feature.
*   **Revenue Recognition for Destination Charges:** Detailed explanation of revenue recognition with destination charges.
*   **Revenue Recognition for Direct Charges:** Detailed explanation of revenue recognition with direct charges.
*   **Revenue Recognition for Separate Charges and Transfers:** Detailed explanation of revenue recognition with separate charges and transfers.
*   **Data Import:** How to import non-Stripe transaction data for comprehensive revenue recognition.
*   **Reporting:** Information on accessing and exporting various revenue recognition reports.
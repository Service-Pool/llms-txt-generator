## Financial Reporting and Reconciliation

This section of the documentation covers how to understand and reconcile your financial data within Stripe. It includes information on various reports available to help you track your income, expenses, and balances, as well as tools for integrating with accounting software and managing revenue recognition.

### Key Topics

*   **Bank Reconciliation:** Learn how to reconcile your Stripe payouts with your bank account to ensure accurate financial tracking.
*   **Payout Reconciliation:** Understand how to match Stripe payouts with the specific transactions they settle.
*   **Balance Summary Report:** Get a detailed view of your Stripe balance, including available, pending, and reserved funds.
*   **Accounting Integrations:** Discover how to connect Stripe with popular accounting tools like QuickBooks and NetSuite to automate bookkeeping.
*   **Standalone Fees:** Understand how Stripe applies transaction fees separately from the initial transaction.
*   **Stripe Fee Credits:** Learn how to apply, view, and reconcile fee credits to offset service costs.
*   **Revenue Recognition:** Automate your accrual accounting process with Stripe's comprehensive revenue recognition tools. This includes:
    *   **Data Import:** Bring in non-Stripe transaction data to manage all your revenue recognition in one place.
    *   **Connectors:** Utilize specialized connectors for platforms like Apple App Store and Google Play for automated data import.
    *   **Data Reconciliation:** Reconcile revenue recognition data with other financial reports.
    *   **Reports:** Generate and export various revenue reports, including balance sheets, income statements, and trial balances.
    *   **Rules and Settings:** Customize how revenue is recognized based on your business needs.
*   **Report Configuration:** Learn about common settings and filters available across all financial reports to tailor your data views.
*   **Reporting Categories:** Understand the different categories used to classify transactions for reporting purposes.
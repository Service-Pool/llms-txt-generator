## Financial Reporting and Reconciliation

This section provides documentation on how to access, understand, and utilize Stripe's financial reporting tools to reconcile transactions, manage your accounts, and ensure accurate bookkeeping.

### Key Features and Reports

*   **Bank Reconciliation:** Learn how to reconcile your Stripe payouts with your bank account to track funds and close your books accurately. This report is available for US-based Stripe accounts with automated payouts.
*   **Payout Reconciliation:** Match Stripe payouts with the specific batches of transactions they settle. This report is ideal for users with automatic payouts who prefer to reconcile on a per-payout basis.
*   **Balance Summary Report:** This report acts like a bank statement, allowing you to reconcile your Stripe balance at the end of the month. It provides an itemized transaction history.
*   **Accounting Integrations:** Discover how to integrate Stripe with accounting tools like QuickBooks and NetSuite to automate bookkeeping and keep financial data updated. This includes understanding the default Stripe accounts created in QuickBooks.
*   **Fees Reports:**
    *   **Fees Report:** View all fees charged by Stripe, networks, and external partners.
    *   **Standalone Fees:** Understand how standalone fees are applied separately from transactions and when they typically occur.
    *   **Stripe Fee Credits:** Learn how to apply, view, and reconcile fee credits to offset service costs.
*   **Reporting Categories and Types:** Understand the `reporting_category` field on `BalanceTransaction` objects for more useful groupings in financial reporting.
*   **Report Configuration:** Learn about common report configuration settings, including filters for date range, currency, and connected accounts, as well as time zone customization.

### Revenue Recognition

Stripe Revenue Recognition helps automate your accrual accounting process, ensuring compliance with global accounting standards.

*   **Overview:** Understand how Stripe Revenue Recognition calculates, defers, and reports revenue, including recognized and deferred revenue summaries, downloadable reports, and configurable rules.
*   **Getting Started:** Learn how to import transaction data, set up rules, generate reports, and test your transaction model.
*   **Data Management:**
    *   **Data Freshness:** Understand when data becomes available for Stripe Revenue Recognition reports.
    *   **Data Import:** Import data from other sources to manage all your revenue recognition in Stripe, including general imports, exclusion imports, and journal entry imports. This includes connectors for Apple App Store and Google Play.
    *   **Manage Imported Data:** Learn how to view the status of CSV imports and manage imported transactions.
    *   **Error Handling:** Troubleshoot and resolve errors encountered during data import.
*   **Revenue Recognition for Connect Platforms:** Understand how revenue recognition works for platforms using destination charges, direct charges, and separate charges and transfers.
*   **Methodology:**
    *   **How Revenue Recognition Works:** Detailed explanation of the principles and processes behind Stripe Revenue Recognition.
    *   **Subscriptions and Invoicing:** How revenue recognition applies to subscriptions and invoices.
    *   **Refunds and Disputes:** How refunds and disputes impact revenue recognition.
    *   **Multi-currency:** Understand the roles of presentment and settlement currencies in revenue recognition.
*   **Rules:**
    *   **Revenue Recognition Rules:** Customize rules to define specific revenue treatments for your business.
    *   **Create a Rule:** Step-by-step guide on creating custom revenue recognition rules.
*   **Settings:**
    *   **Revenue Recognition Settings:** Adjust the behavior of Stripe Revenue Recognition with various settings.
    *   **Accounting Period Control:** Configure how to close accounting periods, including manual closure, automated closure, and reopening past periods.
    *   **Standalone Selling Prices:** Set up standalone selling prices and create bundles for accurate revenue allocation.
*   **Reports:**
    *   **Revenue Recognition Reports:** Generate and export various revenue reports from the Stripe Dashboard or via CSV.
    *   **Monthly Summary:** Provides a high-level overview of revenue activity for a selected month.
    *   **Trial Balance:** View and analyze account balances to ensure debits equal credits.
    *   **Income Statement:** Analyze revenue, expenses, and net income for a specified period.
    *   **Balance Sheet:** Review your company's financial position at a specific time.
    *   **Accounts Receivable Aging:** Monitor outstanding invoices and assess credit risk.
    *   **Debits and Credits:** View detailed transaction entries for reconciliation and auditing.
    *   **Revenue Waterfall:** Analyze monthly revenue with a waterfall report showing booked and recognized revenue over time.
    *   **Activity Breakdown:** Audit transaction and invoice-level activity with advanced grouping and filtering.
    *   **Audit Your Numbers:** Examine the details of your revenue numbers in the Dashboard.
*   **Advanced Features:**
    *   **Revenue Contracts:** Model enterprise B2B sales contracts for accurate revenue recognition.
    *   **Performance Obligations API:** Model performance obligation fulfillment for revenue recognition.
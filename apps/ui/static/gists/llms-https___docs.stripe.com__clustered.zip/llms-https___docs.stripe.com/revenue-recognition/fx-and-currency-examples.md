## Reporting and Reconciliation

This section details how to reconcile your Stripe financial data with your bank accounts and accounting systems, and how to leverage Stripe's reporting tools for financial analysis.

### Reconciling Stripe with Your Bank and Books

*   **/bank-reconciliation**: Learn how to reconcile your Stripe payouts with the cash in your bank account. This report helps you understand monthly activity, track realized cash, and ensure accurate book closing. It's currently available for US-based Stripe accounts with automated payouts.
*   **/reports/balance**: The Balance summary report functions like a bank statement, allowing you to reconcile your Stripe balance at the end of the month. It provides an itemized transaction history and is most useful if you treat your Stripe account as a bank account for accounting purposes.
*   **/reports/payout-reconciliation**: This report helps you match Stripe payouts with the specific batches of transactions they settle. It's designed for users with automatic payouts who prefer to reconcile transactions on a settlement batch basis.
*   **/accounting-integrations**: Discover how to integrate your accounting solution with Stripe. This includes exporting data to QuickBooks in IIF format and using Stripe apps to automate bookkeeping.
*   **/reports/options**: Understand common report configuration settings, including filters for date range, time zone, and data availability.

### Understanding Your Financial Data

*   **/reports/reporting-categories**: Learn about the `reporting_category` field on BalanceTransaction objects, which provides a more useful grouping for finance and reporting than the `type` field.
*   **/stripe-fee-credits**: Understand how Stripe fee credits are applied to offset service costs, including their expiration and application order.
*   **/standalone-fees**: Learn about standalone fees, a method where Stripe applies transaction fees separately after the initial transaction, typically within 36 hours.
*   **/stripe-reports**: Get an overview of Stripe's reporting features, including prebuilt reports for analyzing account activity and advanced tools for revenue recognition and custom reporting with Stripe Sigma.

### Revenue Recognition

This comprehensive suite of pages covers Stripe's Revenue Recognition feature, designed to automate accrual accounting processes and ensure compliance with accounting standards.

*   **/revenue-recognition**: An overview of Stripe Revenue Recognition, its benefits for automating accrual accounting, and links to key features and use cases.
*   **/revenue-recognition/methodology**: Understand the core principles of how Stripe Revenue Recognition calculates, defers, and reports revenue, adhering to GAAP and IFRS standards.
*   **/revenue-recognition/get-started**: A guide to setting up and using Stripe Revenue Recognition, including importing transaction data, setting rules, generating reports, and testing your model.
*   **/revenue-recognition/invite-accountant**: Learn how to grant accountants specific access to Stripe Revenue Recognition for audit-ready books, balancing operational autonomy with data security.
*   **/revenue-recognition/rules**: Customize how revenue is treated for your business by configuring Revenue Recognition rules, including categorizing transactions, booking passthrough fees, and amortizing revenue.
*   **/revenue-recognition/rules/create-a-rule**: Step-by-step instructions on creating custom Revenue Recognition rules within the Stripe Dashboard.
*   **/revenue-recognition/revenue-settings**: Adjust the behavior of Stripe Revenue Recognition with settings for accounting periods, amortization granularity, and more.
*   **/revenue-recognition/revenue-settings/accounting-period-control**: Configure your accounting calendar, including options for calendar months, 4-4-5 calendars, and manual or automated closing of accounting periods.
*   **/revenue-recognition/revenue-settings/examples**: Examples demonstrating the impact of different amortization granularities (by second, day, or month) on revenue recognition.
*   **/revenue-recognition/standalone-selling-price**: Set up standalone selling prices to accurately allocate revenue for bundled products and create custom revenue schedules for individual components.
*   **/revenue-recognition/performance-obligations-api**: Understand how to model performance obligation fulfillment, a key aspect of revenue recognition where goods or services are delivered to the customer.
*   **/revenue-recognition/methodology/multi-currency**: Learn how presentment and settlement currencies, as well as functional currencies, play a role in Stripe Revenue Recognition.
*   **/revenue-recognition/methodology/refunds-and-disputes**: Understand how refunds and disputes impact your revenue numbers, including contra revenue and clearing of deferred revenue.
*   **/revenue-recognition/methodology/subscriptions-and-invoicing**: Discover how Stripe Revenue Recognition accurately defers and recognizes revenue for subscriptions and invoices, treating each line item as a performance obligation.
*   **/revenue-recognition/revenue-contracts**: Represent and manage enterprise sales-led contracts in Stripe Revenue Recognition, allowing for custom revenue schedules independent of billing periods.

### Data Import and Management

*   **/revenue-recognition/data-import**: Import data from other sources to manage all your revenue recognition in Stripe, including general imports, exclusion imports, and journal entry imports.
*   **/revenue-recognition/data-import/apple-app-store**: Automatically import subscription purchases from the Apple App Store into Stripe Revenue Recognition for improved accuracy and near real-time availability.
*   **/revenue-recognition/data-import/google-play**: Automatically import subscription purchases from Google Play into Stripe Revenue Recognition, offering benefits like near real-time availability and improved refund treatment.
*   **/revenue-recognition/data-import/manage-imported-data**: Search for and manage existing imported data within the Stripe Dashboard, with status tracking for imports and detailed views of imported transactions.
*   **/revenue-recognition/data-import/error-handling**: Learn how to handle and resolve errors encountered during revenue recognition data imports.
*   **/revenue-recognition/data-import/examples**: Practical examples of applying data import to common use cases, such as adding service periods to Stripe payments or overriding service periods on invoice line items.
*   **/revenue-recognition/data-freshness**: Understand when data becomes available for Stripe Revenue Recognition reports across different sources like the Dashboard, Sigma, and the Reporting API.

### Reports and Auditing

*   **/revenue-recognition/reports**: Generate and export revenue reports from Stripe Revenue Recognition to analyze revenue, deferred revenue, and booked revenue.
*   **/revenue-recognition/reports/monthly-summary**: View a summary of monthly revenue activity.
*   **/revenue-recognition/reports/trial-balance**: View and analyze account balances over specific periods to ensure your books are balanced.
*   **/revenue-recognition/reports/income-statement**: Analyze your company's revenue, expenses, and net income for a specified period.
*   **/revenue-recognition/reports/balance-sheet**: Review your company's financial position at a specific point in time, listing assets and liabilities.
*   **/revenue-recognition/reports/accounts-receivable-aging**: Monitor outstanding invoices and assess credit risk by grouping them into age ranges.
*   **/revenue-recognition/reports/debits-and-credits**: View detailed transaction entries for reconciliation and auditing, showing every debit and credit entry in your accounting system.
*   **/revenue-recognition/reports/activity-breakdown**: Audit transaction and invoice level activity with advanced grouping and filtering capabilities for detailed analysis of journal entry activity.
*   **/revenue-recognition/reports/waterfall**: Analyze monthly revenue with the waterfall report, showing booked revenue and recognized amounts over time.
*   **/revenue-recognition/audit-numbers**: Use the Stripe Dashboard to examine the details of your revenue numbers by customer or transaction for various reports.
*   **/revenue-recognition/data-reconciliation**: Reconcile cash accounts from Stripe Revenue Recognition with the Balance Summary report, excluding fees and other non-revenue items.
*   **/revenue-recognition/overrides**: Make manual corrections to your revenue recognition reports (note: this feature is being deprecated in favor of data import).

### Connect Platforms

*   **/revenue-recognition/connect**: Learn how revenue recognition works specifically for Connect platforms, covering different charge and transfer models.
*   **/revenue-recognition/connect/destination-charges**: Understand how revenue recognition tracks platform fees when using the destination charge model in Stripe Connect.
*   **/revenue-recognition/connect/direct-charges**: Learn how revenue recognition works with direct charges in Stripe Connect, where platforms make charges directly on connected accounts.
*   **/revenue-recognition/connect/charges-transfers**: Understand how revenue recognition handles separate charges and transfers in Stripe Connect, where charges are made on the platform account on behalf of connected accounts.
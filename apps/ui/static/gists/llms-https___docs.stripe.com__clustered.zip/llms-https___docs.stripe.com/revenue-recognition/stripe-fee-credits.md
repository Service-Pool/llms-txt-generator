Stripe fee credits allow you to offset your service costs by applying credits to Stripe fees as they are billed. Each credit has a specific expiration date and amount. Once a credit is used or expires, it will no longer apply to eligible Stripe fees. You can view product eligibility, expiration dates, and the credit amount on the fee credits details page.

### Applying Fee Credits

Stripe applies fee credits to your Stripe fees as they are billed, using a first-in, first-out (FIFO) model. Credits can only be applied to future fees.

If multiple credits are active in your account, Stripe applies only one credit to a given fee, following this order:

1.  **Nearest expiration date:** The credit with the closest expiration date is prioritized.
2.  **Type of credit:** Prepayments are prioritized over incentives.
3.  **Least remaining balance:** The credit with the smallest remaining balance is considered.

Product usage (sometimes referred to as the attribution date) might differ from the billed (invoiced) date. If usage occurs before a credit is activated in your account but is invoiced after activation, the credit will not apply to the fee because the fee was created before the credit existed. Conversely, if the attribution date for a fee is before a credit expires, but the fee is invoiced after the credit expires, Stripe will still apply the credit to the fee.

When credits are exhausted or expire, and no other credits are active, Stripe will automatically collect fees.
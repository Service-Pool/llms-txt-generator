## Credit Notes and Revenue Recognition

This section details how Stripe Revenue Recognition handles credit notes, providing examples to illustrate the process.

### Credit Note Examples

This section explains how revenue recognition works with credit notes. Unless stated otherwise, these examples assume that revenue recognition takes place on a per-day basis.

#### Credit note before a payment

A pre-paid credit note is issued before the customer makes a payment or before the invoice is fully paid. It’s used to adjust the amount the customer owes or to provide a discount upfront. Here’s an example:

In this example, a customer starts a subscription for a 3-month period on January 1 at 00:00:00 UTC that costs 120 USD. Before a payment is received, you offer a pre-payment credit note of 30 USD that is applied to the customer balance. This is treated like an upfront discount and reduces your overall invoice to 90 USD. The invoice is then paid in February for 90 USD. Your summary for March would look something like this:

| Account          | Starting | Jan 2026 | Feb 2026 | Mar 2026 | Ending |
| :--------------- | :------- | :------- | :------- | :------- | :----- |
| AccountsReceivable | 0.00     | +90.00   | -90.00   | 0.00     | 0.00   |
| Cash             | 0.00     | 0.00     | +90.00   | 90.00    | 90.00  |
| Revenue          | 0.00     | +31.00   | +28.00   | +31.00   | 90.00  |
| DeferredRevenue  | 0.00     | +59.00   | -28.00   | -31.00   | 0.00   |

#### Credit note after a payment

You can use a refund, a customer credit, or an out-of-band credit to issue a credit note to a customer after they’ve made a payment.

In this example, a customer starts a subscription for a 3-month period on January 1 at 00:00:00 UTC that costs 90 USD. The subscription generates an invoice and the customer pays it immediately. On February 1, you issue a credit note of
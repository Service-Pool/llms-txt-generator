## Stripe Revenue Recognition

Stripe Revenue Recognition is a powerful feature designed to automate your accrual accounting process, ensuring compliance with global accounting standards like ASC 606 and IFRS 15. It helps businesses accurately recognize and defer revenue, providing a clear picture of profitability and financial health.

This feature is particularly beneficial for:

*   **Public companies or large businesses** with over $25 million USD in annual revenue, who are legally required to comply with accounting standards.
*   **Startups** needing to adhere to accrual accounting for investor relations or loan applications.
*   **Subscription and service-based businesses** where revenue is earned over time.
*   **Businesses with upfront payments** before goods or services are delivered.

### Key Features and Functionality:

*   **Automated Revenue Calculation:** Stripe Revenue Recognition automatically calculates revenue for all Stripe transactions, including subscriptions, invoices, one-time payments, refunds, and disputes, with second-level precision.
*   **Recognized and Deferred Revenue Summaries:** Gain clear insights into your revenue through easy-to-understand summaries.
*   **Downloadable Accounting Reports:** Access comprehensive reports in CSV format, including:
    *   Monthly Summary
    *   Trial Balance
    *   Income Statement
    *   Balance Sheet
    *   Accounts Receivable Aging
    *   Debits and Credits
    *   Revenue Waterfall
    *   Activity Breakdown
*   **Interactive Revenue Numbers:** Facilitates full audit transparency by allowing you to drill down into transaction details.
*   **Configurable Accounting Period Controls:** Customize how you close accounting periods, with options for manual or automated closing, and the ability to reopen past periods for adjustments.
*   **Customizable Rules and Settings:** Define revenue treatments specific to your business needs, such as categorizing invoice line items, booking passthrough fees, excluding specific transactions, or amortizing revenue over custom periods.
*   **Integration with Stripe Objects:** Leverages existing Stripe data for intelligent default settings and accurate revenue recognition.
*   **Connect Platform Support:** Understand how revenue recognition works for Connect platforms using destination charges, direct charges, and separate charges and transfers.
*   **Data Management:**
    *   **Data Freshness:** Understand when transaction data becomes available for reporting.
    *   **Data Import:** Import non-Stripe transactions or adjust existing Stripe transactions to manage all revenue recognition in one place. This includes general imports, exclusion imports, and journal entry imports.
    *   **Connectors for App Stores:** Automate data import from Apple App Store and Google Play.
    *   **Manage Imported Data:** Review and manage your imported files and transactions.
*   **Revenue Recognition for Platforms:** Specific guidance for platforms on how revenue recognition applies to different charge models.
*   **Revenue Contracts:** Model enterprise B2B sales contracts, allowing for custom revenue schedules independent of billing periods.
*   **Standalone Selling Prices (SSP):** Accurately allocate revenue for bundled products.
*   **Multi-currency Support:** Understand the roles of presentment and settlement currencies in revenue recognition.
*   **Refunds and Disputes Handling:** See how refunds and disputes impact your revenue numbers and accounting.
*   **Subscription and Invoicing Management:** Accurately defer and recognize revenue for subscriptions and invoices.
*   **Transaction Overrides:** Make manual corrections to revenue recognition reports (though data import is the recommended method moving forward).
*   **Performance Obligations API:** Model performance obligation fulfillment for accurate revenue recognition.
*   **Auditing Tools:** Examine the details of your revenue numbers directly within the Stripe Dashboard.
*   **Accountant Access:** Invite your accountants to access Stripe Revenue Recognition with tailored permissions.

### Getting Started:

1.  **Set up Revenue Recognition:** Configure your Stripe account to leverage the automated features. This may involve modeling subscriptions using products and prices, setting taxes correctly, and using the discount object.
2.  **Import Data (if necessary):** If you have non-Stripe transactions, use the data import feature to consolidate all revenue sources.
3.  **Configure Rules and Settings:** Customize revenue treatments and accounting periods to match your business model.
4.  **Generate Reports:** Utilize the various reports and charts to analyze your revenue and prepare financial statements.
5.  **Test Your Model:** Before going live, test your transaction model to ensure accuracy.

Stripe offers a 30-day free trial for Revenue Recognition, allowing you to explore its features using a sandbox environment.
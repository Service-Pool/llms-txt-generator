## Reconciling Stripe with Your Finances

This documentation group focuses on how to reconcile your Stripe financial data with your internal accounting systems and bank statements. It covers various reports and tools Stripe offers to ensure accurate financial tracking, from understanding payout reconciliation to automating accrual accounting.

---

### Key Topics:

*   **Bank Reconciliation:** Learn how to reconcile your Stripe payouts with the cash in your bank account, ensuring all funds are accounted for and your books are accurate. (Page 1)
*   **Accounting Integrations:** Discover how to connect Stripe with popular accounting tools like QuickBooks and NetSuite to automate bookkeeping and data entry. (Page 2)
*   **Stripe Reports for Reconciliation:**
    *   **Balance Summary Report:** Use this report as a bank statement to reconcile your Stripe balance at the end of the month. (Page 3)
    *   **Payout Reconciliation Report:** Match Stripe payouts with the specific batches of transactions they settle, ideal for users with automatic payouts. (Page 5)
    *   **How to Select a Report:** A guide to choosing the right Stripe report for your specific financial workflow and reconciliation needs. (Page 7)
    *   **Report Configuration:** Understand common report settings and filters to customize the data you view. (Page 4)
*   **Understanding Fees:**
    *   **Fees Report:** View all fees charged by Stripe, networks, and external partners. (Page 8)
    *   **Standalone Fees:** Learn about an alternative method for applying transaction fees and how they are reported. (Page 8)
    *   **Stripe Fee Credits:** Understand how to apply, view, and reconcile fee credits. (Page 9)
*   **Revenue Recognition:**
    *   **Overview:** Automate your accrual accounting process to comply with global accounting standards. (Page 33)
    *   **Methodology:** Understand how Stripe Revenue Recognition calculates, defers, and reports your revenue. (Page 35)
    *   **Data Import:** Bring in non-Stripe transaction data to manage all your revenue recognition in one place. (Page 19)
    *   **Connectors:** Utilize connectors for Apple App Store and Google Play to automatically import subscription data. (Pages 20, 23)
    *   **Reporting:** Generate and export various revenue reports, including balance sheets, income statements, and trial balances. (Pages 41, 45, 47, 48)
    *   **Data Reconciliation:** Learn how to reconcile Stripe Revenue Recognition data with other financial reports. (Page 25)
    *   **Rules and Settings:** Customize how revenue is recognized with configurable rules and settings. (Pages 51, 54)
    *   **Examples:** Explore various scenarios and examples to understand revenue recognition in practice. (Pages 26-32)
*   **Reporting Categories:** Understand the different categories and types of transactions to better interpret your financial data. (Page 6)
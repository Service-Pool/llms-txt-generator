# Single Sign-On (SSO)

Single Sign-On (SSO) allows your team to sign in to the Stripe Dashboard using a single set of credentials managed by your Identity Provider (IdP). This enhances security and simplifies the login process for your users. Stripe supports SAML 2.0, enabling your IdP to manage user account creation, authentication, and authorization. Any SAML 2.0 compliant IdP can be integrated with Stripe.

## Key Concepts

*   **Identity Provider (IdP):** A system that authenticates users and provides them with access to other applications. Examples include Entra ID, Google Workspace, Okta, and OneLogin.
*   **SAML (Security Assertion Markup Language):** An open standard for exchanging authentication and authorization data between parties, specifically between an IdP and a service provider (like Stripe).
*   **SCIM (System for Cross-domain Identity Management):** A protocol that automates user provisioning and deprovisioning between identity domains or IT systems.

## Setting up SSO

The general process for setting up SSO with an IdP involves:

1.  **Proving Domain Ownership:** Verify that you own the email domains your team uses to access Stripe.
2.  **Configuring Your IdP:** Set up your chosen IdP to work with Stripe. This typically involves creating an application within your IdP for Stripe.
3.  **Configuring Stripe:** Configure Stripe to work with your IdP. This includes providing information from your IdP to Stripe.

## Supported Identity Providers

Stripe provides specific guides for integrating with popular IdPs:

*   [Entra ID (formerly Azure AD)](/get-started/account/sso/entra-id)
*   [Google Workspace](/get-started/account/sso/google-workspace)
*   [Okta](/get-started/account/sso/okta)
*   [OneLogin](/get-started/account/sso/onelogin)
*   [Other SAML Identity Providers](/get-started/account/sso/other)

## Advanced Features

### SCIM Provisioning

SCIM allows for the automatic provisioning and deprovisioning of users in Stripe based on their assignments in your IdP. This ensures that user access is managed efficiently and securely.

*   [Set up SCIM provisioning](/get-started/account/sso/scim)

### Group-Based Role Assignment

You can automatically assign roles to users in Stripe based on their group memberships within your IdP, synchronized via SCIM. This simplifies role management for larger teams.

*   [Set up group-based role assignment with SCIM synchronized groups](/get-started/account/sso/group-role-assignments)

### Consolidating SSO Integrations

If you manage multiple Stripe accounts, it's recommended to consolidate your SSO integrations to ensure a consistent and manageable authentication experience.

*   [Consolidate your SSO integrations](/get-started/account/orgs/sso-consolidation)

## Troubleshooting

If you encounter issues during SSO setup or usage, refer to the troubleshooting guide for common errors and their resolutions.

*   [Troubleshoot SSO](/get-started/account/sso/troubleshooting)

## Security Considerations

*   **Security Incidents:** Be aware that if your IdP is compromised, unauthorized access to your Stripe account could occur. It's your responsibility to implement necessary security protocols and controls to mitigate such risks.
*   **Role Management:** When SSO is enabled, team roles must be updated through your Identity Provider. Changes to user roles will only reflect in Stripe after the user signs in again with the updated SAML assertion.
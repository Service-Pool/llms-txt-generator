## Single Sign-On (SSO) with Stripe

This section provides comprehensive documentation on setting up and managing Single Sign-On (SSO) for your Stripe account. SSO allows your team to access Stripe using a single set of credentials managed by your Identity Provider (IdP), enhancing security and simplifying user access.

### Key Concepts

*   **Single Sign-On (SSO):** A method of authentication that allows users to log in to multiple applications with a single set of credentials.
*   **Identity Provider (IdP):** A system that creates, maintains, and manages identity information for principals (users) and provides authentication services to relying applications. Stripe supports any IdP that adheres to SAML 2.0.
*   **SAML (Security Assertion Markup Language):** An open standard for exchanging authentication and authorization data between parties, specifically between an IdP and a service provider (Stripe).
*   **SCIM (System for Cross-domain Identity Management):** A protocol that automates user provisioning and deprovisioning between identity domains or IT systems.

### Setting Up SSO

The general process for setting up SSO with Stripe involves three main steps:

1.  **Prove Domain Ownership:** Verify that you own the email domains your team uses to sign in to Stripe.
2.  **Configure Your IdP:** Set up your chosen IdP to work with Stripe.
3.  **Configure Stripe:** Configure Stripe to work with your IdP.

### Supported Identity Providers

Stripe provides specific guides for integrating with popular IdPs:

*   **Microsoft Entra ID (formerly Azure Active Directory):** [Single sign-on with Entra ID](/get-started/account/sso/entra-id)
*   **Google Workspace:** [Single sign-on with Google Workspace](/get-started/account/sso/google-workspace)
*   **Okta:** [Single sign-on with Okta](/get-started/account/sso/okta)
*   **OneLogin:** [Single sign-on with OneLogin](/get-started/account/sso/onelogin)
*   **Other SAML Identity Providers:** [Single sign-on with SAML Identity Provider](/get-started/account/sso/other)

### Advanced SSO Features

*   **Group-Based Role Assignment:** Automatically assign user roles based on their group memberships synchronized through SCIM into Stripe. This allows for dynamic and offline role management. See [Set up group-based role assignment with SCIM synchronized groups](/get-started/account/sso/group-role-assignments).
*   **SCIM Provisioning:** Automate the provisioning and deprovisioning of team members in Stripe directly from your IdP. This ensures that user access is managed efficiently and securely. See [Set up SCIM provisioning](/get-started/account/sso/scim).
*   **Consolidating SSO Integrations:** If you manage multiple Stripe accounts, it's recommended to consolidate your SSO integrations for a unified management experience, especially when using Stripe Organizations. See [Consolidate your SSO integrations](/get-started/account/orgs/sso-consolidation).

### Troubleshooting SSO

Encountering issues with SSO configuration is common. Stripe provides a guide to help you resolve common errors:

*   **Troubleshoot SSO:** Learn how to resolve common errors, such as expired SAML requests, invalid SAML responses, incorrect issuer IDs, and invalid IdP URLs. See [Troubleshoot SSO](/get-started/account/sso/troubleshooting).

By leveraging these resources, you can effectively implement and manage SSO for your Stripe account, ensuring secure and streamlined access for your team.
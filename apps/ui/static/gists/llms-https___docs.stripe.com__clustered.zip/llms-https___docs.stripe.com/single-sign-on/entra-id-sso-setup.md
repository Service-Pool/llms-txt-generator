## Single Sign-On (SSO) and SCIM Provisioning

This section details how to configure Single Sign-On (SSO) and System for Cross-domain Identity Management (SCIM) provisioning for your Stripe account. These features allow you to manage user access and roles through your existing Identity Provider (IdP), enhancing security and simplifying user management.

### Setting Up SSO

Stripe supports SAML 2.0 for SSO, allowing any SAML 2.0 compliant IdP to manage user authentication and authorization for your Stripe account. This means your team can access Stripe using their existing credentials without needing separate passwords.

**Key aspects of SSO setup include:**

*   **Domain Verification:** You must prove ownership of the email domains your team uses to sign in to Stripe.
*   **IdP Configuration:** You'll need to configure your chosen IdP to work with Stripe.
*   **Stripe Configuration:** You'll also configure Stripe to work with your IdP.

**Supported Identity Providers:**

*   **Microsoft Entra ID (formerly Azure AD):** [Learn how to set up SSO with Entra ID](/get-started/account/sso/entra-id).
*   **Google Workspace:** [Learn how to set up SSO with Google Workspace](/get-started/account/sso/google-workspace).
*   **Okta:** [Learn how to set up SSO with Okta](/get-started/account/sso/okta).
*   **OneLogin:** [Learn how to set up SSO with OneLogin](/get-started/account/sso/onelogin).
*   **Other SAML Identity Providers:** [Learn how to set up SSO with a generic SAML IdP](/get-started/account/sso/other).

### SCIM Provisioning

SCIM provisioning automates the creation and deactivation of user accounts in Stripe based on their assignments in your IdP. This complements Just-In-Time (JIT) provisioning by allowing you to provision users *before* they sign in and deprovision them on demand.

*   **Capabilities:** Stripe adheres to the SCIM 2.0 protocol and supports user provisioning, retrieval, update, listing, and deprovisioning.
*   **User Identification:** Stripe uses the user's email address as a unique identifier.
*   **Attribute Handling:** Stripe handles specific user attributes like `id`, `userName`, `displayName`, `active`, and `meta`. Email updates require re-provisioning the user.

**Learn more about setting up SCIM provisioning:** [Set up SCIM provisioning](/get-started/account/sso/scim).

### Group-Based Role Assignments

You can automatically assign roles to users based on their group memberships synchronized through SCIM. This allows for dynamic and offline role management.

*   **Prerequisites:** You must have SSO and SCIM set up, and your IdP configured to synchronize users and groups to Stripe.
*   **Configuration:** Assign roles to groups directly within Stripe's Team and security settings. Members of a group will inherit the assigned roles.

**Learn more about group-based role assignments:** [Set up group-based role assignment with SCIM synchronized groups](/get-started/account/sso/group-role-assignments).

### Consolidating SSO Integrations

If you manage multiple Stripe accounts, it's recommended to consolidate your SSO integrations for a centralized management experience, especially when using Stripe Organizations.

*   **Process:** This typically involves consolidating multiple IdP applications (one for each Stripe account) into a single IdP application that authenticates users to multiple Stripe accounts.
*   **Impact:** Consolidation does not affect existing group assignments or require downtime for users.

**Learn more about consolidating SSO integrations:** [Consolidate your SSO integrations](/get-started/account/orgs/sso-consolidation).

### Troubleshooting SSO

This section provides guidance on resolving common errors encountered during SSO configuration.

*   **Testing:** Stripe offers a test wizard to validate your SSO configuration before saving, preventing lockout issues.
*   **Common Errors:** Includes resolutions for issues like expired SAML requests, invalid SAML responses, incorrect issuer IDs, and invalid IdP URLs.

**Learn more about troubleshooting SSO:** [Troubleshoot SSO](/get-started/account/sso/troubleshooting).
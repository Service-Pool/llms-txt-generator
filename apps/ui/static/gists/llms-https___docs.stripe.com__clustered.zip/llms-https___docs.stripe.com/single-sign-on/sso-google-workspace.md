## Single Sign-On (SSO) with Stripe

This documentation section covers the setup and management of Single Sign-On (SSO) for accessing the Stripe Dashboard. SSO allows your team to authenticate through a single Identity Provider (IdP), enhancing security and simplifying the login process. Stripe supports SAML 2.0, enabling integration with various IdPs.

### Key Concepts

*   **Identity Provider (IdP):** A service that authenticates users and provides identity information to other applications. Examples include Entra ID, Google Workspace, Okta, and OneLogin.
*   **SAML (Security Assertion Markup Language):** An open standard for exchanging authentication and authorization data between parties, specifically between an IdP and a service provider (like Stripe).
*   **Provisioning:** The process of creating, updating, and deleting user accounts in an application. Stripe supports Just-In-Time (JIT) provisioning via SAML and SCIM provisioning for automated user management.
*   **SCIM (System for Cross-domain Identity Management):** A protocol that automates the exchange of user identity information between identity domains, allowing for automatic provisioning and deprovisioning of users.
*   **Group-Based Role Assignment:** A feature that allows you to automatically assign roles to users in Stripe based on their group memberships in your IdP, synchronized via SCIM.

### Setting Up SSO

The general process for setting up SSO with Stripe involves:

1.  **Proving Domain Ownership:** Verifying that you own the email domains your team uses to access Stripe.
2.  **Configuring Your IdP:** Setting up your chosen IdP to work with Stripe. This often involves creating an application within your IdP for Stripe.
3.  **Configuring Stripe:** Integrating Stripe with your IdP, which may involve providing details from your IdP to Stripe.

### Supported Identity Providers

Stripe provides specific guides for integrating with popular IdPs:

*   **Entra ID (formerly Azure Active Directory):** [Link to Entra ID SSO Guide](/get-started/account/sso/entra-id)
*   **Google Workspace:** [Link to Google Workspace SSO Guide](/get-started/account/sso/google-workspace)
*   **Okta:** [Link to Okta SSO Guide](/get-started/account/sso/okta)
*   **OneLogin:** [Link to OneLogin SSO Guide](/get-started/account/sso/onelogin)
*   **Other SAML Identity Providers:** For IdPs not listed above, Stripe provides general guidance for SAML integration. [Link to Other SAML IdP Guide](/get-started/account/sso/other)

### SCIM Provisioning

SCIM enables automatic provisioning and deprovisioning of team members from your IdP to Stripe. This complements SAML by automating user lifecycle management.

*   **Set up SCIM Provisioning:** [Link to SCIM Provisioning Guide](/get-started/account/sso/scim)
*   **Group-Based Role Assignment with SCIM:** Automatically assign roles based on IdP group synchronization. [Link to Group Role Assignment Guide](/get-started/account/sso/group-role-assignments)

### Consolidating SSO Integrations

If you manage multiple Stripe accounts, it's recommended to consolidate your SSO integrations for a streamlined experience. This is particularly relevant when using Stripe Organizations.

*   **Consolidate SSO Integrations:** [Link to SSO Consolidation Guide](/get-started/account/orgs/sso-consolidation)

### Troubleshooting SSO

This section provides guidance on resolving common errors encountered during SSO setup and usage.

*   **Troubleshoot SSO:** [Link to SSO Troubleshooting Guide](/get-started/account/sso/troubleshooting)

### Security Considerations

*   **Security Incidents:** Be aware that a compromised IdP can lead to unauthorized access to your Stripe account. It's your responsibility to implement appropriate security protocols.
## Single Sign-On (SSO) with Stripe

This documentation section covers the setup and management of Single Sign-On (SSO) for accessing the Stripe Dashboard. SSO allows your team to use a single set of credentials managed by your Identity Provider (IdP) to access Stripe, enhancing security and simplifying the login process.

### Key Concepts

*   **Identity Provider (IdP):** A system that authenticates users and provides their identity information to other applications. Stripe supports any IdP that adheres to SAML 2.0.
*   **SAML (Security Assertion Markup Language):** An open standard for exchanging authentication and authorization data between parties. Stripe uses SAML 2.0 for SSO.
*   **SCIM (System for Cross-domain Identity Management):** A protocol for automating the exchange of user identity information between identity domains or IT systems. SCIM can be used with Stripe for automatic provisioning and deprovisioning of users.

### Supported IdPs

Stripe provides specific guides for integrating with popular IdPs:

*   **Microsoft Entra ID (formerly Azure Active Directory):** [Single sign-on with Entra ID](/get-started/account/sso/entra-id)
*   **Google Workspace:** [Single sign-on with Google Workspace](/get-started/account/sso/google-workspace)
*   **Okta:** [Single sign-on with Okta](/get-started/account/sso/okta)
*   **OneLogin:** [Single sign-on with OneLogin](/get-started/account/sso/onelogin)
*   **Other SAML Identity Providers:** [Single sign-on with SAML Identity Provider](/get-started/account/sso/other)

### Core SSO Functionality

*   **Setup SSO:** The general process involves proving domain ownership, configuring your IdP to work with Stripe, and configuring Stripe to work with your IdP.
*   **Group-Based Role Assignment:** Automatically assign user roles based on their group memberships synchronized through SCIM. This allows for dynamic and offline role management. [Set up group-based role assignment with SCIM synchronized groups](/get-started/account/sso/group-role-assignments).
*   **SCIM Provisioning:** Automate the provisioning and deprovisioning of team members from your IdP into Stripe. [Set up SCIM provisioning](/get-started/account/sso/scim).

### Advanced Configurations

*   **Consolidate SSO Integrations:** If you manage multiple Stripe accounts, you can consolidate your SSO integrations to simplify management and ensure consistency. [Consolidate your SSO integrations](/get-started/account/orgs/sso-consolidation).
*   **Troubleshoot SSO:** Learn how to resolve common errors that may occur during SSO configuration. [Troubleshoot SSO](/get-started/account/sso/troubleshooting).

### Security Considerations

*   **Domain Ownership Verification:** You must prove ownership of the email domains your team uses to sign in to Stripe.
*   **IdP Security:** If your IdP is compromised, unauthorized access to your Stripe account is possible. It's crucial to evaluate your security needs and implement necessary protocols.
*   **Role Updates:** Changes to user roles in your IdP only appear in Stripe after the user signs in again using the updated SAML assertion.
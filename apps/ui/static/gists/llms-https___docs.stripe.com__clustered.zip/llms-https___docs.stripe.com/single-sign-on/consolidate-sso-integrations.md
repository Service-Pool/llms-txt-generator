## Single Sign-On (SSO) for Stripe

This documentation group provides comprehensive guidance on setting up and managing Single Sign-On (SSO) for your Stripe account. SSO allows your team to access Stripe and other applications using a single set of credentials managed by your Identity Provider (IdP), enhancing security and user experience.

### Key Concepts and Features:

*   **What is SSO?** Understand how SSO streamlines access to Stripe by integrating with your existing IdP.
*   **Supported IdPs:** Stripe supports any IdP that implements SAML 2.0. Specific guides are available for popular providers like:
    *   Microsoft Entra ID (formerly Azure Active Directory)
    *   Google Workspace
    *   Okta
    *   OneLogin
*   **SCIM Provisioning:** Learn how to automate the provisioning and deprovisioning of user accounts in Stripe based on your IdP's group memberships. This includes managing user lifecycles efficiently.
*   **Group-Based Role Assignments:** Dynamically assign roles to users in Stripe based on their group memberships synchronized through SCIM. This simplifies access control and ensures users have the appropriate permissions.
*   **Consolidating SSO Integrations:** If you manage multiple Stripe accounts, this section guides you on consolidating your SSO integrations to ensure a unified and secure access experience across all accounts.
*   **Troubleshooting SSO:** Find solutions to common issues encountered during SSO setup and configuration, including SAML request/response errors and identity provider URL problems.

### Getting Started:

1.  **Verify Domain Ownership:** Before configuring SSO, you must prove ownership of the domains used by your team for signing into Stripe.
2.  **Configure Your IdP:** Set up your chosen Identity Provider to work with Stripe. This typically involves creating an application within your IdP for Stripe.
3.  **Configure Stripe:** Integrate Stripe with your IdP by providing the necessary metadata and configuration details.
4.  **Test Your Configuration:** Utilize Stripe's built-in testing tools to ensure your SSO setup is correct before it impacts your users.

By leveraging SSO, you can significantly improve the security posture of your Stripe account and simplify user management for your team.
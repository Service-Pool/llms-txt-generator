## Single Sign-On (SSO)

Single Sign-On (SSO) allows your team to sign in to the Stripe Dashboard using a single set of credentials managed by your Identity Provider (IdP). This enhances security and simplifies the login process for your users. Stripe supports SAML 2.0, enabling your IdP to manage user account creation, authentication, and authorization. Any SAML 2.0-compliant IdP can be integrated with Stripe.

### Supported Identity Providers

Stripe provides specific integration guides for the following popular Identity Providers:

*   **Microsoft Entra ID (formerly Azure Active Directory):** [Set up single sign-on with Entra ID](/get-started/account/sso/entra-id)
*   **Google Workspace:** [Set up single sign-on with Google Workspace](/get-started/account/sso/google-workspace)
*   **Okta:** [Set up single sign-on with Okta](/get-started/account/sso/okta)
*   **OneLogin:** [Set up single sign-on with OneLogin](/get-started/account/sso/onelogin)
*   **Other SAML Identity Providers:** [Set up single sign-on with SAML Identity Provider](/get-started/account/sso/other)

### Key Concepts and Features

*   **Identity Provider (IdP):** The external system that manages user identities and authentication (e.g., Entra ID, Google Workspace, Okta).
*   **SAML 2.0:** The security protocol used for exchanging authentication and authorization data between parties.
*   **User Provisioning:**
    *   **Just-In-Time (JIT) Provisioning:** Users are automatically created in Stripe the first time they sign in via SSO.
    *   **SCIM Provisioning:** For automated user lifecycle management (creation, updates, deactivation), Stripe supports SCIM 2.0. This allows you to provision and deprovision users directly from your IdP. See [Set up SCIM provisioning](/get-started/account/sso/scim) for more details.
*   **Group-Based Role Assignments:** You can automatically assign user roles in Stripe based on their group memberships synchronized through SCIM. See [Set up group-based role assignment with SCIM synchronized groups](/get-started/account/sso/group-role-assignments).
*   **Domain Verification:** You must prove ownership of the email domains your team uses to sign in to Stripe.
*   **Consolidating SSO Integrations:** If you manage multiple Stripe accounts, it's recommended to consolidate your SSO integrations for a unified management experience, especially when using Stripe Organizations. See [Consolidate your SSO integrations](/get-started/account/orgs/sso-consolidation).

### Troubleshooting SSO

When configuring SSO, you can use the built-in test wizard to identify and resolve common errors before they impact your users. Refer to the [Troubleshoot SSO](/get-started/account/sso/troubleshooting) guide for detailed information on resolving issues such as expired SAML requests, invalid SAML responses, incorrect issuer IDs, and invalid IdP URLs.

### Security Considerations

If your Identity Provider is compromised, unauthorized access to your Stripe account could occur. It is your responsibility to evaluate your security needs and implement appropriate security protocols and controls to mitigate such risks.
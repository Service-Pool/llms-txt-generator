## Single Sign-On (SSO) for Stripe Accounts

This section provides comprehensive documentation on setting up and managing Single Sign-On (SSO) for your Stripe account. SSO allows your team to access Stripe using their existing identity provider (IdP) credentials, enhancing security and simplifying the login process.

### Core Concepts

*   **Single Sign-On (SSO):** A system that allows users to log in to multiple applications with a single set of credentials.
*   **Identity Provider (IdP):** A trusted entity that provides authentication services for other applications. Stripe supports any IdP that adheres to SAML 2.0.
*   **SAML (Security Assertion Markup Language):** An open standard for exchanging authentication and authorization data between parties, specifically between an IdP and a service provider (like Stripe).
*   **SCIM (System for Cross-domain Identity Management):** A protocol that automates the exchange of user identity information between identity domains or IT systems. It enables automatic provisioning and deprovisioning of users.

### Setting Up SSO

The general process for setting up SSO with Stripe involves three main steps:

1.  **Prove Domain Ownership:** Verify that you own the email domains your team uses to access Stripe. This is a security measure to ensure you control the accounts associated with those domains.
2.  **Configure Your IdP:** Set up your chosen identity provider to work with Stripe. This typically involves creating an application within your IdP for Stripe.
3.  **Configure Stripe:** Configure Stripe to work with your IdP, often by providing information from your IdP's configuration to Stripe.

### Supported Identity Providers

Stripe offers specific guides for integrating with popular IdPs:

*   **Microsoft Entra ID (formerly Azure Active Directory):** [Single sign-on with Entra ID](/get-started/account/sso/entra-id)
*   **Google Workspace:** [Single sign-on with Google Workspace](/get-started/account/sso/google-workspace)
*   **Okta:** [Single sign-on with Okta](/get-started/account/sso/okta)
*   **OneLogin:** [Single sign-on with OneLogin](/get-started/account/sso/onelogin)
*   **Other SAML 2.0 Identity Providers:** [Single sign-on with SAML Identity Provider](/get-started/account/sso/other)

### Advanced SSO Features

*   **SCIM Provisioning:** Automate the provisioning and deprovisioning of users in Stripe based on their group memberships in your IdP. This ensures that users have access only when they need it.
    *   [Set up SCIM provisioning](/get-started/account/sso/scim)
    *   [Set up group-based role assignment with SCIM synchronized groups](/get-started/account/sso/group-role-assignments)
*   **Consolidate SSO Integrations:** If you manage multiple Stripe accounts, you can consolidate your SSO integrations to simplify management and ensure a consistent user experience.
    *   [Consolidate your SSO integrations](/get-started/account/orgs/sso-consolidation)

### Troubleshooting SSO

Encountering issues with SSO setup is common. Stripe provides resources to help you resolve these problems:

*   [Troubleshoot SSO](/get-started/account/sso/troubleshooting): This guide covers common errors and their resolutions, including issues with SAML requests, responses, and issuer IDs.

By leveraging SSO, you can significantly improve the security posture and administrative efficiency of your Stripe account management.
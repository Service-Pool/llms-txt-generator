## Single Sign-On (SSO) and SCIM Provisioning

This section covers the configuration and management of Single Sign-On (SSO) and System for Cross-domain Identity Management (SCIM) provisioning within Stripe. These features allow for streamlined user authentication and access management for your Stripe account, enhancing security and simplifying administration.

### Core Concepts

*   **Single Sign-On (SSO):** Enables your team to sign in to Stripe using a single set of credentials managed by your Identity Provider (IdP). This eliminates the need for separate Stripe passwords and improves security by centralizing authentication. Stripe supports SAML 2.0, meaning any SAML 2.0 compliant IdP can be integrated.
*   **SCIM Provisioning:** Automates the process of provisioning and deprovisioning user access to Stripe. This means users can be automatically created in Stripe when assigned access by your IdP, and automatically removed when their access is revoked. This complements SSO by managing user lifecycles.
*   **Identity Provider (IdP):** A trusted entity that provides authentication services for users. Common IdPs supported by Stripe include Microsoft Entra ID (formerly Azure Active Directory), Google Workspace, Okta, and OneLogin.

### Setting Up SSO

The process of setting up SSO generally involves these key steps:

1.  **Prove Domain Ownership:** You must verify ownership of the email domains your team uses to sign in to the Stripe Dashboard.
2.  **Configure Your IdP:** Set up your chosen IdP to work with Stripe, which typically involves creating an application for Stripe within your IdP.
3.  **Configure Stripe:** Configure Stripe to work with your IdP, often by providing details from your IdP's configuration to Stripe.

Specific guides are available for integrating with popular IdPs:

*   **Microsoft Entra ID:** [Single sign-on with Entra ID](/get-started/account/sso/entra-id)
*   **Google Workspace:** [Single sign-on with Google Workspace](/get-started/account/sso/google-workspace)
*   **Okta:** [Single sign-on with Okta](/get-started/account/sso/okta)
*   **OneLogin:** [Single sign-on with OneLogin](/get-started/account/sso/onelogin)
*   **Other SAML IdPs:** [Single sign-on with SAML Identity Provider](/get-started/account/sso/other)

The general overview of SSO setup can be found at: [Single-sign-on (SSO)](/get-started/account/sso).

### SCIM Provisioning

SCIM provisioning allows for automatic user management. When enabled, you can:

*   **Provision Users:** Automatically create user accounts in Stripe when they are assigned access through your IdP.
*   **Deprovision Users:** Automatically remove user access from Stripe when they are deprovisioned in your IdP.

Stripe adheres to the SCIM 2.0 protocol. Key capabilities supported include:

*   Creating, retrieving, updating, listing, and deprovisioning users.

**Important Considerations for SCIM:**

*   Stripe uses the user's email as a unique identifier and does not support email updates directly. To change a user's email, you must re-provision them with a new email.
*   Both user deactivation and deletion in your IdP result in the user being removed from your Stripe account.
*   Stripe handles specific user attributes: `id`, `userName`, `displayName`, `active`, and `meta`.

For detailed instructions on setting up SCIM provisioning, refer to: [Set up SCIM provisioning](/get-started/account/sso/scim).

### Group-Based Role Assignments

Leveraging SCIM, you can implement **group-based role assignments**. This feature allows you to automatically assign Stripe Dashboard roles to users based on their group membership within your IdP.

To set this up:

1.  Ensure SSO and SCIM are configured.
2.  Configure your IdP to synchronize users and groups to Stripe.
3.  Configure group-based role assignment within Stripe, assigning roles to the synchronized groups. Users in these groups will then inherit the assigned roles.

More information can be found at: [Set up group-based role assignment with SCIM synchronized groups](/get-started/account/sso/group-role-assignments).

### Consolidating SSO Integrations

If you manage multiple Stripe accounts, it's highly recommended to consolidate your SSO integrations. This ensures a consistent authentication experience across all your accounts.

*   **For Stripe Organizations:** When using Stripe Organizations, ensure all accounts within an organization share the same SSO integration.
*   **General Recommendation:** Even without Organizations, consolidating SSO integrations simplifies management and reduces potential misconfigurations.

The process typically involves consolidating multiple IdP applications (one for each Stripe account) into a single IdP application that authenticates users to multiple Stripe accounts.

Refer to: [Consolidate your SSO integrations](/get-started/account/orgs/sso-consolidation) for detailed guidance, often using Okta as an example.

### Troubleshooting SSO

When configuring SSO, it's crucial to test your setup before saving to avoid locking out users. If you encounter issues, a troubleshooting guide is available to help resolve common errors.

Common errors and their resolutions include:

*   **The SAML request has expired:** Try signing in again to generate a fresh SAML assertion.
*   **Invalid SAML response:** Review the SAML response using browser extensions like SAML Tracer.
*   **Invalid issuer ID:** Ensure the issuer ID in your IdP matches the one configured in Stripe.
*   **Invalid identity provider URL:** Verify that the IdP URL configured in Stripe is correct and reachable.

Detailed troubleshooting steps can be found at: [Troubleshoot SSO](/get-started/account/sso/troubleshooting).
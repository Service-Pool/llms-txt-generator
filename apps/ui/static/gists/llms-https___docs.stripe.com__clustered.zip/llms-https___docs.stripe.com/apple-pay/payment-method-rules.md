## Payment Method Rules

Payment method rules allow you to set conditions on payment methods directly from the Dashboard without any custom logic or code. Rules allow you to:

*   Hide or show a payment method if the order amount is over or under a certain amount
*   Hide or show a payment method for buyers in certain countries or using certain currencies

### Payment Method Rules Considerations

Non-card payment methods can help offer improved unit economics compared to cards and they often drive higher AOV and conversion rates. When you turn on these payment methods, you might want to apply specific business logic to control when payment methods are available to your buyers. With payment method rules, you can apply these insights directly in Dashboard—no code required.

Payment method rules are compatible with Stripe A/B Testing. This allows you to run A/B tests using the targeting criteria you select or test additional criteria. For example, you can test the impact of only showing a specific payment method when the price is greater than a certain dollar amount.

**Note:** Payment method rules won’t apply when a Payment Element, Express Checkout Element, Checkout, or
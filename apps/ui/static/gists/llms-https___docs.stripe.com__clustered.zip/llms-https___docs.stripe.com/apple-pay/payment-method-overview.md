## Managing Payment Methods

Stripe offers a comprehensive suite of tools and features to manage payment methods, catering to a wide range of business needs and customer preferences. This section provides an overview of how to integrate and manage various payment methods, including cards, digital wallets, and local payment options.

### Key Features and Concepts:

*   **Payment Method Integration Options:** Stripe provides flexible options for integrating payment methods, whether you're building a custom integration with Elements or using pre-built solutions like Checkout and Payment Links.
*   **Dynamic Payment Methods:** Stripe can automatically present the most relevant payment methods to your customers based on factors like currency, location, and transaction details, simplifying the checkout process and potentially increasing conversion rates.
*   **Local Payment Methods:** To cater to a global customer base, Stripe supports a wide array of local payment methods, enabling businesses to accept payments in over 100 currencies and from various countries without needing a local entity.
*   **Buy Now, Pay Later (BNPL):** Offer flexible payment options to your customers with popular BNPL providers like Affirm, Afterpay/Clearpay, Klarna, and more, allowing them to split purchases into installments while you get paid upfront.
*   **Digital Wallets:** Integrate popular digital wallets such as Apple Pay, Google Pay, Link, PayPal, and WeChat Pay to provide a seamless and secure payment experience for your customers.
*   **Recurring Payments:** Stripe supports various methods for charging customers on a recurring basis, including subscriptions, installment plans, and charges on saved payment methods.
*   **Payment Method Management:** You can manage and configure available payment methods directly from the Stripe Dashboard, including enabling or disabling specific methods, setting payment method rules, and performing A/B tests to optimize payment offerings.
*   **Compliance and Security:** Stripe ensures compliance with various regulations, such as Strong Customer Authentication (SCA) and local data tokenization guidelines, to protect both businesses and customers.

### Supported Payment Methods:

Stripe supports a vast range of payment methods, categorized as follows:

*   **Cards:** Global and local card networks, including Visa, Mastercard, American Express, Discover, Cartes Bancaires, eftpos Australia, Interac, and more.
*   **Bank Debits:** Direct debit options from various countries.
*   **Bank Redirects:** Payment methods that redirect customers to their bank for authentication.
*   **Bank Transfers:** Direct bank transfer options.
*   **Buy Now, Pay Later:** Installment payment options from providers like Affirm, Afterpay/Clearpay, Klarna, Scalapay, and Zip.
*   **Real-time Payments:** Instant payment methods such as Pix, PayNow, and UPI.
*   **Vouchers:** Payment methods that involve customers paying with a voucher at authorized locations.
*   **Wallets:** Digital wallets like Alipay, Apple Pay, Google Pay, Link, PayPal, WeChat Pay, and more.

For detailed information on integrating and managing specific payment methods, refer to the relevant documentation pages within the Stripe API reference.
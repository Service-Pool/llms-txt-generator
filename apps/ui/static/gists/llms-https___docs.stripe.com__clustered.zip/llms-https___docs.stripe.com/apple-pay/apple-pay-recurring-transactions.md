## Manage recurring payments on Apple Pay

Improve authorization rates for recurring Apple Pay transactions.

### How recurring Apple Pay payments work

To make recurring payments, some businesses need to save the Apple Pay payment method on file when a user is on-session then make the recurring payments later when the user is off-session. The first on-session payment is often called a customer initiated transaction (CIT), and the later recurring payments are often called merchant initiated transactions (MIT). Two examples of recurring payments (or MIT) are:

*   Subscriptions where users get billed on a fixed frequency.
*   Recurring off-session payments where the billing frequency is inconsistent, or where customers can vary the frequency.

When users interact with the Apple Pay payment sheet, to keep the PAN (the original card number) private, Apple Pay processes a card PAN and generates a Device Primary Account Number (DPAN)
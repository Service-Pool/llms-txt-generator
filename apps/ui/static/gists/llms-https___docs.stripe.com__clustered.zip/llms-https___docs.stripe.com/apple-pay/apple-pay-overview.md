## Apple Pay

Apple Pay is a mobile payment and digital wallet platform developed by Apple Inc. that allows users to make payments on iPhones, iPads, Apple Watches, and Macs.

### Key Features and Benefits:

*   **Secure and Convenient:** Apple Pay uses tokenization to secure transactions, meaning actual card numbers are not stored on the device or shared with merchants. This offers a convenient and secure payment experience for customers.
*   **SCA-Ready:** Apple Pay is compliant with Strong Customer Authentication (SCA) regulations, providing an additional layer of security for online payments.
*   **Wide Compatibility:** Apple Pay is compatible with most Stripe products and features, allowing for seamless integration into existing workflows.
*   **No Additional Fees:** There are no extra fees for processing Apple Pay payments; the pricing is the same as for other card transactions.
*   **Broad Availability:** Apple Pay is available to cardholders at participating banks in supported countries.

### Integration:

*   **iOS Applications:** Apple Pay can be accepted in iOS applications starting from iOS 9.
*   **Web:** Apple Pay can be accepted on the web through Safari, starting with iOS 10 or macOS Sierra.

### Use Cases:

*   Accepting payments for physical goods.
*   Processing donations.
*   Handling subscriptions.
*   Facilitating in-app purchases.

### Related Topics:

*   [Apple Pay merchant tokens](/apple-pay/merchant-tokens)
*   [Recurring payments on Apple Pay](/apple-pay/apple-pay-recurring)
*   [Apple Pay Best Practices](/apple-pay/best-practices)
*   [Cartes Bancaires with Apple Pay](/apple-pay/cartes-bancaires)
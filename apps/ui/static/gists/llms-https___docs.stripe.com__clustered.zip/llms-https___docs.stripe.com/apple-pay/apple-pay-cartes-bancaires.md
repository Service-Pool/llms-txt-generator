```markdown
## Cartes Bancaires with Apple Pay

This document explains how to integrate Cartes Bancaires with Apple Pay in your Stripe integration.

### Prerequisites

*   A Stripe account.
*   An Apple Pay integration set up.

### Enabling Cartes Bancaires

To enable Cartes Bancaires with Apple Pay, you need to add `.cartesBancaires` to your list of enabled Apple Pay networks in your app's configuration.

**Example (Swift):**

```swift
StripeAPI.additionalEnabledApplePayNetworks = [.cartesBancaires]
```

### Important Considerations

*   Stripe only supports EUR payments for Cartes Bancaires with Apple Pay.
*   Only enable Cartes Bancaires with Apple Pay if you support charges through Cartes Bancaires.
*   If you are a platform using the `on_behalf_of` parameter, ensure that the `on_behalf_of` account supports Cartes Bancaires charges. You can check an account's eligibility using the Capabilities API.
```
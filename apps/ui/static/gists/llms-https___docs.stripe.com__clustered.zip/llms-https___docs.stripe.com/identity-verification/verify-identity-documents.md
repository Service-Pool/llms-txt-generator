## Stripe Identity: Verifying User Identities

This documentation group provides comprehensive guidance on implementing and managing Stripe Identity, a service designed to verify the identities of global users. It covers the entire lifecycle of identity verification, from initial setup and integration to handling outcomes and accessing verification data.

**Key Areas Covered:**

*   **Introduction to Stripe Identity:** Understand the core purpose and benefits of using Stripe Identity for fraud prevention, risk management, and enhancing trust and safety. This includes an overview of supported countries and available verification methods.
*   **Getting Started:** Learn how to activate Stripe Identity in your Stripe Dashboard and begin the process of verifying user identities.
*   **Verification Flows and Sessions:** Discover how to create and manage reusable verification configurations using "Verification Flows" and understand the role of "Verification Sessions" in tracking the verification process and API interactions.
*   **Verification Checks:** Explore the different types of verification checks offered by Stripe Identity, including document verification, selfie matching, ID number verification, phone verification, and address verification.
*   **Integrating Identity Verification:** Detailed guides on how to integrate Stripe Identity into your application, including client-side and server-side implementation for collecting and verifying identity documents.
*   **Handling Verification Outcomes:** Learn how to listen for and process verification results, enabling your application to automatically react to successful or failed verifications using webhooks.
*   **Accessing Verification Results:** Understand how to access sensitive verification data, including options for using the Identity Dashboard, secret API keys, and restricted API keys.
*   **Reviewing and Analyzing Verifications:** Explore tools for manual review of verifications and understand "Insights" provided by Stripe Identity's AI model to identify risks and gain deeper clarity into verification decisions.
*   **Best Practices and Going Live:** Get guidance on best practices for building a production-ready Stripe Identity integration, including considerations for branding, pricing, limiting submission attempts, and securely handling sensitive information.
*   **Explaining Identity to Customers:** Resources to help you communicate the identity verification process to your customers, addressing potential questions and concerns.
*   **Supported Use Cases and Locations:** Information on the eligibility criteria, supported business locations, and specific use cases for Stripe Identity.
## Stripe Identity Documentation

This documentation group provides comprehensive guidance on implementing and utilizing Stripe Identity for identity verification. It covers everything from initial setup and supported use cases to handling verification outcomes, accessing results, and best practices for going live.

---

### Core Concepts and Setup

*   **Identity Overview (`/identity`)**: This is the main entry point for Stripe Identity. It provides a high-level overview of the service, its capabilities, supported countries, and a quick start guide.
*   **Supported Use Cases and Locations (`/identity/use-cases`)**: Crucial for understanding eligibility, this page details the business locations and specific use cases that Stripe Identity supports, along with any limitations.
*   **Before Going Live (`/identity/before-going-live`)**: This section outlines essential best practices and considerations before deploying a production-ready Stripe Identity integration, including branding, pricing, and data storage recommendations.

### Implementing Verification

*   **Verify Identity Documents (`/identity/verify-identity-documents`)**: This guide walks you through the process of collecting and verifying identity documents from your users, covering client-side and server-side integration steps.
*   **Verification Flows (`/identity/verification-flows`)**: Learn how to create reusable configurations for your verification processes, allowing for consistent application across different integration interfaces and use cases.
*   **Verification Sessions API (`/identity/verification-sessions`)**: This page details the API used to manage the entire verification process, from creation to completion, and how to retrieve verification results.
*   **Verification Checks (`/identity/verification-checks`)**: Understand the different types of verification checks available (document, selfie, ID number, phone, address) and the information and flows associated with each.

### Handling and Accessing Results

*   **Handle Verification Outcomes (`/identity/handle-verification-outcomes`)**: This guide explains how to listen for verification results and automatically trigger reactions in your application, including setting up webhooks.
*   **Access Verification Results (`/identity/access-verification-results`)**: Learn how to access sensitive verification data, including options for using the Identity Dashboard, secret API keys, and restricted API keys.
*   **Review Tools (`/identity/review-tools`)**: Discover how to supplement programmatic verification with manual reviews, allowing for human expertise in examining unusual verifications and updating statuses.
*   **Insights (`/identity/insights`)**: Understand the AI-driven insights Stripe Identity provides, which offer more nuanced information beyond top-level verification decisions to assist with manual reviews and customer support.

### Customer Communication

*   **Explain Identity to Your Customers (`/identity/explaining-identity`)**: This resource provides pre-approved content and guidance on how to answer customer questions about ID verification and Stripe Identity, fostering transparency and trust.
## Stripe Identity Documentation

This documentation suite provides comprehensive guidance on implementing and managing Stripe Identity, a service for verifying user identities. It covers everything from initial setup and integration to handling verification outcomes, accessing results, and understanding advanced features.

### Core Concepts and Getting Started

*   **Overview (`/identity`)**: Provides a high-level introduction to Stripe Identity, its capabilities, supported countries, and key features like verifying ID documents, matching with selfies, and accessing extracted data. It outlines the basic steps to get started: signing up, activating Identity, verifying users, and handling outcomes.
*   **Supported Use Cases and Locations (`/identity/use-cases`)**: Details the eligibility criteria for using Stripe Identity, including business location, intended use, and business type. It lists countries where Stripe Identity is generally available and those in public beta, along with explicitly unsupported use cases.
*   **Before Going Live (`/identity/before-going-live`)**: Offers best practices for building a production-ready Stripe Identity integration. This includes reviewing supported use cases, setting up branding, understanding pricing and billing, and recommendations for limiting submission attempts and sensitive data storage.

### Integration and Verification Flows

*   **Verify Identity Documents (`/identity/verify-identity-documents`)**: A step-by-step guide on using Stripe Identity to securely collect and verify identity documents. It covers setting up your Stripe account, integrating with client-side and server-side components, and handling the verification process.
*   **Verification Flows (`/identity/verification-flows`)**: Explains how to create and manage reusable configurations for identity verification. Flows allow you to standardize verification behavior across different integration interfaces (API, Dashboard, static links) and manage distinct use cases.
*   **Verification Sessions API (`/identity/verification-sessions`)**: Details the API for managing the entire verification process, from creation to completion. It covers creating `VerificationSession` objects, specifying session types (e.g., `document`, `id_number`), and best practices for reusing sessions.
*   **Verification Checks (`/identity/verification-checks`)**: Describes the different types of verification checks supported by Stripe Identity, including document, selfie, ID number, phone, and address checks. It explains the requirements, coverage, and flow for each check type.

### Handling Verification Outcomes and Data

*   **Handle Verification Outcomes (`/identity/handle-verification-outcomes`)**: Guides you on listening for verification results to trigger automated reactions in your application. It covers receiving event notifications via webhooks, handling successful and failed checks, and turning on event handlers for production.
*   **Access Verification Results (`/identity/access-verification-results`)**: Explains how to access sensitive verification results. It presents options like using the Identity Dashboard, accessing data programmatically with secret or restricted API keys, and details which verification fields are available through each method.
*   **Review Tools (`/identity/review-tools`)**: Introduces manual review capabilities to supplement programmatic fraud detection. It describes how to use list and detailed views in the Dashboard to examine unusual verifications and update statuses, especially when business requirements differ from default risk thresholds.
*   **Insights (`/identity/insights`)**: Explains how Stripe Identity's AI model generates insights beyond top-level verification decisions. It defines "Insights" and "Insight" types (Level and Label), and provides details on document insights like "Activity on Stripe network."

### Customer Communication

*   **Explain Identity to Your Customers (`/identity/explaining-identity`)**: Provides pre-approved content and guidance for answering customer questions about ID verification and Stripe Identity. It includes sample FAQs to help users understand the process, data access, and privacy.
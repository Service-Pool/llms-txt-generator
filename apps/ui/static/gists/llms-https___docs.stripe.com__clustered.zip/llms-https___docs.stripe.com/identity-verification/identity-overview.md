# Stripe Identity

Stripe Identity allows you to verify the identity of global users to prevent fraud, streamline risk operations, and increase trust and safety. It supports verifying government-issued ID documents from over 120 countries, capturing photo IDs, matching them with selfies, and validating Social Security numbers.

## Key Features and Concepts

*   **Identity Verification**: Confirm the authenticity of government-issued ID documents.
*   **Global Coverage**: Supports ID documents from a wide range of countries.
*   **Fraud Prevention**: Helps mitigate risks associated with identity fraud.
*   **Risk Operations**: Streamlines processes related to assessing and managing risk.
*   **Trust and Safety**: Enhances user trust through robust verification.

## Core Components

*   **Verification Sessions API**: Powers Stripe Identity, tracking the verification process from creation to completion and providing results.
*   **Verification Checks**: Various checks are supported, including:
    *   **Document Checks**: Verifies the authenticity of government-issued identity documents.
    *   **Selfie Checks**: Matches government-issued photo IDs with user selfies.
    *   **ID Number Checks**: Verifies a user's name, date of birth, and national ID number.
    *   **Phone Checks**: (Invite only) Verifies phone numbers.
    *   **Address Checks**: (Invite only) Verifies addresses.
*   **Verification Flows**: Allows you to create reusable configurations for verification across your integration, managing different verification use cases and ensuring consistency.
*   **Handle Verification Outcomes**: Listen for verification results to automatically trigger reactions in your application. This is often done using webhooks.
*   **Access Verification Results**: Options to access sensitive verification results, including the Identity Dashboard, secret API keys, and restricted API keys.
*   **Review Tools**: Enables manual reviews to supplement programmatic systems with human expertise for an extra layer of fraud protection.
*   **Insights**: Provides nuanced information beyond top-level verification decisions, derived from AI models, to assist with manual reviews and customer support.
*   **Before Going Live**: Best practices and considerations for building a production-ready Stripe Identity integration, including branding, pricing, and limiting submission attempts.
*   **Supported Use Cases and Locations**: Information on eligibility based on business location and how you plan to use Stripe Identity.
*   **Explaining Identity to Customers**: Guidance and pre-approved content to help you answer customer questions about ID verification and Stripe Identity.

## Getting Started

1.  **Sign Up and Activate Identity**: Create a Stripe account and activate Identity in the Dashboard.
2.  **Verify Your Users’ Identity Documents**: Begin by creating sessions and collecting identity documents.
3.  **Handle Verification Outcomes**: Set up mechanisms to listen for and react to verification results.
4.  **Create Re-usable Configurations**: Use verification flows to manage settings and ensure consistency.

## Additional Resources

*   **Pricing**: Learn about pay-as-you-go and custom pricing for Stripe Identity.
*   **Sample Projects**: Try out a demo or clone a sample project to preview Stripe Identity.
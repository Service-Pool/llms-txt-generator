## Stripe Identity: Verification and Data Management

This documentation section covers the core aspects of using Stripe Identity for identity verification, from understanding the different verification checks to managing and accessing the verification results.

### Key Features and Concepts

*   **Verification Checks:** Stripe Identity supports various verification checks to ensure user authenticity. These include:
    *   **Document Verification:** Verifies the authenticity of government-issued identity documents. This process involves AI models, automated analysis, and manual review to check for legibility, expiration, and potential fraud. (See: `/identity/verification-checks`)
    *   **Selfie Verification:** Matches government-issued photo IDs with selfies to prevent the use of stolen documents. (See: `/identity/verification-checks`)
    *   **ID Number Verification:** Verifies a user's name, date of birth, and national ID number. (See: `/identity/verification-checks`)
    *   **Phone Verification:** An invite-only verification method. (See: `/identity/verification-checks`)
    *   **Address Verification:** An invite-only verification method. (See: `/identity/verification-checks`)

*   **Verification Flows:** Allow you to create reusable configurations for your identity verification processes. This ensures consistency across different integration interfaces and can be managed through the Dashboard or API. Flows can be tailored for various use cases, such as marketing campaigns or differentiating between high-value and low-value transactions. (See: `/identity/verification-flows`)

*   **Verification Sessions API:** The central API for managing the entire verification process, from creation to completion. Each `VerificationSession` has a unique ID that can be used to retrieve it and track its status. Reusing `VerificationSession` IDs is recommended for interrupted or resumed verification processes. (See: `/identity/verification-sessions`)

### Implementing and Managing Verifications

*   **Getting Started:** To begin using Stripe Identity, you'll need to sign up and activate Identity in your Stripe Dashboard. (See: `/identity`)

*   **Verifying Identity Documents:** This guide provides a step-by-step process for using Stripe Identity to securely collect and verify identity documents, including options for displaying a document upload modal on your website and handling verification results. (See: `/identity/verify-identity-documents`)

*   **Handling Verification Outcomes:** Learn how to listen for verification results and automatically trigger reactions in your application. This involves setting up webhooks to receive event notifications when a verification finishes processing, allowing you to handle successful and failed checks. (See: `/identity/handle-verification-outcomes`)

*   **Accessing Verification Results:** You can access sensitive verification results through several options:
    *   **Identity Dashboard:** The recommended method for accessing sensitive results, allowing controlled access for team members.
    *   **Programmatic Access:** Most verification details can be accessed using your secret key. However, access to more sensitive fields requires restricted API keys. The table provides a breakdown of what is available through each method. (See: `/identity/access-verification-results`)

*   **Review Tools:** Supplement Stripe's programmatic systems with manual reviews to add an extra layer of fraud protection. This is useful for unusual verifications or when your business requirements differ from Stripe Identity's default risk thresholds. You can review verifications in a list view or a detailed view. (See: `/identity/review-tools`)

*   **Insights:** Stripe Identity's AI model generates insights that provide a more nuanced understanding of verification signals beyond the top-level decisions. These insights can be used to assist with manual reviews or customer support. Insights can be of type `Level` (low, elevated, high risk) or `Label` (present or absent). (See: `/identity/insights`)

### Best Practices and Considerations

*   **Before Going Live:** Before launching your Stripe Identity integration, ensure your use case and business are supported, set up branding, understand pricing and billing, and implement measures to limit submission attempts and sensitive information storage. (See: `/identity/before-going-live`)

*   **Explaining Identity to Customers:** Provide clear explanations to your customers about why identity verification is necessary and how their data is handled. This documentation offers pre-approved content for FAQs to address customer concerns about data privacy and the verification process. (See: `/identity/explaining-identity`)

*   **Supported Use Cases and Locations:** Eligibility to use Stripe Identity depends on your business location, how you plan to use the service, and your industry. Check the provided lists to determine if Stripe Identity supports your specific use case and location. (See: `/identity/use-cases`)
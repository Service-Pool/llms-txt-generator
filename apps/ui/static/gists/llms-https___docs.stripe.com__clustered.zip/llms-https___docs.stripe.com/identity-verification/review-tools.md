## Stripe Identity: Reviewing and Understanding Verification Results

This section of the Stripe documentation focuses on how to effectively review and understand the outcomes of identity verification processes using Stripe Identity. It provides guidance on leveraging both programmatic access and manual review tools to ensure accuracy, security, and compliance.

### Key Topics Covered:

*   **Accessing Verification Results:** Learn how to retrieve sensitive verification data, including document images, extracted personal information, and verification outcomes, using the Stripe API and the Identity Dashboard. Understand the differences in access levels between secret and restricted API keys.
*   **Handling Verification Outcomes:** Discover how to set up webhooks to receive real-time notifications about verification status changes, enabling your application to automatically react to successful or failed verifications.
*   **Review Tools for Manual Verification:** Explore the capabilities of Stripe's review tools, which allow for manual inspection of verification attempts. This includes understanding the list and detailed views for examining verification data and images, and how to supplement programmatic fraud detection with human expertise.
*   **Insights for Deeper Analysis:** Understand how Stripe Identity's AI model generates nuanced insights beyond simple pass/fail results. Learn about different insight types (Level and Label) and how they can be used to assist with manual reviews and customer support.
*   **Best Practices for Production:** Get guidance on preparing your Stripe Identity integration for a live environment, including understanding pricing, limiting submission attempts, and managing sensitive data storage.
*   **Explaining Identity to Customers:** Find pre-approved content and guidance on how to clearly communicate the purpose and process of identity verification to your users, addressing potential concerns about data privacy and security.
*   **Supported Use Cases and Locations:** Determine if Stripe Identity is suitable for your business by reviewing the supported use cases and geographical availability.
*   **Verification Checks and Flows:** Understand the different types of verification checks available (document, selfie, ID number, etc.) and how to configure reusable verification settings using Verification Flows.
*   **Verification Sessions API:** Learn about the core API for managing the entire identity verification lifecycle, from creation to result retrieval.

By navigating these topics, developers and businesses can implement robust and compliant identity verification solutions with Stripe Identity, ensuring a secure and trustworthy experience for their users.
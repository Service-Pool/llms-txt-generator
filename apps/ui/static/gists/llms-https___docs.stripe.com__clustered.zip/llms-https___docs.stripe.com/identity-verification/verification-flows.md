# Stripe Identity Documentation

This documentation set provides comprehensive guidance on implementing and utilizing Stripe Identity for identity verification. It covers everything from initial setup and supported use cases to handling verification outcomes, accessing results, and understanding the underlying APIs and checks.

## Core Concepts and Getting Started

*   **Overview:** (Page 5) Provides a high-level introduction to Stripe Identity, its capabilities, and supported regions. It outlines the key steps to get started, including signing up, activating Identity, verifying user documents, handling outcomes, and creating reusable configurations.
*   **Supported Use Cases and Locations:** (Page 8) Details the eligibility criteria for using Stripe Identity, including business location, intended use, and business type. It lists the countries where Stripe Identity is generally available and in public beta.
*   **Before Going Live:** (Page 2) Offers best practices for building a production-ready Stripe Identity integration. This includes reviewing supported use cases, setting up branding, understanding pricing, and implementing measures to prevent fraud and limit sensitive data storage.
*   **Verify Identity Documents:** (Page 12) A step-by-step guide on how to use Stripe Identity to securely collect and verify identity documents. It covers client-side and server-side integration, including adding verification buttons, displaying modals, and handling verification results.

## Verification Process and Outcomes

*   **Verification Flows:** (Page 10) Explains how to create and manage reusable configurations for your verification process. Flows allow you to standardize verification behavior across different interfaces and use cases.
*   **Verification Checks:** (Page 9) Details the different types of verification checks supported by Stripe Identity, including document, selfie, ID number, phone, and address checks. It describes the information required for each check and their respective coverage.
*   **Handle Verification Outcomes:** (Page 4) Guides you on how to listen for verification results and automatically trigger reactions in your application. It covers setting up webhooks to receive event notifications when a verification finishes processing and handling both successful and failed checks.
*   **Access Verification Results:** (Page 1) Explains how to access sensitive verification results, such as user details and document images. It outlines options like using the Identity Dashboard, secret API keys, and restricted API keys for programmatic access.
*   **Review Verification Results:** (Page 7) Introduces manual review tools that supplement programmatic systems with human expertise. It describes how to use list and detailed views to examine unusual verifications and update their statuses.

## Advanced Features and Insights

*   **Insights:** (Page 6) Describes how Stripe Identity's AI model generates insights from verification checks. It explains the different types of insights (Level and Label) and how they can be used to assist with manual reviews and customer support.
*   **The Verification Sessions API:** (Page 11) Provides details about the API that powers Stripe Identity. It explains how to use Verification Sessions to securely collect information, perform verification checks, and track the entire verification process.

## Customer Communication

*   **Explain Identity to Your Customers:** (Page 3) Offers pre-approved content and guidance for answering customer questions about ID verification and Stripe Identity. This helps build trust and transparency with your users.
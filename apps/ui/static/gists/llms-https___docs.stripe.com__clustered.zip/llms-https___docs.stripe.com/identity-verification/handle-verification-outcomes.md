## Stripe Identity Documentation

This documentation group provides comprehensive guidance on implementing and managing Stripe Identity, a service for verifying user identities. It covers the entire lifecycle of identity verification, from initial setup and integration to handling outcomes and accessing verification results.

### Core Concepts and Setup

*   **Identity Overview (`/identity`)**: This is the main entry point for understanding Stripe Identity. It outlines the service's capabilities, supported use cases, and provides a high-level overview of how to get started, including account activation and verification processes.
*   **Supported Use Cases and Locations (`/identity/use-cases`)**: Crucial for understanding eligibility, this page details the business locations and specific use cases that Stripe Identity supports, helping users determine if the service is suitable for their needs.
*   **Before Going Live (`/identity/before-going-live`)**: This section offers best practices and essential considerations before deploying a production-ready Stripe Identity integration. It covers aspects like reviewing supported use cases, setting up branding, understanding pricing, and implementing security measures like limiting submission attempts.

### Integration and Verification Flows

*   **Verify Identity Documents (`/identity/verify-identity-documents`)**: This guide walks users through the process of securely collecting and verifying identity documents. It covers integrating verification buttons, displaying modals, and handling the initial stages of the verification process.
*   **Verification Flows (`/identity/verification-flows`)**: This page explains how to create and manage reusable configurations for identity verification. Flows allow for consistent application of verification settings across different integration interfaces and use cases.
*   **Verification Checks (`/identity/verification-checks`)**: This documentation details the different types of verification checks Stripe Identity supports, including document, selfie, ID number, phone, and address checks. It explains the requirements, coverage, and flow for each check.
*   **The Verification Sessions API (`/identity/verification-sessions`)**: This section dives into the technical details of the Verification Sessions API, which is central to the identity verification process. It covers creating and managing verification sessions, their lifecycle, and best practices for their use.

### Handling Verification Outcomes and Data

*   **Handle Verification Outcomes (`/identity/handle-verification-outcomes`)**: This guide focuses on how to react to verification results. It explains how to listen for event notifications, handle successful and failed checks, and turn on event handlers for production use.
*   **Access Verification Results (`/identity/access-verification-results`)**: This page provides detailed information on how to access sensitive verification results. It outlines options like using the Identity Dashboard, secret API keys, and restricted API keys for accessing various verification details.
*   **Review Tools (`/identity/review-tools`)**: This section describes how to supplement programmatic verification systems with human expertise through manual reviews. It covers using list and detailed views to inspect verifications and make informed decisions.
*   **Insights (`/identity/insights`)**: This page explains how Stripe Identity's AI model generates insights from verification checks. It defines different types of insights (Level and Label) and how they can be used to understand risks and assist with manual reviews or customer support.

### Customer Communication

*   **Explain Identity to Your Customers (`/identity/explaining-identity`)**: This resource offers pre-approved content and guidance on how to explain the identity verification process to customers, addressing potential questions and concerns about data privacy and security.
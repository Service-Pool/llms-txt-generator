# Stripe Identity: Verifying User Identities

This documentation collection provides a comprehensive guide to Stripe Identity, a service that allows businesses to verify the identities of their global users to prevent fraud, streamline risk operations, and enhance trust and safety.

## Key Concepts and Features

*   **Overview:** Understand the core functionality of Stripe Identity, including its capabilities for verifying government-issued ID documents, matching them with selfies, and accessing collected data. (Page 5)
*   **Verification Checks:** Explore the different types of verification checks supported by Stripe Identity, such as document, selfie, ID number, phone, and address verification. Learn about the requirements and flows for each check. (Page 9)
*   **Verification Flows:** Discover how to create and manage reusable configurations for your identity verification processes. Flows allow you to standardize verification behavior across different integration interfaces and use cases. (Page 10)
*   **Verification Sessions API:** Delve into the Verification Sessions API, the core component that powers Stripe Identity. This API manages the entire verification process, from creation to completion, and provides access to verification results. (Page 11)
*   **Verifying Identity Documents:** Learn the step-by-step process of using Stripe Identity to securely collect and verify your users' identity documents, including integrating verification buttons, displaying modals, and handling results. (Page 12)

## Handling Verification Outcomes and Data

*   **Handle Verification Outcomes:** Understand how to listen for verification results and automatically trigger reactions in your application. This includes setting up webhooks to receive event notifications when a verification finishes processing. (Page 4)
*   **Access Verification Results:** Learn how to access sensitive verification results, such as user data and document images. You can use the Identity Dashboard, secret API keys, or restricted API keys for this purpose. (Page 1)
*   **Review Tools:** Discover how to supplement programmatic fraud detection with manual reviews. Stripe Identity offers tools to examine unusual verifications and update their statuses, providing an extra layer of fraud protection. (Page 7)
*   **Insights:** Gain insights into the AI model's analysis of verification signals. Understand how to use these nuanced insights to assist with manual reviews and customer support processes. (Page 6)

## Best Practices and Preparation

*   **Before Going Live:** Familiarize yourself with best practices for building a production-ready Stripe Identity integration. This includes reviewing supported use cases, setting up branding, understanding pricing, and limiting submission attempts. (Page 2)
*   **Supported Use Cases and Locations:** Determine if Stripe Identity is suitable for your business by checking the supported use cases and available countries for integration. (Page 8)
*   **Explaining Identity to Customers:** Learn how to effectively communicate the purpose and process of identity verification to your customers, addressing potential questions and concerns. (Page 3)
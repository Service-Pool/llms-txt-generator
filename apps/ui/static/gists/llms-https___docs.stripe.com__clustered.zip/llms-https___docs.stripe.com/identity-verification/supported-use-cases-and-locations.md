```markdown
# Stripe Identity: Supported Use Cases and Locations

This section outlines the eligibility criteria for using Stripe Identity, detailing supported business locations and use cases to ensure compliance and optimal integration.

## Business Location Eligibility

Stripe Identity is generally available for businesses based in:

*   **Japan**
*   **United Kingdom**
*   **United States**

Additionally, Stripe Identity is available in a self-serve public beta for businesses based in:

*   **Australia**
*   **Austria**
*   **Belgium**
*   **Bulgaria**
*   **Canada**
*   **Croatia**
*   **Cyprus**
*   **Czech Republic**
*   **Denmark**
*   **Estonia**
*   **Finland**
*   **France**
*   **Germany**
*   **Greece**
*   **Hungary**
*   **Ireland**
*   **Italy**
*   **Latvia**
*   **Lithuania**
*   **Luxembourg**
*   **Malta**
*   **Netherlands**
*   **New Zealand**
*   **Norway**
*   **Poland**
*   **Portugal**
*   **Romania**
*   **Slovenia**
*   **Spain**
*   **Sweden**
*   **Switzerland**

While you can verify identity documents from hundreds of countries globally, the availability of Stripe Identity for your business is primarily determined by your business's country of operation.

## Supported Use Cases

The primary purpose of Stripe Identity is to verify the authenticity of government-issued ID documents to prevent fraud, streamline risk operations, and enhance trust and safety.

**Supported Use Cases Include:**

*   Verifying the authenticity of government-issued ID documents from over 120 countries.
*   Capturing government-issued photo IDs with a conversion-optimized verification flow.
*   Matching government-issued photo IDs with selfies.
*   Validating Social Security numbers (SSNs).
*   Accessing collected images and extracted data from government-issued ID documents.

For specific questions regarding supported and unsupported use cases, please contact Stripe support. Our Services Terms provide a comprehensive description of the permissible uses of Stripe Identity.

## Unsupported Use Cases

Stripe Identity must not be used for the following purposes:

*   **Reselling as an independent ID verification service:** You may not resell, provide, or further distribute identity verification services or data obtained from Stripe Identity to third parties. This includes using Stripe Identity as your primary business offering for identity verification.
*   **Selling or renting data received from Stripe Identity:** You are prohibited from selling or renting any data you receive through Stripe Identity.

Adhering to these guidelines ensures the secure and compliant use of Stripe Identity.
```
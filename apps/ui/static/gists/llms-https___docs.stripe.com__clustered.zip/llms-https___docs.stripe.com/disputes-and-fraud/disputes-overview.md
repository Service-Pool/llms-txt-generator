## Disputes

A dispute, also known as a chargeback, occurs when a cardholder questions a payment with their card issuer. This process can lead to financial loss and negatively impact your relationship with card networks. Stripe provides tools and guidance to help you manage, prevent, and understand disputes.

### How Disputes Work

When a cardholder disputes a transaction, their bank initiates a formal dispute on the card network. This immediately reverses the payment, and the disputed amount, along with associated fees, is debited from your Stripe account. Stripe guides you through the process of submitting evidence to contest the dispute, but the final decision rests with the cardholder's bank.

### Managing Disputes

*   **Respond to Disputes:** Learn how to challenge or accept a dispute through the Stripe Dashboard. You'll need to provide evidence to support your case.
*   **API for Disputes:** Programmatically manage disputes by uploading evidence, responding to them, and receiving dispute events via webhooks.
*   **Dispute Reason Codes:** Understand the various reason codes that categorize dispute claims across major card networks (Visa, Mastercard, American Express) and the evidence required to challenge them.
*   **Dispute Withdrawals:** Learn what happens when a cardholder withdraws a dispute and how it differs from other dispute outcomes.

### Preventing Disputes

*   **Dispute Prevention Tools:** Stripe integrates with Verifi and Ethoca to help reduce your dispute rate and avoid network fines.
*   **Smart Disputes:** Automate evidence collection and submission for eligible disputes to improve your chances of winning and save time on manual management.
*   **Radar for Fraud Teams:** Utilize advanced fraud detection and customizable rules to identify and prevent fraudulent transactions that often lead to disputes.
*   **Best Practices for Fraud Prevention:** Implement strategies like clear communication with customers, transparent policies, and robust verification checks to minimize disputes.

### Analyzing Disputes

*   **Disputes Analytics:** Monitor your dispute volume, rates, and outcomes through dedicated analytics in the Stripe Dashboard to understand their financial impact and identify risks of entering card network monitoring programs.
*   **Measuring Disputes:** Understand the difference between "dispute activity" and "dispute rate" to accurately track your performance.
*   **Card Monitoring Programs:** Learn about the card network monitoring programs and what to do if your business is placed into one due to high dispute or fraud levels.

### Specific Dispute Scenarios

*   **Apple Pay Disputes:** Understand liability shifts, disputes, and refunds specific to Apple Pay transactions.
*   **Klarna Disputes:** Learn about the lifecycle and response process for Klarna disputes.
*   **PayPal Disputes:** Understand how dispute management works for PayPal payments.
*   **Visa Compliance Disputes:** Learn how to respond to disputes that arise from non-compliance with Visa's network rules.
*   **Visa Compelling Evidence 3.0:** Utilize Visa's criteria to fight friendly fraud by submitting specific evidence for qualifying disputes.

By leveraging Stripe's comprehensive tools and resources, you can effectively manage disputes, reduce their occurrence, and protect your business from associated financial risks.
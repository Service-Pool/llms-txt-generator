## Radar risk signals for multiple payment processors

Evaluate your non-Stripe processed payments with Radar.

Stripe Radar allows businesses to evaluate their externally-processed payments in real time and receive risk signals from the Radar AI models. You can request a payment evaluation at any time in the payment lifecycle–not only when you submit to the processor.

Payment evaluations provide the `fraudulent_payment` signal by default, which identifies if a payment will likely result in a dispute with a fraudulent reason code or an early fraud warning.

The following signals are also available in preview:
*   `fraudulent_dispute`: identifies if a payment will likely result in a dispute with a fraudulent reason code.
*   `early_fraud_warning`: identifies if a payment will likely result in an early fraud warning.

### Prerequisites

Before you request a payment evaluation on an externally-processed transaction, you must:
*   Create a tokenized `PaymentMethod`. We currently support only card type payment methods.
*   Create a Radar Session token, which automatically collects advanced risk factors for each transaction.
*   Collect the customer email by populating the `billing_details.email` attribute in the payment method or creating a new customer (either a customer-configured Account object or a Customer object).

The following diagram shows your initial call to create a `PaymentEvaluation` and the real-time response from Stripe.

```mermaid
sequenceDiagram
    participant Your App
    participant Stripe Radar API

    Your App->>Stripe Radar API: POST /v1/radar/payment_evaluations
    Your App->>Stripe Radar API: { payment_method_token, radar_session_token, billing_details.email }
    Stripe Radar API-->>Your App: { fraudulent_payment_signal }
```
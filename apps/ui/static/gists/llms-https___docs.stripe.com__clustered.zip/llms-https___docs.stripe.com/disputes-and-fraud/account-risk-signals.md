## Account Risk Signals

This section details how Stripe provides risk signals for connected accounts, helping you detect and respond to potential issues before they impact your business.

### Overview

The Account Signals API offers risk intelligence for your connected accounts, enabling you to identify and mitigate risks in three key categories:

*   **Fraudulent Merchant:** Detect connected accounts engaged in fraudulent activities, such as misrepresenting goods or services, processing unauthorized transactions, or committing first-party fraud.
*   **Account Delinquency:** Identify connected accounts exhibiting signs of financial distress that could lead to unfulfilled orders, increased disputes, or an inability to cover refunds.
*   **Fraudulent Website:** Flag connected accounts operating deceptive or policy-violating websites, including those with misleading product claims, fake storefronts, or content that contradicts their stated business model.

### How it Works

Stripe continuously evaluates your connected accounts using machine learning models trained on millions of payments across the Stripe network. When a risk signal changes, Stripe sends a webhook event to your endpoint, allowing you to take immediate action.

### Signal Types

Learn how to use each signal type:

*   **Fraudulent Merchant Signal:** Detects connected accounts engaging in fraudulent activity using ML models trained on Stripe network data.
*   **Account Delinquency Signal:** Identifies connected accounts at risk of financial distress that might lead to negative balances.
*   **Fraudulent Website Signal:** Evaluates whether a connected account's website is deceptive or violates policy.
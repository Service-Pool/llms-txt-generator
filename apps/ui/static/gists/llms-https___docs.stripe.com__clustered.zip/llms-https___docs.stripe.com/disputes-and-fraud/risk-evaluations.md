## Risk Evaluations

Stripe Radar includes an adaptive AI model that uses a risk score to evaluate the risk level for each payment in real time. The model uses hundreds of risk factors about each payment and data across our network of businesses to predict whether a payment is likely to be fraudulent. It learns from new customer purchase patterns and transaction features, and incorporates feedback from you whenever payments are marked as fraudulent.

Risk settings and the risk controls for fraudulent disputes and early fraud warnings don’t use this AI model. They use more specialized models that can balance the tradeoffs between authorization and fraud.

When a business using Stripe sees a card, a SEPA Direct Debit account, or an ACH account, Stripe has likely processed payments for that payment method in the past:

*   92% chance we’ve seen the card
*   82% chance we’ve seen the SEPA account
*   71% chance we’ve seen the ACH account

### When to Use Radar

Radar evaluates risk and runs rules for three Stripe API objects: Charges, PaymentIntents and SetupIntents. Stripe designed the Radar rules to take four actions:

*   Request 3DS authentication
*   Allow the creation of the object
*   Block the creation of the object
*   Review the object
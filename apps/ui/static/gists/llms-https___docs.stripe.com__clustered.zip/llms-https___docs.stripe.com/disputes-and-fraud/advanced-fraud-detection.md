## Advanced Fraud Detection

Stripe.js is Stripe’s JavaScript library designed to enable businesses to securely collect sensitive payment information from the customer’s browser. The Stripe In-App Payments provides the native iOS and Android counterparts to Stripe.js.

Stripe.js and the mobile SDKs provide advanced fraud detection by looking at risk factors about device characteristics and user activity that help distinguish between legitimate and fraudulent transactions. These risk factors power Stripe’s fraud prevention systems, such as Radar. The risk factors are transmitted to Stripe’s back end by periodically making requests to the m.stripe.com endpoint.

Also, on each page where you load Stripe.js, it can load hCaptcha. hCaptcha is a type of CAPTCHA that helps stop fraud and provides additional risk factors to Stripe while being low friction for legitimate customers. To opt out of use of hCAPTCHA integration, reach out to Stripe Support.

Our goal is to maximize payments from legitimate customers while minimizing fraud. Fraud can be one of the most challenging aspects of running an online business. Even businesses that don’t typically see significant
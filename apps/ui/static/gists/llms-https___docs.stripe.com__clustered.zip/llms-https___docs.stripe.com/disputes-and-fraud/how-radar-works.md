# How Radar Works

Stripe Radar provides real-time fraud protection and requires no additional development time. Radar for Fraud Teams adds customization capabilities and deeper insights and trend analysis for your business. Radar for Platforms provides protection against both transaction and account risk.

Radar evaluates transactions in real-time, using AI algorithms to assess the risk of fraud. All Radar pricing tiers charge a fee for each transaction they evaluate, including the first transaction and all subsequent transactions for recurring payments. The exception is Stripe Billing users, who we only bill for the first transaction—we don’t bill subsequent transactions. Radar for Platforms also charges a connected account fee.

Radar screens all payment attempt types (for example, successful, declined, blocked, and flagged for review) and the following payment method types:

*   Cards
*   Wallets (when the underlying payment method is a card)
*   ACH Direct Debit
*   SEPA Direct Debit

**Preview**
Other popular payment methods

Radar doesn’t screen SetupIntents for non-card payment methods.

## Features

*   **AI-based fraud detection:** Enable risk controls on your account to automatically identify and block elevated or high-risk payments that are likely to result in fraudulent disputes or early fraud warnings.
*   **Custom rules engine:**
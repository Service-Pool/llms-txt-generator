## High-Risk Merchant Lists

Card networks maintain databases of merchants who have had their accounts terminated by payment processors due to high chargeback rates or violations of card brand rules. These databases, known as Terminated Merchant Files (TMFs), include Mastercard's MATCH and Visa's VMSS.

**Key Takeaways:**

*   **Purpose:** TMFs are used by payment processors to identify and manage high-risk merchants.
*   **Consequences:** Being listed on a TMF can make it difficult to establish new merchant accounts, as many entities refuse to work with listed businesses.
*   **Common Lists:**
    *   **MATCH (Mastercard Alert to Control High-risk Merchants):** Mastercard's database of TMFs.
    *   **VMSS (Visa):** Visa's equivalent to MATCH.
*   **Merchant Responsibility:** It's crucial for merchants to understand TMF criteria to avoid being listed and to maintain their ability to process payments.

**Understanding MATCH and VMSS:**

*   **MATCH:** Contains information about accounts closed by credit card processors globally due to high chargebacks or rule violations.
*   **VMSS:** Serves a similar purpose for Visa.

**Implications for Merchants:**

Merchants must be aware of the criteria that can lead to their inclusion in these lists. Proactive measures to maintain low chargeback rates and adhere to card brand rules are essential to avoid severe business disruption.
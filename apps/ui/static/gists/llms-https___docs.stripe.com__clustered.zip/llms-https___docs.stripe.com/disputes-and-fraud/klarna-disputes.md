## Respond to Klarna Disputes

This section details the lifecycle of Klarna disputes and how to respond to them.

### Klarna Dispute Lifecycle

A dispute arises when a Klarna customer files a complaint or return request for a specific order through the Klarna consumer app. Customers have up to 180 calendar days from the date of capture to file a dispute. These complaints and return requests are associated with specific reason codes that Stripe relays to you. While the process can vary slightly by reason code, it generally follows a standard pattern.

### Dispute-Raising Exceptions

In certain exceptional circumstances, Klarna may raise a dispute outside the standard 180-day limitation. These exceptions include:

*   Fraudulent disputes reported by customers.
*   Legal claims initiated through an external authority.
*   Local consumer protection laws.
*   Debt collection processes.

### Chargeback Dispute Outcomes

Information regarding chargeback dispute outcomes and their financial implications can be found [here](https://stripe.com/docs/payments/klarna/disputes#chargeback-dispute-outcomes).

### Comparison to Card Disputes

There are several key similarities and differences between Klarna disputes and traditional card disputes. For a detailed comparison, please refer to the [comparison section](https://stripe.com/docs/payments/klarna/disputes#comparison-to-card-disputes).
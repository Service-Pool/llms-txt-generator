# Lists

Stripe Radar for Fraud Teams lets you create lists of specific types of information and use them in rules. For example, you might want to create rules using a list of:

*   **Customer IDs for trusted customers.** Use this list to automatically allow payments by these customers.
*   **Email addresses you tied to fraud.** Automatically block any payment with an email address on this list.
*   **Suspicious IP addresses.** Place payments into review that have a matching IP address.

Lists make rules more manageable. Instead of creating individual rules for one item at a time, you can add similar types of information to a list (for example, email addresses) for a rule to use automatically.

## Default lists

Stripe Radar includes a set of default lists to help you get started. Your default allow and block rules can reference the allow and block lists in the following categories. Some lists are relevant across payment methods, and others apply only to specific payment methods.

*   Cards
*   ACH Direct Debit
*   SEPA Direct Debit

### Card BIN

The Bank Identification Number (BIN) of the card being used to make the payment. This is the first six digits of the card number.
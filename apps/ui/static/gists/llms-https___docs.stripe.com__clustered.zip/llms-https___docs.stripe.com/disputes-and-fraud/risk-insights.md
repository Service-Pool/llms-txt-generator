## Risk Insights

Understand risk factors and details about a particular payment.

Stripe Radar’s AI model determines the risk score and risk level for a payment and uses them to decide when to block or mark payments for review. The system evaluates hundreds of risk factors about each payment, using data from Stripe’s network across millions of businesses. The risk insights feature, available with Stripe Radar for Fraud Teams, provides a sneak peek into some of the risk factors that power Radar’s AI model.

### Risk insights for payments

**Note:** We store risk insights data for up to 6 months. If a transaction is older than this, you won’t be able to access the risk insights interface.

Risk insights also includes information about the customer, such as matching the cardholder’s name with the provided email, and the success rate of transactions on the Stripe network associated with the email address. A low authorization rate might indicate suspicious behavior, because previous declines sometimes suggest past attempts at fraudulent transactions.

We also highlight geography-based information, including the billing, shipping, and, IP address locations associated with this payment.

### Risk insights

If you want to see more Radar’s risk factors, click the **Show all** button.
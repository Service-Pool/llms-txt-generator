## Fraud Prevention Rules

Fraud prevention rules allow you to take action whenever a payment matches certain criteria. Stripe Radar provides built-in rules to help detect and protect you against fraud risk on card, ACH, and SEPA Direct Debit payments.

Radar for Fraud Teams and Radar for Platforms let you use the Dashboard to create custom rules based on the business logic specific to your business. For example, you can:

*   Request 3D Secure (3DS) for all payments that support it and are made by a new customer
*   Allow all payments from your call center’s IP address
*   Block payments made from a location or card issued outside your country
*   Review all payments greater than 1,000 USD that were made with a prepaid card
*   Review and automatically pause payouts on accounts that have a high dispute rate (with Radar for Platforms)

**Caution:** EU businesses might be affected by the Geo-blocking Regulation and its prohibitions on blocking payments from customers based in EU member states.

### Built-in rules

The following rules are available by default, unless flagged as custom rules, which are only available if you use Radar for Fraud Teams or Radar for Platforms.

*   **Block fraud automatically**
    Alternatively,
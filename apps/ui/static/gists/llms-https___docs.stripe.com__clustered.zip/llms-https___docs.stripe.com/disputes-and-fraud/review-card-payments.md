## Review Card Payments

While Stripe’s automated systems work to prevent fraud on your account, you can use reviews to provide an extra layer of fraud protection by giving card payments a manual inspection.

For example, you might want to review transactions that:

*   Have an elevated risk of fraud according to Stripe’s fraud protection system
*   Were made from outside your country
*   Are greater than a certain amount
*   Use an email address from an unusual domain

The review queue of Stripe Radar for Fraud Teams allows you to examine unusual payments, without having to look at each payment individually. You can create a targeted list of payments to review with criteria that you specify, and review them in the Dashboard.

**Note:** Review rules apply only to card payments. For ACH and SEPA Direct Debit, we recommend you test your rules by drafting an allow or block rule and viewing the test results on the Review new rule page to see how your rules might perform.

### Review Payments

The Dashboard review queue is a prioritized list of completed or to-be-captured payments that might need further investigation. You can review payments by:

*   **List view:** Scan a list of
```markdown
## Supported Attributes for Radar Rules

This section provides a comprehensive list of attributes that can be used within Stripe Radar rules to define specific criteria for fraud prevention and dispute resolution. Understanding these attributes is crucial for writing effective rules that accurately target desired payment behaviors.

### Rule Structure

Radar rules consist of two main components: an **action** and a **condition**. Together, they form a predicate that dictates how Radar processes a payment. For example, a rule to automatically resolve disputes under $10 would be structured as:

`Resolve dispute if :amount_in_usd: <= 10.00`

Here, "Resolve dispute" is the action, and ":amount_in_usd: <= 10.00" is the condition.

### Payment Method Specific Attributes

When writing rules, you can leverage attributes specific to different payment methods. It's important to note that for transactions not using a particular payment method, non-Boolean attributes for that method will be treated as missing. This means rules depending on such attributes cannot act on transactions that don't utilize the relevant payment method.

#### Card

*   **`:is_3d_secure`** (Boolean): Identifies if the payment uses a 3D Secure source.
*   **`:is_3d_secure_authenticated`** (Boolean): Identifies if the payment was authenticated after a successfully completed 3D Secure verification (either risk-based or challenge-based).
*   **`:has_liability_shift`** (Boolean): Provides an approximation of whether the payment might have liability shift. This is true if a non-wallet card payment had liability shift prior to authorization. However, the gateway might downgrade liability shift due to network rules, making this attribute potentially inaccurate. Conversely, `has_liability_shift` might be false for certain digital wallets that actually have liability shift.

#### Amount

*   **`:average_usd_amount_attempted_on_card_all_time`** (Numeric): Represents the average amount (in USD) of attempted transactions (charges) for the card across all time on your account.

---

**Note:** For a complete and up-to-date list of all supported attributes, including those for ACH Direct Debit and SEPA Direct Debit, please refer to the official Stripe Radar documentation. The attributes available may evolve with platform updates.
```
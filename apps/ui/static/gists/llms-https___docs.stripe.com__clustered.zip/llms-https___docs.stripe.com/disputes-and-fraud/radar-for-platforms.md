# Radar for Platforms

Stripe has developed risk tooling for Connect platforms to help you more effectively prevent, detect, and mitigate both buyer risk and financially risky connected accounts (for example, fraud risk).

Radar for Platforms helps your platform manage risk end-to-end:

*   Identify potential financial risk using machine learning generated risk scores and customized rules engines
*   Investigate connected accounts using risk metrics and indicators
*   Gather additional information using document verification or a selfie confirmation
*   Take action on transactions and connected accounts (including setting reserves)

## Risk signals through the API

**Private preview**

In addition to Dashboard-based risk assessment, Radar for Platforms provides programmatic access to risk signals through the API. These signals enable you to build automated workflows and integrate risk data directly into your platform’s operations. The following signal categories are available in private preview. To request access to the private preview, contact your Stripe account team.

*   **Account fraud signal**: Detect connected accounts engaging in fraudulent activity, such as misrepresenting goods or services, processing unauthorized transactions, or committing first-party fraud.
*   **Account insolvency signal**: Identify connected accounts showing financial distress indicators that might lead to unfulfilled orders, increased disputes, or inability to cover
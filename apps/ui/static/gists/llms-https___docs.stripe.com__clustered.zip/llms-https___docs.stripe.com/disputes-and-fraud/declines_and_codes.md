## Declines and Codes

This section details how Stripe handles payment declines and the various codes associated with them, providing insights into why payments fail and how to address these issues.

### Understanding Payment Declines

*   **Card Declines (`/declines/card`)**: This page explains common reasons for card payment failures, such as insufficient funds, incorrect card data, or suspected fraudulent activity. It also introduces Stripe Sigma for analyzing decline rates.
*   **General Declines (`/declines`)**: This overview page discusses the three primary reasons for payment failures: issuer declines, blocked payments, and invalid API calls. It emphasizes Stripe's role in reducing decline rates and how to investigate payment failures using the Dashboard or API.

### Decline Codes and Resolution

*   **Stripe Decline Codes (`/declines/codes`)**: This resource provides an in-depth look at Stripe's specific decline codes, which offer more detailed explanations than issuer codes. It also covers `advice_code` and suggests next steps for resolving these declines, including specific codes like `authentication_required`.

### Related Concepts

*   **Acceptance Analytics (`/payments/analytics/acceptance`)**: While not directly about declines, this page helps understand factors affecting payment acceptance and reasons for payment failures, offering insights to improve success rates.
*   **3D Secure Authentication (`/payments/3d-secure`)**: This page explains how 3D Secure adds a security layer to card transactions, which can impact authentication and potentially prevent declines related to fraud.
*   **Strong Customer Authentication (SCA) Exemptions (`/payments/3d-secure/strong-customer-authentication-exemptions`)**: This page details exemptions that can reduce friction for customers during authentication, potentially impacting decline rates for certain transactions.
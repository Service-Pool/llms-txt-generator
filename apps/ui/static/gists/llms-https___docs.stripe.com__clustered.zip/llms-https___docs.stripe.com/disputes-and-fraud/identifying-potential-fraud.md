## Identifying Potential Fraud

This section provides guidance on how to identify potential fraudulent transactions, leveraging both external indicators and implicit signals.

### Understanding Merchant Responsibility

Stripe users are responsible for fulfilling orders and possess the most comprehensive customer information at the time of purchase. This positions them best to determine the legitimacy of a payment. While external indicators like Early Fraud Warnings exist, many fraud activities exhibit implicit signs that, when combined, can more clearly indicate a fraudulent transaction.

### Leveraging Stripe Radar for Fraud Teams

For users of Stripe Radar for Fraud Teams, payments with an elevated risk of fraud are automatically placed under review. You can further enhance this by creating custom rules based on specific factors to either block these payments entirely or flag them for manual review.

### Implicit Fraud Indicators

While not definitive on their own, the presence of multiple implicit indicators can strongly suggest a fraudulent payment. These indicators help merchants proactively identify and manage suspicious transactions, thereby preventing disputes and fraud.

### Taking Action

Stripe's recommendations aim to prevent disputes and fraud but cannot eliminate them entirely. Merchants are empowered to accept or refund any payments they deem fraudulent and are equipped to accept the financial responsibility for any suspicious payments.
## Card Verification Checks

When a card payment is submitted to a card network for authorization, Stripe provides the CVC, postal code, and billing street address for them to verify (if you collected these from the customer in your checkout flow). The card issuer checks this against the information they have on file for the cardholder. If the provided information doesn’t match, the verification check fails. A failed CVC or postal code check can indicate the payment is fraudulent, so review it carefully before fulfilling the order.

Each `Charge` object includes the verification response as part of its `source` attribute. You can also find the verification results in the Dashboard when viewing a payment.

If no information is collected, the card issuer can’t perform a verification check. Collect the CVC, postal code, and billing address for every payment to avoid this issue. The results of verification checks help improve the detection of fraudulent activity.

### Card Verification Code Check (CVC)

The CVC (or CVV) is the three- or four-digit number printed directly on a card that only cardholders can access.
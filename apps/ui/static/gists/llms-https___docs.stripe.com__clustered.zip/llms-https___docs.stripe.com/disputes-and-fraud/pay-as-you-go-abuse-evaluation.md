# Pay-as-you-go abuse evaluation

The Radar API provides a non-payment abuse signal that can help you identify subscription customers who are unlikely to pay their next invoice. This is useful for post-paid billing models where customers accumulate usage before being charged. For example, usage-based services that bill at the end of the month.

Use this signal to manually review high-risk accounts, issue an early invoice, or limit product access before a billing cycle ends.

## How it works

Instead of evaluating a payment at checkout, you simulate a future invoice payment to receive a non-payment abuse risk signal. The risk signal indicates whether the customer’s upcoming invoice is at risk of abuse.

Use the Payment Evaluation endpoint for evaluation outside of a checkout flow, such as a background worker that evaluates subscriptions mid-billing cycle. A Radar Session isn’t required, so the `client_device_metadata_details` field is optional for this use case.

## Create a payment evaluation

To request a non-payment abuse risk level, you need a payment method, customer, and the expected invoice amount. Call `POST /v1/radar/payment_evaluations` with the following parameters:

| Parameter | Type | Description |
|---|---|---|
| `payment_method` | String | The ID of the PaymentMethod to use for the evaluation. |
| `customer` | String | The ID of the Customer to use for the evaluation. |
| `amount` | Integer | The expected invoice amount in the smallest currency unit (e.g., cents for USD). |
| `currency` | String | The currency of the invoice amount (e.g., `usd`). |
| `radar_session` | String | The ID of a Radar Session to use for the evaluation. |
| `client_device_metadata_details` | Object | Details about the client device. |
| `client_device_metadata_details.ip_address` | String | The IP address of the client device. |
| `client_device_metadata_details.user_agent` | String | The user agent of the client device. |

The response will include a `risk_level` indicating the likelihood of abuse, and `risk_score` for more granular analysis.
## How Dispute Prevention Works

Stripe has integrated with dispute prevention solutions offered by Verifi (a Visa solution) and Ethoca (a Mastercard solution). These integrations allow you to leverage these products without manual setup, helping to reduce your dispute rate and increase revenue retention.

### Verifi and Ethoca Solutions

*   **Verifi:** Includes Order Insights (OI) and Rapid Dispute Resolution (RDR).
*   **Ethoca:** Includes Ethoca Alerts.

### Benefits of Dispute Prevention

Enrolling in Dispute Prevention offers several advantages:

*   **Reduced Dispute Rates:** Proactively address disputes, leading to a lower overall dispute rate.
*   **Lowered Dispute Fees:** By resolving disputes before they escalate, you can avoid associated fees.
*   **Avoid Network Fines:** High dispute rates can lead to fines from card networks. Dispute prevention helps you stay compliant and avoid these penalties.
*   **Stripe Payment Volume Reserves:** Maintaining a low dispute rate can prevent Stripe from placing reserves on your payment volume.

### Rapid Dispute Resolution (RDR)

RDR allows you to construct a ruleset to resolve incoming disputes on Visa transactions for a fee per dispute. For example, you can set up rules to resolve all potential fraud disputes under $10.

**Key Benefits of RDR:**

*   **Disputes Don't Count Towards Your Rate:** Resolved disputes through RDR do not count towards your overall dispute rates, which helps you avoid monitoring programs.
*   **No Separate Dispute Received Fee:** You do not incur a separate dispute received fee for these resolved disputes.

**Note:** Verifi currently does not support partial dispute resolution or disputes on refunded transactions. Therefore, RDR only resolves disputes when the cardholder disputes the transaction and it has not been refunded.
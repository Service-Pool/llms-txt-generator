## Dispute Reason Codes

Each card network defines hundreds of codes representing very specific reasons for dispute claims, many of which overlap across all networks. Stripe maps each network code into one of seven categories based on the general claim. This guide covers the most common dispute reasons for Visa, Mastercard, and American Express. We’ve organized these into seven categories and provide examples of evidence you can use to challenge each type of dispute.

The cardholder’s bank, not Stripe, decides the outcome of each dispute. For general guidance on what you need for each category, see Category defense guidelines. For more comprehensive network guidance, reference the official network’s documentation.

**Note:** The following tables include possible evidence to submit when countering a claim, but each dispute is different. We encourage you to review each situation individually to determine how to respond.

### Visa

| Stripe category             | Visa code                               |
| :-------------------------- | :-------------------------------------- |
| Credit not processed        | 13.6 Credit not processed               |
| Canceled Merchandise/Services | 13.7                                    |
| Duplicate                   | 12.6.1 Duplicate processing             |
|                             | 12.6.2 Paid by other means              |
| Fraudulent                  | 33 Fraud analysis request               |
|                             | 10.1 EMV Liability Shift Counterfeit Fraud |
|                             | 10.2 EMV Liability Shift Non-Counterfeit Fraud |
|                             | 10.3 Other Fraud - Card Present Environment |
|                             | 10.4 Other Fraud - Card Absent Environment |
|                             | 10.5 Visa Fraud Monitoring Program      |
| General                     | 28 Request for copy bearing signature   |
|                             | 30 Cardholder request due to dispute    |
|                             | 34 Legal process request                |
|                             | 11.1 Card Recovery Bulletin             |
|                             | 11.2 Declined Authorization             |
|                             | 11.3 No Authorization                   |

### Mastercard

*(Content for Mastercard categories and codes would go here)*

### American Express

*(Content for American Express categories and codes would go here)*
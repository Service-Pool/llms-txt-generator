## Measuring Disputes

Understanding your dispute activity and rate is crucial for managing your business effectively and maintaining good standing with card networks. Stripe provides tools to help you track and analyze these metrics.

### Key Metrics

Stripe's Dashboard displays two primary calculations for measuring disputes:

*   **Dispute Activity:** This metric represents the **percentage of disputes on successful payments, calculated by dispute date.** It accounts for all disputes received within a given period, regardless of when the original payment was processed.
*   **Dispute Rate:** This metric represents the **percentage of disputes on successful payments, calculated by charge date.** It only includes disputes for payments that were processed within the specified period.

### Understanding the Difference with an Example

Let's say you processed 1,000 payments in a given week, and in that same week, you received 10 disputes.

*   If only 3 of those disputes were from the 1,000 payments processed that week, and the other 7 disputes were from payments processed earlier, then:
    *   Your **Dispute Activity** for that week would be 1% (10 disputes / 1,000 payments).
    *   Your **Dispute Rate** for that week would be 0.3% (3 disputes / 1,000 payments).

This distinction is important because disputes can take time to be reported, leading to a difference between when a dispute is *received* and when the *charge* occurred.

### Importance of Dispute Activity

Card networks like Visa and Mastercard use the **dispute activity** calculation for their fraud and dispute monitoring programs. If your dispute activity consistently exceeds the thresholds set by these networks over several months, you may be placed into one of their monitoring programs. These programs can involve additional fines and fees, and in severe cases, can jeopardize your ability to accept credit card payments.

By monitoring these metrics, you can proactively identify potential issues and take steps to reduce your dispute volume, thereby avoiding negative consequences and protecting your business.
## Set up and configure Smart Disputes

Automatically fight disputes and improve your dispute win rates.

Smart Disputes automatically compiles and submits high-quality evidence packets on your behalf before the dispute deadline. This helps you recover revenue you might otherwise lose to timeouts or incomplete submissions, while still giving you full control to review, edit, or submit your own evidence.

No additional setup is required after you enroll your account in Smart Disputes. Stripe builds and submits evidence packets automatically when enough data is available. You can also manually enhance these packets to improve performance.

### How it works

After you’re notified of a dispute:

1.  Stripe automatically builds evidence packets for every eligible dispute.
2.  You retain full control, and you can:
    *   Submit your own evidence or the Smart Dispute packet manually.
    *   Accept the dispute.
    *   Rely on Smart Disputes to submit evidence automatically before the dispute deadline.
3.  Improve your odds of winning by adding evidence to a Smart Disputes packet.
4.  If you take no action, Smart Disputes submits the packet automatically to make sure you don’t miss the opportunity to contest a dispute. If you prefer, you can engage manually by submitting it before the deadline or adding more evidence to improve your likelihood.
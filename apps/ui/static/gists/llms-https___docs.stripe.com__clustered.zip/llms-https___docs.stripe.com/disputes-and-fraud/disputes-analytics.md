## Disputes Analytics

This section provides an overview of how to understand and analyze dispute volume, rates, and outcomes within the Stripe Dashboard.

**Key Features:**

*   **Dispute Volume and Rate Monitoring:** Track the number of disputes and the percentage of successful payments that result in disputes. This is crucial for understanding your business's dispute activity and identifying potential risks.
*   **Dispute Category Analysis:** Analyze disputes across various categories, including by payment method and country, to pinpoint specific areas of concern.
*   **Reason Code Understanding:** Gain insights into the underlying reasons for disputes, enabling you to address the root causes effectively.
*   **Evidence Submission Performance:** Monitor and improve your performance in submitting evidence for disputes, which can significantly impact win rates.

**How Disputes Affect Your Business:**

*   **Financial Impact:** Understand the direct financial consequences of disputes, including lost revenue and dispute fees.
*   **Monitoring Program Risk:** Assess whether your dispute rate puts you at risk of entering card network monitoring programs, which can lead to additional fines and fees.
*   **Overall Business Health:** Regular monitoring of dispute activity helps in maintaining a healthy and sustainable business by proactively addressing issues.

**What's Included and Excluded:**

*   **Included (Card Mode):** Subsequent disputes (multiple disputes on the same charge), Early Fraud Warnings (EFW).
*   **Excluded:** Inquiries, Hidden disputes (handled automatically by Stripe), RDR (Rapid Dispute Resolution) and prevented disputes.

By leveraging the Disputes analytics page in the Stripe Dashboard, you can gain a comprehensive understanding of your dispute landscape and implement strategies to mitigate risks and improve outcomes.
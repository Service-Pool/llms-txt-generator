## Disputed PayPal Payments

Customers must authenticate any payment with their PayPal account to decrease the risk of fraud. However, customers can dispute PayPal payments if, for example:

*   They don’t receive the goods they paid for.
*   The received goods don’t match their description.

Note that your settlement choice when activating PayPal affects the funds flow for PayPal disputes. See [Choose settlement preference](https://stripe.com/docs/paypal/settings#settlement-preference) for more context.

### Dispute Process

Customers can file a dispute on PayPal up to 180 calendar days from the date of purchase. They can also file a dispute through the payment method they used to complete the PayPal purchase (such as their bank).

After the customer initiates a dispute, Stripe notifies you through:

*   Email
*   The Stripe Dashboard
*   An API `charge.dispute.created` event (if your integration is set up to receive events to an event destination)
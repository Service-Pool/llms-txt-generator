## Radar Analytics Center

The Radar analytics center in the Dashboard helps you analyze and understand the state of fraud for your business. Stripe provides several reports with information about how much fraud Radar blocks for your business and the top fraud-related metrics for your business over time.

Using Fraud insights, Sigma, or Data Pipeline, you can use Radar rule attributes alongside your own dataset to:

*   Continuously improve your fraud management.
*   Identify fraudulent payments.
*   Create a deeper understanding of your customers.
*   Analyze data in an environment that works best for you.

We’ve enhanced the depth and breadth of data we analyze in the new Radar analytics center view, which appears by default in your Radar Overview tab of the Dashboard. To return to the legacy overview page, use the New overview toggle.

### Radar Analytics center

Preview

### Legacy Radar overview

The Overview tab of your Radar Dashboard acts as a command center to help you gauge the efficacy of your fraud prevention strategy and Radar interventions. From here, you can:

*   View graphs detailing how fraud affects your business and how effectively Radar manages it.
*   Compare your fraud intervention results to other businesses like yours.
*   Track
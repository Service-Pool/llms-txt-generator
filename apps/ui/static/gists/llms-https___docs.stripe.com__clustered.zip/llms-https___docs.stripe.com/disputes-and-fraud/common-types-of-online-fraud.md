## Common Types of Online Fraud

A payment is considered fraudulent when the cardholder didn’t authorize it. Most fraudulent payments are made using stolen cards or card numbers. When a cardholder is notified that the payment has been made or they review their card statement, they contact their card issuer to dispute it.

Online fraud is fundamentally different to fraud that occurs at brick-and-mortar businesses as it’s harder to be certain that the person you’re selling to is who they say they are. Some fraudulent actors adopt more sophisticated methods than just trying to make purchases on a stolen card. When accepting payments online, it’s important to be aware of the different kinds of fraud and what your liability is.

### Suspected fraud

Stripe’s AI model continuously monitors all payments processed by our users. In rare cases, you might receive a notification from Stripe that we suspect a payment is fraudulent after the card issuer authorizes it. This can occur if we detect subsequent activity on the card that now suggests it’s being used fraudulently.

Although we notify you as
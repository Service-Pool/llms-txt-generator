## Smart Disputes

Automate evidence collection and submission for eligible card disputes.

Smart Disputes saves you time by automating evidence collection, compilation, and submission for eligible disputes on card transactions. To get started with Smart Disputes, see Set up and configure Smart Disputes.

### Automate dispute management

Smart Disputes uses an AI rules engine to analyze incoming disputes. It extracts relevant evidence from Stripe internal data, your transaction data, and cardholder data. The system tailors this evidence to the dispute reason to help you win. We determine Smart Disputes eligibility using multiple factors, including the dispute reason code, payment method, evidence availability, evidence relevance, and cost.

### Save time

Smart Disputes automatically assembles evidence packets for eligible disputes when you receive a dispute and submits them before the dispute deadline, so you don’t have to contest them.

### Recover revenue

We use artificial intelligence and insights from the Stripe network to tailor evidence packets that help you recover disputed revenue.

### No integration required

Smart Disputes is built into Stripe and requires no additional integration work if you already use Stripe.

### How it works

When you receive a Smart Disputes eligible dispute, Stripe notifies you by email and in the Dashboard. If you don’t take any
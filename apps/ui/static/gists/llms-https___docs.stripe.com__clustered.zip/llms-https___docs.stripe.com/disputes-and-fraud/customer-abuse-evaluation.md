## Customer Abuse Evaluation

This page provides information on how to use Stripe's Customer Abuse Evaluation API to detect and prevent various forms of customer abuse.

### Key Features:

*   **Detect Multi-accounting and Account Sharing:** Identify suspicious patterns during account registration and login to prevent abuse before payment is collected.
*   **Upfront Risk Scores:** Obtain risk scores earlier in your workflow (at login or registration) compared to traditional PaymentIntents, enabling proactive decisions about account access.
*   **No Payment Collection Required:** Evaluate risk without needing to collect payment information upfront.

### Customer Evaluation Lifecycle:

1.  **Client-side:** Use Stripe.js to create a Radar Session, which captures device metadata. Send the session token to your server.
2.  **Server-side:**
    *   Create a customer or use an existing Customer object.
    *   Request a `CustomerEvaluation` when customers register or log in.
3.  **Post-evaluation:** Report the outcome to Stripe to improve future evaluations.

### How it Works:

The Customer Evaluation API provides risk intelligence for your registration and login flows. By analyzing device metadata and other signals, it helps detect suspicious activities like multi-accounting and account sharing. This allows you to make informed decisions about blocking or allowing account access, thereby preventing service abuse.
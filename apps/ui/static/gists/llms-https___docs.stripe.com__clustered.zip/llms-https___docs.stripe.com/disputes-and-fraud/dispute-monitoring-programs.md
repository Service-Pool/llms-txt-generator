```markdown
## Dispute and Fraud Card Monitoring Programs

As part of your financial obligations to the card networks, you must keep disputes (also called chargebacks) and fraud at acceptable levels. If they exceed the thresholds dictated by a network (for example, Visa or Mastercard), the network places you into one of their monitoring programs. As part of a program, you can incur monthly fines and additional fees until you reduce your dispute or fraud levels in a sustained way.

Stripe can work with you on a remediation plan to reduce the levels of disputes or fraud related to your account. We also communicate directly with the networks and relay information on a monthly basis. Download our remediation template to get started.

While monitoring programs are comparatively rare, take them seriously. If you’re placed into one, you must take immediate action to address the situation. Failure to comply with the requirements of a program within the specified time period can result in the network refusing to process further payments to you. This can put your ability to accept any credit card payments at risk.

**Note:** This page
```
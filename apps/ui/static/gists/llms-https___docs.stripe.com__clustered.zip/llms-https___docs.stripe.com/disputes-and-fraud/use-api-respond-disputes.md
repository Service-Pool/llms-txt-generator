## Managing Disputes and Declines

This section provides comprehensive guidance on handling payment disputes and declines within the Stripe ecosystem. It covers understanding the dispute lifecycle, responding to disputes, leveraging Stripe's tools for prevention and automation, and mitigating risks associated with fraudulent activity.

### Understanding Disputes

*   **How Disputes Work:** Learn the standard lifecycle of a payment card dispute, from initial customer contact with their bank to Stripe's notification and the merchant's response. This includes understanding how disputes are initiated, the associated fees, and Stripe's role in facilitating the evidence submission process.
*   **Disputes Overview:** Gain a general understanding of disputes (also known as chargebacks), their immediate impact on your account balance, and how Stripe guides you through the resolution process.
*   **Dispute Reason Code Categories:** Explore the eight categories Stripe uses to organize dispute reason codes across different payment methods, helping you understand the general claim type and required evidence.
*   **Dispute Reason Codes:** Delve into specific dispute reason codes for major networks like Visa, Mastercard, and American Express, understanding their nuances and the evidence needed to challenge them.
*   **Dispute Withdrawals:** Understand what happens when a cardholder withdraws a dispute, noting that it doesn't automatically mean a win for the merchant and still counts towards dispute rates.
*   **Measuring Disputes:** Learn how Stripe calculates and displays dispute activity and dispute rate, crucial metrics for monitoring your business's performance and avoiding card network monitoring programs.
*   **Dispute and Fraud Card Monitoring Programs:** Understand the implications of exceeding dispute or fraud thresholds set by card networks, including potential fines and the risk of being placed in monitoring programs. Learn how Stripe assists in remediation.
*   **Disputes Analytics:** Analyze your dispute volume, rates, and outcomes to understand their financial impact and identify risks of entering card network monitoring programs.

### Responding to Disputes

*   **Respond to Disputes:** Learn how to challenge or accept disputes directly within the Stripe Dashboard, understanding notification channels and the importance of responding before the deadline.
*   **Use the API to Respond to Disputes:** Discover how to programmatically manage disputes by uploading evidence, responding to claims, and receiving dispute events via webhooks.
*   **Dispute Evidence Best Practices:** Implement strategies for formatting and presenting the most convincing evidence to successfully challenge a dispute, focusing on clarity, chronology, and completeness.
*   **Visa Compelling Evidence 3.0 Disputes:** Understand the criteria and API usage for responding to specific Visa disputes that allow businesses to combat friendly fraud by demonstrating a non-fraudulent history with cardholders.
*   **Visa Compliance Disputes:** Learn how to identify and respond to Visa compliance disputes, which arise when a transaction is believed to violate Visa's network rules, and understand the associated fees.

### Preventing and Automating Disputes

*   **Dispute Prevention:** Explore Stripe's solutions for automatically preventing disputes and lowering your dispute rate, including features like automatic resolution and deflection.
*   **How Dispute Prevention Works:** Understand the benefits and requirements of Stripe's dispute prevention solutions, which integrate with Verifi and Ethoca to reduce dispute rates and avoid network fines.
*   **Configure Smart Disputes Auto-Respond Settings:** Learn how to set up Smart Disputes to automatically submit evidence for eligible disputes, saving time and avoiding missed deadlines.
*   **Set up and Configure Smart Disputes:** Discover how to automate evidence collection and submission for eligible card disputes, improving your chances of winning and recovering revenue.
*   **Smart Disputes:** Understand how Stripe's AI-powered Smart Disputes feature automates evidence collection and submission to help you win disputes and recover funds.

### Understanding and Preventing Fraud

*   **Declines Overview:** Get a general understanding of why payments might fail, including issuer declines, blocked payments, and invalid API calls.
*   **Card Declines:** Learn about common reasons for card payment declines (insufficient funds, incorrect data, fraud) and strategies to lower your decline rate.
*   **Stripe Decline Codes:** Understand Stripe's specific decline codes and how to resolve them when a charge fails, including associated advice codes for next steps.
*   **Understand Fraud:** Develop a strategy for detecting and preventing fraud and other types of disputed payments using Stripe's resources and tools.
*   **Common Types of Online Fraud:** Familiarize yourself with various online fraud methods and your liability for each.
*   **Identifying Potential Fraud:** Learn about common fraud indicators and how Stripe users are best equipped to identify potentially fraudulent payments.
*   **Protect Yourself from Card Testing:** Understand the fraudulent activity of card testing and implement measures to protect your business against it.
*   **Customer Abuse:** Learn how to protect yourself against refund, resale, and trial abuse by implementing preventative measures.
*   **Card Verification Checks:** Utilize CVC, postal code, and billing address verification to protect against disputes and fraud.
*   **Stripe's Risk Score:** Understand how Stripe's risk assessment can be incorporated into authorization decisions to evaluate fraud risk.
*   **3D Secure Authentication:** Reduce fraud and meet regulatory requirements by implementing 3D Secure (3DS) authentication for card transactions.
*   **Strong Customer Authentication (SCA) Exemptions:** Utilize SCA exemptions to reduce cardholder friction while meeting regulatory requirements in the EEA, Switzerland, and the UK.
*   **Strong Customer Authentication Readiness:** Understand how the SCA regulation impacts your business and how to update your integration to support it.
*   **Radar:** Utilize Stripe Radar for real-time fraud protection, leveraging AI algorithms to assess risk and automate responses.
*   **How Radar Works:** Learn about Stripe Radar's features for real-time fraud protection, including AI-based detection and a custom rules engine.
*   **Optimize Risk Factors:** Understand how providing more relevant data to Stripe Radar improves fraud prevention effectiveness.
*   **Risk Evaluations:** Review the outcomes of Stripe Radar risk evaluations, which use an adaptive AI model to predict fraudulent payments.
*   **Risk Setting and Risk Controls:** Automatically adjust fraud protection thresholds based on your business needs and risk tolerance.
*   **Fraud Prevention Rules:** Create custom rules in Stripe Radar to take specific actions when a payment matches certain criteria.
*   **Dispute Resolution Rules:** Learn how to write rules in Radar to automatically resolve specific disputes, such as refunding low-value disputes.
*   **Fraud Alerts:** Receive notifications when Stripe detects unusual fraud patterns, allowing for a quick response to mitigate risks.
*   **Fraud Insights:** Analyze fraud trends specific to your business to tailor your fraud-fighting strategy.
*   **Radar Analytics Center:** Analyze and understand fraud patterns and their impact on your business using various reports and tools within the Dashboard.
*   **Customer Abuse Evaluation:** Get risk evaluations for customer account registration and login events to detect multi-accounting and account sharing abuse.
*   **Bot Abuse Prevention:** Use bot scores to detect and prevent bot-driven payments on your platform.
*   **Fraudulent Merchant Signal:** Detect connected accounts engaging in fraudulent activity using Stripe's machine learning models.
*   **Account Delinquency Signal:** Identify connected accounts at risk of financial distress that might lead to negative balances.
*   **Fraudulent Website Signal:** Evaluate a connected account's website for deception or policy violations.
*   **Free Trial Abuse Prevention:** Detect and block customers likely to abuse free trials before they convert to subscriptions.
*   **Lists:** Create custom lists of information (e.g., trusted customer IDs, suspicious IP addresses) to use in Radar rules for blocking, allowing, or reviewing payments.
*   **Radar for Platforms:** Utilize Stripe's risk tooling designed for Connect platforms to manage buyer risk and financially risky connected accounts.
*   **Radar Risk Signals for Multiple Payment Processors:** Evaluate non-Stripe processed payments with Radar to receive risk signals from the Radar AI models.
*   **Provide Radar Additional Fraud Data:** Learn how to capture critical device details using Radar Sessions for more accurate fraud scoring.
*   **Review Card Payments:** Use manual reviews to supplement automated fraud prevention systems by inspecting suspicious card payments.
*   **Risk Insights:** Understand risk factors and details about a particular payment to gain deeper insights into Radar's AI model.
*   **Review Uncaptured Payments:** Learn how to manage reviews for payments that have been authorized but not yet captured.

### Payment-Specific Considerations

*   **Apple Pay Liability Shift, Disputes, and Refunds:** Understand how to manage disputed or refunded Apple Pay payments, including the nuances of liability shifts.
*   **Disputed PayPal Payments:** Learn how dispute management works specifically for PayPal payments, including the dispute process and potential outcomes.
*   **Respond to Disputes (Klarna):** Understand the lifecycle of Klarna disputes and how to respond to them, noting differences from card disputes.
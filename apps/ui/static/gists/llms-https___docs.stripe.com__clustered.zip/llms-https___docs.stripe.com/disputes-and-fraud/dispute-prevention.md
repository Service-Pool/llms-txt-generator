## Dispute Prevention

Disputes, also known as chargebacks, can lead to significant costs. Dispute resolution and deflection help you save on these costs, reduce your dispute rates, and automate part of your dispute management process. To sign up for dispute prevention, go to your Dispute settings.

### Use Dispute Prevention To:

*   **Set resolution rules through Stripe Radar to automatically resolve (refund) specific disputes.** Resolved disputes don’t count towards your dispute rate and don’t incur a dispute received fee.
*   **Deflect disputes by sending extra transaction data with dispute deflection.**
*   **Block disputes entirely if the extra transaction data provided with Order Insights is Compelling Evidence (CE 3.0) eligible.**

You can review and manage dispute prevention from the Dashboard. Learn more about disputes and fraud.

### Benefits

*   **Lower dispute rates:** Automatically refunded disputes don’t count towards your dispute rate.
*   **No integration required:** Stripe integrates directly with Verifi and provides your existing transaction data on your behalf at the time of lookup.
*   **Lower costs:** Fewer disputes means fewer dispute fees.
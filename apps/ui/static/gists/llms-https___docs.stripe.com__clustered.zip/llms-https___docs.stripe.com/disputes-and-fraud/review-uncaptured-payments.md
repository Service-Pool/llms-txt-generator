## Managing and Preventing Disputes

This section of the documentation covers how to handle payment disputes, understand their causes, and implement strategies to prevent them. It details Stripe's tools and processes for managing chargebacks, including responding to disputes, analyzing dispute data, and leveraging fraud prevention measures.

---

### Understanding Disputes

*   **How Disputes Work:** Learn about the lifecycle of payment card disputes, from the initial customer contact with their bank to Stripe's notification and the merchant's role in submitting evidence. This includes understanding pre-dispute notifications and early fraud warnings.
*   **Disputes Overview:** Get a general understanding of what disputes are, why they occur, and how Stripe facilitates the process. It covers the immediate reversal of funds and associated fees.
*   **Dispute Reason Code Categories:** Explore the eight categories Stripe uses to organize dispute reason codes across different payment methods, aiding in understanding the general claim type and required evidence.
*   **Dispute Reason Codes:** Detailed information on common dispute reasons for Visa, Mastercard, and American Express, including examples of evidence needed to challenge each type.
*   **Dispute Withdrawals:** Understand what happens when a cardholder retracts a dispute and how it differs from a standard dispute resolution.

### Responding to Disputes

*   **Respond to Disputes:** Comprehensive guide on how to challenge or accept a dispute through the Stripe Dashboard or programmatically via the API. This includes understanding notification channels and response deadlines.
*   **Use the API to Respond to Disputes:** Learn how to manage disputes programmatically, including uploading evidence, responding to disputes, and receiving dispute events via webhooks.
*   **Dispute Evidence Best Practices:** Guidelines on how to format and present evidence effectively to increase the chances of winning a dispute.
*   **Visa Compelling Evidence 3.0 Disputes:** Specific guidance on using Visa's Compelling Evidence 3.0 criteria to fight friendly fraud with qualifying Visa transactions.
*   **Visa Compliance Disputes:** Information on how to respond to Visa compliance disputes, which arise when a transaction is believed to not conform to Visa's network rules.

### Preventing Disputes and Fraud

*   **Dispute Prevention:** An overview of Stripe's dispute prevention solutions, including the benefits of reducing dispute rates and costs.
*   **How Dispute Prevention Works:** Details on Stripe's integrations with Verifi and Ethoca solutions for dispute prevention, including Rapid Dispute Resolution (RDR).
*   **Automatically Prevent Disputes:** Learn how to use dispute prevention features to automatically resolve or deflect disputes, thereby lowering dispute rates and costs.
*   **Understand Fraud:** Strategies and tools for detecting and preventing fraud and other types of disputed payments, including common fraud indicators and best practices.
*   **Common Types of Online Fraud:** An overview of different fraud types and associated merchant liability.
*   **Identifying Potential Fraud:** Guidance on recognizing common fraud indicators and leveraging Stripe's tools like Radar for Fraud Teams.
*   **Card Verification Checks:** How to use CVC, postal code, and billing address verification to protect against disputes and fraud.
*   **Protect Yourself from Card Testing:** Information on card testing as a fraudulent activity and how to prevent it.
*   **Customer Abuse:** Strategies to protect against refund, resale, and trial abuse, including assessing refund concentration and implementing preventative measures.
*   **Abuse Prevention:** Using Stripe Radar to detect and prevent abuse across the user lifecycle, including customer, free trial, pay-as-you-go, and bot abuse.
*   **Customer Abuse Evaluation:** Utilizing the Customer Evaluation API for risk intelligence during registration and login to detect multi-accounting and account sharing.
*   **Free Trial Abuse Prevention:** Detecting and blocking customers likely to abuse free trials before they convert to subscriptions.
*   **Pay-as-you-go Abuse Evaluation:** Identifying subscription customers at risk of not paying their next invoice.
*   **Bot Abuse Prevention:** Using bot scores to detect and prevent bot-driven payments.
*   **3D Secure Authentication:** Implementing 3D Secure to reduce fraud and meet regulatory requirements for card transactions.
*   **Strong Customer Authentication (SCA) Exemptions:** Utilizing SCA exemptions to reduce cardholder friction while meeting regulatory requirements in the EEA, Switzerland, and the UK.
*   **Stripe's Risk Score:** Leveraging Stripe's risk assessment for authorizations to evaluate fraud risk.
*   **Advanced Fraud Detection:** Using Stripe.js and mobile SDKs for advanced fraud detection by analyzing device characteristics and user activity.

### Automating Dispute and Fraud Management

*   **Smart Disputes:** An overview of the Smart Disputes feature, which automates evidence collection and submission for eligible disputes.
*   **Set Up and Configure Smart Disputes:** Step-by-step guide on enabling and configuring Smart Disputes for automatic dispute fighting.
*   **Configure Smart Disputes Auto-Respond Settings:** How to set up auto-respond for eligible disputes to automatically submit evidence at the deadline.
*   **Radar:** Stripe's AI-powered fraud detection system that evaluates transactions in real-time.
*   **How Radar Works:** An explanation of Radar's features for real-time fraud protection, including AI-based detection and custom rules engines.
*   **Optimize Risk Factors:** Recommendations for providing relevant data to Stripe to improve Radar's fraud detection accuracy.
*   **Radar for Platforms:** Risk tooling designed for Connect platforms to mitigate buyer and connected account risk.
*   **Radar Analytics Center:** Tools and reports for analyzing fraud patterns and their impact on your business.
*   **Fraud Alerts:** Receiving notifications when Stripe detects unusual fraud patterns.
*   **Fraud Insights:** Visualizing and analyzing fraud trends specific to your business to tailor your fraud-fighting strategy.
*   **Risk Evaluations:** Understanding the outcomes of Stripe Radar risk evaluations.
*   **Risk Setting and Risk Controls:** Choosing a risk setting to automatically adjust protection thresholds and balance fraud prevention with revenue.
*   **Fraud Prevention Rules:** Creating custom rules in Radar to take specific actions on payments that match certain criteria.
*   **Dispute Resolution Rules:** Writing rules in Radar to automatically resolve specific disputes.
*   **Lists:** Creating custom lists of information (e.g., customer IDs, email addresses) to use in Radar rules for blocking, allowing, or reviewing payments.
*   **Reviews:** Using manual inspection of card payments to supplement automated fraud detection systems.
*   **Review Uncaptured Payments:** Managing payments that are placed on hold for review before capture.
*   **Risk Insights:** Understanding the risk factors and details that contribute to a payment's risk score.

### Analytics and Monitoring

*   **Payments Analytics:** Tracking and analyzing payment performance using key metrics and reports, including authentication, disputes, and card acceptance.
*   **Acceptance Analytics:** Analyzing payment success rates, network authorization rates, and identifying reasons for payment failures.
*   **Authentication Analytics:** Understanding how 3D Secure impacts payment success rates for card payments.
*   **Disputes Analytics:** Analyzing dispute volume, rates, and outcomes to understand their financial impact and risk of entering monitoring programs.
*   **Payments Optimization:** Utilizing features like Authorization Boost to increase payment success rates and reduce processing costs.
*   **Recommendations:** Receiving suggestions from Stripe to increase revenue and improve fraud detection.
*   **Measuring Disputes:** Understanding dispute activity and dispute rate calculations and their implications.
*   **Dispute and Fraud Card Monitoring Programs:** Learning about card network monitoring programs and what to do if your account is placed into one.
*   **Account Risk Signals:** Obtaining risk signals for connected accounts related to fraud, delinquency, and website legitimacy.
*   **Fraudulent Merchant Signal:** Detecting connected accounts engaging in fraudulent activity.
*   **Account Delinquency Signal:** Identifying connected accounts at risk of financial distress that could lead to negative balances.
*   **Fraudulent Website Signal:** Evaluating a connected account's website for deception or policy violations.

### Specific Payment Methods

*   **Apple Pay Liability Shift, Disputes, and Refunds:** Managing disputed or refunded Apple Pay payments, including understanding liability shifts.
*   **Disputed PayPal Payments:** Understanding how dispute management works for PayPal payments.
*   **Respond to Disputes (Klarna):** The lifecycle of Klarna disputes and how to respond to them.
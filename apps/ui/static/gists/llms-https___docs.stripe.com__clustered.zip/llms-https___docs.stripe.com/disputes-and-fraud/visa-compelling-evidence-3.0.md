## Visa Compelling Evidence 3.0 Disputes

Visa Compelling Evidence 3.0 (CE 3.0) is a set of criteria that allows businesses to present evidence of a non-fraudulent history with cardholders to combat friendly fraud. By submitting qualifying evidence for Visa CE 3.0 eligible disputes, you can increase the likelihood of an issuer reversing friendly fraud disputes in your favor.

### CE 3.0 Qualifying Disputes

To respond to a dispute using Visa CE 3.0, the dispute must meet the following criteria:

*   The disputed transaction must be a Visa transaction with network reason code `10.4`.
*   There must be at least two previous transactions that were not disputed, using the same payment method as the disputed transaction.
*   The previous non-disputed transactions must be within 120-364 days of the disputed transaction.
*   The previous non-disputed transactions must be paid, undisputed, and cannot be validation charges.
*   You must provide descriptions for the disputed transaction’s product and for the past undisputed transactions’ products.
*   You must categorize the disputed transaction as either merchandise or services in the `merchandise_or_services` field.
*   The disputed transaction and both past undisputed transactions must match at least one of the following:
    *   Two main evidence elements (e.g., Customer Purchase IP and Customer Device Fingerprint).
    *   One main evidence element and one secondary evidence element.

### Using the API for Visa CE 3.0

You can use the API to respond to qualifying Visa CE 3.0 disputes. This involves submitting the required evidence through the `evidence` parameter of the Dispute object.

For example, to submit evidence for a Visa CE 3.0 dispute, you would update the dispute object with relevant information such as:

*   `evidence[customer_email_address]`
*   `evidence[shipping_date]`
*   `evidence[shipping_documentation]` (using a `FILE_ID`)
*   `evidence[product_description]`
*   `evidence[customer_purchase_ip]`
*   `evidence[customer_device_fingerprint]`

Refer to the [Dispute evidence documentation](https://stripe.com/docs/disputes/api#update-a-dispute) for a comprehensive list of available fields and their formats.

### Key Considerations

*   **Friendly Fraud:** CE 3.0 is specifically designed to help combat friendly fraud, where a legitimate cardholder disputes a transaction they authorized, often due to misunderstanding or forgetting the purchase.
*   **Evidence Requirements:** Meeting the specific evidence requirements is crucial for a successful CE 3.0 dispute response. Ensure you have detailed product descriptions and matching transaction history.
*   **API Integration:** For programmatic management of disputes, leverage the Stripe API to submit evidence efficiently.
## Stripe's Risk Score

This document explains how to use Stripe's risk assessment to evaluate the level of fraud risk associated with an authorization.

### Overview

Stripe provides a composite score and risk categorization to help you assess the risk level of an authorization. The values exist on a 0-99 scale, with higher values representing higher risk. In addition to the risk score, Stripe provides an assessment of the authorization’s riskiness in an enum value, labeling every authorization as 'normal' or 'high'.

### Network Tools and Performance

The following statistics provide directional guidance on the performance of Stripe's risk tools, depending on your goals (approval rate or fraud prevention):

| Goal                    | Precision | Recall | % Volume Impact |
| :---------------------- | :-------- | :----- | :-------------- |
| Optimizing for fraud prevention | 2%        | 2%     | 0.10%           |
| Balancing fraud prevention and approval rate | 10–15%    | 25–30% | 0.06% – 0.07%   |
| Optimizing for approval rate | 15–20%    | 20–25% | 0.02% – 0.04%   |
|                         | 25–30%    | 10–15% | 0.01% – 0.02%   |

**Note:** Precision and recall are inversely related. Blocking more transactions increases the false positive rate while decreasing the likelihood of allowing fraud. Blocking fewer transactions has the opposite effect.

### Using Risk Scores

We recommend backtesting your data against the score to assess opportunities to use the score to drive down fraud rates. For example, you might find that `fraud_score > 20` and `risk_level = normal` equates to particularly risky authorizations for your portfolio and opt to block authorizations that satisfy those conditions.

### Further Assistance

Contact Stripe for support in adjusting these thresholds or if you have any questions.
## Recommendations

View recommendations on the Acceptance page in the Stripe Dashboard. Depending on availability, you might have no recommendations or up to three at any given time. To dismiss a particular recommendation, click the cancel icon (X).

To share feedback on recommendations, select Feedback in Payments analytics, and click Submit.

**Note:** Carefully consider any recommendations. It’s up to your business to analyze and decide to act on a recommendation. Recommendations don’t constitute professional advice. Any estimated impacts, such as increases in revenue, are estimates and aren’t guaranteed. Stripe doesn’t have all the relevant information about your business to guarantee an outcome. Recommendations might require a tradeoff, such as an increase in costs, risk of fraud, or additional applicable legal terms.

### Recommendation availability

We offer recommendations in your account when they’re relevant to your business. We base recommendations on factors such as your account settings, how you integrate with Stripe, or thresholds. For example, if you share data on some of your payments, but not 80% or more, Stripe might recommend that you share that data on more of your payments. Not all businesses
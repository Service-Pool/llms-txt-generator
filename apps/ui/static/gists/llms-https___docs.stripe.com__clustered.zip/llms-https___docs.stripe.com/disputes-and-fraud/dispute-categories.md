## Dispute Reason Code Categories

This section provides an overview of how Stripe categorizes dispute reason codes across different payment methods and outlines the general evidence guidelines for challenging each category.

Each payment method, such as cards, digital wallets, or Buy Now, Pay Later services, defines a multitude of specific reason codes for dispute claims. To simplify this complexity, Stripe groups these codes into eight overarching categories. These categories are based on the general nature of the claim and the type of evidence typically required to effectively contest it.

You can manage disputes through either the Stripe Dashboard or the API.

### Reason Code Categories

The following tables present Stripe's categories for dispute reason codes, organized by payment method. The specific reason code for a dispute is available on the dispute object. For detailed information on Visa, Mastercard, and American Express reason codes, please refer to the respective network documentation.

#### Visa

| Stripe Category           | Visa Code(s) | Description                                    |
| :------------------------ | :----------- | :--------------------------------------------- |
| Credit not processed      | 13.6         | Credit not processed                           |
|                           | 13.7         | Canceled Merchandise/Services                  |
| Duplicate                 | 12.6.1       | Duplicate processing                           |
|                           | 12.6.2       | Paid by other means                            |
| Fraudulent                | 33           | Fraud analysis request                         |
|                           | 10.1         | EMV Liability Shift Counterfeit Fraud          |
|                           | 10.2         | EMV Liability Shift Non-Counterfeit Fraud      |
|                           | 10.3         | Other Fraud - Card Present Environment         |
|                           | 10.4         | Other Fraud - Card Absent Environment          |
|                           | 10.5         | Visa Fraud Monitoring Program                  |
| General                   | 28           | Request for copy bearing signature             |
|                           | 30           | Cardholder request due to dispute              |
|                           | 34           | Legal process request                          |
|                           | 11.1         | Card Recovery Bulletin                         |
|                           | 11.2         | Declined Authorization                         |
|                           | 11.3         | No Authorization                               |
|                           | 12.1         |                                                |

*Note: This table provides a sample of Visa categories. For a comprehensive list, please consult Stripe's official documentation or Visa's network rules.*
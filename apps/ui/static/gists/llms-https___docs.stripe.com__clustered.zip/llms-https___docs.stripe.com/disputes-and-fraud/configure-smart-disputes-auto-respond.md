## Configure Smart Disputes Auto-Respond Settings

Smart Disputes can automatically submit evidence for eligible disputes at the deadline, helping you avoid missed opportunities to contest chargebacks. This guide explains how to configure auto-respond settings based on your account type.

### How it works

When auto-respond is on, Stripe automatically submits evidence for eligible disputes at the deadline. This means:

*   You don’t miss dispute deadlines.
*   Evidence is automatically submitted for eligible disputes.
*   You spend less time on manual dispute management.

Smart Disputes determines eligibility based on dispute characteristics and available evidence. Not all disputes qualify for automatic submission.

You can manually submit evidence at any time, even with auto-respond enabled.

### For direct accounts

1.  Go to **Settings > Disputes** in the Dashboard.
2.  Toggle the **Smart Disputes auto-respond** setting.

Changes apply immediately to disputes that still require a response. When you disable auto-respond, you accept and lose any dispute that you don’t counter by the deadline.

### For Connect platforms

As a platform, you control Smart Disputes auto-respond settings for your connected accounts. You can set a default for all connected accounts and choose whether they can override your default.

#### Configure settings in the Dashboard

1.  Go to **Settings > Connect > Disputes** in the Dashboard.
2.  Configure the **Smart Disputes auto-respond** setting for your connected accounts.
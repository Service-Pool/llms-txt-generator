## Risk Settings and Risk Controls

Stripe Radar allows you to fine-tune your fraud prevention strategy by selecting a risk setting that aligns with your business needs and tolerance for risk. Based on your chosen risk setting, Stripe recommends specific risk controls to enhance your protection against fraud.

### Risk Settings

Risk settings enable you to balance fraud prevention with payment authorization rates. By configuring risk controls, you can set dynamic thresholds to block payments that are likely to result in fraudulent disputes or early fraud warnings. Some risk settings also recommend enabling or disabling additional controls, such as adaptive 3D Secure, to protect your account while allowing legitimate transactions.

You can access and modify your risk settings on the **Risk controls** page. Depending on your plan, you may need to upgrade to adjust these settings.

The available risk settings are:

*   **Maximize protection:** This setting prioritizes fraud prevention by blocking payments that have a high likelihood of early fraud warnings.
*   **Balance risk and revenue:** This setting aims to strike a balance between protecting your business from fraud and accepting a certain level of risk to maximize revenue.
*   **Maximize revenue:** This setting prioritizes revenue by blocking only high-risk payments, thereby minimizing potential losses due to fraud.

When you change your risk setting, Stripe automatically adjusts the recommended risk controls to match your chosen level of protection.
## Respond to Disputes

A dispute occurs when a customer contacts their bank to contest a payment. When a customer files a dispute, their bank notifies Stripe, which then informs you through email, the Stripe Dashboard, or API events (`charge.dispute.created`).

Each notification includes a link to the Dispute details page in the Dashboard. This page provides information about the dispute's reason and allows you to take action.

**Important:** You must respond to disputes before the deadline (typically 7 to 21 days, depending on the card network). Failure to respond by the deadline results in an automatic loss of the dispute and the disputed funds.

You can view a detailed list of all your disputes in the **Disputes** tab of your Stripe Dashboard.

### Responding to Disputes in the Dashboard

The Stripe Dashboard guides you through the process of challenging or accepting a dispute. You can submit relevant text and images as evidence to support your case.

### Responding to Disputes Programmatically via API

If you prefer to manage disputes programmatically, you can use the Stripe API. This allows you to upload evidence, respond to disputes, and receive dispute events via webhooks. For more information, refer to the [Use the API to respond to disputes](https://stripe.com/docs/disputes/api) documentation.
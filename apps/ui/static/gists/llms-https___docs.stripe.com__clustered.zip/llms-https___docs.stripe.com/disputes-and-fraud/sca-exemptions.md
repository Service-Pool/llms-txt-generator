## Managing Disputes and Fraud

This documentation section provides comprehensive guidance on understanding, preventing, and managing payment disputes and fraud. It covers various aspects, from initial decline codes and dispute resolution to advanced fraud detection and prevention strategies.

### Understanding Disputes

*   **How disputes work:** Learn about the lifecycle of payment card disputes, from initial customer contact with their bank to Stripe's notification and the merchant's role in submitting evidence.
*   **Disputes overview:** Get a general understanding of what disputes are, how they are processed, and what actions can be taken.
*   **Dispute reason codes:** Explore the categories of dispute reason codes across major card networks (Visa, Mastercard, American Express) and understand the evidence required to challenge them.
*   **Measuring disputes:** Understand how Stripe calculates dispute activity and dispute rate, and the implications of exceeding network thresholds.
*   **Dispute withdrawals:** Learn what happens when a cardholder withdraws a dispute and how it differs from other dispute outcomes.
*   **Dispute analytics:** Analyze dispute volume, rates, and outcomes to understand their financial impact and identify risks of entering card network monitoring programs.

### Responding to Disputes

*   **Respond to disputes:** Learn how to challenge or accept disputes through the Stripe Dashboard or programmatically via the API.
*   **Use the API to respond to disputes:** Discover how to manage disputes programmatically, including uploading evidence and receiving dispute events.
*   **Dispute evidence best practices:** Get guidance on formatting and organizing evidence to effectively challenge a dispute.
*   **Visa Compelling Evidence 3.0 disputes:** Understand the criteria and API usage for Visa's Compelling Evidence 3.0 to fight friendly fraud.
*   **Visa compliance disputes:** Learn how to identify and close Visa compliance disputes using the API.
*   **Klarna disputes:** Understand the specific dispute lifecycle and response process for Klarna payments.
*   **Disputed PayPal payments:** Learn how dispute management works for PayPal transactions.

### Preventing Disputes and Fraud

*   **Dispute prevention:** Explore Stripe's solutions for automatically preventing disputes and lowering your dispute rate.
*   **Understand fraud:** Learn about different types of fraud and strategies to prevent them.
*   **Common types of online fraud:** Familiarize yourself with various fraud schemes and your liability.
*   **Identifying potential fraud:** Discover common fraud indicators and how to assess the risk of a payment.
*   **Card testing:** Understand the nature of card testing and how to protect your business against it.
*   **Customer abuse:** Learn how to prevent, detect, and mitigate refund, resale, and trial abuse.
*   **Card verification checks:** Utilize CVC, postal code, and billing address verification to enhance fraud detection.
*   **3D Secure authentication:** Reduce fraud and meet regulatory requirements with this additional security layer for card transactions.
*   **Strong Customer Authentication (SCA) exemptions:** Understand how to reduce cardholder friction while meeting SCA requirements in the EEA, Switzerland, and the UK.
*   **Stripe's risk score:** Evaluate the fraud risk associated with an authorization using Stripe's composite score and risk categorization.
*   **Radar:** Leverage Stripe Radar for real-time AI-powered fraud detection and prevention.
*   **How Radar works:** Understand the features and capabilities of Stripe Radar for protecting your business against fraud.
*   **Optimize risk factors:** Learn how to provide relevant data to improve Radar's fraud detection accuracy.
*   **Risk evaluations:** Review the outcomes of Stripe Radar risk evaluations and how the AI model works.
*   **Risk setting and risk controls:** Automatically adjust protection thresholds based on your business needs and fraud tolerance.
*   **Fraud prevention rules:** Create custom rules to take specific actions on payments that match defined criteria.
*   **Dispute resolution rules:** Automatically resolve specific disputes based on predefined criteria.
*   **Lists:** Create custom lists of information (e.g., email addresses, IP addresses) to be used in Radar rules for blocking, allowing, or reviewing payments.
*   **Advanced fraud detection:** Utilize Stripe.js and mobile SDKs for enhanced fraud detection by analyzing device characteristics and user activity.
*   **Customer abuse evaluation:** Detect multi-accounting and account sharing abuse during registration and login flows.
*   **Bot abuse prevention:** Use bot scores to detect and prevent bot-driven payments.
*   **Free trial abuse prevention:** Detect and block customers likely to abuse free trials.
*   **Pay-as-you-go abuse evaluation:** Identify subscription customers at risk of not paying their next invoice.
*   **Fraudulent merchant signal:** Detect connected accounts engaged in fraudulent activity.
*   **Account delinquency signal:** Identify connected accounts at risk of financial distress that could lead to negative balances.
*   **Fraudulent website signal:** Evaluate a connected account's website for deception or policy violations.
*   **Radar for Platforms:** Utilize Stripe's risk tooling to mitigate buyer and connected account risk for Connect platforms.
*   **Fraud alerts:** Receive notifications when Stripe detects unusual fraud patterns.
*   **Fraud insights:** Analyze fraud trends specific to your business to tailor your prevention strategy.
*   **Radar analytics center:** Review fraud patterns and their impact on your business through various reports.
*   **Review card payments:** Supplement automated fraud detection with manual inspection of suspicious payments.
*   **Review uncaptured payments:** Manage payments that are placed in review when using auth and capture.
*   **Risk insights:** Understand risk factors and details about a particular payment.
*   **High risk merchant lists:** Be aware of criteria for inclusion in Terminated Merchant Files (TMFs) like MATCH and VMSS.
*   **Dispute and fraud card monitoring programs:** Understand card network monitoring programs and what to do if your account is placed into one.
*   **Apple Pay liability shift, disputes, and refunds:** Learn how to manage disputed or refunded Apple Pay payments, including liability shifts.

### Analytics and Optimization

*   **Payments analytics:** Track and analyze payment performance using key metrics and reports.
*   **Acceptance analytics:** Understand factors affecting payment acceptance and identify reasons for declines.
*   **Authentication analytics:** Analyze how 3D Secure impacts your payment success rate.
*   **Payments optimization:** Learn how Authorization Boost features can increase payment success rates and reduce processing costs.
*   **Recommendations:** Discover Stripe recommendations to increase revenue and improve fraud detection.
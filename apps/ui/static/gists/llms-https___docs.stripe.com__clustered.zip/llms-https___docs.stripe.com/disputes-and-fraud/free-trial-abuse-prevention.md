# Free Trial Abuse Prevention

Free trial abuse can occur when customers exploit free trials to access your product without intending to pay. Common patterns include using prepaid or virtual cards, or repeatedly signing up with the same card across multiple accounts.

Radar provides a free trial abuse control that automatically detects and blocks high-risk trial starts before they convert to subscriptions. You can enable it on the Risk controls page in the Dashboard.

## How it works

When a customer starts a free trial, Radar evaluates the payment method they provide and predicts whether their subscription payment will fail when the trial ends. If the risk is high, Radar blocks the trial from starting before the customer can gain access to your product.

To evaluate trial starts, Radar must know which payment method collections represent a free trial. We recommend integrating with Checkout Sessions, which automatically evaluates trial starts with no code changes.

## Enable Radar to detect trial starts

We recommend integrating with Checkout Sessions in subscription mode, which automatically detects trial
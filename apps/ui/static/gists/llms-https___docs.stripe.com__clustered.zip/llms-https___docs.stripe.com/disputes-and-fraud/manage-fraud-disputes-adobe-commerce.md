## Manage Fraud and Disputes with Stripe Radar for Adobe Commerce

This guide explains how to leverage Stripe Radar for fraud prevention and manage payment disputes within the Adobe Commerce platform.

### Fraud Prevention with Stripe Radar

Stripe Radar provides real-time fraud protection without requiring additional development effort. For enhanced customization and deeper insights, consider **Radar for Fraud Teams**.

*   **Real-time Protection:** Radar analyzes transactions in real-time to identify and mitigate fraud.
*   **Elevated Risk Status:** If Radar detects a high-risk payment, it may be placed under review with an "Elevated risk" status.
*   **Customizable Rules (Radar for Fraud Teams):** With Radar for Fraud Teams, you can create custom rules to automatically decline charges with elevated risk or flag them for manual review. Adobe Commerce will automatically place payments marked for manual review into a "Manual Review Required" status.

#### Testing Fraudulent Payments

To test fraudulent payment scenarios, switch the module to use a sandbox environment and place an order using the following card number: `4000 0000 0000 9235`.

### Manual Review Workflows

Radar for Fraud Teams allows you to flag payments for human review.

*   **Review Queue:** Payments flagged for manual review are placed in a queue within Adobe Commerce, allowing your team to investigate them.
*   **Decision Making:** Your team can then decide to approve or decline these payments based on their assessment.

By integrating Stripe Radar with Adobe Commerce, you gain robust tools to protect your business from fraudulent transactions and streamline the dispute management process.
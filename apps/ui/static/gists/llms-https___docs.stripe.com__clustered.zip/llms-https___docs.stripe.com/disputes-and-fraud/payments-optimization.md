## Payments Optimization

This section provides guidance on how to leverage Stripe's features to enhance payment success rates and reduce processing costs.

### Authorization Boost

Stripe's Authorization Boost features utilize AI-driven adjustments to payment attempts, particularly for card-not-present (CNP) transactions, to improve success rates and lower network costs.

#### Adaptive Acceptance

Adaptive Acceptance employs AI to reformat payment requests according to card issuers' preferences. This can be applied before a payment is sent or after a decline. For instance, Stripe can selectively adjust and reattempt declined payments in real-time to recover potential revenue.

**Note:** Stripe does not guarantee outcomes from using Authorization Boost features. Optimization calculations are estimates and subject to change. Regularly review this page for the latest information.
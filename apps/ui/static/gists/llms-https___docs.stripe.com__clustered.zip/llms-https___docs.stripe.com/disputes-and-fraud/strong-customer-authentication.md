## Managing Disputes and Declines

This documentation group covers how to handle payment disputes and declines, offering strategies and tools to minimize their occurrence and manage them effectively when they arise.

### Key Areas:

*   **Understanding Disputes:** Learn what a dispute is, how the process works, and the financial implications for your business. This includes understanding dispute reason codes and how they are categorized.
*   **Responding to Disputes:** Discover how to challenge or accept a dispute, both through the Stripe Dashboard and programmatically via the API. Best practices for submitting compelling evidence are also detailed.
*   **Preventing Disputes and Fraud:** Explore various methods and tools to proactively reduce the likelihood of disputes and fraudulent transactions. This includes leveraging Stripe Radar, implementing verification checks, and understanding common fraud types.
*   **Managing Declines:** Gain insights into why card payments might be declined and how to lower your decline rates. This section covers understanding decline codes and common reasons for payment failures.
*   **Automating Dispute Management:** Learn about Stripe's Smart Disputes feature, which automates evidence collection and submission, and how to configure auto-respond settings.
*   **Specific Payment Method Disputes:** Find information on handling disputes for specific payment methods like Apple Pay, PayPal, and Klarna.
*   **Analytics and Monitoring:** Understand how to measure and analyze your dispute activity and rates, and learn about card network monitoring programs.

### Relevant Pages:

*   **/apple-pay/disputes-refunds**: Details on handling disputes and refunds specifically for Apple Pay transactions, including liability shifts.
*   **/declines/card**: Explains common reasons for card payment declines and how to reduce your decline rate.
*   **/declines/codes**: Provides a reference for Stripe decline codes and guidance on resolving them.
*   **/declines**: An overview of payment declines and strategies for lowering decline rates.
*   **/disputes/api**: How to programmatically manage disputes using the Stripe API, including uploading evidence and responding.
*   **/disputes/best-practices**: Best practices for formatting and submitting evidence to counter a dispute.
*   **/disputes/categories**: Information on how Stripe categorizes dispute reason codes across different payment methods.
*   **/disputes/smart-disputes/auto-respond**: How to configure Smart Disputes to automatically respond to eligible disputes.
*   **/disputes/withdrawing**: What happens when a cardholder withdraws a dispute and how to manage such situations.
*   **/disputes/how-disputes-work**: A detailed explanation of the payment card dispute lifecycle.
*   **/disputes**: A general overview of disputes, how they work, and how to prevent them.
*   **/disputes/match**: Information on high-risk merchant lists like MATCH and VMSS, and how to avoid being listed.
*   **/disputes/measuring**: How to measure and understand your dispute activity and rate.
*   **/disputes/monitoring-programs**: Details on card network monitoring programs and what to do if your account is placed into one.
*   **/disputes/get-started/prevention**: An introduction to Stripe's dispute prevention solutions using Verifi and Ethoca.
*   **/disputes/prevention-preview**: An overview of dispute prevention features to automatically reduce your dispute rate.
*   **/disputes/prevention**: How to identify and prevent various types of fraud and disputed payments.
*   **/disputes/prevention-advanced-fraud-detection**: Information on using Stripe.js and mobile SDKs for advanced fraud detection.
*   **/disputes/prevention-best-practices**: Best practices for creating a fraud and dispute prevention strategy.
*   **/disputes/prevention-card-testing**: How to protect your business from card testing fraud.
*   **/disputes/prevention-abuse**: Strategies to protect yourself against customer abuse, such as refund or resale abuse.
*   **/disputes/prevention-fraud-types**: An overview of common types of online fraud and your liability.
*   **/disputes/prevention-identifying-fraud**: How to identify potential fraud indicators.
*   **/disputes/prevention-verification**: Using card verification checks (CVC, postal code, address) to protect against fraud.
*   **/disputes/reason-codes-defense-requirements**: Details on dispute reason codes for Visa, Mastercard, and American Express, and defense requirements.
*   **/disputes/responding**: How to challenge or accept a dispute directly in the Stripe Dashboard.
*   **/disputes/set-up-smart-disputes**: Step-by-step guide to setting up and configuring Smart Disputes.
*   **/disputes/smart-disputes**: An overview of Smart Disputes for automating evidence collection and submission.
*   **/disputes/api/visa-ce3**: How to use the API for Visa Compelling Evidence 3.0 disputes to fight friendly fraud.
*   **/disputes/api/visa-compliance**: How to use the API to respond to Visa compliance disputes.
*   **/issuing/controls/advanced-fraud-tools/stripes-risk-score**: Using Stripe's risk score to evaluate fraud risk for authorizations.
*   **/payments/3d-secure**: Information on 3D Secure authentication to reduce fraud and meet regulatory requirements.
*   **/payments/3d-secure/strong-customer-authentication-exemptions**: How to use SCA exemptions to reduce cardholder friction.
*   **/payments/analytics/acceptance**: Analyzing payment acceptance rates and reasons for failures.
*   **/payments/analytics/authentication**: How 3D Secure authentication impacts payment success rates.
*   **/payments/analytics/disputes**: Analyzing dispute volume, rates, and outcomes.
*   **/payments/analytics**: An overview of payments analytics, including reports on authentication, disputes, and acceptance.
*   **/payments/analytics/optimization**: Using features like Authorization Boost to increase payment success rates and reduce costs.
*   **/payments/analytics/recommendations**: Understanding Stripe recommendations to increase revenue and improve fraud detection.
*   **/payments/klarna/disputes**: The lifecycle of Klarna disputes and how to respond to them.
*   **/payments/paypal/disputed-payments**: How dispute management works for PayPal payments.
*   **/use-stripe-apps/adobe-commerce/payments/fraud-disputes**: Managing fraud and disputes within the Adobe Commerce integration.
*   **/radar/abuse-prevention**: Using Stripe Radar to detect and prevent abuse throughout the user lifecycle.
*   **/radar/customer-abuse**: Evaluating customer account registration and login events for abuse.
*   **/radar/account-delinquency**: Identifying connected accounts at risk of financial distress.
*   **/radar/account-risk-signals**: Getting risk signals for connected account fraud, delinquency, and website legitimacy.
*   **/radar/bot-abuse**: Using bot scores to detect and prevent bot-driven payments.
*   **/radar/fraudulent-merchant**: Detecting connected accounts engaging in fraudulent activity.
*   **/radar/free-trial-abuse**: Detecting and blocking customers likely to abuse free trials.
*   **/radar**: An overview of Stripe Radar for real-time fraud protection.
*   **/radar/issuing-authorization-evaluation**: Getting real-time fraud risk scoring for Issuing card authorizations.
*   **/radar/lists**: Creating custom lists of information to block, allow, or review payments.
*   **/radar/pay-as-you-go-abuse**: Identifying subscription customers at risk of not paying their next invoice.
*   **/radar/optimize-risk-factors**: Recommendations for maximizing Stripe Radar's effectiveness by providing more data.
*   **/radar/how-radar-works**: An explanation of how Stripe Radar's AI algorithms assess fraud risk.
*   **/radar/analytics/fraud-alerts**: Receiving notifications when Stripe detects unusual fraud patterns.
*   **/radar/analytics/fraud-insights**: Reviewing fraud trends specific to your business to tailor your strategy.
*   **/radar/analytics**: The Radar analytics center for reviewing fraud patterns and their impact.
*   **/radar/multiprocessor**: Evaluating non-Stripe processed payments with Radar risk signals.
*   **/radar/radar-for-platforms**: Using Stripe tools to reduce buyer and connected account risk for platforms.
*   **/radar/radar-session**: Capturing critical device details for improved fraud protection with Radar Sessions.
*   **/radar/reviews/auth-and-capture**: Using reviews for uncaptured payments when your integration uses auth and capture.
*   **/radar/reviews**: Using reviews to supplement automated fraud detection with human expertise.
*   **/radar/reviews/risk-insights**: Understanding risk factors and details about a particular payment.
*   **/radar/risk-evaluation**: Reviewing the outcomes of Stripe Radar risk evaluations.
*   **/radar/risk-settings**: Choosing a risk setting to automatically adjust protection thresholds.
*   **/radar/rules/dispute-resolution-rules**: Writing rules to automatically resolve specific disputes.
*   **/radar/rules**: Using fraud prevention rules to protect your business.
*   **/radar/rules/reference**: Understanding the structure and processing order of Radar rules.
*   **/radar/rules/supported-attributes**: A list of attributes supported in Radar rules for creating custom logic.
*   **/radar/testing**: Using test credit card numbers to test your fraud prevention strategy.
*   **/radar/fraudulent-website**: Evaluating a connected account's website for deception or policy violations.
*   **/strong-customer-authentication**: How the Strong Customer Authentication regulation affects your business and integration.
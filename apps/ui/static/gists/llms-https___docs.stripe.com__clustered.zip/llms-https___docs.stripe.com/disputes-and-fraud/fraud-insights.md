# Fraud Insights

Building an effective fraud fighting strategy requires understanding the specific drivers of fraud for your business. If you use Radar for Fraud Teams, you can access the Insights tab of the Radar page in your Dashboard to:

*   Visualize trends in transaction volume and fraud rates over time.
*   Identify combinations of Radar attributes that have material impact on your fraud rates.
*   Inspect high-level patterns to verify your findings in individual transactions.
*   Adjust your Radar rules or Risk controls based on the patterns you discover.

## Configure your view

You can customize the data displayed on the Insights page by selecting a time period, defining what types of payments to view, and applying specific attribute filters.

The initial Insights view applies the following default filters:

*   **Elevated risk scores**: Shows only transactions with a risk score greater than 65.
*   **High velocity**: Shows only transactions on cards where the total number of charges per card number is greater than 10 per hour.

### Specify the time period

By default, we display transactions in near real-time for the prior 3 months of transaction history. To see data for a different time period, click the date
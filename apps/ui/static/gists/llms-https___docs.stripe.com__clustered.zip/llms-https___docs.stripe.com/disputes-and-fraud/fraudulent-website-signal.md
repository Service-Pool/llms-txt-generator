# Fraudulent Website Signal

Evaluate a connected account's website for deception or policy violations.

The fraudulent website signal evaluates whether a connected account’s website is deceptive or violates policy. This includes websites for accounts that don’t exist yet on Stripe.

## Request an evaluation

Use the Account Evaluations API to trigger a fraudulent website evaluation on demand. You can evaluate an existing connected account or provide account data directly.

### Evaluate an existing account

You can evaluate a website for an existing account.

```bash
curl -X POST https://api.stripe.com/v2/core/account_evaluations \
  -H "Authorization: Bearer sk_test_RXHltS2OKzISvxWQ7NmRN57i001oa6x7o4" \
  -H "Stripe-Version: 2026-03-25.preview" \
  --json '{ "account": "acct_123", "signals": [ "fraudulent_website" ] }'
```

### Evaluate without an existing account

You can evaluate a website before creating a connected account by providing `account_data` with the business URL.

```bash
curl -X POST https://api.stripe.com/v2/core/account_evaluations \
  -H "Authorization: Bearer sk_test_RXHltS2OKzISvxWQ7NmRN57i001oa6x7o4" \
  -H "Stripe-Version: 2026-03-25.preview" \
  --json '{ "account_data": { "defaults": { "profile": { "business_url": "https://example.com" } } }, "signals": [ "fraudulent_website" ] }'
```

## Webhook event

The evaluation is asynchronous. Listen for `v2.core.account_signals.fraudulent_website_ready` event notifications when a website is evaluated. The event payload includes the following information:

| Field       | Description                                                               |
| :---------- | :------------------------------------------------------------------------ |
| `risk_level` | The risk level for the website: `low`, `normal`, `elevated`, or `highest`. |
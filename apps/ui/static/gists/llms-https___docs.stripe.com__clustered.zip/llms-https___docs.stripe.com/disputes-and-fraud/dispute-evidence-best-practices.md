## Dispute Evidence Best Practices

When a customer disputes a payment, they provide evidence to support their claim. As a seller, you have the opportunity to counter this claim by submitting your own evidence. While Stripe facilitates the dispute resolution process, the ultimate decision rests with the customer's bank. To help you present the strongest case, this documentation outlines best practices for submitting dispute evidence.

### Organizing Your Evidence

A well-organized evidence submission is crucial for effectively challenging a dispute. Follow these guidelines to ensure your evidence is clear, concise, and easy for the bank to review:

*   **Present Chronologically:** Arrange all evidence in the order that events occurred. This creates a clear timeline of the transaction, customer interactions, and any subsequent issues, making it easier for the reviewer to understand the sequence of events.
*   **Group by Type:** Categorize your evidence into distinct sections. This could include:
    *   Receipts and order confirmations
    *   Customer communications (emails, chat logs)
    *   Shipping and tracking information
    *   Product descriptions and terms of service
    *   System logs or other relevant documentation
*   **Include Summaries:** For each piece of evidence, provide a brief explanation of what it demonstrates and how it supports your case. This guides the reviewer and highlights the key points you want them to consider.
*   **Maintain Clarity:** Ensure all text is legible and that any images or documents are clear and easy to read. Avoid jargon or overly technical language where possible.

### Key Evidence Types to Consider

The specific evidence required will vary depending on the nature of the dispute, but common types include:

*   **Proof of Transaction:** This includes the original order confirmation, payment receipt, and any details about the transaction itself.
*   **Proof of Fulfillment:** Evidence that the product or service was delivered as agreed. This can include:
    *   Shipping confirmation with tracking numbers and delivery confirmation.
    *   Proof of service delivery (e.g., signed service agreement, completion reports).
    *   Customer's IP address and device fingerprint at the time of purchase (if available and relevant to fraud disputes).
*   **Customer Communications:** Records of any interactions with the customer regarding the order, including inquiries, complaints, and resolutions. This can demonstrate your efforts to resolve the issue directly.
*   **Product/Service Descriptions:** Clear documentation of what was sold, including any terms, conditions, or policies that the customer agreed to.
*   **Refund and Cancellation Policies:** Evidence that your policies were clearly communicated to the customer at the time of purchase.

### Responding to Specific Dispute Categories

Stripe categorizes disputes to help you understand the general claim and the evidence typically required. Refer to the [Dispute reason code categories](#) documentation for a detailed breakdown of these categories and their associated evidence requirements.

### Using Stripe's Tools

*   **API:** For programmatic management of disputes, you can use the Stripe API to upload evidence and respond to disputes. Refer to the [Use the API to respond to disputes](#) documentation for details.
*   **Dashboard:** The Stripe Dashboard provides a user-friendly interface for managing disputes and submitting evidence.
*   **Smart Disputes:** Consider using Smart Disputes to automatically compile and submit evidence for eligible disputes, helping you avoid missed deadlines and improve your chances of winning. Learn more in [Configure Smart Disputes auto-respond settings](#).

By following these best practices, you can significantly improve your ability to successfully challenge disputes and protect your revenue.
## Fraud Alerts

Stripe continuously monitors your payment activity for signs of fraud attacks. When unusual patterns are detected, such as a significant shift in the distribution of Radar risk scores, you'll receive an email and a notification in your Stripe Dashboard. These alerts help you respond quickly to potential fraud attacks, mitigate risks like lost revenue and increased dispute fees, and avoid enrollment in card network monitoring programs.

### Receiving Fraud Alerts

When Stripe detects a potential fraud attack on your account, you will be notified through:

*   **Email Notification:** An email detailing the detected attack, with a link to view more information in your Dashboard.
*   **Dashboard Notification:** A bell icon notification in your Dashboard, also with a link to the alert details.

Both the email and Dashboard notification will direct you to a dedicated fraud alert investigation page where you can review the specifics and take necessary actions.

### Reviewing Fraud Alerts

Upon accessing a fraud alert in your Dashboard, you can:

*   **View Risk Trends:** Examine charts that illustrate the distribution of Radar risk scores or risk levels during the alert period, compared to previous periods. This helps you understand shifts in fraud patterns.
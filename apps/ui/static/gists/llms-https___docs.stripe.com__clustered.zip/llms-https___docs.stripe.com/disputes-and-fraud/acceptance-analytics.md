## Payments Analytics

This section provides an overview of Stripe's Payments Analytics features, focusing on understanding payment performance, optimizing acceptance rates, and managing disputes.

### Acceptance Analytics

The **Acceptance** page in the Stripe Dashboard allows you to analyze your payment success rate and network authorization rate. It provides pivot reports for common criteria, helping you identify where and why payments fail. This information can be used to improve your payment success rate and increase revenue.

**Key Features:**

*   **Payment Success Rate Analysis:** Understand the overall percentage of attempted payments that are successfully authorized.
*   **Network Authorization Rate:** Analyze how often payments are authorized by card networks and issuing banks.
*   **Pivot Reports:** Break down acceptance data by various criteria such as payment method, country, and more, to pinpoint specific areas for improvement.
*   **Identification of Decline Reasons:** Gain insights into common reasons for payment declines, enabling targeted strategies to reduce them.

**Data Included:**

*   **Attempted Payments:** Details of payment attempts sent through card networks.
*   **Authorized Payments:** Information on payments validated by issuing banks, with funds reserved.

**Note:** Optimization calculations are estimates and not guarantees. The data is intended to inform decision-making. Calculation methodologies are subject to change.

### Authentication Analytics

The **Authentication** page helps you understand how **3D Secure (3DS)** impacts your payment success rate for card payments. 3DS is an authentication method that adds a security layer to card transactions, helping to protect businesses from fraud liability.

**Key Features:**

*   **3D Secure Impact Analysis:** Visualize how 3DS authentication affects your payment success rates.
*   **Metrics and Charts:** View data on 3DS requests, successful authentications, and their correlation with payment outcomes.

**Data Exclusions:**

*   3DS requests during card validations.
*   Payments made with digital wallets (e.g., Apple Pay, Google Pay) that use device-based authentication.
*   3DS requests for Data Only authentication.

**Configuration:**

*   **3D Secure Setup:** You must first set up 3DS to view authentication analytics.
*   **Currency and Data Views:** Filter data by currency and choose between Raw (including repeat attempts) or Deduplicated views.

### Disputes Analytics

The **Disputes** page provides insights into your dispute volume, rates, and the outcomes of your dispute submissions. This helps you understand the financial impact of disputes and identify risks related to card network monitoring programs.

**Key Features:**

*   **Dispute Volume and Rate Monitoring:** Track the number and percentage of disputes over time.
*   **Dispute Outcome Analysis:** Understand the success rates of your dispute submissions.
*   **Category Analysis:** Analyze disputes by payment method, country, and reason codes.

**Included Data (Card Mode):**

*   Subsequent disputes (multiple disputes on the same charge).
*   Early fraud warnings (EFW).

**Excluded Data:**

*   Inquiries.
*   Hidden disputes (handled automatically by Stripe).
*   Rapid Dispute Resolution (RDR) and prevented disputes.

**Benefits:**

*   Monitor your dispute rate to avoid card network monitoring programs.
*   Understand the financial impact of disputes.
*   Identify trends and reasons behind disputes.

### Payments Optimization

The **Payments Optimization** page highlights Stripe's **Authorization Boost** features, designed to increase your payment success rate and reduce processing costs for card-not-present (CNP) payments.

**Key Features:**

*   **Authorization Boost:** Utilizes AI-driven adjustments to payment attempts that fail or are improperly formatted.
*   **Adaptive Acceptance:** Reformats payment requests based on card issuers' preferences, attempting to recover declined payments in real-time.
*   **Estimated Impact Reports:** View estimated increases in payment volume, success rate, and cost savings from optimization features.

**Note:** Optimization outcomes are estimates and not guaranteed.

### Recommendations

The **Recommendations** page offers suggestions from Stripe to help increase your revenue and improve fraud detection. These recommendations are based on your account settings, integration methods, and thresholds.

**Key Features:**

*   **Personalized Suggestions:** Receive tailored recommendations relevant to your business.
*   **Actionable Insights:** Get guidance on how to improve revenue or fraud detection.
*   **Dismissal and Feedback:** Option to dismiss recommendations and provide feedback.

**Availability:** Recommendations appear when they are relevant to your business.

---

**Related Topics:**

*   [How disputes work](/disputes/how-disputes-work)
*   [3D Secure authentication](/payments/3d-secure)
*   [Acceptance analytics](/payments/analytics/acceptance)
*   [Authentication analytics](/payments/analytics/authentication)
*   [Disputes analytics](/payments/analytics/disputes)
*   [Payments optimization](/payments/analytics/optimization)
*   [Recommendations](/payments/analytics/recommendations)
```markdown
## Rules Reference

Before creating a rule, you need to understand how they’re processed and what transaction and account attributes you can use to set evaluation criteria. The Stripe machine-learning fraud systems can block many fraudulent payments for you, but you can also set up rules that are unique to your business using the supported attributes.

### Transaction Rule Processing and Ordering

Radar evaluates each payment against the rules you create according to their action type, using the following prioritization:

*   **Request 3DS:** Rules that when used with the Payment Intents API or Checkout, request the issuer to do 3D Secure authentication if supported. Radar evaluates these before any block, review, or allow rules.
*   **Allow:** Rules that allow a payment to be processed. Payments that fall under allow rules aren’t evaluated against any block or review rules.
*   **Block:** Rules that block a payment and reject it. Blocked payments aren’t evaluated against any review rules.
*   **Review:** Rules that allow payments to be processed but then place them in review.

Rules of the same action type aren’t ordered.

If a payment matches the criteria for a rule, Radar takes the

```
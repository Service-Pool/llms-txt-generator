# Optimizing Stripe Radar's Effectiveness

Stripe Radar leverages AI models that analyze numerous risk factors to differentiate between fraudulent and legitimate payments. While some risk factors are computed automatically, many depend on the data your integration provides. Supplying more relevant data enhances fraud prevention capabilities. The key is to collect sufficient information for accurate risk assessment without negatively impacting the checkout experience.

## Integration and Risk Factor Completeness

Radar utilizes data from the Stripe network to detect and block fraudulent transactions across various integrations. The chosen integration impacts the completeness of the risk factors sent to Stripe. The more payment data you capture, the better Radar can detect and prevent fraud.

| Integration Type                                                             | Risk Factor Completeness |
| :--------------------------------------------------------------------------- | :----------------------- |
| Payment Links                                                                | Recommended: Excellent   |
| Checkout                                                                     | Recommended: Excellent   |
| Elements with customer risk factors                                          | Recommended: Excellent   |
| Direct API integration with Radar Sessions and customer risk factors         | Excellent                |
| Direct API integration with client and customer risk factors                 | Very good                |
| Direct API integration with client risk factors                              | Good                     |

If your integration doesn't send enough payment data, you can augment it by adding customer risk factors (user email, name, and billing address) to the `Customer` object. Additionally, client risk factors (IP address, user agent, and checkout URL) can be added to the `PaymentIntent` object.
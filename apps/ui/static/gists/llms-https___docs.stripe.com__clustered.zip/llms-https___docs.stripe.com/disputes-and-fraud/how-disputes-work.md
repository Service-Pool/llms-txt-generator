## How Disputes Work

A dispute occurs when a customer contacts their bank to contest a payment. This process, also known as a chargeback, can significantly impact your business by reversing transactions and incurring fees. Understanding the dispute lifecycle is crucial for effective management and prevention.

### The Dispute Process

1.  **Notification:** When a customer disputes a charge, their bank alerts Stripe. Stripe then notifies you via email, the Stripe Dashboard, and through API webhooks (`charge.dispute.created`).
2.  **Fund Reversal:** Stripe debits the disputed amount and a dispute fee from your Stripe account.
3.  **Evidence Submission:** Stripe provides you with details of the dispute and the customer's claim, guiding you through the process of submitting evidence to contest the chargeback.
4.  **Bank Decision:** Stripe facilitates your case, but the final decision rests solely with the customer's bank.

### Pre-Dispute Notifications

Stripe may alert you to "pre-dispute notifications" before a formal dispute is filed. These notifications, such as Early Fraud Warnings (EFWs), offer an opportunity to:

*   **Avoid Disputes:** Proactive customer service and transaction clarification can resolve issues before they escalate to a formal dispute.
*   **Mitigate Impact:** Failing to address pre-dispute notifications can negatively affect the outcome of a formal dispute.

### Key Concepts

*   **Dispute Fee:** A fee charged by Stripe for each dispute, in addition to the disputed amount.
*   **Evidence:** Information you provide to the bank to support your case against the dispute.
*   **Card Networks:** Organizations like Visa and Mastercard that govern the dispute process.
*   **Monitoring Programs:** Programs initiated by card networks if your dispute levels exceed certain thresholds, potentially leading to fines and additional fees.
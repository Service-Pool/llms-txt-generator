## Disputes

This section details how to manage and prevent payment disputes, also known as chargebacks. It covers understanding the dispute process, responding to disputes, leveraging Stripe's tools for automation and prevention, and analyzing dispute-related data.

### Understanding Disputes

*   **How disputes work**: Learn about the lifecycle of payment card disputes, from initial notification to resolution, and Stripe's role in facilitating the process.
*   **Dispute reason code categories**: Understand how Stripe categorizes dispute reasons across different payment networks and what evidence is typically required to challenge them.
*   **Dispute withdrawals**: Learn what happens when a cardholder withdraws a dispute and how it impacts the process.
*   **Measuring disputes**: Understand how to interpret dispute activity and dispute rate calculations to monitor your business's dispute performance.
*   **Dispute and fraud card monitoring programs**: Learn about card network monitoring programs, the thresholds that trigger them, and the consequences of being enrolled.

### Responding to Disputes

*   **Respond to disputes**: Comprehensive guide on how to challenge or accept a dispute through the Stripe Dashboard or API.
*   **Use the API to respond to disputes**: Details on programmatically managing disputes, including uploading evidence and receiving dispute events.
*   **Dispute evidence best practices**: Guidelines on formatting and presenting evidence to effectively challenge a dispute.
*   **Visa Compelling Evidence 3.0 disputes**: Specific information on using Visa's Compelling Evidence 3.0 criteria to fight friendly fraud.
*   **Visa compliance disputes**: How to handle disputes related to non-compliance with Visa's network rules.

### Preventing Disputes and Fraud

*   **Dispute prevention**: An overview of Stripe's dispute prevention solutions, including Verifi and Ethoca, and their benefits.
*   **Understand fraud**: Learn about different types of fraud, common indicators, and strategies for prevention.
*   **Common types of online fraud**: An overview of various online fraud schemes and associated merchant liabilities.
*   **Identifying potential fraud**: Tips and indicators to help identify potentially fraudulent payments.
*   **Protect yourself from card testing**: Learn about card testing as a fraudulent activity and how to mitigate it.
*   **Customer abuse**: Strategies to protect against refund, resale, and trial abuse.
*   **Card verification checks**: How to use CVC, postal code, and billing address verification to enhance fraud detection.
*   **Stripe Radar**: An introduction to Stripe's AI-powered fraud detection system.
    *   **How Radar works**: An explanation of Radar's features for real-time fraud assessment.
    *   **Optimize risk factors**: How to provide more data to Stripe to improve Radar's fraud detection accuracy.
    *   **Risk evaluations**: Understanding how Radar's AI model assesses payment risk.
    *   **Risk setting and risk controls**: How to configure Radar's settings to balance fraud prevention and revenue.
    *   **Fraud prevention rules**: Creating custom rules to automatically manage payments based on risk criteria.
    *   **Dispute resolution rules**: Setting up rules to automatically resolve specific disputes.
    *   **Lists**: Creating custom lists of information (e.g., email addresses, IP addresses) to use in Radar rules.
    *   **Fraud alerts**: Getting notified when Stripe detects unusual fraud patterns.
    *   **Fraud insights**: Analyzing fraud trends specific to your business.
    *   **Radar analytics center**: Reviewing fraud patterns and their impact on your business.
    *   **Bot abuse prevention**: Using bot scores to detect and prevent bot-driven payments.
    *   **Customer abuse evaluation**: Getting risk evaluations for account registration and login events.
    *   **Free trial abuse prevention**: Detecting and blocking customers likely to abuse free trials.
    *   **Pay-as-you-go abuse evaluation**: Identifying subscription customers at risk of not paying their invoices.
    *   **Fraudulent merchant signal**: Detecting connected accounts engaging in fraudulent activity.
    *   **Fraudulent website signal**: Evaluating a connected account's website for deception or policy violations.
    *   **Account delinquency signal**: Identifying connected accounts at risk of financial distress.
    *   **Account risk signals**: Overview of risk signals for connected accounts.
    *   **Radar for Platforms**: Tools for Connect platforms to manage buyer and connected account risk.
    *   **Radar fraud scores for Issuing authorizations**: Real-time fraud risk scoring for Issuing card authorizations.
    *   **Provide Radar additional fraud data**: How to use Radar Sessions to capture critical device details for better fraud protection.
    *   **Review card payments**: Using manual reviews to supplement automated fraud detection.
    *   **Review uncaptured payments**: Managing payments that are held for review before capture.
    *   **Risk insights**: Understanding risk factors and details about a particular payment.
*   **3D Secure authentication**: How 3D Secure adds a security layer to card transactions to reduce fraud and meet regulatory requirements.
    *   **Strong Customer Authentication (SCA) exemptions**: Using exemptions to reduce cardholder friction while meeting SCA requirements.
    *   **Strong Customer Authentication readiness**: Understanding how SCA affects your business and updating your integration.

### Analytics and Reporting

*   **Payments analytics**: Overview of key metrics and reports to track payment performance.
*   **Disputes analytics**: Analyzing dispute volume, rates, and outcomes.
*   **Acceptance analytics**: Understanding factors affecting payment acceptance and decline reasons.
*   **Authentication analytics**: How 3D Secure impacts payment success rates.
*   **Recommendations**: Receiving suggestions from Stripe to increase revenue and improve fraud detection.

### Specific Payment Methods

*   **Apple Pay liability shift, disputes, and refunds**: Managing disputes and refunds for Apple Pay transactions.
*   **Disputed PayPal payments**: Understanding the dispute management process for PayPal.
*   **Respond to disputes (Klarna)**: The lifecycle of Klarna disputes and how to respond.
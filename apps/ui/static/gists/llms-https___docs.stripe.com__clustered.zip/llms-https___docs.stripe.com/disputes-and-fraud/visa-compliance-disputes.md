## Visa Compliance Disputes

Businesses may encounter Visa compliance disputes when a card issuer believes a transaction does not adhere to Visa's network rules. If a resolution cannot be reached between the parties involved, the dispute is settled by the network, incurring a fee.

When contesting a Visa compliance dispute, in addition to standard Stripe dispute fees, Stripe will collect a $500 USD (or local equivalent) to cover the network's costs associated with dispute resolution. This $500 USD will be refunded if you win the dispute.

**Note:** Pre-compliance disputes are how issuers refer to compliance cases. For more information on Visa rules, please refer to the official Visa documentation.

### Identifying Visa Compliance Disputes

You can identify a Visa compliance dispute by examining the dispute object for the following indicators:

*   `payment_method_details.case_type` is set to `compliance`.
*   `enhanced_eligibility_types` contains `visa_compliance`.
*   `reason` is `noncompliant`.

```json
{
  "id": "du_TFCU9xJ2Gsj7BAiAoQok8Icp",
  "charge": "ch_vEUUPELhHVkPbMN1md3B0vG7",
  "enhanced_eligibility_types": ["visa_compliance"],
  "reason": "noncompliant",
  "payment_method_details": {
    "card": {
      "brand": "visa",
      "case_type": "compliance"
    }
  }
}
```

### Closing Visa Compliance Disputes via the API

Closing a Visa compliance dispute via the API signifies that you have no evidence to submit and are effectively dismissing the dispute, acknowledging it.
## Handling Payment Disputes and Declines

This section covers how to manage and prevent payment disputes and declines, ensuring a smoother transaction process and minimizing financial losses. It details Stripe's tools and strategies for addressing these critical aspects of online commerce.

### Understanding and Responding to Disputes

*   **How Disputes Work:** Learn the lifecycle of a payment dispute, from initial customer contact with their bank to Stripe's notification and the process of submitting evidence. Understand how disputes impact your account balance and the associated fees.
*   **Responding to Disputes:** Discover how to challenge or accept a dispute through the Stripe Dashboard or programmatically via the API. This includes understanding dispute deadlines and the consequences of not responding.
*   **Dispute Reason Codes:** Familiarize yourself with the various reason code categories used by major card networks (Visa, Mastercard, American Express) and the evidence required to challenge them.
*   **Dispute Evidence Best Practices:** Learn how to organize and present the most convincing evidence to successfully counter a dispute claim.
*   **Dispute Withdrawals:** Understand what happens when a cardholder withdraws a dispute and how it differs from a resolved dispute.
*   **Measuring Disputes:** Analyze how Stripe calculates dispute activity and dispute rate, and understand the implications of exceeding network thresholds.
*   **Dispute Monitoring Programs:** Learn about card network monitoring programs, the criteria for enrollment, and the actions required to avoid or exit these programs.
*   **Dispute Analytics:** Utilize the Disputes analytics page in the Stripe Dashboard to monitor dispute volume, rates, and outcomes, and understand their financial impact.

### Preventing Disputes and Fraud

*   **Dispute Prevention:** Explore Stripe's integrated solutions, Verifi and Ethoca, designed to reduce dispute rates and associated fees.
*   **Smart Disputes:** Automate evidence collection and submission for eligible disputes to increase your chances of winning and save time on manual management.
*   **Configure Smart Disputes Auto-Respond:** Set up automatic responses for eligible disputes to ensure deadlines are met and evidence is submitted without manual intervention.
*   **Visa Compelling Evidence 3.0:** Leverage Visa's criteria to fight friendly fraud by providing specific evidence related to previous non-disputed transactions.
*   **Visa Compliance Disputes:** Understand and respond to disputes that arise when a transaction doesn't conform to Visa's network rules.

### Fraud Detection and Prevention with Radar

*   **Radar Overview:** Get a comprehensive understanding of Stripe Radar, its AI-powered fraud detection capabilities, and how to set it up.
*   **How Radar Works:** Learn about Radar's real-time transaction evaluation, AI algorithms, and the different features available for fraud protection.
*   **Radar Analytics Center:** Analyze fraud patterns and their impact on your business through various reports and insights.
*   **Fraud Alerts and Insights:** Receive notifications about unusual fraud patterns and leverage fraud insights to tailor your fraud-fighting strategy.
*   **Risk Evaluations:** Understand how Radar's adaptive AI model assesses payment risk using hundreds of risk factors.
*   **Optimize Risk Factors:** Learn how to provide relevant data to Stripe to improve Radar's fraud detection accuracy.
*   **Risk Settings and Controls:** Configure risk settings to balance fraud protection with authorization rates, and utilize recommended risk controls.
*   **Fraud Prevention Rules:** Create custom rules to automate actions for payments that match specific criteria, such as requesting 3D Secure authentication or blocking high-risk payments.
*   **Supported Attributes for Rules:** Discover the comprehensive list of attributes you can use to build effective Radar rules.
*   **Testing Stripe Radar:** Utilize test card numbers and rule testing features to validate your fraud prevention strategy.
*   **Lists:** Create custom lists of customer IDs, email addresses, or IP addresses to manage payments more effectively within your rules.
*   **Abuse Prevention:** Detect and prevent various forms of abuse, including customer abuse, free trial abuse, pay-as-you-go abuse, and bot abuse.
*   **Customer Abuse Evaluation:** Get risk evaluations for account registration and login events to detect multi-accounting and account sharing.
*   **Account Delinquency Signal:** Identify connected accounts at risk of financial distress that could lead to negative balances.
*   **Fraudulent Merchant Signal:** Detect connected accounts engaging in fraudulent activity.
*   **Fraudulent Website Signal:** Evaluate connected accounts' websites for deception or policy violations.
*   **Bot Abuse Prevention:** Use bot scores to detect and prevent bot-driven payments.
*   **Free Trial Abuse Prevention:** Detect and block customers likely to abuse free trials.
*   **Pay-as-you-go Abuse Evaluation:** Identify subscription customers at risk of not paying their next invoice.
*   **Radar for Platforms:** Utilize Stripe's risk tooling to manage buyer and connected account risk for platforms.
*   **Radar Risk Signals for Multiple Payment Processors:** Evaluate externally processed payments with Radar's risk signals.
*   **Radar Fraud Scores for Issuing Authorizations:** Obtain real-time fraud risk scoring for Issuing card authorizations.
*   **Review Card Payments:** Use manual reviews to supplement automated fraud detection systems.
*   **Review Uncaptured Payments:** Manage payments that are placed in review when using auth and capture.

### Declines and Authentication

*   **Card Declines:** Understand common reasons for card declines and strategies to lower your decline rate.
*   **Stripe Decline Codes:** Learn about Stripe's specific decline codes and how to resolve them when a charge fails.
*   **3D Secure Authentication:** Implement 3D Secure to reduce fraud and meet regulatory requirements for card transactions.
*   **Strong Customer Authentication (SCA) Exemptions:** Utilize SCA exemptions to reduce cardholder friction on eligible transactions while meeting regulatory requirements.
*   **Strong Customer Authentication Readiness:** Understand how SCA regulations impact your business and how to update your integration.
*   **Acceptance Analytics:** Analyze payment success rates, identify reasons for declines, and improve your payment acceptance.
*   **Authentication Analytics:** See how 3D Secure impacts your payment success rate for card payments.

### Payment Method Specific Considerations

*   **Apple Pay Liability Shift, Disputes, and Refunds:** Manage disputed or refunded Apple Pay payments, understanding liability shifts and refund processes.
*   **Disputed PayPal Payments:** Learn how dispute management works for PayPal payments.
*   **Respond to Klarna Disputes:** Understand the lifecycle of Klarna disputes and how to respond to them.
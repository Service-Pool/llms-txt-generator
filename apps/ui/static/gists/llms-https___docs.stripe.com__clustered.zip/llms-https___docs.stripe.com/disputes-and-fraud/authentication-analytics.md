## Authentication Analytics

Use the **Authentication** page in the Dashboard to see how 3D Secure (3DS) affects your payments success rate. 3DS is an authentication method for card payments and can help protect businesses from liability for fraud. You must first set up 3DS to see your authentication analytics.

### Configure your data set

Use filters to control all the metrics, charts, and tables on this page.

These metrics and charts exclude:

*   3DS requests that occur during card validations
*   Payments made with digital wallets such as Apple Pay and Google Pay. These digital wallets use device-based authentication methods (such as biometrics) instead of 3DS
*   3DS requests for Data Only authentication. Data Only doesn’t lead to 3DS challenges or liability shift for your customers

### Specify currency

If you don’t apply a currency filter, all payments appear in your default settlement currency, regardless of the actual payment currency. If you apply a currency filter, only payments made using the selected currency appear.

To change the currency, click **+ More filters > Currency**, and select the currency you want from the list.

### Specify data as Raw or Deduplicated

You can also view your data as Raw or Deduplicated:

*   **Raw** (default): Raw data includes all payment attempts, including repeat attempts to complete a payment. When Stripe calculates
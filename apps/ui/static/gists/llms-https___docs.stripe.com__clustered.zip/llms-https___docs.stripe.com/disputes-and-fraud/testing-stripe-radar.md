## Testing Stripe Radar

This section provides guidance on how to test your fraud prevention strategy using Stripe Radar.

### Test Credit Card Numbers

Use the following test credit card numbers to create payments in a sandbox environment with specific risk levels. You can create these test payments either in the Stripe Dashboard (in sandbox mode) or by calling the `create charge` API with your test API key.

| Card Number     | Risk Level

<!-- truncated by AI -->
## Radar

Stripe Radar is a comprehensive suite of tools designed to protect your business from fraud. It leverages AI and machine learning to evaluate transactions in real-time, assess risk, and provide various methods for preventing and managing fraudulent activities.

### Key Features and Capabilities

*   **Real-time Fraud Detection:** Radar analyzes transactions as they happen, using AI algorithms to assess the risk of fraud.
*   **Customizable Fraud Prevention:** While Radar offers built-in protections, Radar for Fraud Teams allows for deeper customization and insights, enabling you to tailor defenses to your specific business needs.
*   **Abuse Prevention:** Beyond transactional fraud, Radar helps detect and prevent various forms of abuse, including customer abuse (refund, resale, trial abuse), bot abuse, and account delinquency.
*   **Risk Evaluation and Scoring:** Radar assigns risk scores and levels to transactions, helping you identify potentially fraudulent payments and take appropriate action.
*   **Automated Responses:** You can configure Radar to automatically respond to fraud warnings, block high-risk payments, or place them under manual review.
*   **Lists and Rules:** Create custom lists of trusted or blocked customers, IP addresses, or other criteria, and build rules to automate actions based on these lists.
*   **Analytics and Insights:** Analyze fraud patterns, track their impact on your business, and gain insights to refine your fraud prevention strategy.
*   **Support for Multiple Payment Methods:** Radar screens various payment types, including cards, wallets, ACH Direct Debit, and SEPA Direct Debit.
*   **Radar for Platforms:** Provides risk tooling specifically for Connect platforms to manage buyer and connected account risk.
*   **Integration with Stripe Tools:** Seamlessly integrates with other Stripe products like Stripe.js, Elements, and Sigma for enhanced data collection and analysis.

### Getting Started with Radar

1.  **Set Up Your Integration:** Ensure your payment integration collects the necessary transaction data for Stripe to assess fraud risk effectively.
2.  **Configure Radar Settings:** Choose a risk setting that balances fraud protection with revenue goals.
3.  **Customize Rules:** Create custom rules to automate actions based on specific criteria relevant to your business.
4.  **Utilize Analytics:** Regularly review fraud analytics and insights to understand trends and optimize your strategy.

### Advanced Fraud Detection

Radar employs sophisticated techniques to detect and prevent fraud:

*   **Risk Factors:** Leverages numerous risk factors, many of which depend on the data your integration provides. The more relevant data you send, the better Radar's fraud prevention capabilities.
*   **Machine Learning Models:** Continuously learns from new customer purchase patterns and transaction features, incorporating feedback to improve accuracy.
*   **Customer Abuse Evaluation:** Detects multi-accounting and account sharing abuse at signup and login before payment collection.
*   **Bot Abuse Prevention:** Identifies payments likely made by automated scripts or bots.
*   **Account Delinquency Signal:** Identifies connected accounts at risk of financial distress that could lead to negative balances.
*   **Fraudulent Merchant Signal:** Detects connected accounts engaging in fraudulent activity.
*   **Fraudulent Website Signal:** Evaluates connected accounts' websites for deception or policy violations.

By implementing Stripe Radar, you can significantly enhance your business's security, reduce financial losses due to fraud, and maintain customer trust.
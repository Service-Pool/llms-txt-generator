## Stripe Billing and Invoicing Documentation

This documentation set provides comprehensive guidance on leveraging Stripe's Billing and Invoicing features to manage subscriptions, recurring payments, and one-time charges. It covers everything from foundational concepts to advanced configurations for various business models.

### Core Billing and Subscription Management

*   **Billing Overview:** Understand the core functionalities of Stripe Billing for automating recurring payments, creating custom pricing plans, and managing billing periods.
*   **About the Billing APIs:** Learn how the various Billing API objects interact to manage subscriptions, invoicing, and customer management.
*   **Subscriptions:** Dive deep into how subscriptions work, designing and building subscription integrations, and migrating existing subscriptions to Stripe.
*   **Subscription Pricing Models:** Explore different pricing strategies including flat-rate, per-seat, usage-based, and tiered pricing.
*   **Usage-Based Billing:** Implement flexible pricing models where customers are charged based on their actual product or service consumption. This includes:
    *   **How usage-based billing works:** Understand the lifecycle and core concepts.
    *   **Pricing Models:** Set up various models like pay-as-you-go, flat fee and overages, and credit-based pricing.
    *   **Recording Usage:** Learn how to report customer usage data to Stripe via API, Dashboard, or S3.
    *   **Advanced Usage-Based Billing:** Explore sophisticated features for SaaS and AI businesses, including real-time credit burndown and managing multiple rates.
    *   **Billing Credits:** Offer prepaid credits or promotional offerings to customers.
    *   **Meters:** Create and configure meters to aggregate usage events for billing.
    *   **Alerts and Thresholds:** Set up notifications and trigger invoices based on usage or monetary thresholds.
*   **Billing Collection Methods:** Configure how Stripe collects payments for invoices and subscriptions, choosing between automatic charging and manual payments.
*   **Billing Automations:** Streamline business processes, enhance customer communication, and improve revenue recovery through custom, no-code automated workflows.
    *   **How Automations Work:** Understand triggers, conditions, and actions.
    *   **Automation Use Cases:** Explore popular examples for customizing dunning, notifications, and more.
*   **Revenue Recovery:** Implement automated features to reduce and recover failed subscription payments, minimizing churn and lost revenue.
    *   **Automate Payment Retries (Smart Retries):** Leverage AI to intelligently retry failed payments.
    *   **Automate Customer Emails:** Notify customers about payment issues and other important events.
    *   **Recovery Analytics:** Monitor payment failure rates and recovery effectiveness.
*   **Test Your Billing Integration:** Learn how to thoroughly test your Billing integration using test clocks and simulations to ensure production readiness.

### Customer Management and Portal

*   **Customers:** Understand the core Customer resource for storing profile, billing, and tax information.
*   **Customer Management:** Explore features for managing customer accounts and billing details.
*   **Customer Portal:** Provide a self-serve portal for customers to manage their subscriptions, payment methods, and invoices.
    *   **Activate No-Code Customer Portal:** Set up the portal with a no-code configuration.
    *   **Integrate Customer Portal with API:** Customize and integrate the portal into your application.
    *   **Configure the Customer Portal:** Customize features and UI for subscription management, quantity updates, and more.
    *   **Deep Links in the Customer Portal:** Create streamlined customer flows to specific portal actions.
    *   **Add a Cancellation Page:** Allow customers to cancel subscriptions directly from the portal and collect cancellation reasons.
*   **Customer Invoice Balance:** Manage customer invoice balances, issuing credit and debit adjustments.

### Invoicing

*   **Invoicing Overview:** Create and manage invoices for one-time payments, with options for manual creation or API automation.
*   **How Invoicing Works:** Understand the invoice lifecycle and automatic collection workflow.
*   **No-Code Invoicing Guide:** Get started with Stripe Invoicing using the Dashboard without writing code.
*   **Integrate with the Invoicing API:** Automate invoice creation and management through the API.
*   **Invoice Lifecycle:** Learn about the different statuses an invoice moves through.
*   **Preview an Invoice:** Generate a preview to calculate total amounts, line items, taxes, and discounts without creating an invoice.
*   **Edit Invoices:** Revise finalized invoices in open or uncollectible status.
*   **Issue Credit Notes:** Adjust or refund finalized invoices with credit notes.
*   **Create Invoice Payment Plans:** Break down invoice amounts into multiple payments with different due dates.
*   **Accept Partial Payments:** Capture multiple, smaller payments for larger invoices.
*   **Automatic Charging:** Have Stripe automatically charge a customer's stored payment method.
*   **Automatic Collection:** Automate revenue recovery for one-off invoices with features like Smart Retries and email reminders.
*   **Automatic Reconciliation:** Let Stripe handle cash reconciliation for credit transfer payment methods.
*   **Automatic Invoice Advancement:** Configure Stripe to automatically advance invoice states and collect payments.
*   **Hosted Invoice Page:** Provide customers with a secure URL to view, pay, and download invoices and receipts.
*   **Scheduled Payments:** Allow customers to schedule future payments through the Hosted Invoice Page.
*   **Send Customer Emails:** Configure and send invoicing emails for various notifications and reminders.
*   **Customize Invoices:** Tailor the content and branding of your invoices.
*   **Invoice Rendering Templates:** Personalize invoice appearance for different customer segments.
*   **Group Invoice Line Items:** Categorize and display invoice line items under different groups for better clarity.
*   **Invoice Summary Items:** Use API features to summarize and hide invoice line items.
*   **Manage Bulk Invoice Line Items:** Add, update, and remove multiple invoice line items with the Invoices API.
*   **Multi-currency Customers:** Accept multiple currencies for customer payments and subscriptions.
*   **Best Practices for Global Invoices:** Learn country-specific requirements for B2B invoicing.
*   **Payment Methods for Invoices:** Understand supported payment methods like ACH Direct Debit and bank transfers.
*   **Bank Transfer:** Accept bank transfer payments on your invoices.
*   **Test Stripe Invoicing:** Learn how to test your Invoicing integration using various scenarios and tools.
*   **Create an Invoice with Connect:** Create invoices for connected accounts and optionally take fees.

### Advanced Billing and Scripting

*   **Billing Scripts:** Customize Stripe Billing logic with scripts to modify default behavior for proration, customer balance application, and item handling.
*   **Subscription Pricing Plans:** Choose between pay-as-you-go or subscription-based plans for predictable monthly costs.
*   **Billing for LLM tokens:** Bill for LLM tokens without building a pricing engine, with Stripe handling model price updates and usage metering.
*   **Billing for a Multi-Entity Business:** Integrate Stripe Billing for businesses with multiple legal entities using Stripe Connect.
## Stripe Billing and Invoicing: Comprehensive Guide

This documentation set provides a comprehensive overview of Stripe's Billing and Invoicing features, empowering businesses to manage subscriptions, recurring payments, and one-time charges with flexibility and automation.

### Core Billing Concepts

*   **Billing APIs Overview (`/billing/billing-apis`):** Understand the fundamental objects and their interactions within Stripe Billing, including Products, Prices, Customers, and the role of Checkout Sessions for subscription creation. Learn about the recommended use of Accounts v2 API for customer management.
*   **Billing Collection Methods (`/billing/collection-method`):** Configure how Stripe collects payments for invoices and subscriptions, choosing between automatic charging and manual payments, and understanding the implications of each.
*   **Customer Management (`/customer-management`):** This section delves into managing customer accounts and their associated billing information.
    *   **Customers (`/customer-management/customer` and `/billing/customer`):** Learn how to create and manage customer profiles, storing essential billing and tax information for subscriptions and invoices.
    *   **Customer Portal (`/customer-management/integrate-customer-portal`, `/customer-management/activate-no-code-customer-portal`, `/customer-management/configure-portal`, `/customer-management/portal-deep-links`, `/customer-management/cancellation-page`):** Discover how to provide customers with a self-service portal to manage their subscriptions, payment methods, and billing details. This includes setting up the no-code portal, integrating it with your application via API, creating custom flows with deep links, and enabling a cancellation page with reason collection.
    *   **Customer Invoice Balance (`/customer-management/customer/balance` and `/invoicing/customer/balance`):** Understand how to manage customer invoice balances, issuing credit and debit adjustments and applying them to future invoices.

### Subscriptions and Recurring Revenue

*   **Billing Overview (`/billing`):** Get a high-level understanding of Stripe Billing's capabilities for automating recurring payments, creating custom pricing plans, and managing billing periods.
*   **Subscriptions (`/billing/subscriptions`):** This broad category covers various aspects of subscription management.
    *   **Subscription Invoices (`/billing/invoices/subscription`):** Learn how Stripe generates and manages invoices for subscription billing cycles, including the lifecycle of new subscription invoices and handling payment failures.
    *   **Pricing Models:**
        *   **Tiered Pricing (`/subscriptions/pricing-models/tiered-pricing`):** Implement non-linear pricing where the unit cost changes based on quantity or usage.
        *   **Usage-Based Pricing (`/subscriptions/pricing-models/usage-based-pricing`, `/billing/subscriptions/usage-based`, `/billing/subscriptions/usage-based/how-it-works`, `/billing/subscriptions/usage-based-legacy`):** Charge customers based on their actual consumption of your product or service, with various models like pay-as-you-go, fixed fee and overages, and credit burndown. This includes understanding the lifecycle, recording usage, and managing billing setups.
        *   **Advanced Usage-Based Billing (`/billing/subscriptions/usage-based/advanced/about`, `/billing/subscriptions/usage-based-v2/overview`, `/billing/subscriptions/usage-based/pricing-plans`, `/billing/subscriptions/usage-based/advanced/compare`):** Explore advanced features for SaaS and AI businesses, enabling complex hybrid pricing models that combine recurring fees, usage-based charges, and credit management.
    *   **Usage-Based Billing Specifics:**
        *   **Recording Usage (`/billing/subscriptions/usage-based/recording-usage`, `/billing/subscriptions/usage-based/recording-usage-api`, `/billing/subscriptions/usage-based/recording-usage-in-bulk-dashboard`, `/billing/subscriptions/usage-based/recording-usage-in-bulk`):** Learn how to record customer usage data through the API, Dashboard (manual or CSV upload), or Amazon S3 for accurate billing.
        *   **Meters (`/billing/subscriptions/usage-based/meters/configure`):** Understand how to create and configure meters to aggregate usage events for billing.
        *   **Billing Credits (`/billing/subscriptions/usage-based/billing-credits`, `/billing/subscriptions/usage-based/billing-credits/implementation-guide`, `/billing/subscriptions/usage-based/use-cases/credits-based-pricing-model`):** Implement prepaid billing solutions with billing credits for usage-based products, offering flexibility for prepayments or promotional offerings.
        *   **Alerts and Thresholds (`/billing/subscriptions/usage-based/alerts`, `/billing/subscriptions/usage-based/monitor`, `/billing/subscriptions/usage-based/thresholds`):** Set up alerts and thresholds to notify you when customers exceed usage limits or to trigger invoices based on accumulated usage.
        *   **Grace Periods (`/billing/subscriptions/usage-based/configure-grace-period`):** Configure grace periods for invoice finalization to allow for reporting usage after the billing period has ended.
    *   **Sales-Led Billing (`/billing/subscriptions/sales-led-billing`):** Automate complex B2B sales contracts, using Quotes for negotiation and shaping deals within Stripe Billing.
    *   **Subscription Pricing Plans (`/billing/subscription-pricing`, `/billing/subscription-pricing/cancel`):** Explore subscription-based plans for paying for Stripe Billing and Tax, offering predictable monthly costs and potential discounts. Learn about managing subscription fees and cancellation policies.

### Invoicing and One-Time Payments

*   **Invoicing Overview (`/invoicing`):** Create and manage invoices for one-time payments, with options for no-code solutions via the Dashboard or API automation for advanced features.
*   **Invoicing API Integration (`/invoicing/integration`, `/invoicing/integration/quickstart`, `/invoicing/integration/testing`, `/invoicing/integration/workflow-transitions`):** Learn how to integrate with the Invoicing API to automate invoice creation, sending, and payment collection. This includes testing your integration and understanding status transitions.
*   **Invoice Management:**
    *   **Use the Dashboard (`/invoicing/dashboard`, `/invoicing/dashboard/manage-invoices`):** Create, send, and modify invoices directly from the Stripe Dashboard.
    *   **Invoice Lifecycle (`/invoicing/overview`):** Understand the different stages an invoice goes through from draft to paid or voided.
    *   **Customization (`/invoicing/customize`, `/invoicing/invoice-rendering-template`):** Tailor the content and branding of your invoices using templates and the invoice editor.
    *   **Automatic Charging (`/invoicing/automatic-charging`, `/invoicing/automated-collections`):** Configure Stripe to automatically charge a customer's stored payment method for invoices.
    *   **Automatic Collection (`/invoicing/automatic-collection`, `/invoicing/automatic-invoice-advancement`):** Leverage automated revenue recovery features for one-off invoices, including Smart Retries and email reminders.
    *   **Scheduled Finalization (`/invoicing/scheduled-finalization`):** Schedule invoices to be sent or charged on a future date.
    *   **Partial Payments (`/invoicing/partial-payments`):** Accept multiple smaller payments for larger invoices.
    *   **Payment Plans (`/invoicing/payment-plans`):** Break down an invoice's total amount into separate payments with different due dates.
    *   **Hosted Invoice Page (`/invoicing/hosted-invoice-page`, `/invoicing/hosted-invoice-page/scheduled-payments`):** Provide customers with a secure URL to view, pay, and download invoices and receipts.
    *   **Credit Notes (`/invoicing/dashboard/credit-notes`, `/invoicing/integration/programmatic-credit-notes`):** Issue credit notes to adjust or refund finalized invoices.
    *   **Line Item Management (`/invoicing/group-line-items`, `/invoicing/line-item-grouping`, `/invoicing/bulk-update-line-item`):** Group, summarize, and manage invoice line items for better clarity and organization.
    *   **Taxes (`/invoicing/taxes/manual-tax-amounts`):** Manually set tax amounts on invoices when using unsupported external tax systems.
    *   **Multi-currency Customers (`/invoicing/multi-currency-customers`, `/invoicing/global-invoices`):** Accept payments in multiple currencies and follow best practices for global invoicing.
    *   **Payment Methods (`/invoicing/payment-methods`, `/invoicing/bank-transfer`):** Learn about supported payment methods for invoices, including bank transfers and ACH Direct Debit.

### Quotes and Estimates

*   **Quotes (`/quotes`):** Provide price estimates to customers before creating a subscription or invoice, allowing for negotiation and conversion into finalized deals.
    *   **Create and Send a Quote (`/quotes/create`):** Learn how to create, send, and accept quotes for one-off invoices or subscriptions.
    *   **Renegotiate a Quote (`/quotes/clone`):** Modify finalized quotes by duplicating and updating them as new drafts.

### Revenue Management and Analytics

*   **Revenue (`/revenue`):** Manage the entire revenue lifecycle, from customer acquisition to closing books and automating sales taxes.
*   **Revenue Recovery (`/billing/revenue-recovery`, `/billing/revenue-recovery/customer-emails`, `/billing/revenue-recovery/recovery-analytics`, `/billing/revenue-recovery/smart-retries`):** Implement automated features to reduce and recover failed subscription payments through smart retries, customer emails, and recovery analytics.
*   **Analytics (`/billing/subscriptions/analytics`, `/billing/subscriptions/analytics/benchmarking`):** Monitor and analyze recurring revenue using the Stripe Dashboard, with options for downloadable reports and benchmarking against similar businesses.

### Automation and Customization

*   **Automations (`/billing/automations`, `/billing/automation-recipes`):** Streamline business processes, enhance customer communication, and improve revenue recovery with no-code custom workflows triggered by events.
*   **Scripts (`/billing/scripts`, `/billing/scripts/configure`, `/billing/scripts/customer-balance`, `/billing/scripts/item-handling`, `/billing/scripts/prorations`):** Program custom billing logic that runs directly on Stripe to modify default behaviors for proration, customer balance application, and item handling on invoices.

### Testing and Development

*   **Test Your Billing Integration (`/billing/testing`, `/billing/testing/test-clocks`, `/billing/testing/test-clocks/api-advanced-usage`, `/billing/testing/test-clocks/simulate-subscriptions`):** Thoroughly test your Billing integration before production using test clocks to simulate billing objects and subscription lifecycles.
*   **Test Stripe Invoicing (`/invoicing/integration/testing`):** Learn how to test your Invoicing integration with common scenarios, including webhook notifications and payment failures.

### Advanced Features

*   **Billing for LLM Tokens (`/billing/token-billing`):** Bill for LLM tokens without building a pricing engine, as Stripe handles model price updates and usage metering.
*   **Multi-Entity Business (`/billing/multi-entity-business`):** Integrate Stripe Billing for businesses with multiple legal entities, using Stripe Connect for a scalable architecture.
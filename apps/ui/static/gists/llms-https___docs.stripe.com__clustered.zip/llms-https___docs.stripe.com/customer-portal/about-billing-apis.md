# Stripe Billing: Subscriptions, Invoicing, and Customer Management

This documentation set provides a comprehensive guide to Stripe's billing and invoicing features, empowering businesses to manage recurring revenue, automate payments, and provide a seamless customer experience.

## Core Billing Concepts

*   **Billing APIs**: Understand the fundamental objects and their interactions within Stripe Billing to manage subscriptions, customers, and payments. (Page 1)
*   **Subscriptions**: Learn how to build and manage subscription integrations, including pricing models, billing cycles, and subscription events. (Page 11, Page 12)
*   **Invoicing**: Master the creation, customization, and sending of invoices for both one-time and recurring payments. (Page 11, Page 58, Page 63, Page 64, Page 68, Page 89)
*   **Customers**: Learn how to create and manage customer profiles to store billing and tax information. (Page 10, Page 63)

## Subscription Management

*   **Subscription Lifecycle**: Understand how subscriptions are created, managed, and how they progress through different statuses. (Page 12)
*   **Pricing Models**: Explore various pricing models, including flat rate, per-seat, usage-based, and tiered pricing. (Page 16, Page 17, Page 25, Page 27, Page 36, Page 48, Page 49, Page 50, Page 51)
*   **Usage-Based Billing**: Implement flexible billing based on customer usage, including advanced features like credit burndown and real-time top-ups. (Page 25, Page 26, Page 27, Page 28, Page 29, Page 30, Page 31, Page 32, Page 33, Page 34, Page 35, Page 36, Page 37, Page 38, Page 39, Page 40, Page 41, Page 42, Page 43, Page 44, Page 45, Page 46, Page 47, Page 48, Page 49, Page 50, Page 51, Page 56)
*   **Subscription Updates and Cancellations**: Manage subscription modifications, including plan changes, quantity updates, and cancellations. (Page 8, Page 100)

## Invoicing and Payments

*   **Invoice Creation and Management**: Create, customize, and manage invoices through the Dashboard or API. (Page 12, Page 58, Page 68, Page 69)
*   **Collection Methods**: Configure automatic charging or manual payment collection for invoices. (Page 2, Page 12, Page 59)
*   **Automated Collections**: Leverage Stripe's features for automatic payment retries, email notifications, and reconciliation. (Page 22, Page 60, Page 72)
*   **Payment Methods**: Support a variety of payment methods, including credit cards, bank transfers, and more. (Page 92, Page 93)
*   **Partial Payments and Payment Plans**: Accept partial payments and create flexible payment plans for invoices. (Page 85, Page 86)
*   **Customer Credit Balance**: Manage customer credit balances and issue adjustments. (Page 9, Page 62, Page 65)
*   **Quotes**: Provide price estimates to customers before finalizing subscriptions or invoices. (Page 18, Page 96, Page 97, Page 98)

## Customer Portal

*   **Customer Portal Overview**: Empower customers to manage their subscriptions, payment methods, and billing information through a self-serve portal. (Page 5, Page 6, Page 7)
*   **Customization**: Configure the customer portal's features, branding, and deep links for streamlined customer flows. (Page 3, Page 4, Page 5, Page 8)
*   **Cancellation Page**: Allow customers to cancel subscriptions directly within the customer portal, with options to collect cancellation reasons. (Page 3)

## Revenue Recovery and Analytics

*   **Revenue Recovery**: Implement automated features to reduce churn and recover failed subscription payments. (Page 21, Page 22, Page 23)
*   **Analytics**: Monitor and analyze recurring revenue, subscription performance, and payment failure rates. (Page 15, Page 23, Page 14)

## Testing and Automation

*   **Testing Billing Integrations**: Utilize test clocks and simulations to thoroughly test your billing integration before going live. (Page 52, Page 53, Page 54, Page 55, Page 82)
*   **Automations**: Streamline business processes and enhance customer communication with custom, no-code automated workflows. (Page 19, Page 20)
*   **Scripts**: Customize Stripe Billing logic with scripts for advanced scenarios like item handling, proration, and customer balance application. (Page 13, Page 102, Page 103, Page 104, Page 105)

## Advanced Billing Scenarios

*   **Usage-Based Billing for LLM Tokens**: Bill customers specifically for LLM token consumption. (Page 56)
*   **Sales-Led B2B Billing**: Automate complex sales contracts and negotiations. (Page 18)
*   **Multi-Entity Businesses**: Integrate Stripe Billing for businesses with multiple legal entities. (Page 57)
*   **Global Invoicing**: Follow best practices for setting up compliant invoices in various regions. (Page 88)
## Stripe Billing: Subscriptions and Invoicing

This documentation set provides a comprehensive guide to Stripe's Billing and Invoicing features, covering everything from setting up subscriptions and managing customer accounts to handling complex pricing models and automating revenue recovery.

### Core Concepts: Subscriptions and Invoices

*   **About the Billing APIs (`/billing/billing-apis`)**: Understand the fundamental objects that power Stripe Billing, including Products, Prices, Customers, and how Stripe manages the billing lifecycle automatically once a subscription is created. It also introduces the Accounts v2 API for customer management.
*   **Subscription Invoices (`/billing/invoices/subscription`)**: Learn how Stripe automatically generates invoices for each subscription billing cycle. This page details the invoice lifecycle, from creation and finalization to payment success and subscription activation.
*   **Customers (`/billing/customer`, `/invoicing/customer`)**: Explore the `Customer` resource, a core entity for storing profile, billing, and tax information. Learn how to create and manage customers to facilitate subscriptions and one-off invoices.
*   **Products and Prices (`/invoicing/products-prices`)**: Understand how to define your business offerings using Products and Prices, which are essential for both subscriptions and invoices.

### Setting Up and Managing Subscriptions

*   **Billing (`/billing`)**: Get a high-level overview of Stripe Billing, its capabilities for automating recurring payments, creating custom pricing plans, and managing billing periods.
*   **How subscriptions work (`/billing/subscriptions/how-subscriptions-work`)**: Gain a conceptual understanding of how subscriptions function within Stripe.
*   **Design an integration (`/billing/subscriptions/design-an-integration`)**: Learn the key decisions and considerations when integrating subscriptions into your business.
*   **Manage subscriptions (`/billing/subscriptions/manage-subscriptions`)**: Discover various aspects of subscription management, including setting billing cycles, configuring trial offers, and enabling different billing modes.
*   **Cancel subscriptions (`/billing/subscriptions/cancel`)**: Understand the policies and procedures for canceling subscriptions, including annual commitment details.

### Usage-Based Billing

*   **Usage-based billing (`/billing/subscriptions/usage-based`, `/billing/subscriptions/usage-based-legacy`)**: Explore the concept of charging customers based on their product or service usage, a common model for SaaS businesses.
*   **How advanced usage-based billing works (`/billing/subscriptions/usage-based/advanced/about`, `/billing/subscriptions/usage-based-v2/overview`)**: Dive into advanced features for complex hybrid pricing models, including usage attributes, credit management, and plan versioning.
*   **Pricing Models**:
    *   **Set up usage-based pricing models (`/billing/subscriptions/usage-based-pricing`)**: Learn how to implement models like fixed fee and overage, pay-as-you-go, and credit burndown.
    *   **Set up tiered pricing (`/billing/subscriptions/pricing-models/tiered-pricing`)**: Understand how to create non-linear pricing based on quantity or usage.
    *   **Set up a flat fee and overages pricing model (`/billing/subscriptions/usage-based-v1/use-cases/flat-fee-and-overages`)**: Implement a model combining predictable recurring fees with charges for additional usage.
    *   **Set up a credit-based pricing model (`/billing/subscriptions/usage-based/use-cases/credits-based-pricing-model`)**: Learn to charge customers for pre-purchased credits.
    *   **Set up a pay-as-you-go pricing model (`/billing/subscriptions/usage-based/implementation-guide`)**: Implement a flexible model where customers are charged in arrears for accrued usage.
*   **Recording Usage**:
    *   **Record usage for billing (`/billing/subscriptions/usage-based/recording-usage`, `/billing/subscriptions/usage-based-legacy/recording-usage`)**: Learn how to report customer usage data to Stripe for accurate billing.
    *   **Create and configure a meter (`/billing/subscriptions/usage-based/meters/configure`)**: Understand how to create meters to aggregate meter events for usage-based billing.
    *   **Record usage in the Dashboard (`/billing/subscriptions/usage-based/recording-usage-in-bulk-dashboard`)**: Learn to manually input or upload usage data via CSV.
    *   **Record usage for billing using Amazon S3 (`/billing/subscriptions/usage-based/recording-usage-in-bulk`)**: Discover how to upload usage events in bulk from an S3 bucket.
    *   **Record usage for billing with the API (`/billing/subscriptions/usage-based/recording-usage-api`, `/billing/subscriptions/usage-based-legacy/recording-usage`)**: Learn to send meter events programmatically.
*   **Monitoring and Alerts**:
    *   **Set up usage-based alerts (`/billing/subscriptions/usage-based/alerts`, `/billing/subscriptions/usage-based/monitor`)**: Configure alerts for when customers exceed usage thresholds.
    *   **Set up thresholds (`/billing/subscriptions/usage-based/thresholds`)**: Implement billing thresholds to limit amounts owed or products consumed between invoices.
*   **Billing Credits**:
    *   **Billing credits (`/billing/subscriptions/usage-based/billing-credits`)**: Understand how to use billing credits for prepaid or promotional usage-based products.
    *   **Set up billing credits (`/billing/subscriptions/usage-based/billing-credits/implementation-guide`)**: Learn the steps to implement a prepaid billing solution with credits.
*   **Other Usage-Based Features**:
    *   **Configure an invoice finalization grace period (`/billing/subscriptions/usage-based/configure-grace-period`)**: Learn how to adjust the time for reporting usage after a billing period ends.
    *   **Analyze and query meter usage (`/billing/subscriptions/usage-based/analytics`)**: Explore the Meter Usage Analytics API for custom dashboards and reports.

### Invoicing

*   **Invoicing (`/invoicing`)**: Get an overview of Stripe Invoicing for creating and managing one-time payment invoices, including no-code options and API integration.
*   **How invoicing works (`/invoicing/overview`)**: Understand the stages of the invoice lifecycle.
*   **Create and send an invoice (`/invoicing/integration/quickstart`)**: A quickstart guide for integrating with the Invoicing API.
*   **Use the Dashboard (`/invoicing/dashboard`)**: Learn to create, send, and modify invoices directly from the Stripe Dashboard.
*   **Manage invoices (`/invoicing/dashboard/manage-invoices`)**: Track invoice statuses and details within the Dashboard.
*   **Preview an invoice (`/invoicing/preview`)**: Create a preview to calculate total invoice amounts, line items, taxes, and discounts without creating an invoice.
*   **Customize invoices (`/invoicing/customize`)**: Tailor the content and branding of your invoices.
*   **Invoice rendering templates (`/invoicing/invoice-rendering-template`)**: Personalize invoice appearance for different customer groups.
*   **Group invoice line items (`/invoicing/group-line-items`)**: Organize and display invoice line items under different groups for better customer understanding.
*   **Invoice summary items (`/invoicing/line-item-grouping`)**: Use API features to summarize and hide invoice line items.
*   **Issue credit notes (`/invoicing/dashboard/credit-notes`)**: Learn to adjust or refund finalized invoices with credit notes.
*   **Generate credit notes programmatically (`/invoicing/integration/programmatic-credit-notes`)**: Use the Invoicing API to create credit notes.
*   **Automatic charging (`/invoicing/automatic-charging`, `/invoicing/automated-collections`)**: Have Stripe automatically charge a customer's stored payment method.
*   **Automatic collection (`/invoicing/automatic-collection`, `/invoicing/automated-collections`)**: Automate revenue recovery processes for one-off invoices.
*   **Automatic invoice advancement (`/invoicing/integration/automatic-advancement-collection`)**: Understand how Stripe can automatically advance invoice states and collect payments.
*   **Schedule invoice finalization (`/invoicing/scheduled-finalization`)**: Schedule an invoice to be sent or charged on a future date.
*   **Accept partial payments for invoices (`/invoicing/partial-payments`)**: Learn to capture multiple, smaller payments for larger invoices.
*   **Create invoice payment plans (`/invoicing/payment-plans`)**: Break down an invoice's total amount into separate payments with different due dates.
*   **Payment methods for invoices (`/invoicing/payment-methods`)**: Explore supported payment methods for Invoicing, including ACH Direct Debit and bank transfers.
*   **Bank transfer (`/invoicing/bank-transfer`)**: Accept bank transfer payments on your invoices.
*   **Multi-currency customers (`/invoicing/multi-currency-customers`)**: Bill customers in different currencies than their default.
*   **Best practices for global invoices (`/invoicing/global-invoices`)**: Learn best practices for setting up compliant invoices in non-US regions.
*   **Manage bulk invoice line items (`/invoicing/bulk-update-line-item`)**: Add, update, and remove multiple invoice line items with the Invoices API.
*   **Create an invoice with Connect (`/invoicing/connect`)**: Create invoices for connected accounts.
*   **Use tax amounts from unsupported systems with Stripe Billing (`/invoicing/taxes/manual-tax-amounts`)**: Manually set tax amounts on invoices when using an unsupported external tax system.
*   **Test Stripe Invoicing (`/invoicing/integration/testing`)**: Learn how to test your Invoicing integration before going live.

### Customer Management and Portal

*   **Provide a customer portal to your customers (`/customer-management`)**: Enable customers to manage their own accounts and subscriptions.
*   **Activate the no-code customer portal (`/customer-management/activate-no-code-customer-portal`)**: Set up Stripe's customer portal with a no-code configuration.
*   **Integrate the customer portal with the API (`/customer-management/integrate-customer-portal`)**: Learn how to integrate the customer portal using the Stripe API.
*   **Configure the customer portal (`/customer-management/configure-portal`)**: Customize settings for the self-serve customer portal.
*   **Deep links in the customer portal (`/customer-management/portal-deep-links`)**: Design streamlined customer flows with the customer portal API.
*   **Add a cancellation page to the customer portal (`/customer-management/cancellation-page`)**: Allow customers to cancel subscriptions within the portal and optionally collect cancellation reasons.
*   **Customer invoice balance (`/billing/customer/balance`)**: Understand how to issue credit and debit adjustments against a customer's invoice balance.

### Revenue Recovery and Automation

*   **Revenue recovery (`/billing/revenue-recovery`)**: Discover automated features to reduce and recover failed subscription payments.
*   **Automate customer emails (`/billing/revenue-recovery/customer-emails`)**: Use customer emails to prevent involuntary churn and recover revenue.
*   **Revenue recovery analytics (`/billing/revenue-recovery/recovery-analytics`)**: Analyze subscription payment failure rates and recovery effectiveness.
*   **Automate payment retries (`/billing/revenue-recovery/smart-retries`)**: Automatically retry failed payments to reduce involuntary churn.
*   **How automations work (`/billing/automations`)**: Learn how to build custom, automated workflows using triggers, conditions, and actions.
*   **Automation use-cases (`/billing/automation-recipes`)**: View example use cases for common automations.
*   **Customize Billing with scripts (`/billing/scripts`)**: Use scripts to program custom billing logic that runs directly on Stripe.
*   **Configure a script in the Dashboard (`/billing/scripts/configure`)**: Find, activate, and manage billing scripts from the Dashboard.
*   **Apply custom balances to invoices (`/billing/scripts/customer-balance`)**: Customize how customer balances are applied to invoices.
*   **Control which items appear on subscription invoices (`/billing/scripts/item-handling`)**: Use scripts to control how subscriptions create invoice items.
*   **Customize subscription proration calculations (`/billing/scripts/prorations`)**: Implement custom logic to calculate proration amounts for subscription changes.

### Testing and Analytics

*   **Test your Billing integration (`/billing/testing`)**: Learn how to test your Billing integration to ensure it's production-ready.
*   **Use Simulations to simulate Billing objects (`/billing/testing/test-clocks`)**: Simulate Billing objects through time to test various scenarios.
*   **Simulate subscriptions (`/billing/testing/test-clocks/simulate-subscriptions`)**: Learn how to simulate subscription events like invoices and renewals.
*   **API and advanced usage (`/billing/testing/test-clocks/api-advanced-usage`)**: Explore advanced strategies for using test clocks.
*   **Analytics (`/billing/subscriptions/analytics`)**: Monitor and analyze your recurring revenue using the Stripe Dashboard and downloadable reports.
*   **Benchmarking (`/billing/subscriptions/analytics/benchmarking`)**: Compare your business's metric performance to similar businesses on Stripe.

### Other Billing Features

*   **Billing collection methods (`/billing/collection-method`)**: Configure how Stripe processes payments for invoices and subscriptions (automatic charging vs. manual payments).
*   **Sales-led B2B billing (`/billing/subscriptions/sales-led-billing`)**: Automate workflows for sales-focused businesses to manage complex sales contracts.
*   **Billing for LLM tokens (`/billing/token-billing`)**: Bill for LLM tokens without building a pricing engine, with Stripe handling model price updates and usage metering.
*   **Billing for a multi-entity business (`/billing/multi-entity-business`)**: Integrate Stripe Billing for businesses with multiple legal entities.
*   **Subscription pricing plans (`/billing/subscription-pricing`)**: Learn about subscription-based plans for paying for Stripe Billing and Tax.
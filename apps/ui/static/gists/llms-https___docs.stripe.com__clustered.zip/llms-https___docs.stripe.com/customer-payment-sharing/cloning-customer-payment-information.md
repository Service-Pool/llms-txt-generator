# Clone Customer Payment Information Across Connected Accounts

This documentation describes a **legacy feature** for reusing payment information across multiple connected accounts that share customers.

**Caution:** Support for this feature might end without notice. If you use this feature, update your integration to use the current process for reusing payment information across connected accounts. For more information, see [Share payment methods across multiple accounts](#).

For some business models, it’s helpful to reuse your customers’ payment information across connected accounts. For example, a customer who makes a purchase from one of your connected sellers shouldn’t need to re-enter their credit card or bank account details to purchase from another seller.

With Connect, you can accomplish this by following three steps:

1.  **Storing customers, with a payment method, on the platform account.**
2.  **Creating tokens to clone the payment method when it’s time to charge the customer on behalf of a connected account.**
3.  **Creating charges using the new tokens.**

## Storing Customers

When not cloning payment methods, you save the Stripe Customer objects on each individual connected Stripe account. When cloning payment methods, you instead save them on the platform Stripe account.

This is an API call, but be sure to use your own secret and publishable keys instead of the connect account’s.

```bash
curl https://api.stripe.com/v1/customers \
  -u "sk_test_RXHltS2OKzISvxWQ7NmRN57i001oa6x7o4:" \
  --data-urlencode "email=paying.user@example.com" \
  -d source=tok_mastercard
```

## Creating Tokens

**Caution:** If your platform uses the Sources API, you must create a Source from that customer rather than creating a token. If your platform uses the Payment Methods API, you must create a PaymentMethod from that customer. After following either of these guides, proceed to [Creating charges](#) without creating a token.

When you’re ready to create a charge...
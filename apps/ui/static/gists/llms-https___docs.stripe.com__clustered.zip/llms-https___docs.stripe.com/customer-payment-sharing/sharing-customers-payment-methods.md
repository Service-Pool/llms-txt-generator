# Share customers and payment methods across accounts in an organization

Many growing businesses expand to multiple Stripe accounts to keep finances from different business lines separate, or because the business operates in multiple regions with different legal entities. As a multi-entity business, you can share customers and payment methods across accounts in an organization to avoid:

*   Recollecting payment methods or contact information multiple times from the same customer
*   Introducing inconsistencies in a customer’s contact and payment details between accounts
*   Maintaining and updating duplicate records

## Limitations

Customer and payment method sharing is currently in public preview with the following restrictions:

*   You can only share payment methods ( `pm_` ) of type card. This includes cards that originate from a wallet, such as Apple Pay, Google Pay, and Link.
*   You can’t share legacy sources ( `src_` ), legacy cards ( `card_` ), or legacy bank accounts ( `ba_` ).
*   You can attach other payment methods (such as ACH or Klarna) to a shared customer in one account, but they won’t be shared to other accounts in your organization.
*   You can’t disable sharing after enabling the feature.
*   You can’t share customers or payment methods between accounts that are not part of the same organization.
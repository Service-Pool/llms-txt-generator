# Element LoadError Event

The `loaderror` event is triggered when the `Element` fails to load.

- `event`: The name of the event. In this case, `loaderror`.
- `handler`: `handler(event) => void` is a **callback function** that you provide that will be called when the event is fired. When called it will be passed an event object with the following properties:
    - `elementType`: The type of element that emitted this event.
    - `error`: An `error` object that describes the failure.

### Example

```title Handle an Element loaderror event ```
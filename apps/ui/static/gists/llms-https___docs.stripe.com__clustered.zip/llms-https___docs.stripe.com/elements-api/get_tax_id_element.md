## Retrieve a Tax ID Element `elements.getElement(type: 'taxId')`

This method retrieves a previously created Tax ID Element.

- `type` The type of Element being retrieved, which is `taxId` in this case.

### Example

```title
Retrieve a Tax ID Element
```
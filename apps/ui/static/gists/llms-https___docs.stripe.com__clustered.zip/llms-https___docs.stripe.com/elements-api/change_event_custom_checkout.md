## Checkout Events

Listen to Checkout events to respond to changes caused by customer actions on your checkout page.

### Change Event

`checkout.on('change', handler)`

The `change` event is triggered when [Checkout Session](https://docs.stripe.com/js/custom_checkout/session_object.md) data changes, such as when the customer changes their shipping address. The event payload is always a [Checkout Session](https://docs.stripe.com/js/custom_checkout/session_object.md) object.

*   `event`: The name of the event. In this case, `'change'`.
*   `handler`: `handler(session) => void` is a **callback function** that you provide that will be called when the event is fired. When called it will be passed a [Checkout Session](https://docs.stripe.com/js/custom_checkout/session_object.md) object.

#### Example

```title
Listen to change events
```
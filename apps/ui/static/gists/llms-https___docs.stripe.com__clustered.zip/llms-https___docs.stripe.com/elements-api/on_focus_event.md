## Focus event

`element.on(event: 'focus', handler: function)`

Triggered when the `Element` gains focus.

*   `event` The name of the event. In this case, `focus`.
*   `handler` `handler(event) => void` is a **callback function** that you provide that will be called when the event is fired.

### Example

```title
Handle an Element focus event
```
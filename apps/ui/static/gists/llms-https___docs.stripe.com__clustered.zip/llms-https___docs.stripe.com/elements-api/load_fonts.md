## Load additional custom fonts into Elements

`checkout.loadFonts(fonts: array)`

Load an additional array of custom fonts into Elements after it loads.

- `fonts` An array of custom fonts. Specify fonts as [CssFontSource](#css_font_source_object) or [CustomFontSource](#custom_font_source_object) objects.

### Example

```title Load additional custom fonts ```
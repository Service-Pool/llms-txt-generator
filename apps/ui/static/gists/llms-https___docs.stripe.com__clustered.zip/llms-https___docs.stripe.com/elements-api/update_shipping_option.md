## Update the selected shipping option

`actions.updateShippingOption(shippingOption?: string)`

Use this method to update the selected shipping option. See [shippingOptions](https://docs.stripe.com/js/custom_checkout/session_object.md#custom_checkout_session_object-shippingOptions) for a list of the available shipping options.

- `shippingOption` The [ID](https://docs.stripe.com/js/custom_checkout/session_object.md#custom_checkout_session_object-shippingOptions-id) of the shipping option to select.

### Example

```title
Update the selected shipping option
```
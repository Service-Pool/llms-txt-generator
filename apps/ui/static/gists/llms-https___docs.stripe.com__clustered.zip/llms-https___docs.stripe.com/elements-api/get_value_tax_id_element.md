## Get value from a Tax ID Element

`element.getValue()`

Validates and retrieves form values from a Tax ID Element. If there are any input validation errors, the errors are displayed by their associated fields.

### Example

```title
Get value from a Tax ID Element
```
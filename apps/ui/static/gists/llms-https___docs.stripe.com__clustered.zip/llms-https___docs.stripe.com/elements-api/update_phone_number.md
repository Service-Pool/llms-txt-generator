## Update the Customer's phone number

`actions.updatePhoneNumber(phoneNumber: nullable string)`

Use this method to update the Customer's phone number. If your integration uses the [Express Checkout Element](https://docs.stripe.com/elements/express-checkout-element.md), the phone number is collected directly from the wallet and the value set by `updatePhoneNumber` is not used for express checkout payments.

- `phoneNumber` The Customer's phone number.

### Example

```title
Update the Customer's phone number
```
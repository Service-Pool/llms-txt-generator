## Get the Express Checkout Element

`checkout.getExpressCheckoutElement()`

This method gets the previously created Express Checkout Element instance, if it exists.

### Example

```title
Get the Express Checkout Address Element
```
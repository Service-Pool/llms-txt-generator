## Update the Customer's email address

`updateEmail(email: nullable string)`

Use this method to update the Customer's email address. If your integration uses [Link](https://docs.stripe.com/payments/link.md) and you do not provide an email during Checkout Session creation, you must call `updateEmail` for Link to appear as a payment option for returning users. If your integration uses the [Express Checkout Element](https://docs.stripe.com/elements/express-checkout-element.md), the email address is collected directly from the wallet and the value set by `updateEmail` is not used for express checkout payments.

*   `email` The Customer's email address.

### Example

```title
Update the Customer's email address
```
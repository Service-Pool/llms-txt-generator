## Update the Customer's business name and tax ID

Use this method to update the Customer's business name and tax ID.

```javascript
actions.updateTaxIdInfo({
  businessName: 'Stripe Inc.',
  taxId: '123456789',
  type: 'eu_vat',
});
```

- `taxIdInfo` The Customer's tax ID information including the business name and tax ID.
  - `businessName` The Customer's business name.
  - `taxId` The Customer's tax ID.
  - `type` One of [the supported tax ID types](https://docs.stripe.com/tax/checkout/tax-ids?payment-ui=embedded-components.md#supported-types)
  - `value` The value of the tax ID.
## Escape event `element.on(event: 'escape', handler: function)`

Triggered when the escape key is pressed within an `Element`.

*   `event` The name of the event. In this case, `escape`.
*   `handler` `handler(event) => void` is a **callback function** that you provide that will be called when the event is fired.

### Example

```title Handle an Element escape event
```
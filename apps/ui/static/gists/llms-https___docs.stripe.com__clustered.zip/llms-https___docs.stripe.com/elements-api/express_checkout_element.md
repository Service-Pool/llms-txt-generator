## The Express Checkout Element

The Express Checkout Element is an embeddable component for accepting payments through one-click payment buttons.
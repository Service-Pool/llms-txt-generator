## Viewport Meta Tag Requirements

To ensure a seamless user experience for 3D Secure across all devices, it's recommended to set your page's viewport `width` to `device-width` using the [viewport meta tag](https://developer.mozilla.org/en-US/docs/Mozilla/Mobile/Viewport_meta_tag).

While there are other configurable viewport settings, the crucial aspect for 3D Secure is the inclusion of `width=device-width` in your configuration.
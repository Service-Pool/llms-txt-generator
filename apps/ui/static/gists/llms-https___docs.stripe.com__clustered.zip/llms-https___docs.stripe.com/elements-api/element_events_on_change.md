## Change event

`element.on(event: 'change', handler: function)`

The change event is triggered when any value in the change event payload changes. The event payload always contains certain keys, in addition to some `Element`-specific keys.

> Consult with your legal counsel regarding your requirements and obligations about how you collect, use, and store customers' personal data
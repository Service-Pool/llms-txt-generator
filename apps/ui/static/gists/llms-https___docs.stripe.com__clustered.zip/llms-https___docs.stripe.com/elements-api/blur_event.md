## Blur event `element.on(event: 'blur', handler: function)`

Triggered when the `Element` loses focus.

*   `event` The name of the event. In this case, `blur`.
*   `handler` `handler(event) => void` is a **callback function** that you provide that will be called when the event is fired.

### Example

```title Handle an Element blur event ```
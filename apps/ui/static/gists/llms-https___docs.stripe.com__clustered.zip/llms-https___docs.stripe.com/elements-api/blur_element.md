## Blur an Element

`element.blur()`

Blurs the [Element](https://docs.stripe.com/js/element.md).

### Example

```title
Handle an Element blur event
```
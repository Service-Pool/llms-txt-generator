## The Address Element

The Address Element is an embeddable component for collecting local and international billing and shipping addresses.
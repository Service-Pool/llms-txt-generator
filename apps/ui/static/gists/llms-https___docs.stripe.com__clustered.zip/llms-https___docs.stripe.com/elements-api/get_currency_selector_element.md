## Get the Currency Selector Element

`checkout.getCurrencySelectorElement()`

This method gets the previously created Currency Selector Element instance, if it exists.

### Example

```title
Get the Currency Selector Address Element
```
## Get the Shipping Address Element

`checkout.getShippingAddressElement()`

This method gets the previously created Shipping Address Element instance, if it exists.

### Example

```title
Get the Shipping Address Element
```
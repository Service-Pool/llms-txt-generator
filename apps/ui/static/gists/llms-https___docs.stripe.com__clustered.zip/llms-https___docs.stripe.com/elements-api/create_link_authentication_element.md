## Link Authentication Element

The Link Authentication Element is an embeddable component for collecting customer information.

### Create the Link Authentication Element

`elements.create(type: 'linkAuthentication', options?: object)`

This method creates an instance of the Link Authentication Element.

*   `type`: The type of Element being created, which is `linkAuthentication` in this case.
*   `options`: Options for creating the Link Authentication Element.
    *   `defaultValues`: Provide the initial contact information that will be displayed in the Link Authentication Element. The form will render with empty fields if not provided.
        *   `email`: The customer's email address.

### Example

```title
Create a Link Authentication Element
```
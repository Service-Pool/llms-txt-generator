## Elements

This section covers the various Elements provided by the Stripe JavaScript library, which are embeddable UI components for collecting payment information and other customer details.

### Core Elements and Their Usage

*   **Address Element**: A component for collecting billing and shipping addresses.
    *   [The Address Element](/js/element/address_element.md)
    *   [Get an Address Element](/js/elements_object/get_address_element.md)
*   **Express Checkout Element**: For accepting payments through one-click payment buttons.
    *   [The Express Checkout Element](/js/element/express_checkout_element.md)
    *   [Create the Express Checkout Element](/js/elements_object/create_express_checkout_element.md)
    *   [Get an Express Checkout Element](/js/elements_object/get_express_checkout_element.md)
*   **Link Authentication Element**: For collecting customer email addresses for Link.
    *   [Create the Link Authentication Element](/js/elements_object/create_link_authentication_element.md)
    *   [Get a Link Authentication Element](/js/elements_object/get_link_authentication_element.md)
*   **Payment Element**: A versatile element for collecting payment details.
    *   [Get a Payment Element](/js/elements_object/get_payment_element.md)
*   **Tax ID Element**: For collecting tax identification numbers.
    *   [Retrieve a Tax ID Element](/js/elements_object/get_tax_id_element.md)
    *   [Get value from a Tax ID Element](/js/elements_object/get_value_tax_id_element.md)

### Element Methods

*   **Collapse a Payment Element**: Collapses the Payment Element into a row of payment method tabs.
    *   [Collapse a Payment Element](/js/elements_object/collapse_payment_element.md)
*   **Blur an Element**: Blurs the Element.
    *   [Blur an Element](/js/element/other_methods/blur.md)
*   **Update Element**: Updates an Element's properties.
    *   (See specific element documentation for update methods)

### Element Events

Elements emit various events to notify your application of changes or user interactions.

*   **Update-end Event**: Triggered when `elements.update()` is complete.
    *   [Update-end event](/js/element/events/on_update_end.md)
*   **Change Event**: Triggered when any value within an Element changes.
    *   [Change event (general)](/js/element/events/on_change.md)
    *   [Change event (Custom Checkout Elements)](/js/custom_checkout/element_events/on_change.md)
*   **Ready Event**: Triggered when an Element is fully rendered and ready for interaction.
    *   [Ready event (general)](/js/element/events/on_ready.md)
    *   [Ready event (Custom Checkout Elements)](/js/custom_checkout/element_events/on_ready.md)
*   **Focus Event**: Triggered when an Element gains focus.
    *   [Focus event (general)](/js/element/events/on_focus.md)
    *   [Focus event (Custom Checkout Elements)](/js/custom_checkout/element_events/on_focus.md)
*   **Blur Event**: Triggered when an Element loses focus.
    *   [Blur event (general)](/js/element/events/on_blur.md)
    *   [Blur event (Custom Checkout Elements)](/js/custom_checkout/element_events/on_blur.md)
*   **Escape Event**: Triggered when the escape key is pressed within an Element.
    *   [Escape event (general)](/js/element/events/on_escape.md)
    *   [Escape event (Custom Checkout Elements)](/js/custom_checkout/element_events/on_escape.md)
*   **Click Event**: Triggered when an Element is clicked.
    *   [Click event](/js/element/events/on_click.md)
*   **LoadError Event**: Triggered when an Element fails to load.
    *   [LoadError event (general)](/js/element/events/on_loaderror.md)
    *   [LoadError event (Custom Checkout Elements)](/js/custom_checkout/element_events/on_loaderror.md)
*   **Express Checkout Specific Events**:
    *   **Confirm Event**: Triggered when a customer finalizes their payment with Express Checkout.
        *   [Confirm event (general)](/js/custom_checkout/element_events/on_confirm.md)
        *   [Confirm event (Express Checkout Element)](/js/custom_checkout/element_events/on_confirm.md)
    *   **Cancel Event**: Triggered when the Express Checkout payment interface is dismissed.
        *   [Cancel event (general)](/js/custom_checkout/element_events/on_cancel.md)
        *   [Cancel event (Express Checkout Element)](/js/custom_checkout/element_events/on_cancel.md)
    *   **ShippingAddressChange Event**: Triggered when the customer selects a new shipping address in the Express Checkout interface.
        *   [Shippingaddresschange event](/js/elements_object/express_checkout_element_shippingaddresschange_event.md)
    *   **ShippingRateChange Event**: Triggered when the customer selects a new shipping rate in the Express Checkout interface.
        *   [Shippingratechange event](/js/elements_object/express_checkout_element_shippingratechange_event.md)

### Creating and Managing Elements

*   **Create an Element**: Generic method to create an instance of an individual Element.
    *   [Create an Element (general)](/js/elements_object/create_element.md)
    *   [Create an Element (Issuing)](/js/issuing_elements/create.md)
*   **Get an Element**: Retrieves a previously created Element instance.
    *   (See specific element documentation for `getElement` methods)

### Embedded Checkout

This section details the JavaScript API for integrating Stripe's embedded Checkout.

*   **Mount embedded Checkout**: Attaches Checkout to the DOM.
    *   [Mount embedded Checkout](/js/embedded_checkout/mount.md)
*   **Unmount embedded Checkout**: Unmounts Checkout from the DOM.
    *   [Unmount embedded Checkout](/js/embedded_checkout/unmount.md)
*   **Destroy embedded Checkout**: Removes Checkout from the DOM and destroys it.
    *   [Destroy embedded Checkout](/js/embedded_checkout/destroy.md)

### Custom Checkout

This section covers the JavaScript API for building custom checkout flows.

*   **Checkout Actions**: Methods for interacting with the Checkout Session.
    *   [Read session data](/js/custom_checkout/session.md)
    *   [Apply a promotion code](/js/custom_checkout/apply_promotion_code.md)
    *   [Remove a promotion code](/js/custom_checkout/remove_promotion_code.md)
    *   [Update the Customer's shipping address](/js/custom_checkout/update_shipping_address.md)
    *   [Update the Customer's billing address](/js/custom_checkout/update_billing_address.md)
    *   [Update the Customer's email address](/js/custom_checkout/update_email.md)
    *   [Update the Customer's phone number](/js/custom_checkout/update_phone_number.md)
    *   [Update the Customer's business name and tax ID](/js/custom_checkout/update_tax_id_info.md)
    *   [Update line item quantities](/js/custom_checkout/update_line_item_quantity.md)
    *   [Update the selected shipping option](/js/custom_checkout/update_shipping_option.md)
    *   [Run server update](/js/custom_checkout/run_server_update.md)
*   **Checkout Elements**: Methods for creating and managing specific elements within Custom Checkout.
    *   [Create a Billing Address Element](/js/custom_checkout/create_billing_address_element.md)
    *   [Create a Shipping Address Element](/js/custom_checkout/create_shipping_address_element.md)
    *   [Create a Currency Selector Element](/js/custom_checkout/create_currency_selector_element.md)
    *   [Get the Payment Element](/js/custom_checkout/get_payment_element.md)
    *   [Get the Billing Address Element](/js/custom_checkout/get_billing_address_element.md)
    *   [Get the Shipping Address Element](/js/custom_checkout/get_shipping_address_element.md)
    *   [Get the Express Checkout Element](/js/custom_checkout/get_express_checkout_element.md)
    *   [Get the Currency Selector Element](/js/custom_checkout/get_currency_selector_element.md)
*   **Checkout Appearance and Fonts**:
    *   [Change the visual customization of Elements using the Appearance API](/js/custom_checkout/change_appearance.md)
    *   [Load additional custom fonts into Elements](/js/custom_checkout/load_fonts.md)
*   **Checkout Events**: Listen to events for changes in the checkout process.
    *   [Checkout events](/js/custom_checkout/events.md)
    *   [Change event](/js/custom_checkout/change_event.md)

### React Stripe.js Checkout

This section details the Checkout API within the React Stripe.js library.

*   **Checkout Actions**: Methods for interacting with the Checkout Session in React.
    *   [Apply a promotion code](/js/react_stripe_js/checkout/apply_promotion_code.md)
    *   [Remove a promotion code](/js/react_stripe_js/checkout/remove_promotion_code.md)
    *   [Update the Customer's shipping address](/js/react_stripe_js/checkout/update_shipping_address.md)
    *   [Update the Customer's billing address](/js/react_stripe_js/checkout/update_billing_address.md)
    *   [Update the Customer's email address](/js/react_stripe_js/checkout/update_email.md)
    *   [Update the Customer's phone number](/js/react_stripe_js/checkout/update_phone_number.md)
    *   [Update the Customer's business name and tax ID](/js/react_stripe_js/checkout/update_tax_id_info.md)
    *   [Update line item quantities](/js/react_stripe_js/checkout/update_line_item_quantity.md)
    *   [Update the selected shipping option](/js/react_stripe_js/checkout/update_shipping_option.md)
    *   [Run server update](/js/react_stripe_js/checkout/run_server_update.md)

### Payment Request API

*   **PaymentRequest events**: General information about events emitted by `PaymentRequest` instances.
    *   [PaymentRequest events](/js/payment_request/events.md)

### Appendix

*   **Viewport meta tag requirements**: Essential for a good user experience with 3D Secure.
    *   [Viewport meta tag requirements](/js/appendix/viewport_meta_requirements.md)
## Get a Payment Element

`elements.getElement(type: 'payment')`

This method retrieves a previously created Payment Element.

- `type` The type of Element being retrieved, which is `payment` in this case.

### Example

```title
Get a Payment Element
```
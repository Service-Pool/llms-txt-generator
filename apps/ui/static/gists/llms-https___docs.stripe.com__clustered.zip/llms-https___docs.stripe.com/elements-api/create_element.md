## Elements

This section details the various Elements available for use with Stripe's JavaScript SDK, covering their creation, retrieval, and event handling.

### Creating Elements

*   **Create an Element** (`/js/elements_object/create_element.md`): This method creates an instance of an individual `Element`. It takes the `type` of `Element` to create as well as an `options` object.
*   **Create the Express Checkout Element** (`/js/elements_object/create_express_checkout_element.md`): This method creates an instance of the Express Checkout Element. It accepts an `options` object for customization, including shipping country restrictions, Apple Pay specific options, and recurring/deferred payment configurations.
*   **Create the Link Authentication Element** (`/js/elements_object/create_link_authentication_element.md`): This method creates an instance of the Link Authentication Element. It accepts an `options` object, specifically for providing `defaultValues` for email.
*   **Create an Issuing Element** (`/js/issuing_elements/create.md`): This method creates an instance of an individual Issuing Element. It takes the `type` of Element to create as well as an `options` object.

### Retrieving Elements

*   **Get a Payment Element** (`/js/elements_object/get_payment_element.md`): This method retrieves a previously created Payment Element.
*   **Get an Express Checkout Element** (`/js/elements_object/get_express_checkout_element.md`): This method retrieves a previously created Express Checkout Element.
*   **Get a Link Authentication Element** (`/js/elements_object/get_link_authentication_element.md`): This method retrieves a previously created Link Authentication Element.
*   **Get an Address Element** (`/js/elements_object/get_address_element.md`): This method retrieves a previously created Address Element. It requires a `mode` option if multiple Address Elements are used.
*   **Retrieve a Tax ID Element** (`/js/elements_object/get_tax_id_element.md`): This method retrieves a previously created Tax ID Element.

### Element Actions and Events

*   **Blur an Element** (`/js/element/other_methods/blur.md`): Blurs the specified [Element](https://docs.stripe.com/js/element.md).
*   **Update-end event** (`/js/element/events/on_update_end.md`): Triggered when the call to `elements.update()` is complete.
*   **Change event** (`/js/element/events/on_change.md`): Triggered when any value in the change event payload changes.
*   **Ready event** (`/js/element/events/on_ready.md`): Triggered when the `Element` is fully rendered and methods like `element.focus()` and `element.update()` can be called. This event can provide information about available payment methods for `expressCheckout` Elements.
*   **Focus event** (`/js/element/events/on_focus.md`): Triggered when the `Element` gains focus.
*   **Blur event** (`/js/element/events/on_blur.md`): Triggered when the `Element` loses focus.
*   **Escape event** (`/js/element/events/on_escape.md`): Triggered when the escape key is pressed within an Element.
*   **Click event** (`/js/element/events/on_click.md`): Handles click events on an Element.
*   **LoadError event** (`/js/element/events/on_loaderror.md`): Triggered when the `Element` fails to load. This event is supported by `payment`, `linkAuthentication`, `address`, `expressCheckout`, `currencySelector`, `taxId`, `card`, and `cardNumber` Elements. It provides an `error` object detailing the failure.
*   **Confirm event** (`/js/elements_object/express_checkout_element_confirm_event.md`): Triggered from an Express Checkout Element when the customer finalizes their payment. This event allows for payment confirmation and provides details about the payment, customer billing, and shipping addresses.
*   **Cancel event** (`/js/elements_object/express_checkout_element_cancel_event.md`): Triggered from an Express Checkout Element when the payment interface is dismissed. This event should be used to handle order cancellations if necessary.
*   **Shippingaddresschange event** (`/js/elements_object/express_checkout_element_shippingaddresschange_event.md`): Triggered from an Express Checkout Element when the customer selects a new shipping address. Note that this event is not available for Elements with Checkout Sessions.
*   **Shippingratechange event** (`/js/elements_object/express_checkout_element_shippingratechange_event.md`): Triggered from an Express Checkout Element when the customer selects a new shipping rate. Note that this event is not available for Elements with Checkout Sessions.

### Specific Element Types

*   **The Express Checkout Element** (`/js/element/express_checkout_element.md`): An embeddable component for accepting payments through one-click payment buttons.
*   **The Address Element** (`/js/element/address_element.md`): An embeddable component for collecting local and international billing and shipping addresses.

### Tax ID Element Methods

*   **Get value from a Tax ID Element** (`/js/elements_object/get_value_tax_id_element.md`): Validates and retrieves form values from a Tax ID Element. Input validation errors are displayed by their associated fields.

### Embedded Checkout

*   **Mount embedded Checkout** (`/js/embedded_checkout/mount.md`): Attaches Checkout to the DOM using a CSS selector or a DOM element.
*   **Unmount embedded Checkout** (`/js/embedded_checkout/unmount.md`): Unmounts Checkout from the DOM.
*   **Destroy embedded Checkout** (`/js/embedded_checkout/destroy.md`): Removes Checkout from the DOM and destroys it.

### Custom Checkout

*   **Read session data** (`/js/custom_checkout/session.md`): Returns an object containing data about the Checkout Session.
*   **Apply a promotion code** (`/js/custom_checkout/apply_promotion_code.md`): Applies a promotion code to the Checkout Session.
*   **Remove a promotion code** (`/js/custom_checkout/remove_promotion_code.md`): Removes the currently applied promotion code.
*   **Update the Customer's shipping address** (`/js/custom_checkout/update_shipping_address.md`): Updates the Customer's shipping address. This is not used for Express Checkout payments.
*   **Update the Customer's billing address** (`/js/custom_checkout/update_billing_address.md`): Updates the Customer's billing address. This is not used for Express Checkout payments.
*   **Update the Customer's email address** (`/js/custom_checkout/update_email.md`): Updates the Customer's email address. Required for Link to appear for returning users if not provided during session creation. This is not used for Express Checkout payments.
*   **Update the Customer's phone number** (`/js/custom_checkout/update_phone_number.md`): Updates the Customer's phone number. This is not used for Express Checkout payments.
*   **Update the Customer's business name and tax ID** (`/js/custom_checkout/update_tax_id_info.md`): Updates the Customer's business name and tax ID.
*   **Update line item quantities** (`/js/custom_checkout/update_line_item_quantity.md`): Changes the quantity of a line item.
*   **Update the selected shipping option** (`/js/custom_checkout/update_shipping_option.md`): Updates the selected shipping option.
*   **Run server update** (`/js/custom_checkout/run_server_update.md`): Wraps an async function that makes a request to your server to update the Checkout Session, with a 20-second timeout.
*   **Checkout events** (`/js/custom_checkout/events.md`): Listen to Checkout events to respond to changes on your checkout page.
*   **Change event** (`/js/custom_checkout/change_event.md`): Triggered when Checkout Session data changes, such as a shipping address update. The event payload is a Checkout Session object.
*   **Create a Billing Address Element** (`/js/custom_checkout/create_billing_address_element.md`): Creates an instance of a Billing Address Element, with options for displaying saved contacts and customizing field display.
*   **Create a Shipping Address Element** (`/js/custom_checkout/create_shipping_address_element.md`): Creates an instance of a Shipping Address Element, with options for displaying saved contacts and customizing field display.
*   **Create a Currency Selector Element** (`/js/custom_checkout/create_currency_selector_element.md`): Creates an instance of a Currency Selector Element.
*   **Get the Payment Element** (`/js/custom_checkout/get_payment_element.md`): Gets the previously created Payment Element instance.
*   **Get the Billing Address Element** (`/js/custom_checkout/get_billing_address_element.md`): Gets the previously created Billing Address Element instance.
*   **Get the Shipping Address Element** (`/js/custom_checkout/get_shipping_address_element.md`): Gets the previously created Shipping Address Element instance.
*   **Get the Express Checkout Element** (`/js/custom_checkout/get_express_checkout_element.md`): Gets the previously created Express Checkout Element instance.
*   **Get the Currency Selector Element** (`/js/custom_checkout/get_currency_selector_element.md`): Gets the previously created Currency Selector Element instance.
*   **Change the visual customization of Elements using the Appearance API** (`/js/custom_checkout/change_appearance.md`): Modifies the visual customization of Elements created with Custom Checkout using the Appearance API.
*   **Load additional custom fonts into Elements** (`/js/custom_checkout/load_fonts.md`): Loads an array of custom fonts into Elements after they load.
*   **Element Change event** (`/js/custom_checkout/element_events/on_change.md`): Triggered when any value in the change event payload changes for supported Checkout Elements (`paymentElement`, `billingAddressElement`, `shippingAddressElement`, and `taxIdElement`).
*   **Element Ready event** (`/js/custom_checkout/element_events/on_ready.md`): Triggered when an Element is fully rendered.
*   **Element Focus event** (`/js/custom_checkout/element_events/on_focus.md`): Triggered when an Element gains focus.
*   **Element Blur event** (`/js/custom_checkout/element_events/on_blur.md`): Triggered when an Element loses focus.
*   **Element Escape event** (`/js/custom_checkout/element_events/on_escape.md`): Triggered when the escape key is pressed within an Element.
*   **Element LoadError event** (`/js/custom_checkout/element_events/on_loaderror.md`): Triggered when an Element fails to load.
*   **Element Confirm event** (`/js/custom_checkout/element_events/on_confirm.md`): Triggered from the Express Checkout Element when the customer finalizes their payment.
*   **Element Cancel event** (`/js/custom_checkout/element_events/on_cancel.md`): Triggered from the Express Checkout Element when the payment interface is dismissed.

### React Stripe.js Checkout

*   **Apply a promotion code** (`/js/react_stripe_js/checkout/apply_promotion_code.md`): Applies a promotion code to the Checkout Session.
*   **Remove a promotion code** (`/js/react_stripe_js/checkout/remove_promotion_code.md`): Removes the currently applied promotion code.
*   **Update the Customer's shipping address** (`/js/react_stripe_js/checkout/update_shipping_address.md`): Updates the Customer's shipping address. This is not used for Express Checkout payments.
*   **Update the Customer's billing address** (`/js/react_stripe_js/checkout/update_billing_address.md`): Updates the Customer's billing address. This is not used for Express Checkout payments.
*   **Update the Customer's email address** (`/js/react_stripe_js/checkout/update_email.md`): Updates the Customer's email address. Required for Link to appear for returning users if not provided during session creation. This is not used for Express Checkout payments.
*   **Update the Customer's phone number** (`/js/react_stripe_js/checkout/update_phone_number.md`): Updates the Customer's phone number. This is not used for Express Checkout payments.
*   **Update the Customer's business name and tax ID** (`/js/react_stripe_js/checkout/update_tax_id_info.md`): Updates the Customer's business name and tax ID.
*   **Update line item quantities** (`/js/react_stripe_js/checkout/update_line_item_quantity.md`): Changes the quantity of a line item.
*   **Update the selected shipping option** (`/js/react_stripe_js/checkout/update_shipping_option.md`): Updates the selected shipping option.
*   **Run server update** (`/js/react_stripe_js/checkout/run_server_update.md`): Wraps an async function that makes a request to your server to update the Checkout Session, with a 20-second timeout.

### Payment Request Events

*   **PaymentRequest events** (`/js/payment_request/events.md`): Details the various events emitted by `PaymentRequest` instances.

### Viewport Meta Tag Requirements

*   **Viewport meta tag requirements** (`/js/appendix/viewport_meta_requirements.md`): Specifies the requirement for a viewport meta tag with `width=device-width` for optimal 3D Secure user experience.
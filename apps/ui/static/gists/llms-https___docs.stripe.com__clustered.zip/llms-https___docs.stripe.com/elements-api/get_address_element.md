## Get an Address Element

`elements.getElement(type: 'address', options?: object)`

This method retrieves a previously created Address Element.

*   `type` The type of Element being retrieved, which is `address` in this case.
*   `options` Options for retrieving the Address Element.
    *   `mode` Required when using multiple Address Elements. Specify which mode of the Address Element you would like to retrieve.

### Example

```title
Get an Address Element
```
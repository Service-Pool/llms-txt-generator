## Get the Billing Address Element

`checkout.getBillingAddressElement()`

This method gets the previously created Billing Address Element instance, if it exists.

### Example

```title Get the Billing Address Element ```
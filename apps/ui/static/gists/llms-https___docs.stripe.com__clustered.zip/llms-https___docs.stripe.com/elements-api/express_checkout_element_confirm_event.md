## Confirm event `expressCheckoutElement.on(event: string, handler: function)`

The `confirm` event is triggered from an Express Checkout Element when the customer finalizes their payment. Use this event to trigger payment confirmation.

- `event` The name of the event. In this case, `confirm`.
- `handler` A callback function `handler(event) => void` you provide that's called after the event is fired. When called, it passes an event object with the following properties:
    - `elementType` The type of element the event fires from, which is `expressCheckout` in this case.
    - `expressPaymentType` The payment method the customer checks out with.
    - `paymentFailed` A function `paymentFailed(payload) => void` that's called if you're unable to process the customer's payment.
    - `reason` Default is `'fail'`. The payment interface might surface the reason to provide a hint to the customer on why their payment failed.
    - `message` A short, concise, localized error message to display on the payment sheet. If none is provided, the payment sheet will display a generic error message for the given reason. **Note:** Custom error messages may not be supported or may be truncated by certain wallets.
    - `billingDetails` Object containing information about the customer's billing details.
        - `name` The name of the customer.
        - `email` The email address of the customer.
        - `phone` The phone number of the customer.
        - `address` The billing address of the customer. **Note:** When using PayPal, the full billing address of the customer is not always exposed. Typically, only the country code is passed back from PayPal. To access the full billing address, you would need to request it from PayPal directly.
            - `line1`
            - `line2`
            - `city`
            - `state`
            - `postal_code`
            - `country`
    - `shippingAddress` Object containing information about the customer's shipping address.
        - `name` The name of the recipient.
        - `address` The shipping address of the customer.

### Example

```title
Handle 'confirm' event
```
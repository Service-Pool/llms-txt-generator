## Checkout Events

Listen to Checkout events to respond to changes caused by customer actions on your checkout page.

### Event Types

The following events are available for Custom Checkout:

*   **`change`**: Triggered when [Checkout Session](https://docs.stripe.com/js/custom_checkout/session_object.md) data changes, such as when the customer changes their shipping address. The event payload is always a [Checkout Session](https://docs.stripe.com/js/custom_checkout/session_object.md) object.
*   **`ready`**: Triggered when the checkout is fully rendered and methods on the instance, like `actions.setShippingAddress` and `actions.setBillingAddress`, can be called.

### Listening to Events

You can listen to these events using the `checkout.on()` method:

```javascript
import {loadStripe} from '@stripe/stripe-js';

const stripe = await loadStripe('pk_test_...');
const checkout = await stripe.initEmbeddedCheckout({
  // ... other options
});

checkout.on('change', (session) => {
  // Handle changes to the Checkout Session
  console.log('Checkout session changed:', session);
});

checkout.on('ready', () => {
  // Handle checkout readiness
  console.log('Checkout is ready');
});
```
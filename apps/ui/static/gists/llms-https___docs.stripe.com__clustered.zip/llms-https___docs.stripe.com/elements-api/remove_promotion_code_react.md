## Remove a promotion code

`removePromotionCode()`

Use this method to remove the currently applied promotion code, if applicable.

### Example

```title
Remove a promotion code
```
## Create the Express Checkout Element

`elements.create(type: 'expressCheckout', options?: object)`

This method creates an instance of the Express Checkout Element.

- `type` The type of Element being created, which is `expressCheckout` in this case.
- `options` Options for creating the Express Checkout Element.
    - `allowedShippingCountries` By default, the Express Checkout Element allows all countries for shipping. You can specify which countries are allowed for shipping in the Express Checkout Element with a list of two-letter country codes.
    - `applePay` Specify Apple Pay specific options. These are passed through to the Apple Pay API.
    - `recurringPaymentRequest` Specify a request to set up a recurring payment. See the [Apple Pay documentation](https://developer.apple.com/documentation/apple_pay_on_the_web/applepayrecurringpaymentrequest) for more details.
        - `paymentDescription`
        - `managementURL`
        - `regularBilling`
        - `amount`
        - `label`
        - `recurringPaymentStartDate`
        - `recurringPaymentEndDate`
        - `recurringPaymentIntervalUnit`
        - `recurringPaymentIntervalCount`
    - `trialBilling`
        - `amount`
        - `label`
        - `recurringPaymentStartDate`
        - `recurringPaymentEndDate`
        - `recurringPaymentIntervalUnit`
        - `recurringPaymentIntervalCount`
    - `billingAgreement`
    - `deferredPaymentRequest` Specify a request to set up a deferred payment. See the [Apple Pay documentation](https://developer.apple.com/documentation/apple_pay_on_the_web/applepaydeferredpaymentrequest) for more details.
        - `paymentDescription`
        - `managementURL`
        - `deferredBilling`
        - `amount`
        - `amountType` Indicates whether the billing amount is known at request time. When set to 'final', the Apple Pay payment sheet shows the configured amount.
        - `label`
        - `deferredPaymentDate`
        - `billingAgreement`
        - `freeCancellationDate` If set, you must also supply a freeCancellationDateTimeZone.
        - `freeCancellationDateTimeZone` If set, you must also supply a freeCancellationDate. These are [tz](https://en.wikipedia.org/wiki/List_of_tz_database_time_zones) timezones such as `America/Los_Angeles`, `Europe/Dublin`, and `Asia/Singapore`.
    - `automaticReloadPaymentRequest` Specify a request to set up an automatic reload payment. See the [Apple Pay documentation](https://developer.apple.com/documentation/apple_pay_on_the_web/applepayautomaticreloadpaymentrequest) for more details.
        - `paymentDescription`
        - `managementURL`
        - `automaticReloadBilling`
        - `amount`
        - `label`
        - `automaticReloadPaymentThresholdAmount`
        - `billingAgreement`
    - `billingAddressRequired` Controls whether the Express Checkout Element collects the billing address. The default value depends on your integration:
        - If you pass `allowedShippingCountries`, `phoneNumberRequired`, `shippingAddressRequired`, `emailRequired`, `applePay`, `lineItems`, or `business` when
## Update the Customer's billing address

`updateBillingAddress(billingAddress: nullable object)`

Use this method to update the Customer's billing address. If your integration uses the [Express Checkout Element](https://docs.stripe.com/elements/express-checkout-element.md), the billing address is collected directly from the wallet and the value set by `updateBillingAddress` is not used for express checkout payments.

*   `billingAddress` New billing information for the Customer.
    *   `name` Full name.
    *   `address` Address.
    *   `country` Two-letter country code ([ISO 3166-1 alpha-2](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2)).
    *   `line1` Address line 1 (e.g., street, PO Box, or company name).
    *   `line2` Address line 2 (e.g., apartment, suite, unit, or building).
    *   `city` City, district, suburb, town, or village.
    *   `postal_code` ZIP or postal code.
    *   `state` State, county, province, or region.

### Example

```title
Update the Customer's billing address
```
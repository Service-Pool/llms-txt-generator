## Unmount Embedded Checkout

`checkout.unmount()`

Unmounts Checkout from the DOM. Call `checkout.mount` to reattach it to the DOM.

### Example

```title
Unmount embedded Checkout
```
## Create a Currency Selector Element

`checkout.createCurrencySelectorElement()`

This method creates an instance of a Currency Selector Element.

### Example

```title
Create a Currency Selector Element
```
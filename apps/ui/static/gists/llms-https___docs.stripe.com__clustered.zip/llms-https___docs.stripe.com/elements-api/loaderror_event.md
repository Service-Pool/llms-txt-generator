## LoadError Event

`element.on(event: 'loaderror', handler: function)`

Triggered when the `Element` fails to load.

**This event is only emitted from the `payment`, `linkAuthentication`, `address`, `expressCheckout`, `currencySelector`, `taxId`, `card`, and `cardNumber` Elements.**

*   `event`: The name of the event. In this case, `loaderror`.
*   `handler`: `handler(event) => void` is a **callback function** that you provide that will be called when the event is fired. When called it will be passed an event object with the following properties:
    *   `elementType`: The type of element that emitted this event.
    *   `error`: An `error` object that describes the failure.

### Example

```title
Handle an Element loaderror event
```
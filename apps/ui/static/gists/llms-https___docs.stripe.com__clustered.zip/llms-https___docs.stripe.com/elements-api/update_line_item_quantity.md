## Update line item quantities

`updateLineItemQuantity(options: object)`

Use this method to change the quantity of a line item.

- `options` Options for `updateLineItemQuantity`.
  - `lineItem` The [ID](https://docs.stripe.com/js/custom_checkout/session_object.md#custom_checkout_session_object-lineItems-id) of the line item to update.
  - `quantity` The new quantity of the line item.

### Example

```title
Update line item quantities
```
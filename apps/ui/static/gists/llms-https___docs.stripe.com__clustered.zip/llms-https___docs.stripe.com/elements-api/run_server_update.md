## Run server update

`actions.runServerUpdate(userFunction: function)`

Use this method to wrap an async function that makes a request to your server to update the Checkout Session.

> `runServerUpdate` enforces a 20-second timeout for your update function. If your function doesn't resolve within 20 seconds, `runServerUpdate` returns an error. Wrap `runServerUpdate` calls in `try`/`catch` blocks to handle any errors.

- `userFunction` An async function to make a request to your server to update the Checkout Session.

### Example

```title Run server update ```
## Ready event

`element.on(event: 'ready', handler: function)`

Triggered when the `Element` is fully rendered and methods on the instance, like `element.focus()` and `element.update()`, can be called.

*   `event` The name of the event. In this case, `ready`.
*   `handler` `handler(event) => void` is a **callback function** that you provide that will be called when the event is fired. After it's called, it passes an event object with the following properties:
    *   `elementType` The type of element the event is fired from.
    *   `availablePaymentMethods` This field is **only** present on the `expressCheckout` Element. Describes which buttons render in the Element. Returns undefined if no buttons will render.
        *   `link`
        *   `applePay`
        *   `googlePay`
        *   `paypal`
        *   `amazonPay`
        *   `klarna`

### Example

```title
Handle an Element ready event
```
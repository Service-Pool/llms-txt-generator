## Shippingaddresschange event `expressCheckoutElement.on(event: string, handler: function)`

The `shippingaddresschange` event is triggered from an Express Checkout Element whenever the customer selects a new address in the payment interface. This event is not available for Elements with Checkout Sessions (EwCS integrations). When using an Express Checkout Element with a Checkout Session, shipping address changes are managed through the Checkout Session itself. You can update the session on your server after the customer completes their payment rather than responding to this event during the payment flow.

- `event` The name of the event. In this case, `shippingaddresschange`.
- `handler` A callback function `handler(event) => void` you provide that's called after the event is fired. After it's called, it passes an event object with the following properties:
    - `elementType` The type of element the event is fired from, which is `expressCheckout` in this case.
    - `resolve` A function `resolve(payload) => void` that's called if the recipient's shipping address is valid.
    - `applePay` Specify Apple Pay specific options. These are passed through to the Apple Pay API.
    - `recurringPaymentRequest` Specify a request to set up a recurring payment. See the [Apple Pay documentation](https://developer.apple.com/documentation/apple_pay_on_the_web/applepayrecurringpaymentrequest) for more details.
    - `paymentDescription`
    - `managementURL`
    - `regularBilling`
    - `amount`
    - `label`
    - `recurringPaymentStartDate`
    - `recurringPaymentEndDate`
    - `recurringPaymentIntervalUnit`
    - `recurringPaymentIntervalCount`
    - `trialBilling`
    - `amount`
    - `label`
    - `recurringPaymentStartDate`
    - `recurringPaymentEndDate`
    - `recurringPaymentIntervalUnit`
    - `recurringPaymentIntervalCount`
    - `automaticReloadPaymentRequest` Specify a request to set up an automatic reload payment. See the [Apple Pay documentation](https://developer.apple.com/documentation/apple_pay_on_the_web/applepayautomaticreloadpaymentrequest) for more details.
    - `paymentDescription`
    - `managementURL`
    - `automaticReloadBilling`
    - `amount`
    - `label`
    - `automaticReloadPaymentThresholdAmount`
    - `lineItems` An array of LineItem objects. These LineItems are shown as line items in the payment interface, if line items are supported.
        - `name` The name of the line item surfaced to the customer in the payment interface.
        - `amount` The amount in
## Cancel event `expressCheckoutElement.on(event: string, handler: function)`

The `cancel` event is triggered from an Express Checkout Element when the payment interface is dismissed. Note that in some browsers, the payment interface might be dismissed by the customer even after they authorize the payment. This means that you might receive a `cancel` event after receiving a `confirm` event. If you're using the `cancel` event as a hook for canceling the customer's order, make sure you also refund the payment that you just created.

- `event` The name of the event. In this case, `cancel`.
- `handler` A callback function that you provide that's called after the event is fired.

### Example

```title Handle 'cancel' event
```
## Pre-authorized Debit Payments in Canada

This section details how to accept Pre-authorized Debit (PAD) payments from customers with Canadian bank accounts using Stripe.

### Overview

Stripe users in Canada and the United States can accept PADs through the Automated Clearing Settlement System (ACSS) provided by Payments Canada. This payment method requires businesses to collect a mandate from the customer, which defines specific payment schedules or terms.

### Key Features and Requirements

*   **Mandate Collection:** Before debiting a customer's bank account, you must obtain a mandate. This mandate includes the customer's institution number, transit number, account number, name, and email.
*   **Stripe.js Integration:** When using Stripe.js, Stripe offers a hosted solution for collecting mandates, bank account details, and performing instant bank verification (with delayed verification using micro-deposits as a fallback).
*   **Verification:** Bank account verification is a mandatory step to accept PADs and helps reduce payment failures and fraud.
*   **Reusable and Delayed Notification:** Canadian pre-authorized debits are a reusable payment method, but they are also a delayed notification method, meaning funds are not immediately available.

### Accepting PAD Payments

*   **Using Stripe Checkout:** You can create a Checkout Session with `acss_debit` as a payment method type to track and handle payment states.
*   **Direct API Integration:** For more custom payment flows, you can integrate directly using the API.

### Mandate Agreements

*   **Default Mandate:** Stripe.js provides a default hosted solution for collecting mandates.
*   **Custom Mandate Agreements:** In specific scenarios, you may need to create a custom mandate agreement. This is typically for situations where you want to opt-out of sending debit notification emails or need to provide different cancellation or recourse terms that comply with Payments Canada rules.

### Saving Bank Details for Future Payments

You can use the Setup Intents API to collect payment method details in advance, allowing for future purchases without requiring the customer to re-enter their information.

### Settlement Time

As a delayed notification payment method, PAD payments typically take **5 business days** to arrive in your account.
## ACH Direct Debit Overview

This section provides an overview of accepting payments via ACH Direct Debit, a common method for US bank account debits. It covers the core concepts, integration requirements, and important considerations for using ACH Direct Debit with Stripe.

### Key Concepts

*   **Authorization:** Customers must authorize you to debit their bank account. This authorization is typically captured through a mandate.
*   **Verification:** Bank accounts must be verified before they can be used for ACH debits. Stripe offers various verification methods, including instant verification via Financial Connections.
*   **Delayed Notification:** ACH payments are a delayed notification payment method, meaning confirmation of success or failure can take several business days. This impacts when funds are reflected in your Stripe balance.
*   **US-Only:** ACH Direct Debit is exclusively for US bank accounts and USD currency.

### Integration Methods

Stripe offers several ways to integrate ACH Direct Debit:

*   **Payment Intents API & Checkout Sessions API:** These are the recommended modern APIs for creating new ACH Direct Debit integrations. They offer enhanced features like Checkout and Payment Element support, dynamic payment method handling, and faster settlement.
*   **Legacy Charges API:** This is a deprecated method for accepting ACH payments. If you have an existing integration using the Charges API, it is strongly recommended to migrate to the Payment Intents API.

### Important Considerations

*   **Migration:** Stripe is deprecating support for ACH Direct Debit via legacy integrations. You must migrate to the Payment Intents API or Checkout Sessions API to continue accepting ACH payments.
*   **Verification:** Ensure you understand the bank account verification requirements for your chosen integration method.
*   **Network Decline Codes:** Familiarize yourself with network decline codes specific to ACH Direct Debit to troubleshoot payment failures.
*   **Financial Connections:** This service provides instant bank account verification and can also collect additional data like balances and ownership information, reducing payment failures and improving conversion.
*   **Invoicing:** ACH Direct Debit can be used for invoicing, offering a potentially lower-cost alternative to card payments for businesses with high invoice totals.
*   **Customization:** While Stripe provides default solutions, you can customize mandate agreements and email notifications for certain ACH Direct Debit flows.
*   **Blocked Accounts:** Understand the reasons why Stripe might block bank accounts for ACH debits and how to address them.
*   **SEC Codes:** Be aware of Standard Entry Class (SEC) codes, which define customer authorization types for ACH transactions and are crucial for compliance.
*   **Nacha Compliance:** Adhere to Nacha rules, particularly for e-commerce purchases, which may require specific transaction classifications.
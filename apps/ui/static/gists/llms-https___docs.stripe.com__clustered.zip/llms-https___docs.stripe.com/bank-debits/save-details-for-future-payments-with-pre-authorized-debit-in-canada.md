## Save Details for Future Payments with Pre-Authorized Debit in Canada

This document explains how to save customer bank details for future Canadian pre-authorized debit (PAD) payments, enabling streamlined repeat transactions.

### Key Concepts

*   **Setup Intents API:** This API allows you to collect payment method details in advance, with the final amount or payment date determined later. This is ideal for scenarios like:
    *   Saving payment methods to a customer's wallet for future purchases.
    *   Collecting surcharges after fulfilling a service.
    *   Initiating free trials for subscriptions.
*   **Delayed Notification Payment Method:** Pre-authorized debit in Canada is a delayed notification payment method, meaning funds are not immediately available after payment. It typically takes up to 5 business days for payments to reflect in your account.
*   **Currency:** While most Canadian bank accounts hold Canadian Dollars (CAD), some hold US Dollars (USD). You can accept PAD payments in either CAD or USD, but it's crucial to select the correct currency for your customer to avoid payment failures.

### Saving Bank Details

To save bank details for future PAD payments, you will use the Setup Intents API. This process involves:

1.  **Creating or Retrieving a Customer:** Ensure you have a Stripe Customer object associated with your customer. This object will store the saved payment method details.
2.  **Using the Setup Intents API:** Initiate a SetupIntent to collect and verify the customer's bank account details and mandate.
3.  **Attaching the Payment Method:** Once the SetupIntent is confirmed, the collected bank account details will be saved as a PaymentMethod and attached to the Customer object.

### Considerations

*   **Currency Selection:** Carefully choose the correct currency (CAD or USD) for your customer's PAD payments to prevent failures.
*   **Delayed Notification:** Be aware of the 5-business-day settlement time for PAD payments.

By following these steps, you can efficiently save customer bank details for future Canadian pre-authorized debit payments, enhancing the customer experience and streamlining your payment collection process.
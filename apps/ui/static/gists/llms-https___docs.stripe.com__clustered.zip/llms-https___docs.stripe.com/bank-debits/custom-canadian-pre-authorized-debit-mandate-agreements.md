### Custom Canadian Pre-Authorized Debit Mandate Agreements

This document outlines the requirements and scenarios for creating custom mandate agreements for Canadian pre-authorized debit (PAD) payments. While Stripe.js provides a default, all-in-one solution for mandate collection, custom agreements may be necessary in specific situations.

**When to Use a Custom Mandate Agreement:**

*   **Exempting Debit Notification Emails:** If you wish to obtain authorization from your customer to *not* send debit notification emails.
*   **Alternative Cancellation or Recourse Terms:** If you need to provide different or additional cancellation or recourse terms that comply with Payments Canada rules.

**Default Mandate Agreement:**

The default mandate agreement provided by Stripe is designed to meet the needs of most businesses. It offers flexible timelines for confirmation and cancellation as permitted by Canadian banks and adheres to all requirements set forth by Payments Canada Rules for pre-authorized debits.

**Creating a Custom Mandate Agreement:**

If your business requires a custom agreement, this page will guide you through the process of creating a valid mandate that satisfies all regulatory requirements. It is crucial to ensure that your custom agreement aligns with the latest Payments Canada rules to avoid compliance issues.

**Key Considerations for Custom Agreements:**

*   **Authorization:** Clearly define the customer's authorization to debit their account.
*   **Notification Requirements:** Specify any deviations from standard email notification procedures, ensuring compliance with regulations.
*   **Cancellation and Recourse:** Outline clear terms for cancellation and customer recourse, adhering to legal and regulatory standards.
*   **Merchant and Stripe Partnership:** Clearly state the merchant's partnership with Stripe for collecting direct debit payments.

**Note:** It is generally recommended to use Stripe's default mandate agreement unless your specific business needs necessitate a custom solution. Consult with legal counsel to ensure your custom mandate agreement is fully compliant.
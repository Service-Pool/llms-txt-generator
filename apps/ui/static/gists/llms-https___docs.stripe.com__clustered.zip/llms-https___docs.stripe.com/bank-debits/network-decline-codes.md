## Network Decline Codes

Network decline codes are alphanumeric error codes that indicate why a payment was declined. These codes often originate from issuing banks, payment processors, or credit networks.

### Resolving Network Decline Codes

Use the following table to help resolve issues related to network decline codes:

| Payment Method | Raw Network Code | Decline Code | Explanation                                                                                             | Next Steps                                                                                                         |
| :------------- | :--------------- | :----------- | :------------------------------------------------------------------------------------------------------ | :----------------------------------------------------------------------------------------------------------------- |
| **ACH Direct Debit** | R01, R09         | insufficient_funds | The customer's bank account lacks sufficient funds to complete the transaction.                       | Contact your customer to confirm sufficient funds and retry the transaction.                                       |
|                | R02              | bank_account_closed | The customer's bank account has been closed and cannot be used for the payment.                       | Contact your customer for updated account details and retry the transaction.                                       |
|                | R03, R04         | bank_account_invalid_details | The provided bank account information is incorrect, preventing the transaction.                   | Contact your customer for the correct account details and retry the transaction.                                   |
|                | R05, R07, R08, R10, R11, R29, R31 | debit_not_authorized | The payment lacks an authorized mandate from the customer.                                          | Collect a new mandate from the customer and retry the transaction.                                                 |
|                | R15              | recipient_deceased | The mandate attempt was made on the account of a potentially deceased individual.                 | Verify the customer's status and retry the transaction.                                                            |
|                | R16              | bank_account_frozen | The customer's bank account is frozen, preventing the payment from being processed.                 | Contact your customer for more information and to resolve the account freeze.                                      |

This section provides guidance on understanding and resolving common network decline codes, with a specific focus on ACH Direct Debit payments.
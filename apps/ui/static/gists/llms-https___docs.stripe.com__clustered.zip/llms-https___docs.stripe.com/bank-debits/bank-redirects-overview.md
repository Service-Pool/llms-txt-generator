## Bank Redirects

Bank redirects are a payment method that allows customers to pay online using their bank accounts. This method is particularly popular in countries like Germany, the Netherlands, and Malaysia, where it accounts for over half of online commerce.

**Use Cases:**

*   **Retailers:** Improve conversion rates and reduce fraud for online transactions.
*   **Software/Service Businesses:** Collect one-time payments from other businesses.

**Considerations:**

*   **Subscriptions:** Bank redirects may not be suitable for subscription-based businesses, as some methods do not support recurring payments.

**Payment Flow:**

1.  At checkout, the customer is redirected to their online banking portal.
2.  They log in with their bank credentials and approve the transaction.
3.  The customer is then returned to your site.
4.  Some bank redirects may use SMS or other two-factor authentication for enhanced security.

**Product Support:**

Stripe offers a unified integration for all bank redirects, simplifying implementation. With Stripe Checkout, you can add any bank redirect by changing a single line of code.

**Supported Payment Methods:**

*   Bancontact
*   BLIK
*   EPS
*   FPX
*   iDEAL | Wero
*   P24
*   SOFORT
*   TWINT
*   Wero
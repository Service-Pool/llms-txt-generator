## Accepting Australia BECS Direct Debit Payments

This guide explains how to accept Australia BECS Direct Debit payments using Stripe, focusing on integration with Stripe Checkout.

### Overview

Stripe users in Australia can leverage Stripe Checkout to accept BECS Direct Debit payments. This method involves customers providing their bank account details and agreeing to a mandate, which authorizes Stripe to debit their account.

### Key Features and Considerations

*   **Mandate Collection:** Businesses must obtain a mandate from customers, which includes their bank account details (account holder's name, BSB number, and bank account number) and requires acceptance of the BECS Direct Debit Service Agreement. Stripe can generate this mandate for you.
*   **Delayed Notification:** BECS Direct Debit is a reusable, delayed notification payment method. Payment success or failure is typically confirmed within three business days after initiating a debit.
*   **Transaction Limits:** For new users, there's a default limit of 10,000 AUD per transaction and per week. Higher limits can be requested by contacting Stripe support.
*   **Checkout Integration:** Stripe Checkout can dynamically present relevant payment methods, including BECS Direct Debit, based on currency, restrictions, and other parameters. Alternatively, you can manually configure payment methods.

### Accepting Payments with Stripe Checkout

1.  **Create a Checkout Session:** When a customer intends to purchase, create a Checkout Session.
2.  **Customer Redirection:** Stripe redirects the customer to the Checkout Session, where they will complete their purchase.
3.  **Return to Site:** After completion, the customer is redirected back to your website.

### Compatibility Requirements

To ensure compatibility with BECS Direct Debit payments in Checkout:

*   **Line Items:** All line items must be for one-time purchases. Subscriptions are not yet supported.
*   **Pricing Currency:** Prices for all line items must be in the same currency. If you have line items in different currencies, create separate Checkout Sessions for each.

### Next Steps

*   **Dynamic Payment Methods:** For a dynamic integration, follow the "Accept a payment" guide to build a Checkout integration.
*   **Manual Configuration:** If you prefer to manually configure payment methods, follow the steps outlined in the documentation.
## Network Decline Codes

Network decline codes are alphanumeric error codes that indicate the reason for a payment decline. These codes often originate from issuing banks, payment processors, or credit networks.

### Resolving Network Decline Codes

The following table provides explanations and next steps for common network decline codes:

| Payment Method | Raw Network Code | Decline Code       | Explanation                                                                                             | Next Steps                                                                                                                               |
| :------------- | :--------------- | :----------------- | :------------------------------------------------------------------------------------------------------ | :--------------------------------------------------------------------------------------------------------------------------------------- |
| ACH Direct Debit | R01, R09         | insufficient\_funds | The customer's bank account lacks the necessary funds to complete the transaction.                      | Contact your customer to verify sufficient funds and retry the transaction.                                                              |
| ACH Direct Debit | R02              | bank\_account\_closed | The customer's bank account has been closed and cannot be used for the payment.                         | Contact your customer for updated account details and retry the transaction.                                                             |
| ACH Direct Debit | R03, R04         | bank\_account\_invalid\_details | The provided bank account information is incorrect.                                                     | Contact your customer for the correct account details and retry the transaction.                                                         |
| ACH Direct Debit | R05, R07, R08, R10, R11, R29, R31 | debit\_not\_authorized | The payment lacks an authorized mandate from the customer.                                              | Collect a new mandate from the customer and retry the transaction.                                                                       |
| ACH Direct Debit | R15              | recipient\_deceased | The mandate attempt was made on the account of a potentially deceased individual.                       | Verify the customer's status and retry the transaction.                                                                                  |
| ACH Direct Debit | R16              | bank\_account\_frozen | The customer's bank account is frozen, preventing the payment from being processed.                     | Contact your customer to resolve the account freeze and retry the transaction.                                                           |
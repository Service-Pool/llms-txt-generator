## Accepting Canadian Pre-authorized Debit Payments

This section details how to accept Canadian Pre-authorized Debit (PAD) payments using Stripe. PAD is a payment method that allows businesses to debit funds directly from a customer's bank account in Canada.

### Key Concepts

*   **Automated Clearing Settlement System (ACSS):** The system used in Canada for PAD payments.
*   **Mandate:** A customer's authorization to debit their bank account. This must be collected before initiating any payments.
*   **Delayed Notification Payment Method:** PAD payments are not immediate. It can take up to 5 business days for payment confirmation.

### Accepting Payments

You can accept Canadian PAD payments through two primary methods:

*   **Stripe Checkout:** A pre-built, hosted payment page that simplifies integration. You can configure a Checkout Session to include `acss_debit` as a payment method type.
*   **Direct API Integration:** For more custom payment flows, you can use Stripe's APIs to collect payment method information and mandate acknowledgments directly.

### Mandate Collection

Collecting a valid mandate is crucial for PAD payments. Stripe provides tools to help with this:

*   **Stripe.js:** The foundational JavaScript library can offer a hosted solution for collecting mandates and bank account details, including instant bank verification.
*   **Custom Mandate Agreements:** In specific scenarios, you may need to create your own mandate agreement to comply with Payments Canada rules or to offer different terms.

### Saving Bank Details for Future Payments

To streamline future purchases, you can use the Setup Intents API to collect and save customer bank account details and mandate information in advance. This allows for one-time or recurring payments without requiring the customer to re-enter their details each time.

### Important Considerations

*   **Currency:** While most Canadian bank accounts hold CAD, it's possible to accept PAD payments in either CAD or USD. Ensure you select the correct currency to avoid payment failures.
*   **Subscriptions:** Currently, subscriptions are not supported for PAD payments within Checkout.
*   **Delayed Settlement:** Remember that PAD payments are a delayed notification method, meaning funds are not immediately available.

### Further Information

*   **Custom Mandate Agreements:** For detailed information on creating custom mandate agreements, refer to the [Custom Canadian pre-authorized debit mandate agreements](link-to-custom-mandate-agreements) documentation.
*   **Saving Bank Details:** Learn more about saving customer details for future payments in the [Save details for future payments with pre-authorized debit in Canada](link-to-save-details) documentation.
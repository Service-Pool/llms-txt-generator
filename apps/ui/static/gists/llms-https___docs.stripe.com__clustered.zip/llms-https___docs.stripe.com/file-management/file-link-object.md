## File Links

This section details how to manage file links within Stripe, allowing you to share uploaded files with non-Stripe users via a secure, unauthenticated URL.

### Core Concepts

*   **File Object:** Represents a file hosted on Stripe's servers, uploaded via the File Upload API.
*   **File Link Object:** A resource that provides a temporary, publicly accessible URL to download the content of a specific File object.

### API Endpoints

The following API endpoints are available for managing File Links:

*   **Create a file link:** `POST /v1/file_links`
*   **Update a file link:** `POST /v1/file_links/:id`
*   **Retrieve a file link:** `GET /v1/file_links/:id`
*   **List all file links:** `GET /v1/file_links`

### File Link Object Attributes

The File Link object has the following attributes:

| Attribute   | Type         | Description                                                                                             |
| :---------- | :----------- | :------------------------------------------------------------------------------------------------------ |
| `id`        | `string`     | Unique identifier for the object.                                                                       |
| `expires_at`| `timestamp`  | Time that the link expires. Can be `null` if the link does not expire.                                |
| `file`      | `string`     | Expandable. The ID of the File object this link points to.                                              |
| `metadata`  | `object`     | Set of key-value pairs that you can attach to an object. This can be useful for storing additional information about the object in a structured format. |
| `url`       | `string`     | The publicly accessible URL to download the file. Can be `null` if the link is expired or invalid.      |
| `created`   | `timestamp`  | Time that the object was created.                                                                       |
| `expired`   | `boolean`    | Whether the link has expired.                                                                           |
| `livemode`  | `boolean`    | Whether the object exists in live mode.                                                                 |

### Example File Link Object

```json
{
  "id": "link_1Mr23jLkdIwHu7ix65betcoo",
  "object": "file_link",
  "created": 1680108075,
  "expired": false,
  "expires_at": null,
  "file": "file_1Mr23iLkdIwHu7ixQkCV3CBR",
  "livemode": false,
  "metadata": {},
  "url": "https://files.stripe.com/links/MDB8YWNjdF8xTTJKVGtMa2RJd0h1N2l4fGZsX3Rlc3RfaXVoY2hrUnJPMzlBR3dPb01XMmFkSTVq00yUPLFf3h"
}
```
## File Management in Stripe

This section details how to manage files within your Stripe account, covering uploading, creating shareable links, and retrieving file information.

### Uploading Files

The Stripe API allows you to securely upload files for various purposes, such as dispute evidence, identification documents, and business assets.

*   **File Upload Guide**: Provides a comprehensive walkthrough of the file upload process using the File Upload API. It explains how to send `multipart/form-data` requests to `https://files.stripe.com/v1/files`, specifying a `purpose` and the `file` itself. Examples are provided for `curl`, Android SDK, and other languages.
*   **Create a file**: This API endpoint (`POST /v1/files`) enables you to upload files. You must provide the `file` object and its `purpose`. Supported purposes include `dispute_evidence`, `business_icon`, `customer_signature`, and many others, each with specific requirements. Optionally, you can include `file_link_data` to automatically create a file link upon upload.

### Managing File Links

File Links allow you to share the contents of uploaded files with non-Stripe users via a secure, unauthenticated URL.

*   **File Links Overview**: Introduces the concept of File Links and their utility in sharing file contents without requiring authentication.
*   **Create a file link**: Use the `POST /v1/file_links` endpoint to generate a new file link. You must provide the `file` ID. Optionally, you can set an `expires_at` timestamp and attach `metadata`.
*   **Update a file link**: The `POST /v1/file_links/:id` endpoint allows you to modify an existing file link. You can update the `expires_at` timestamp or `metadata`. Note that expired links cannot be updated.
*   **Retrieve a file link**: Use `GET /v1/file_links/:id` to fetch details of a specific file link.
*   **List all file links**: The `GET /v1/file_links` endpoint retrieves a list of all file links associated with your account. You can filter this list by `created` date, `expired` status, `file` ID, and use `limit`, `starting_after`, and `ending_before` for pagination.
*   **The File Link object**: Describes the attributes of a File Link object, including its `id`, `expires_at`, `file` (expandable), `metadata`, and `url`.

### File Object Details

The File object represents files hosted on Stripe's servers.

*   **The File object**: Details the attributes of a File object, such as its `id`, `purpose`, `type`, `created` timestamp, `expires_at`, `filename`, `size`, `title`, and `url`. It also includes a `links` object that can contain a list of associated file links.
*   **Retrieve a file**: Use `GET /v1/files/:id` to retrieve the details of a specific file.
*   **List all files**: The `GET /v1/files` endpoint returns a list of files accessible to your account, sorted by creation date. You can filter this list by `purpose` and use pagination parameters.
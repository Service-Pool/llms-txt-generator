This documentation set focuses on Stripe's reporting and data querying capabilities, primarily through **Stripe Sigma** and the **Reports API**. It guides users on how to access, analyze, and reconcile their financial data within Stripe.

The core functionalities covered include:

*   **Accessing Financial Reports:** Details on various report types like Balance, Fees, and Payout Reconciliation, available through the Dashboard and API.
*   **Querying Data with Sigma:** Instructions on using Stripe Sigma, an interactive SQL environment, to write custom queries, analyze transactional data, and create tailored financial reports. This includes information on data freshness, schema, and querying across multiple accounts within an organization.
*   **Utilizing the Reports API:** Guidance on programmatically accessing financial reports, automating reconciliation workflows, and understanding report parameters and schemas.
*   **Specific Data Types:** Sections dedicated to querying specific data categories such as transactional data, fees data, billing data, disputes and fraud data, connected account data, and card issuing data.
*   **Advanced Data Management:** Information on Data Pipeline for syncing Stripe data to external data warehouses and the Stripe Database for direct SQL access to Stripe data.
*   **Metadata for Customization:** How to use metadata to add custom columns to financial reports for more granular analysis.
*   **Authentication Conversion Queries:** A specific example of querying authentication conversion data using Stripe Sigma.

This documentation is essential for users who need to perform in-depth financial analysis, automate reporting processes, and gain deeper insights into their Stripe account activity.
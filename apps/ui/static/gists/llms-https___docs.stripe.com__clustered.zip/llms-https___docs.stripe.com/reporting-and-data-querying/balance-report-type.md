This documentation group focuses on Stripe's reporting and data querying capabilities, primarily through **Stripe Sigma** and the **Reports API**. It provides users with the tools and information needed to extract, analyze, and reconcile their financial data within Stripe.

Here's a breakdown of the key themes and functionalities covered:

*   **Data Access and Querying:**
    *   **Stripe Sigma:** A core offering that provides an interactive SQL environment within the Stripe Dashboard for querying transactional data. Users can create custom reports, use pre-configured templates, and track key metrics. Sigma makes most transaction data available within hours. (Pages 14, 15, 16, 24, 25, 26, 27, 28, 29, 30)
    *   **Reports API:** Enables programmatic access to Stripe's financial reports, allowing for automation of reconciliation workflows and integration into other systems. (Pages 4, 9, 10, 11, 12)
    *   **Stripe Database:** A Stripe-hosted, read-only PostgreSQL database offering direct SQL access to current Stripe data with sub-second latency. (Page 31)
    *   **Querying Specific Data Types:** Dedicated pages explain how to query transactional data, fees data, billing data, disputes and fraud data, connected account data, and card issuing data. (Pages 17, 18, 19, 20, 21, 22)

*   **Reporting and Reconciliation:**
    *   **General Reporting:** Overviews of how to generate financial reports and perform reconciliation using Stripe. (Page 2)
    *   **Specific Report Types:** Detailed explanations of various report types, including:
        *   **Fees Report:** Lists all fees charged by Stripe, networks, and external partners. (Pages 3, 9)
        *   **Balance Report:** Provides a complete transaction history for reconciliation. (Pages 10)
        *   **Payout Reconciliation Report:** Returns data related to payouts to help match them with transactions. (Page 12)
        *   **Connect Report:** For platforms to retrieve financial reports for their connected accounts. (Page 11)
        *   **Revenue Recognition Reports:** Prebuilt templates in Sigma for analyzing revenue, deferred revenue, and billings. (Page 13)
    *   **Balance Transactions:** Explains the different types of balance transactions that represent funds moving through a Stripe account, serving as a recommended starting point for reporting. (Page 5)

*   **Advanced Data Management:**
    *   **Metadata:** How to use metadata to add custom information to Stripe objects and retrieve it in reports. (Page 6)
    *   **Multiple Accounts:** How to access consolidated reports for multiple accounts within an organization. (Page 7)
    *   **Data Freshness:** Information on how Sigma handles data freshness and when data becomes available for querying. (Page 15)
    *   **Data Schema:** An overview of the organizational structure of Stripe data. (Page 23)
    *   **Querying Authentication Conversion:** Specific guidance on using Stripe Sigma to analyze authentication conversion rates and SCA exemptions. (Page 1)

This collection of pages empowers users to gain deep insights into their financial operations, automate reporting processes, and ensure accurate reconciliation by leveraging Stripe's robust data querying and reporting tools.
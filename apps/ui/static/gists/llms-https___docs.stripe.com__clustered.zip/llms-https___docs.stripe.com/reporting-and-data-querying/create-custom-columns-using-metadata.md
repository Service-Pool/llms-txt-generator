## Reporting and Data Querying with Stripe

This section provides comprehensive documentation on how to leverage Stripe's reporting and data querying capabilities to gain insights into your business operations and financial data. It covers various tools and methods for accessing, analyzing, and exporting your Stripe data, including Stripe Sigma, the Reports API, and direct database access.

### Key Concepts and Tools

*   **Stripe Sigma:** An interactive SQL environment within the Stripe Dashboard that allows you to query your transactional data. You can create custom financial reports, build reports from templates, and track key metrics. Sigma offers a free sandbox environment for exploration.
*   **Reports API:** Enables programmatic access to Stripe's financial reports, allowing you to automate reconciliation workflows and schedule report generation. Various report types are available, including Balance, Payout Reconciliation, Fees, Tax, and Connect reports.
*   **Balance Transactions:** The recommended starting point for reporting on your account's balance activity. These represent every type of transaction that affects your Stripe account's balance and can be queried via API or Sigma.
*   **Metadata:** Allows you to attach custom key-value pairs to Stripe objects and transactions, enabling filtering, retrieval of specific information, and the creation of targeted reports.
*   **Stripe Data Pipeline:** Facilitates syncing Stripe data to your data warehouse or cloud storage destinations like Snowflake, Amazon Redshift, Databricks, Amazon S3, Google Cloud Storage, or Azure Blob Storage.
*   **Stripe Database:** A Stripe-hosted, read-only PostgreSQL database that provides direct SQL access to your current Stripe data with sub-second latency.
*   **Organizations:** A feature that allows you to manage multiple Stripe accounts under a single organization, enabling consolidated reporting and querying across all associated accounts.

### Accessing and Querying Your Data

*   **Querying Transactional Data:** Understand how to query core transactional data, including charges, refunds, and transfers, using the `balance_transactions` table as a starting point.
*   **Querying Fees Data:** Retrieve detailed information about transaction and product fees charged by Stripe and external networks using the `itemized_fees` table.
*   **Querying Billing Data:** Access billing-specific data through tables like `subscriptions` and `invoices`, and related components like prices, products, and customers.
*   **Querying Disputes and Fraud Data:** Analyze dispute information using the `disputes` table and identify fraudulent payments with the help of Radar.
*   **Querying Connected Account Data:** For Connect platforms, retrieve information about connected accounts using the `connected_accounts` table and Connect-specific schema sections.
*   **Querying Card Issuing Data:** Access data related to Issuing objects such as Authorizations, Transactions, Cards, and Cardholders within the Issuing schema.
*   **Querying Authentication Conversion:** Use the `authentication_report_attempts` table in Stripe Sigma to retrieve information about authentication attempts, conversion rates, and SCA exemptions.

### Reporting and Reconciliation

*   **Reporting and Reconciliation Overview:** Learn how to use Stripe to generate financial reports and perform reconciliation, including utilizing automatic payouts for better transaction-payout association.
*   **Fees Report:** Access a list of all fees deducted from your Stripe balance, including fees charged by Stripe, networks, and external partners. This report can be viewed as a summary or itemized at the transaction level.
*   **Balance Report:** Retrieve your complete transaction history to aid in reconciliation. This report provides detailed balance change information from various activities.
*   **Payout Reconciliation Report:** Obtain data related to payouts received in your bank account to match them with the transactions they represent.
*   **Connect Report:** Retrieve financial reports for your connected accounts using the API, allowing platforms to view activity in their platform account or connected accounts.
*   **Revenue Recognition Reports:** Utilize prebuilt report templates in Sigma for Revenue Recognition, covering period summaries, income statements, balance sheets, and more.

### Advanced Data Management

*   **Creating Custom Columns with Metadata:** Learn how to add custom columns to Financial Reports by leveraging metadata, allowing you to store and retrieve supplementary information alongside your core transaction data.
*   **Reports for Multiple Accounts:** Access consolidated reports for multiple accounts within your organization, enabling a unified view of your financial data.
*   **Running SQL Queries via API:** Programmatically execute SQL queries against your Stripe data using the QueryRun endpoints of the v2 Reports API, enabling automation and integration into your systems.
*   **Data Freshness:** Understand how Sigma handles data freshness, with most transaction data becoming available within a few hours.
*   **Migrating Queries:** Adapt your Sigma queries to Trino v414, the upgraded query infrastructure, by addressing potential issues with time zones, column references, and scientific notation.
*   **Scheduling Queries:** Automate your Sigma queries to run on a recurring basis (daily, weekly, or monthly) and receive results via email or webhook events.
*   **Using the Sigma API:** Execute Sigma queries programmatically beyond the Dashboard editor for advanced use cases like rendering data in Jupyter notebooks or scheduled data extraction.
*   **Querying Data Across an Organization:** Utilize Sigma with Organizations to run queries that span multiple accounts, providing insights into customers and payments across your entire business.
*   **Writing Queries:** Compose custom queries in standard ANSI SQL using the Sigma query editor, with assistance from a query assistant and access to saved queries, templates, and the table schema.
## Reporting and Data Analysis with Stripe Sigma

This documentation group focuses on leveraging Stripe's reporting and data analysis tools, primarily **Stripe Sigma**, to gain insights into your financial data, transaction patterns, and business performance. It covers how to access, query, and utilize various data sets, including transactional data, fees, billing information, and connected account activity.

### Key Areas Covered:

*   **Accessing and Querying Data:**
    *   **Stripe Sigma:** An interactive SQL environment within the Stripe Dashboard for custom reporting and analysis. Learn how to write SQL queries, use templates, and leverage the query assistant. (Pages: 14, 16, 24, 25, 30)
    *   **Reports API:** Programmatically access Stripe's financial reports for automated reconciliation and data integration. (Pages: 4, 9, 10, 11, 12)
    *   **Stripe Database:** A Stripe-hosted PostgreSQL database offering direct SQL access to your Stripe data with low latency. (Page: 31)
    *   **Data Pipeline:** Sync Stripe data to your data warehouse or cloud storage for advanced analytics. (Pages: 14, 16)

*   **Understanding Data Types and Reports:**
    *   **Balance Transaction Types:** Learn about the different types of transactions that affect your Stripe account balance and how to use them for reporting. (Page: 5)
    *   **Fees Report:** Understand and query transaction and product fees charged by Stripe and external networks. (Pages: 3, 9, 17)
    *   **Balance Report:** Access your complete transaction history for reconciliation purposes. (Page: 10)
    *   **Payout Reconciliation Report:** Retrieve data related to payouts to match them with their corresponding transactions. (Page: 12)
    *   **Connect Reports:** Generate financial reports for your connected accounts as a platform. (Page: 11)
    *   **Disputes and Fraud Data:** Query data related to disputes and identify potential fraudulent payments. (Page: 20)
    *   **Billing Data:** Access information about subscriptions, invoices, prices, and products. (Page: 18)
    *   **Card Issuing Data:** Retrieve information about authorizations, transactions, cards, and cardholders for Stripe Issuing. (Page: 21)
    *   **Revenue Recognition Reports:** Utilize prebuilt templates or build custom queries for revenue recognition analysis. (Page: 13)

*   **Advanced Reporting Features:**
    *   **Metadata:** Add custom information to Stripe objects and use it for filtering and creating targeted reports. (Page: 6)
    *   **Reports for Multiple Accounts:** Access consolidated reports for organizations with multiple Stripe accounts. (Page: 7)
    *   **Querying Authentication Conversion:** Use Stripe Sigma to analyze authentication success rates and SCA exemptions. (Page: 1)
    *   **Data Freshness:** Understand how and when your data becomes available for querying in Sigma. (Page: 15)
    *   **Scheduling Queries:** Automate your Sigma queries to run on a recurring basis and receive results via email or webhooks. (Page: 27)
    *   **Migrating Queries:** Adapt your Sigma queries to the Trino query engine. (Page: 26)
    *   **Sigma API:** Execute Sigma queries programmatically for advanced integration and automation. (Page: 28)

This collection of pages provides a comprehensive guide for users looking to extract, analyze, and report on their Stripe data effectively, enabling better financial management and business decision-making.
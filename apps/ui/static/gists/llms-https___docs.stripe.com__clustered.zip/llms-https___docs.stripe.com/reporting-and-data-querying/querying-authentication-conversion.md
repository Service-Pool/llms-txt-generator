## Reporting and Data Analysis with Stripe Sigma

This documentation group focuses on leveraging Stripe Sigma and related reporting tools to analyze your Stripe data. It covers querying transactional data, understanding various report types, and utilizing Sigma for custom reporting and data extraction.

### Key Areas:

*   **Querying and Data Analysis:** Learn how to write SQL queries using Stripe Sigma to extract insights from your transactional data, including payments, refunds, disputes, and fees. Understand data freshness and the Stripe data schema.
*   **Reporting Tools:** Explore the different types of financial reports available through Stripe, such as balance reports, fees reports, and payout reconciliation reports. Discover how to access these reports programmatically via the Reports API or through the Dashboard.
*   **Advanced Data Features:** Delve into more advanced features like using metadata for custom reporting, querying data across multiple accounts within an organization, and leveraging the Sigma API for programmatic data access.
*   **Data Integration:** Understand how to sync Stripe data to external data warehouses or cloud storage using Data Pipeline and how to import external data into Stripe.

### Relevant Pages:

*   **/payment-authentication/writing-queries**: Querying authentication conversion data.
*   **/plan-integration/get-started/reporting-reconciliation**: General overview of reporting and reconciliation with Stripe.
*   **/reports/all-fees**: Details on the Fees report.
*   **/reports/api**: How the Reports API works for programmatic access to financial reports.
*   **/reports/balance-transaction-types**: Understanding different types of balance transactions for reporting.
*   **/reports/metadata**: Creating custom columns in financial reports using metadata.
*   **/reports/multiple-accounts**: Generating consolidated reports for multiple Stripe accounts.
*   **/reports/query-runs**: Running SQL queries programmatically via the v2 Reports API.
*   **/reports/report-types/fees**: Specifics on the Fees report type schema and parameters.
*   **/reports/report-types/balance**: Details on the Balance report type schema and parameters.
*   **/reports/report-types/connect**: Understanding Connect report types for platform accounts.
*   **/reports/report-types/payout-reconciliation**: Details on the Payout reconciliation report type.
*   **/revenue-recognition/reports/sigma-and-sdp**: Using Sigma for Revenue Recognition reports.
*   **/stripe-data**: General overview of Stripe data and its uses.
*   **/stripe-data/data-freshness**: Information on data freshness in Sigma.
*   **/stripe-data/query-data**: General guide to querying business data with Sigma and Data Pipeline.
*   **/stripe-data/schema**: Overview of the Stripe data schema.
*   **/stripe-data/how-sigma-works**: Explanation of how Stripe Sigma functions.
*   **/stripe-data/sigma**: Introduction to Stripe Sigma for custom reporting.
*   **/stripe-data/migrate-queries**: Migrating Sigma queries between different infrastructure versions.
*   **/stripe-data/schedule-queries**: Scheduling Sigma queries for recurring execution.
*   **/stripe-data/sigma-api**: Using the Sigma API for programmatic query execution.
*   **/stripe-data/sigma-organizations**: Querying data across multiple accounts within an organization using Sigma.
*   **/stripe-data/write-queries**: How to write custom SQL queries in Sigma.
*   **/stripe-data/stripe-database**: Connecting to a Stripe-hosted PostgreSQL database for direct data access.
*   **/stripe-data/query-all-fees-data**: Retrieving detailed information about transaction and product fees.
*   **/stripe-data/query-billing-data**: Querying billing-related data, including subscriptions and invoices.
*   **/stripe-data/query-connect-data**: Retrieving information about connected accounts.
*   **/stripe-data/query-disputes-and-fraud-data**: Querying disputes and fraud-related data.
*   **/stripe-data/query-issuing-data**: Retrieving card issuing data.
*   **/stripe-data/query-transactions**: Querying transactional data like charges, refunds, and transfers.
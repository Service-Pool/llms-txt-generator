## Reporting and Data Querying

This section provides comprehensive documentation on how to access, query, and report on your Stripe data. It covers various tools and methods for understanding your financial activity, including Stripe Sigma, the Reports API, and direct database access.

### Stripe Sigma: Custom Reporting and Analysis

Stripe Sigma is an interactive SQL environment that allows you to query your transactional data directly within the Stripe Dashboard. It's ideal for creating custom financial reports, building reports from pre-configured templates, and tracking key business metrics.

*   **How Sigma Works**: Understand the core functionalities and benefits of Sigma for data analysis.
*   **Writing Queries**: Learn how to compose custom queries using standard ANSI SQL and leverage the query editor's features.
*   **Querying Data Across an Organization**: If you use Stripe Organizations, discover how to run queries across multiple accounts to gain a consolidated view of your business.
*   **Using the Sigma API**: Explore how to execute Sigma queries programmatically for advanced automation and integration use cases.
*   **Scheduling Queries**: Automate your Sigma queries to run on a recurring basis (daily, weekly, or monthly) and receive results via email or webhooks.
*   **Migrating Queries**: Get guidance on adapting your existing Sigma queries to the Trino query engine.

### Stripe Database: Direct SQL Access

Stripe Database offers a Stripe-hosted, read-only PostgreSQL database, providing direct SQL access to your current Stripe data with sub-second latency. This is a powerful option for running analytics or building applications directly on top of your Stripe data.

*   **Stripe Database**: Learn how to connect to the database using standard PostgreSQL clients and understand its data availability and API versioning.

### Reports API: Programmatic Access to Financial Reports

The Reports API allows you to programmatically access Stripe's financial reports, automating your reconciliation workflow. You can schedule reports to run automatically or trigger them on demand.

*   **How the Reports API Works**: Understand the general principles of using the Reports API to access financial data.
*   **Report Types**:
    *   **Balance Report Type**: Retrieve your complete transaction history for reconciliation.
    *   **Fees Report Type**: Access detailed information about transaction and product fees charged by Stripe and other networks.
    *   **Payout Reconciliation Report Type**: Obtain data related to payouts to match them with their corresponding transactions.
    *   **Connect Report Type**: For Connect platforms, retrieve financial reports for your connected accounts.

### Querying Specific Data Categories

Stripe provides dedicated documentation for querying specific types of data, enabling you to extract granular insights.

*   **Querying Transactional Data**: Access data related to charges, refunds, transfers, and other core transaction activities.
*   **Querying Fees Data**: Retrieve detailed breakdowns of all fees charged to your Stripe balance.
*   **Querying Billing Data**: Explore data related to subscriptions, invoices, prices, products, and customers.
*   **Querying Disputes and Fraud Data**: Analyze information about disputes and identify potential fraudulent payments.
*   **Querying Connected Account Data**: For Connect platforms, retrieve information about your connected accounts.
*   **Querying Card Issuing Data**: Access data related to authorizations, transactions, cards, and cardholders for Stripe Issuing.

### Data Management and Organization

*   **Stripe Data**: Get an overview of how to use Stripe data to gauge business performance, including options for Sigma, Data Pipeline, and importing external data.
*   **Data Freshness**: Understand how quickly your data becomes available for querying in Sigma.
*   **Stripe Data Schema**: Browse the organizational structure of Stripe data to help you write effective queries.
*   **Metadata**: Learn how to add custom columns to Financial Reports using metadata for enhanced reporting and filtering.
*   **Reports for Multiple Accounts**: Access consolidated reports for multiple accounts within your organization.
*   **Balance Transaction Types**: Understand the different types of balance transactions that represent funds moving through your Stripe account, crucial for reporting.
*   **Querying Authentication Conversion**: Use Stripe Sigma to retrieve information about authentication, conversion, and SCA exemptions.
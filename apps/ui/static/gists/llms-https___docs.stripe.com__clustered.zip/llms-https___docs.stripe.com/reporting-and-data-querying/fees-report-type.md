## Reporting and Data Analysis

This section outlines how to access and utilize your Stripe data for reporting and analysis. Stripe provides various tools and methods to gain insights into your financial activity, including transaction details, fees, payouts, and customer behavior.

### Key Tools and Concepts:

*   **Stripe Sigma:** A powerful tool that offers an interactive SQL environment within the Stripe Dashboard. It allows you to query your transactional data, create custom financial reports, build reports from pre-configured templates, and track key metrics. Sigma provides read-only access to data on payments, subscriptions, customers, payouts, and more.
    *   **Writing Queries:** You can compose custom queries using standard ANSI SQL in the Sigma query editor. A query assistant can help generate SQL from natural language prompts. Resources like saved queries, team queries, table schemas, and templates are available to aid in query building.
    *   **Scheduling Queries:** Automate your Sigma queries to run on a recurring basis (daily, weekly, or monthly). Results can be emailed to team members or sent as webhook events.
    *   **Querying Across Organizations:** If you use Stripe Organizations, you can leverage Sigma to run queries across multiple accounts, providing insights into your customers and payments throughout your entire business.
    *   **Sigma API:** Enables programmatic execution of Sigma queries, allowing for integration with external tools, scheduled data retrieval, and data extraction/transformation.
    *   **Data Freshness:** Most transaction data in Sigma is available to query within three hours of occurring.
*   **Reports API:** Access Stripe's financial reports programmatically to automate your reconciliation workflow. This API provides access to various report types, including Balance, Payout Reconciliation, Fees, Tax, and Connect reports, allowing you to schedule them or run them on demand.
*   **Balance Transactions:** These are the recommended starting point for reporting on your account's balance activity. They represent every type of transaction that affects your Stripe account balance and can be accessed via the API or Sigma.
*   **Data Pipeline:** Sync your Stripe data to your data warehouse or cloud storage destinations (e.g., Snowflake, Amazon Redshift, Google Cloud Storage).
*   **Stripe Database:** A Stripe-hosted, read-only PostgreSQL database that provides direct SQL access to your current Stripe data with sub-second latency. You can connect using any standard PostgreSQL client and query data for analytics or build applications directly on top of it.
*   **Metadata:** Allows you to attach custom information (key-value pairs) to Stripe objects and transactions. This metadata can be used to filter and retrieve specific information from Stripe reports, facilitating targeted reporting and advanced querying in Sigma.

### Report Types:

Stripe offers several pre-built report types accessible through the Dashboard, API, or Sigma:

*   **Balance Report:** Provides your complete transaction history for reconciliation purposes.
*   **Fees Report:** Details all fees charged by Stripe, networks, and external partners, offering both summary and itemized views at the transaction level.
*   **Payout Reconciliation Report:** Returns data related to payouts to help you match them with the transactions they relate to.
*   **Connect Report:** For Connect platforms, this allows viewing activity in the platform account or connected accounts.
*   **Tax Report:** Provides information related to Stripe Tax.
*   **Revenue Recognition Reports:** Prebuilt report templates in Sigma for analyzing revenue, deferred revenue, and billing activity.

### Querying Specific Data:

*   **Query Transactional Data:** Access data on charges, refunds, transfers, and other financial activities. The `balance_transactions` table is a key resource for this.
*   **Query Fees Data:** Use the `itemized_fees` table in Sigma for a granular breakdown of all fees.
*   **Query Billing Data:** Explore data related to subscriptions, invoices, prices, products, and customers.
*   **Query Disputes and Fraud Data:** Analyze disputes and fraud information using the `disputes` table and potentially the `radar_rules` and `rule_decisions` tables if using Radar for Fraud Teams.
*   **Query Connected Account Data:** For Connect platforms, retrieve information about connected accounts using tables like `connected_accounts`.
*   **Query Card Issuing Data:** Access data on Authorizations, Transactions, Cards, and Cardholders related to Stripe Issuing.

This comprehensive suite of tools and data access methods empowers you to deeply understand your financial operations and make data-driven decisions.
## Stripe Reporting and Data Querying

This section of the Stripe documentation provides comprehensive resources for understanding and utilizing your Stripe data. It covers various methods for generating financial reports, querying transactional data, and integrating Stripe data into your own systems.

**Key Areas Covered:**

*   **Reporting and Reconciliation:** Learn how to use Stripe's built-in reporting features and APIs to generate financial reports and reconcile your accounts. This includes understanding payout types, balance transactions, and advanced reporting capabilities within Stripe Sigma.
*   **Fees Reporting:** Access detailed reports on all fees charged by Stripe, networks, and external partners. This includes both summary and itemized transaction-level fee data.
*   **Balance Transactions:** Understand the different types of balance transactions that represent funds moving through your Stripe account. These are recommended as a starting point for reporting on account balance activity.
*   **Data Querying with Sigma:** Explore Stripe Sigma, an interactive SQL environment that allows you to create custom financial reports by querying your transactional data. This section covers writing SQL queries, using templates, scheduling queries, and querying data across multiple accounts within an organization.
*   **Stripe Data Pipeline:** Learn how to sync Stripe data to your data warehouse or cloud storage destinations like Snowflake, Amazon Redshift, or Google Cloud Storage.
*   **Stripe Database:** Discover how to connect to a Stripe-hosted PostgreSQL database for direct SQL access to your Stripe data with sub-second latency.
*   **Specific Data Querying:** Detailed guides are available for querying specific types of data, including:
    *   Transactional data (charges, refunds, transfers, etc.)
    *   Disputes and fraud data
    *   Fees data
    *   Billing data (subscriptions, invoices, etc.)
    *   Connected account data
    *   Card issuing data
*   **API Access to Reports:** Understand how to access Stripe's financial reports programmatically using the Reports API, enabling automation of your reconciliation workflow.
*   **Metadata for Customization:** Learn how to use metadata to add custom columns to your financial reports, allowing for more tailored data analysis and retrieval.
*   **Authentication Conversion Queries:** Discover how to use Stripe Sigma to query data related to authentication conversion and the Strong Customer Authentication (SCA) exemptions used.

This documentation suite empowers users to gain deep insights into their financial operations, automate reporting processes, and integrate Stripe data seamlessly into their business intelligence tools.
## Stripe Apps for E-commerce Platforms

This documentation section provides guidance on integrating Stripe payment and tax solutions with various e-commerce platforms. It covers installation, configuration, and advanced usage for each platform.

### Adobe Commerce

Stripe offers plugins for Adobe Commerce (Magento Open Source) to facilitate payments, billing, and tax calculations.

*   **Stripe Payments, Billing, and Tax Plugin:** This plugin allows you to accept a wide range of payment methods and automate tax calculation and reporting.
    *   [Install and configure the Stripe Plugin for Adobe Commerce](/use-stripe-apps/adobe-commerce/payments/configuration)
    *   [Build a custom storefront with Stripe features](/use-stripe-apps/adobe-commerce/payments/custom-storefront)
    *   [Use the Stripe app for Adobe Commerce (Magento 2)](/use-stripe-apps/adobe-commerce/payments/install)
    *   [Use Stripe Billing to enable subscriptions for Adobe Commerce](/use-stripe-apps/adobe-commerce/payments/subscriptions)
    *   [Use Stripe Tax to automate tax calculation and reporting for Adobe Commerce](/use-stripe-apps/adobe-commerce/payments/tax)
    *   [Troubleshooting for Adobe Commerce](/use-stripe-apps/adobe-commerce/payments/troubleshooting)
    *   [Using the Adobe Commerce admin panel](/use-stripe-apps/adobe-commerce/payments/admin)
*   **Standalone Tax Plugin:** This plugin automates tax calculation and reporting without requiring Stripe for payment processing.
    *   [Standalone Tax Plugin for Adobe Commerce](/use-stripe-apps/adobe-commerce/standalone-tax)
*   **Adobe Commerce Plugin Cookbooks:** These cookbooks provide recipes for specific integration needs.
    *   [Adobe Commerce Plugin cookbooks](/use-stripe-apps/adobe-commerce/cookbooks)
    *   [Add additional metadata to payments](/use-stripe-apps/adobe-commerce/cookbooks/add-additional-metadata)
    *   [Add custom events to Stripe webhooks](/use-stripe-apps/adobe-commerce/cookbooks/add-custom-events)
    *   [Add external payment methods to the payment form](/use-stripe-apps/adobe-commerce/cookbooks/external-payment-methods)
    *   [Disable specific shipping methods in Express Checkout modals](/use-stripe-apps/adobe-commerce/cookbooks/disable-express-checkout-payment-methods)
    *   [Enable manual capture](/use-stripe-apps/adobe-commerce/cookbooks/enable-manual-capture)
    *   [Hide the terms displayed in the PaymentElement form](/use-stripe-apps/adobe-commerce/cookbooks/hide-terms)
    *   [Integrate a custom fee to the tax calculation](/use-stripe-apps/adobe-commerce/cookbooks/tax-additional-fees)
    *   [Style the payment form at the checkout](/use-stripe-apps/adobe-commerce/cookbooks/style-payment-element)
    *   [Test why a specific payment method doesn't appear](/use-stripe-apps/adobe-commerce/cookbooks/test-specific-method)

### BigCommerce

Stripe Tax can be integrated with BigCommerce to automate sales tax, VAT, and GST calculations.

*   [Stripe Tax for BigCommerce](/use-stripe-apps/bigcommerce)
*   [Install and configure the Stripe Tax app](/use-stripe-apps/bigcommerce/configuration)

### Cegid

Stripe offers an app for Cegid POS systems to accept in-person payments using Stripe Terminal.

*   [Stripe app for Cegid](/use-stripe-apps/cegid/overview)
*   [Install the app](/use-stripe-apps/cegid/installation)
*   [Configure the app](/use-stripe-apps/cegid/configuration)
*   [Troubleshoot the app](/use-stripe-apps/cegid/troubleshooting)

### Commercetools

Stripe provides apps for Commercetools Connect to integrate Stripe Payments with your Commercetools instance.

*   [Stripe app for Commercetools Connect](/use-stripe-apps/commercetools-connect)
*   [Install the app for Composable Commerce from your merchant center](/use-stripe-apps/commercetools-connect/install-and-configure)
*   [Install and configure the Stripe Payment app for Commercetools Checkout](/use-stripe-apps/commercetools-connect/install-and-configure-checkout)
*   [Use Stripe Billing to enable subscriptions for Commercetools](/use-stripe-apps/commercetools-connect/use-subscriptions)

### Guidewire

Stripe Accelerator apps integrate Stripe into Guidewire BillingCenter and ClaimCenter products for payment processing.

*   [Stripe Accelerator apps for Guidewire Insurance platform](/use-stripe-apps/guidewire)

### Mirakl

The Stripe app for Mirakl enables Stripe payments and payouts for Mirakl-built marketplaces.

*   [Stripe app for Mirakl](/use-stripe-apps/mirakl)
*   [Install the Mirakl app](/use-stripe-apps/mirakl/install)
*   [Configure the Mirakl app](/use-stripe-apps/mirakl/configuration)
*   [Onboard sellers](/use-stripe-apps/mirakl/onboarding-sellers)
*   [Payments and payouts using the Mirakl app](/use-stripe-apps/mirakl/payments)
*   [Mirakl reference](/use-stripe-apps/mirakl/reference)

### NetSuite

The Stripe Connector for NetSuite automates accounting workflows and reconciles Stripe activity into NetSuite.

*   [Stripe Connector for NetSuite](/use-stripe-apps/netsuite/overview)
*   [Prepare for onboarding](/use-stripe-apps/netsuite/onboarding)
*   [Configure taxes with Stripe and NetSuite](/use-stripe-apps/netsuite/configure-taxes)
*   [Stripe credit notes and NetSuite credit memos](/use-stripe-apps/netsuite/credit-notes-credit-memos)
*   [Custom payment application](/use-stripe-apps/netsuite/custom-payment-application)
*   [NetSuite customer payment page](/use-stripe-apps/netsuite/customer-payment-page)
*   [Deposit automation](/use-stripe-apps/netsuite/deposit-automation)
*   [Troubleshoot the connector](/use-stripe-apps/netsuite/error-resolution)
*   [Field mappings](/use-stripe-apps/netsuite/field-mappings)
*   [Stripe and NetSuite fields and references](/use-stripe-apps/netsuite/fields-references)
*   [Stripe Billing and Invoicing automation](/use-stripe-apps/netsuite/invoice-automation)
*   [Install the NetSuite connector invoice payment link](/use-stripe-apps/netsuite/invoice-payment-link/installation)
*   [NetSuite invoice payment link](/use-stripe-apps/netsuite/invoice-payment-link/overview)
*   [Set up payment method rules](/use-stripe-apps/netsuite/invoice-payment-link/payment-method-rules)
*   [NetSuite invoice payment page](/use-stripe-apps/netsuite/invoice-payment-page)
*   [Migrate from SuiteSync to the Stripe Connector for NetSuite](/use-stripe-apps/netsuite/migration/get-started)
*   [Migrate the SuiteSync NetSuite Auto Pay workflow](/use-stripe-apps/netsuite/migration/auto-pay-instructions)
*   [Configure your Stripe Connector for NetSuite App](/use-stripe-apps/netsuite/migration/configure-app)
*   [Migrate the legacy SuiteSync Customer Portal Link](/use-stripe-apps/netsuite/migration/customer-payment-page)
*   [Migrate the SuiteSync NetSuite-Initiated Refunds workflow](/use-stripe-apps/netsuite/migration/netsuite-initiated-refunds)
*   [Migrate the SuiteSync Paid Out of Band workflow](/use-stripe-apps/netsuite/migration/paid-out-of-band)
*   [Migrate the SuiteSync eCommerce and third-party billing workflows](/use-stripe-apps/netsuite/migration/payment-linker-instructions)
*   [Multiple currencies with Stripe and NetSuite](/use-stripe-apps/netsuite/multiple-currencies)
*   [Multiple NetSuite subsidiaries](/use-stripe-apps/netsuite/multiple-subsidiaries)
*   [Revenue recognition](/use-stripe-apps/netsuite/revenue-recognition)
*   [Stripe charges in NetSuite](/use-stripe-apps/netsuite/stripe-charges-netsuite)
*   [Stripe Connect in NetSuite](/use-stripe-apps/netsuite/stripe-connect-netsuite)
*   [Install and configure the Stripe Connector Add-ons bundle](/use-stripe-apps/netsuite/migration/stripe-connector-add-ons)
*   [Stripe customers and customer balances in NetSuite](/use-stripe-apps/netsuite/stripe-customers-netsuite)
*   [Stripe disputes in NetSuite](/use-stripe-apps/netsuite/stripe-disputes-netsuite)
*   [Stripe invoices in NetSuite](/use-stripe-apps/netsuite/stripe-invoices-netsuite)
*   [Stripe payouts in NetSuite](/use-stripe-apps/netsuite/stripe-payouts-netsuite)
*   [Stripe prices and coupons in NetSuite](/use-stripe-apps/netsuite/stripe-prices-coupons-netsuite)
*   [Stripe refunds in NetSuite](/use-stripe-apps/netsuite/stripe-refunds-netsuite)
*   [Sync Stripe data to NetSuite](/use-stripe-apps/netsuite/sync-data)

### Oracle

Stripe offers apps for Oracle Opera, Simphony, and Xstore to integrate Stripe Terminal for in-person payments.

*   **Oracle Opera:**
    *   [Stripe app for Oracle Opera](/use-stripe-apps/oracle/opera/overview)
    *   [Install the app](/use-stripe-apps/oracle/opera/installation)
    *   [Configure the app](/use-stripe-apps/oracle/opera/configuration)
    *   [Troubleshoot your installation](/use-stripe-apps/oracle/opera/troubleshooting)
    *   [Access the app web interface](/use-stripe-apps/oracle/opera/web-interface)
*   **Oracle Simphony:**
    *   [Stripe app for Oracle Simphony](/use-stripe-apps/oracle/simphony/overview)
    *   [Install the app](/use-stripe-apps/oracle/simphony/installation)
    *   [Configure the app](/use-stripe-apps/oracle/simphony/configuration)
    *   [Access the app web interface](/use-stripe-apps/oracle/simphony/web-interface)
*   **Oracle Xstore:**
    *   [Stripe app for Oracle Xstore](/use-stripe-apps/oracle/xstore/overview)
    *   [Install the app](/use-stripe-apps/oracle/xstore/installation)
    *   [Access the app web interface](/use-stripe-apps/oracle/xstore/web-interface)

### PrestaShop

The Stripe module for PrestaShop allows integration with Stripe Elements to accept a wide range of payment methods.

*   [Stripe module for PrestaShop](/use-stripe-apps/prestashop)
*   [Install and configure the Stripe module for PrestaShop](/use-stripe-apps/prestashop/configuration)

### SAP

The Stripe Adapter for SAP Digital Payments add-on integrates Stripe payment capabilities into SAP.

*   [Stripe Adapter for SAP Digital Payments add-on](/use-stripe-apps/sap-digital-payments)

### Shopify

Stripe Subscriptions for Shopify enables recurring payments and subscription management for Shopify stores.

*   [Stripe Subscriptions for Shopify](/use-stripe-apps/shopify-subscriptions)

### Shopware 6

The Stripe app for Shopware 6 integrates Stripe Elements to accept numerous payment methods.

*   [Stripe app for Shopware 6](/use-stripe-apps/shopware6)
*   [Install and configure the Stripe app for Shopware 6](/use-stripe-apps/shopware6/configuration)
*   [Use the Shopware 6 app](/use-stripe-apps/shopware6/user-guide)

### WooCommerce

The Stripe Tax Extension for WooCommerce automates sales tax, VAT, and GST calculations.

*   [Stripe Tax Extension for WooCommerce](/use-stripe-apps/woocommerce)
*   [Install and configure the Stripe Tax Extension](/use-stripe-apps/woocommerce/configuration)
*   [Test the Stripe Tax Extension](/use-stripe-apps/woocommerce/troubleshooting)
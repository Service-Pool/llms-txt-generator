## Stripe Apps for E-commerce Platforms

This documentation section provides guidance on integrating Stripe payment solutions with various e-commerce platforms and business systems. It covers installation, configuration, customization, and troubleshooting for each platform.

### Adobe Commerce

*   **Overview:** Learn how to connect Stripe Payments, Billing, and Tax with plugins for Adobe Commerce.
*   **Installation:** Install, upgrade, and uninstall the Stripe app for Adobe Commerce (Magento 2).
*   **Configuration:** Set up payment methods and other options using the Stripe plugin for Adobe Commerce.
*   **Admin Panel Usage:** Configure the Stripe module for Adobe Commerce through the admin panel.
*   **Custom Storefronts:** Build a custom storefront that supports Stripe payment features.
*   **Payments, Billing, and Tax Plugin:** Enable Stripe payments for storefronts built on Adobe Commerce.
*   **Plugin Cookbooks:** Find integration recipes for the Stripe Adobe Commerce apps.
    *   Add additional metadata to payments.
    *   Add custom events to Stripe webhooks.
    *   Add external payment methods to the payment form.
    *   Disable specific shipping methods in Express Checkout modals.
    *   Enable manual capture.
    *   Hide the terms displayed in the PaymentElement form.
    *   Integrate a custom fee to the tax calculation.
    *   Style the payment form at the checkout.
    *   Test why a specific payment method doesn't appear.
*   **Standalone Tax Plugin:** Automate tax collection and reporting on Adobe Commerce with non-Stripe payment solutions.
*   **Troubleshooting:** Learn how to troubleshoot the Stripe Plugin for Adobe Commerce.

### BigCommerce

*   **Stripe Tax for BigCommerce:** Learn about the Stripe Tax app for BigCommerce.
*   **Installation and Configuration:** Install and configure the Stripe Tax app for BigCommerce to automatically calculate and collect sales tax, VAT, and GST.

### Cegid

*   **Overview:** Use the app to integrate Stripe Terminal into Cegid POS systems for in-person payments.
*   **Installation:** Download and install the Stripe app for Cegid.
*   **Configuration:** Configure the Stripe app for Cegid in the Cegid Y2 Back Office application.
*   **Troubleshooting:** Troubleshoot issues with the Stripe app and your Cegid integration.

### Commercetools

*   **Overview:** Integrate Stripe Payments with Commercetools using pre-built checkout apps or custom solutions.
*   **Installation and Configuration (Pre-built Checkout):** Set up your Commercetools instance to install the Stripe Payment for Checkout app.
*   **Installation and Configuration (Composable Commerce):** Install and configure the Stripe Payment Composable Connector from your Commercetools merchant center.
*   **Subscriptions:** Use Stripe Billing to enable subscriptions for Commercetools products.

### Guidewire

*   **Overview:** Use Stripe Accelerator apps to integrate Stripe into Guidewire BillingCenter and ClaimCenter products.
*   **Installation and Configuration:** Download, install, and configure the Stripe Apps for Guidewire from the Guidewire Marketplace.

### Mirakl

*   **Overview:** Use Stripe on Mirakl-built marketplaces for payment processing and payouts.
*   **Installation:** Install the Mirakl app for Stripe.
*   **Configuration:** Define integration variables for the Mirakl app.
*   **Onboarding Sellers:** Set up sellers as Stripe connected accounts using Express or Custom accounts.
*   **Payments and Payouts:** Accept payments and manage payouts using the Stripe Mirakl app.
*   **Reference:** Understand default settings for Mirakl plugin events and scheduled jobs.

### NetSuite

*   **Overview:** Use the Stripe Connector for NetSuite to reconcile Stripe activity into NetSuite and automate accounting workflows.
*   **Prepare for Onboarding:** Prepare your Stripe and NetSuite accounts for onboarding with an implementation partner.
*   **Custom Payment Application:** Customize how payments are recorded and applied using the Stripe Connector for NetSuite.
*   **Customer Payment Page:** Allow customers to make payments toward their NetSuite balance using Stripe.
*   **Deposit Automation:** Automate the bank reconciliation process by creating bank deposits in NetSuite for Stripe payouts.
*   **Charges in NetSuite:** Automatically reconcile Stripe charges and payments to NetSuite.
*   **Disputes in NetSuite:** Automatically represent Stripe disputes or chargebacks in NetSuite.
*   **Field Mappings:** Customize data synced to NetSuite records using the Stripe Connector for NetSuite.
*   **Fields and References:** Understand the correlation between Stripe and NetSuite records.
*   **Invoice Automation:** Sync Stripe invoices into NetSuite for reporting and accounting workflows.
*   **Invoice Payment Link:** Create an invoice payment link for customers to pay NetSuite invoices using Stripe Checkout.
*   **Invoice Payment Page:** Allow customers to use a Stripe payment flow to pay NetSuite invoices.
*   **Migration from SuiteSync:** Migrate your existing SuiteSync configuration to the Stripe Connector for NetSuite.
    *   Configure your Stripe Connector for NetSuite App.
    *   Install the Add-ons bundle.
    *   Migrate the NetSuite-Initiated Refunds workflow.
    *   Migrate the legacy SuiteSync Customer Portal Link.
    *   Migrate the SuiteSync Auto Pay workflow.
    *   Migrate the SuiteSync eCommerce and third-party billing workflows.
    *   Migrate the SuiteSync Paid Out of Band workflow.
*   **Multiple Currencies:** Reconcile payments in multiple currencies with the Stripe Connector for NetSuite.
*   **Multiple Subsidiaries:** Support multiple NetSuite subsidiaries with multiple Stripe accounts.
*   **Revenue Recognition:** Enable NetSuite revenue recognition calculation by syncing data from subscription invoices.
*   **Stripe Connect in NetSuite:** Reconcile Stripe Connect activity, including transfers and application fees, to NetSuite.
*   **Stripe Customers and Customer Balances:** Automatically represent Stripe customers and customer balances in NetSuite.
*   **Stripe Invoices in NetSuite:** Sync Stripe invoices to NetSuite as NetSuite invoices.
*   **Stripe Payouts in NetSuite:** Automatically reconcile Stripe payouts to NetSuite bank deposits.
*   **Stripe Prices and Coupons:** Represent Stripe prices and coupons in NetSuite as NetSuite items.
*   **Stripe Refunds in NetSuite:** Automatically reconcile Stripe refunds to NetSuite bank deposits.
*   **Sync Stripe Data to NetSuite:** Learn how the connector syncs Stripe data to NetSuite.
*   **Troubleshooting:** Troubleshoot errors with the Stripe Connector for NetSuite.

### Oracle

*   **Oracle Opera:**
    *   **Overview:** Integrate Stripe Terminal into Oracle Opera for in-person payments.
    *   **Installation:** Download and install the Stripe app for Oracle Opera.
    *   **Configuration:** Configure the Stripe app for Oracle Opera.
    *   **Web Interface:** Access the web interface for the Stripe app for Oracle Opera.
    *   **Troubleshooting:** Troubleshoot the Stripe app for Oracle Opera installation.
*   **Oracle Simphony:**
    *   **Overview:** Integrate Stripe Terminal into Oracle Simphony POS systems.
    *   **Installation:** Download and install the Stripe App for Oracle Simphony.
    *   **Configuration:** Configure the Stripe app for Oracle Simphony.
    *   **Web Interface:** Access the web interface for the Stripe App for Oracle Simphony.
*   **Oracle Xstore:**
    *   **Overview:** Integrate Stripe Terminal into Oracle Xstore POS systems.
    *   **Installation:** Download and install the Stripe App for Oracle Xstore.

### PrestaShop

*   **Overview:** Use the Stripe Module for PrestaShop to integrate Stripe Elements and accept a wide range of payment methods.
*   **Installation and Configuration:** Install and configure the PrestaShop module from the Stripe App Marketplace.

### Salesforce

*   *(No specific pages found for Salesforce integration in the provided data.)*

### Shopware 6

*   **Overview:** Use the Stripe app for Shopware 6 to integrate Stripe Elements and accept a wide range of payment methods.
*   **Installation and Configuration:** Install and configure the Stripe app for Shopware 6.
*   **User Guide:** Manage payments, handle refunds, and troubleshoot common Shopware 6 issues.

### Shopify

*   **Stripe Subscriptions for Shopify:** Install and configure the Stripe Subscriptions app to accept recurring payments in your Shopify store.
*   **Stripe Tax for Shopify:** *(No specific pages found for Stripe Tax for Shopify in the provided data, but it's listed as an available app.)*

### WooCommerce

*   **Stripe Tax Extension for WooCommerce:**
    *   **Overview:** Automatically calculate sales tax, VAT, and GST for your WooCommerce transactions.
    *   **Installation and Configuration:** Install and configure the Stripe Tax Extension for WooCommerce.
    *   **Testing:** Troubleshoot tax calculation issues and test your setup.

### SAP

*   **Stripe Adapter for SAP Digital Payments:** Integrate Stripe payment capabilities into SAP Digital Payment Add-on (DPA) for SAP S/4HANA.
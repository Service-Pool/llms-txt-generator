# Stripe Apps for Adobe Commerce

This section provides documentation and guides for integrating Stripe with Adobe Commerce. It covers various aspects of payment processing, tax calculation, and customization.

## Cookbooks

The following cookbooks offer step-by-step instructions for specific integration needs:

*   **Add additional metadata to payments**: Learn how to send additional payment metadata from Adobe Commerce to Stripe.
*   **Add custom events to Stripe webhooks**: Extend the list of supported webhook events in the Stripe module for Adobe Commerce.
*   **Add external payment methods to the payment form**: Display non-Stripe payment methods within the Stripe PaymentElement.
*   **Disable shipping methods in the Express Checkout modals**: Remove specific shipping methods from the Express Checkout modal.
*   **Enable manual capture**: Allow separate authorization and capture for eligible Stripe payment methods.
*   **Hide the terms displayed in the PaymentElement form**: Disable the terms text under the PaymentElement using a custom module.
*   **Integrate a custom fee to the tax calculation**: Add additional taxable fees to sold products.
*   **Style the payment form at the checkout**: Customize the theme or appearance of Stripe's PaymentElement.
*   **Test why a specific payment method doesn't appear**: Force a payment method to appear for testing purposes.

## Core Functionality

*   **Stripe plugins for Adobe Commerce**: Learn about the Stripe Payments, Billing, and Tax plugin, and the Standalone Tax plugin for Adobe Commerce.
*   **Using the Adobe Commerce admin panel**: Configure the Stripe module for the Adobe Commerce platform through the admin panel.
*   **Configure the Stripe Plugin for Adobe Commerce**: Set up payment methods and other options using the plugin.
*   **Build a custom storefront**: Develop a custom storefront that supports Stripe payment features.
*   **Stripe Payments, Billing, and Tax plugin for Adobe Commerce**: Enable Stripe payments for storefronts built on Adobe Commerce.
*   **Use the Stripe app for Adobe Commerce (Magento 2)**: Learn how to install, upgrade, and uninstall the Stripe app.
*   **Use Stripe Billing to enable subscriptions for Adobe Commerce**: Configure the Stripe plugin to enable subscriptions for Adobe Commerce products.
*   **Use Stripe Tax to automate tax calculation and reporting for Adobe Commerce**: Automate tax calculation and reporting with a single integration.
*   **Troubleshooting for Adobe Commerce**: Find solutions to common issues with the Stripe Plugin for Adobe Commerce.
*   **Standalone Tax Plugin for Adobe Commerce**: Automate tax calculation and reporting with non-Stripe payment solutions.
## Integrating Custom Fees with Tax Calculations in Adobe Commerce

This section provides guidance on how to integrate custom fees into your tax calculation process when using Stripe with Adobe Commerce.

### Integrate a custom fee to the tax calculation

This cookbook explains how to add additional taxable fees to sold products within Adobe Commerce when using Stripe for tax calculations.

**Key Takeaways:**

*   The Stripe Tax module for Adobe Commerce sends tax calculation requests to the Stripe Tax calculation API at the point of order, invoice, and credit memo creation.
*   To include custom fees in tax calculations, you need to provide the details of these fees to the Stripe Tax module.
*   The developer of the custom fee is responsible for providing the total value of the custom fee to the Stripe Tax module.

**How it Works:**

When a custom fee is added to a product or order, the Stripe Tax module needs to be aware of this fee to include it in the tax calculation request sent to Stripe. This typically involves modifying the module's logic to capture and pass this information.

**Steps to Integrate:**

1.  **Identify the Custom Fee:** Determine which custom fees require tax calculation.
2.  **Provide Fee Details:** Ensure that the custom fee's value is accessible and can be passed to the Stripe Tax module. This might involve custom module development or configuration within Adobe Commerce.
3.  **Stripe Tax Module Integration:** The Stripe Tax module will then incorporate this fee into its calculation request to the Stripe Tax API.

This process ensures that all applicable taxes are calculated accurately, including those on custom fees.
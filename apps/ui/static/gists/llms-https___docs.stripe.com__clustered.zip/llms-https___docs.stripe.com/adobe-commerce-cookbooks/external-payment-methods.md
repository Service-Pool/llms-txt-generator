## Integrating Stripe with E-commerce Platforms and Business Systems

This documentation group provides guidance on integrating Stripe payment processing and tax solutions with various e-commerce platforms and business systems. It covers installation, configuration, and specific use cases for each integration.

---

### Key Integration Areas:

*   **E-commerce Platforms:**
    *   **Adobe Commerce:** Detailed guides on installing, configuring, and customizing the Stripe plugin for Adobe Commerce, including managing payments, subscriptions, and tax calculations.
    *   **BigCommerce:** Instructions for installing and configuring the Stripe Tax app to automate sales tax, VAT, and GST calculations.
    *   **Commercetools:** Information on integrating Stripe Payments with Commercetools using pre-built checkout apps or custom solutions, including support for subscriptions.
    *   **PrestaShop:** Guidance on installing and configuring the Stripe module for PrestaShop, enabling a wide range of payment methods.
    *   **Shopware 6:** Instructions for installing and configuring the Stripe app for Shopware 6, supporting multiple payment methods and features.
    *   **WooCommerce:** Details on installing and configuring the Stripe Tax Extension for WooCommerce to automate tax calculations.
    *   **Shopify:** Information on using the Stripe Subscriptions app to manage recurring payments and subscriptions.

*   **Business Systems & ERPs:**
    *   **Cegid:** Guides for integrating Stripe Terminal with Cegid POS systems for in-person payments, including installation and configuration.
    *   **Guidewire:** Information on using Stripe Accelerator apps to integrate Stripe into Guidewire BillingCenter and ClaimCenter.
    *   **Mirakl:** Documentation on using the Stripe app for Mirakl-built marketplaces, covering onboarding sellers, payments, and payouts.
    *   **NetSuite:** Comprehensive guides on the Stripe Connector for NetSuite, covering data synchronization, tax configuration, invoice automation, customer management, and migration from SuiteSync.
    *   **Oracle (Opera, Simphony, Xstore):** Instructions for integrating Stripe Terminal with Oracle's POS systems (Opera, Simphony, Xstore) for in-person payments.
    *   **SAP:** Details on the Stripe Adapter for SAP Digital Payments add-on to integrate Stripe payment capabilities.

---

### Common Integration Tasks:

Across these platforms, common tasks include:

*   **Installation and Configuration:** Step-by-step guides for installing and setting up Stripe applications or modules.
*   **Payment Processing:** Enabling various payment methods, including cards, wallets, and bank redirects.
*   **Tax Automation:** Utilizing Stripe Tax for automated calculation and collection of sales tax, VAT, and GST.
*   **Subscription Management:** Implementing recurring payments and subscription plans using Stripe Billing.
*   **Data Synchronization:** Reconciling Stripe transaction data with e-commerce platforms and ERP systems (e.g., NetSuite).
*   **Customization:** Modifying payment forms, adding metadata, and customizing checkout experiences.
*   **Troubleshooting:** Resources for resolving common installation, configuration, and operational issues.

---

This documentation group aims to provide developers and merchants with the necessary information to seamlessly integrate Stripe's payment and tax solutions into their chosen platforms, enhancing payment flexibility, automating tax compliance, and streamlining financial operations.
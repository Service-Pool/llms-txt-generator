## Enable Manual Capture

This guide explains how to enable manual capture for eligible Stripe payment methods within Adobe Commerce, allowing for separate authorization and capture of funds.

### Key Concepts

*   **Manual Capture:** This feature allows you to authorize a payment at the time of purchase and then capture the funds at a later stage, typically when the order is ready to be shipped. This provides flexibility in managing your cash flow and order fulfillment process.
*   **Payment Action:** In Adobe Commerce, you can configure the "Payment Action" for eligible payment methods to "Authorize Only" to enable manual capture.

### Implementation Steps

To enable manual capture without upgrading the Stripe module, you will need to update the payment method helper file directly. This involves creating a custom module in Adobe Commerce to override the default behavior.

1.  **Create a New Module:**
    *   Establish a new module with the following directory structure:
        ```
        app/code/Vendor/StripeCustomizations/
        ├── etc/
        │   ├── module.xml
        │   └── di.xml
        ├── Plugin/
        │   └── Helper/
        │       └── PaymentMethodPlugin.php
        └── registration.php
        ```
    *   Replace `Vendor` with your preferred vendor name.

2.  **Register Your Module:**
    *   In the `registration.php` file, register your module with Magento:
        ```php
        <?php
        \Magento\Framework\Component\ComponentRegistrar::register(
            \Magento\Framework\Component\ComponentRegistrar::MODULE,
            'Vendor_StripeCustomizations',
            __DIR__
        );
        ```

3.  **Configure Dependency Injection (DI):**
    *   In `etc/di.xml`, define the plugin to override the payment method helper. The exact configuration will depend on the specific Stripe module version and its implementation.

4.  **Implement the Plugin:**
    *   In `Plugin/Helper/PaymentMethodPlugin.php`, create a plugin that intercepts the relevant method responsible for setting the payment action. You will modify this method to ensure that for eligible payment methods, the "Payment Action" is set to "Authorize Only" when desired.

### Further Information

*   Refer to the Stripe documentation for a comprehensive list of payment methods that support manual capture.
*   Consult the Adobe Commerce developer documentation for detailed information on creating and configuring custom modules and plugins.
## Localizing Prices and Currencies

This section outlines how to present and charge customers in their local currencies, enhancing international revenue and improving conversion rates.

### Key Features and Concepts

*   **Localize Prices:** Offer customers the ability to pay in over 100 currencies. This can be achieved through:
    *   **Adaptive Pricing:** Automatically convert prices to a customer's local currency with minimal integration effort. This is recommended for optimizing conversion rates in international markets quickly.
    *   **FX Quotes API:** Select specific currencies for localization, lock in exchange rates, and decide whether to pass fees to customers. This provides more control and reduces FX risk.
    *   **Manual Currency Prices:** Manually set prices in different currencies. This offers static pricing but involves greater exchange rate risk and requires more technical resources to manage.

*   **Currency Support:** Stripe supports presenting and charging in over 135 currencies globally.

### Related Topics

*   **Payment Links:** Learn how to create and share payment links that can be localized for different currencies.
*   **Checkout Customization:** Explore how to customize the checkout experience, which can include currency options.
*   **Payment Methods:** Understand the various payment methods supported and their currency compatibilities.
## Stripe Documentation: Payment Customization and Management

This documentation set provides comprehensive guidance on customizing and managing payment experiences within Stripe. It covers a range of features designed to enhance customer convenience, optimize conversion rates, and streamline business operations.

**Key areas addressed include:**

*   **Payment Presentation and Localization:**
    *   Enabling customers to pay in their local currency ([/payments/checkout/localize-prices](/payments/checkout/localize-prices), [/payments/currencies/localize-prices](/payments/currencies/localize-prices)).
    *   Displaying annual prices in monthly terms for better customer understanding ([/payments/checkout/yearly-price-display](/payments/checkout/yearly-price-display)).

*   **Checkout Customization and Enhancement:**
    *   Adding discounts, upsells, and optional items to boost sales ([/payments/checkout/promotions](/payments/checkout/promotions)).
    *   Configuring subscription upsells to increase average order value ([/payments/checkout/upsells](/payments/checkout/upsells)).
    *   Collecting additional customer information during checkout ([/payments/checkout/collect-additional-info](/payments/checkout/collect-additional-info)).
    *   Extending checkout with custom components and fields ([/payments/checkout/custom-components](/payments/checkout/custom-components)).
    *   Dynamically customizing shipping options based on customer address ([/payments/checkout/custom-shipping-options](/payments/checkout/custom-shipping-options)).
    *   Adding product images to enhance the checkout experience ([/payments/checkout/customization/product-images](/payments/checkout/customization/product-images)).
    *   Dynamically updating checkout elements in real-time ([/payments/checkout/dynamic-updates](/payments/checkout/dynamic-updates)).
    *   Allowing customers to adjust line item quantities during checkout ([/payments/checkout/adjustable-quantity](/payments/checkout/adjustable-quantity)).
    *   Managing product catalogs and inventory ([/payments/checkout/product-catalog](/payments/checkout/product-catalog)).
    *   Recovering abandoned carts to recapture lost sales ([/payments/checkout/abandoned-carts](/payments/checkout/abandoned-carts)).
    *   Setting a fixed billing cycle date for subscriptions ([/payments/checkout/billing-cycle](/payments/checkout/billing-cycle)).
    *   Ensuring compliant promotional emails to customers ([/payments/checkout/compliant-promotional-emails](/payments/checkout/compliant-promotional-emails)).
    *   Sending automated receipts and paid invoices ([/payments/checkout/receipts](/payments/checkout/receipts)).

*   **Advanced Payment Features:**
    *   Placing extended holds on online card payments ([/payments/extended-authorization](/payments/extended-authorization)).
    *   Implementing partial authorization for transactions with insufficient funds ([/payments/partial-authorization](/payments/partial-authorization)).
    *   Securing corporate payments with explicit identification ([/payments/3d-secure/secure-corporate-payments](/payments/3d-secure/secure-corporate-payments)).
    *   Collecting surcharges to offset processing costs ([/payments/cards/surcharge](/payments/cards/surcharge)).
    *   Sending supplementary purchase data for specific payment methods like Klarna ([/payments/klarna/supplementary-purchase-data](/payments/klarna/supplementary-purchase-data)).
    *   Providing industry-specific metadata for enhanced transaction processing ([/industry-metadata](/industry-metadata)).

*   **Payment Methods and Integrations:**
    *   Exploring and integrating the Link Authentication Element for streamlined login and authentication ([/payments/link/link-authentication-element](/payments/link/link-authentication-element)).
    *   Utilizing Instant Bank Payments for low-cost, instant confirmation bank transfers ([/payments/link/instant-bank-payments](/payments/link/instant-bank-payments)).
    *   Leveraging Link payment methods to increase global conversion and reduce costs ([/payments/link/link-payment-methods](/payments/link/link-payment-methods)).
    *   Customizing the appearance of in-app payment elements ([/elements/appearance-api/embedded-mobile](/elements/appearance-api/embedded-mobile)).
    *   Using the Address Element to collect billing and shipping addresses in mobile integrations ([/payments/mobile/address-element](/payments/mobile/address-element)).
    *   Displaying Buy Now, Pay Later (BNPL) messaging with the Payment Method Messaging Element ([/payments/mobile/payment-method-messaging-element](/payments/mobile/payment-method-messaging-element)).
    *   Understanding payment method support across different countries, currencies, and API options ([/payments/payment-methods/payment-method-support](/payments/payment-methods/payment-method-support)).
    *   Extending fraud prevention with Radar for local payment methods ([/radar/local-payment-methods](/radar/local-payment-methods)).

*   **Financial Connections:**
    *   Deploying Financial Connections integrations with a comprehensive checklist ([/financial-connections/deployment-checklist](/financial-connections/deployment-checklist)).
    *   Verifying bank account ownership using the Ownership Match API ([/financial-connections/ownership-match](/financial-connections/ownership-match)).
    *   Accessing transaction data for Financial Connections accounts ([/financial-connections/transactions](/financial-connections/transactions)).
    *   Managing bank accounts with Tokenized Account Numbers (TANs) ([/financial-connections/tokenized-account-numbers](/financial-connections/tokenized-account-numbers)).
    *   Viewing a list of supported financial institutions for Financial Connections ([/financial-connections/supported-institutions](/financial-connections/supported-institutions)).

*   **Managed Payments and Orchestration:**
    *   Tracking changes and updates to Managed Payments ([/payments/managed-payments/changelog](/payments/managed-payments/changelog)).
    *   Implementing cross-processor retries with Orchestration to recover failed payments ([/payments/orchestration/retries](/payments/orchestration/retries)).

*   **Payment Links:**
    *   Customizing the checkout experience for Payment Links ([/payment-links/customize](/payment-links/customize)).
    *   Sharing Payment Links across various channels ([/payment-links/share](/payment-links/share)).
    *   Tracking the performance of Payment Links using URL parameters and UTM codes ([/payment-links/url-parameters](/payment-links/url-parameters)).

*   **Dispute Management:**
    *   Understanding dispute resolution and reviewing sample evidence packets ([/disputes/visual-evidence](/disputes/visual-evidence)).

*   **Payment Method Management:**
    *   Managing payment methods within app settings using the Payment Method Settings Sheet ([/elements/customer-sheet](/elements/customer-sheet)).

*   **Deprecated Features:**
    *   Information on the deprecated Payment Request Button ([/stripe-js/elements/payment-request-button](/stripe-js/elements/payment-request-button)).
    *   Guidance on deprecated Sources and Customers API ([/sources/customers](/sources/customers)).

This collection of documentation empowers developers to build sophisticated and user-friendly payment solutions by leveraging Stripe's extensive features for customization, management, and optimization.
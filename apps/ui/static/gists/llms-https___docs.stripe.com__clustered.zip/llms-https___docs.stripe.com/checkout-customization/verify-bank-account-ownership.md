## Verifying Bank Account Ownership with Stripe Financial Connections

This documentation outlines how to leverage Stripe's Financial Connections product to verify bank account ownership, a crucial step for many financial services and platforms. It details the process of using the Ownership Match API, its prerequisites, and how to integrate it into your server-side workflows.

### Key Features and Functionality:

*   **Ownership Verification:** The core functionality allows you to verify that a user owns a specific bank account by comparing Financial Connections ownership data with provided owner information.
*   **Ownership Match API:** This API computes match scores to assess the likelihood of ownership.
*   **Server-Side Integration:** The process is primarily designed for server-side implementation, requiring you to collect Financial Connections Account data first.
*   **Data Permissions:** You can specify the exact data permissions needed, with "ownership" being a mandatory permission for this feature.
*   **Webhooks:** Financial Connections webhooks notify you when ownership data becomes available.
*   **API Versioning:** Specific API version and beta headers are required for accessing the Ownership Match API.

### Prerequisites:

*   **Completed Financial Connections Registration:** Essential for live mode usage. This can be checked and initiated through your Stripe Dashboard settings. Test data is always available.
*   **Financial Connections Account:** You must have a connected Financial Connections Account to access ownership data.
*   **API Version and Beta Headers:** Correctly set `financial_connections_ownership_match_api_preview=v1` in your API requests.

### Workflow:

1.  **User Connects Account:** The user initiates the Financial Connections flow to connect their bank account.
2.  **Request Ownership Data:** During the authentication flow, you request the `ownership` data permission.
3.  **Prefetch Ownership Data (Recommended):** Initiate the ownership refresh as soon as the user connects their account.
4.  **Receive Webhook Notification:** A `financial.connections.account.updated` webhook signals that ownership data is available.
5.  **Call Ownership Match API:** On your server, make an API request to the Ownership Match API, providing the necessary Financial Connections Account ID and owner information.
6.  **Receive Match Scores:** The API returns match scores indicating the verification result.

### Important Considerations:

*   **Private Preview:** The Ownership Match API is currently in private preview. Access may require specific requests.
*   **Data Privacy:** Ensure you comply with all relevant data privacy regulations when handling customer financial information.
*   **Error Handling:** Implement robust error handling for API requests and webhook processing.
*   **Testing:** Utilize Financial Connections test data to thoroughly test your integration before going live.
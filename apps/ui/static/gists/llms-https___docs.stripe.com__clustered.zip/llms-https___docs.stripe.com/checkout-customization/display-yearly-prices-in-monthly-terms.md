```markdown
## Displaying Yearly Prices in Monthly Terms

This section explains how to display yearly prices in their monthly equivalent to help customers compare pricing more effectively.

### Key Features

*   **Monthly Equivalent Display:** Annually billed prices can be shown as their per-month cost across various Stripe products like Checkout, Payment Links, pricing tables, and buy buttons.
*   **Checkout and Payment Links:** When this setting is enabled, Checkout displays the equivalent monthly rate below the yearly total. If a yearly price is an upsell from a monthly price and has a lower equivalent monthly rate, the old price will be displayed with a strikethrough.
*   **Pricing Tables:** The pricing table will show the equivalent monthly rate of eligible yearly prices followed by the total annual amount.
*   **Buy Buttons:** The buy button will display the equivalent monthly rate of eligible yearly prices followed by the total annual amount.

### How to Configure

Pricing display can be managed within your Checkout and Payment Links settings.
```
## Managing Payments and Customer Data

This section of the documentation covers various aspects of managing payments and customer data within the Stripe ecosystem. It details how to customize checkout experiences, handle different payment methods and currencies, manage customer subscriptions, and leverage advanced features for improved payment processing and customer engagement.

### Checkout Customization and Enhancement

*   **/payments/checkout/localize-prices**: Learn how to present and charge customers in their local currency to increase international revenue. This includes using Adaptive Pricing and the FX Quotes API.
*   **/payments/checkout/upsells**: Discover how to configure subscription upsells to allow customers to upgrade their plans at checkout, increasing average order value.
*   **/payments/checkout/yearly-price-display**: Understand how to display yearly prices in monthly terms to help customers compare pricing more effectively.
*   **/payments/checkout/abandoned-carts**: Implement strategies to recover abandoned carts by following up with customers via email to encourage them to complete their purchases.
*   **/payments/checkout/custom-components**: Explore how to extend Checkout with custom components to display custom text and collect additional information from customers.
*   **/payments/checkout/custom-shipping-options**: Dynamically customize shipping options based on a customer's shipping address.
*   **/payments/checkout/customization/product-images**: Add product images and descriptions to your checkout pages to provide a visual representation of purchased items and potentially drive higher conversion.
*   **/payments/checkout/dynamic-updates**: Learn how to make updates to the checkout process dynamically while the customer is completing their purchase.
*   **/payments/checkout/adjustable-quantity**: Enable customers to adjust the quantity of items directly within the checkout flow.
*   **/payments/checkout/product-catalog**: Manage your product catalog, including handling limited inventory and making line item quantities adjustable.
*   **/payments/checkout/promotions**: Discover how to boost sales by adding discounts, offering free trials, configuring subscription upsells, and adding optional items to purchases.
*   **/payments/checkout/receipts**: Automate the sending of customized email receipts and paid invoices for successful payments and refunds.
*   **/payment-links/customize**: Customize the checkout experience for Payment Links, including collecting customer information and branding.
*   **/payment-links/share**: Learn how to share payment links across various channels like email, social media, or your website.
*   **/payment-links/url-parameters**: Track the effectiveness of your marketing campaigns by using URL parameters and UTM codes with your payment links.

### Payment Methods and Processing

*   **/payments/currencies/localize-prices**: Understand how to localize prices to present and charge customers in over 135 currencies, which can increase conversion rates and lower processing costs.
*   **/payments/payment-line-items**: Utilize payment line items to send additional transaction metadata, enabling cost savings, facilitating reconciliation, and improving authorization rates.
*   **/payments/3d-secure/secure-corporate-payments**: Explicitly identify card payments as secure corporate payments within the PaymentIntents API.
*   **/payments/cards/surcharge**: Learn how to collect surcharges to offset card processing costs, ensuring compliance with relevant regulations.
*   **/payments/extended-authorization**: Place an extended hold on online card payments for up to 30 days after authorization.
*   **/payments/partial-authorization**: Allow customers to make partial payments for card transactions when their available balance is insufficient for the full amount.
*   **/payments/link/link-authentication-element**: Integrate the Link Authentication Element to streamline email collection and Link authentication.
*   **/payments/link/instant-bank-payments**: Accept low-cost bank payments with instant confirmation using Link's Instant Bank Payments.
*   **/payments/link/link-payment-methods**: Leverage Link to offer customers their preferred payment methods, increasing global conversion and reducing costs.
*   **/payments/klarna/supplementary-purchase-data**: Provide Klarna-specific supplementary data for various industry verticals to improve payment outcomes and customer support.
*   **/payments/payment-methods/payment-method-support**: Understand how integration choices affect payment method support, including country, currency, product, and API options.
*   **/payments/orchestration/retries**: Implement cross-processor retries with Orchestration to automatically retry failed payments using different processors, recovering more revenue.
*   **/industry-metadata**: Provide industry-specific data for travel and entertainment purchases to comply with card network requirements and potentially improve authorization rates.
*   **/radar/local-payment-methods**: Extend fraud prevention tools to analyze local payment methods, offering more payment choices while protecting against fraud.
*   **/sources/customers**: (Deprecated) Learn how to attach and manage sources with Customer objects, and migrate to the Payment Methods API.

### Customer Management and Subscriptions

*   **/payments/checkout/billing-cycle**: Set a subscription's billing cycle anchor to a fixed date for consistent billing.
*   **/elements/customer-sheet**: Use the Payment Method Settings Sheet (CustomerSheet) to allow customers to manage their saved payment methods within your app.
*   **/financial-connections/deployment-checklist**: Follow this checklist before deploying your Financial Connections integration to ensure a smooth user authentication flow.
*   **/financial-connections/ownership-match**: Verify bank account ownership using the Ownership Match API by comparing Financial Connections data with provided owner information.
*   **/financial-connections/supported-institutions**: View the details of supported financial institutions for Financial Connections integrations.
*   **/financial-connections/tokenized-account-numbers**: Understand how Tokenized Account Numbers (TANs) work and how to manage them for ACH payments and payouts.
*   **/financial-connections/transactions**: Access transaction data for a Financial Connections account to build various financial products and solutions.
*   **/payments/managed-payments/changelog**: Keep track of changes and updates to Stripe's Managed Payments feature.

### UI Elements and Customization

*   **/stripe-js/elements/payment-request-button**: (Deprecated) Use the Payment Request Button Element to collect payment and address information from customers using Apple Pay, Google Pay, or Link. Consider the Express Checkout Element as an alternative.
*   **/elements/appearance-api/embedded-mobile**: Customize the appearance of your in-app integration using the Appearance API to match your app's design.
*   **/payments/mobile/address-element**: Use the Address Element to collect complete billing and shipping addresses for in-app integrations, supporting global address formats and offering autocomplete.
*   **/payments/mobile/payment-method-messaging-element**: Automatically explain buy now, pay later payment options with the Payment Method Messaging Element.

### Disputes and Evidence

*   **/disputes/visual-evidence**: Refer to sample evidence packets to help you navigate and respond to common dispute categories.
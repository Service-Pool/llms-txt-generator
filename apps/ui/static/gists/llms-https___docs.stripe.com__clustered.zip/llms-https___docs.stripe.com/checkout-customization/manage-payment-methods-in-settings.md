## Managing Payment Methods and Customer Information

This section of the documentation provides comprehensive guidance on how to manage payment methods, collect customer information, and enhance the checkout experience within your Stripe integration.

### Core Payment Method Management

*   **/elements/customer-sheet**: Learn how to use the **Payment Method Settings Sheet** (also referred to as `CustomerSheet` in code) to allow your customers to manage their saved payment methods directly within your app's settings. This includes adding, removing, and setting default payment methods.
*   **/payments/payment-methods/payment-method-support**: Understand how different payment methods have specific requirements regarding currencies, countries, products, and API options. This page helps you ensure your chosen payment methods are compatible with your integration.
*   **/sources/customers**: This deprecated page provides information on attaching and managing "sources" with Customer objects. While deprecated, it offers context on older methods of handling reusable payment methods.

### Enhancing the Checkout Experience

*   **/payments/checkout/localize-prices**: Discover how to present and charge customers in over 100 currencies, increasing international revenue and potentially lowering processing costs. This includes options like Adaptive Pricing and manual currency pricing.
*   **/payments/checkout/upsells**: Learn how to configure **subscription upsells** within Checkout, allowing customers to upgrade their subscription plans at checkout to increase average order value and cash flow.
*   **/payments/checkout/yearly-price-display**: Implement the feature to display yearly prices in their monthly equivalent terms, helping customers compare pricing more effectively across Checkout, Payment Links, and buy buttons.
*   **/payments/checkout/custom-components**: Extend Checkout's functionality by adding **custom fields** to collect additional information from customers during the checkout process.
*   **/payments/checkout/dynamic-updates**: Understand how to **dynamically update checkout** elements, such as shipping options and line items, based on customer interactions or other real-time data.
*   **/payments/checkout/custom-shipping-options**: Dynamically customize shipping options based on a customer's shipping address for a more tailored checkout experience.
*   **/payments/checkout/product-images**: Enhance product presentation by adding **product images** to your catalog, which will be displayed alongside line items in the checkout page.
*   **/payments/checkout/adjustable-quantity**: Allow customers to **adjust line item quantities** during checkout, providing flexibility for purchasing multiple units of a product.
*   **/payments/checkout/promotions**: Explore strategies to boost sales by adding **discounts, upsells, and optional items** to your checkout flow.
*   **/payments/checkout/receipts**: Configure and send **email receipts and paid invoices** automatically or manually to customers after successful payments or refunds.
*   **/payments/checkout/abandoned-carts**: Implement strategies to **recover abandoned carts** by following up with customers via email to encourage them to complete their purchases.
*   **/payments/checkout/billing-cycle**: Learn how to **set the billing cycle date** for subscriptions, anchoring it to a fixed date for predictable invoicing.
*   **/payments/checkout/compliant-promotional-emails**: Ensure your **promotional emails** are compliant with privacy and marketing laws by following best practices for consent and opt-outs.
*   **/payments/checkout/collect-additional-info**: Collect essential customer information such as **physical addresses, phone numbers, and names** during the checkout process.
*   **/payments/klarna/supplementary-purchase-data**: Provide Klarna-specific supplementary data for various industry verticals to improve payment outcomes and customer support.
*   **/industry-metadata**: Learn how to provide data specific to travel and entertainment purchases to comply with card network requirements and potentially improve authorization rates.

### Advanced Payment Features and Integrations

*   **/payments/extended-authorization**: Place an **extended hold** on online card payments for up to 30 days, providing flexibility for capturing funds after authorization.
*   **/payments/partial-authorization**: Implement **partial authorization** to allow customers to pay with available funds on a card and then use an alternative method for the remaining balance.
*   **/payments/payment-line-items**: Utilize **payment line items** to send additional transaction metadata for cost savings, improved reconciliation, and better authorization rates.
*   **/payments/3d-secure/secure-corporate-payments**: Explicitly identify card payments as **secure corporate payments** on the PaymentIntents API.
*   **/payments/cards/surcharge**: Learn how to **collect surcharges** to offset card processing costs, ensuring compliance with all applicable regulations.
*   **/payments/managed-payments/changelog**: Keep track of the latest changes and updates to **Managed Payments**.
*   **/payments/orchestration/retries**: Configure **cross-processor retries** to automatically retry failed payments using different processors, recovering more revenue.
*   **/payments/link/link-authentication-element**: Integrate the **Link Authentication Element** for a streamlined email collection and Link authentication process.
*   **/payments/link/instant-bank-payments**: Accept low-cost **Instant Bank Payments** with instant confirmation using Link.
*   **/payments/link/link-payment-methods**: Leverage **Link payment methods** to increase global conversion and reduce costs by offering alternative payment options.
*   **/elements/appearance-api/embedded-mobile**: Customize the appearance of your in-app integration using the **Appearance API** for the Payment Element.
*   **/payments/mobile/address-element**: Use the **Address Element** to collect complete billing and shipping addresses for your in-app integrations.
*   **/payments/mobile/payment-method-messaging-element**: Display **Buy Now, Pay Later (BNPL) messaging** automatically to inform customers about available payment options.
*   **/radar/local-payment-methods**: Extend your fraud prevention tools to analyze **local payment methods** beyond cards, ACH, and SEPA Direct Debit.

### Payment Links

*   **/payment-links/customize**: Customize the checkout experience for **Payment Links**, including collecting customer information and branding.
*   **/payment-links/share**: Learn how to **share a payment link** across various channels like email, social media, or your website.
*   **/payment-links/url-parameters**: Track the performance of your **payment links** using URL parameters and UTM codes to gain insights into customer behavior and marketing effectiveness.

### Financial Connections

*   **/financial-connections/deployment-checklist**: Use this **deployment checklist** to ensure a smooth integration of your Financial Connections setup.
*   **/financial-connections/supported-institutions**: View the list of **supported financial institutions** for Financial Connections.
*   **/financial-connections/ownership-match**: Verify bank account ownership using the **Ownership Match API** with Financial Connections.
*   **/financial-connections/tokenized-account-numbers**: Manage bank accounts with **Tokenized Account Numbers (TANs)**, which are temporary bank account credentials.
*   **/financial-connections/transactions**: Access **transactions** for a Financial Connections account with your user's permission.

### Disputes

*   **/disputes/visual-evidence**: Refer to **sample evidence packets** to help you through the dispute resolution process.
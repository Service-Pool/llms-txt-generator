```markdown
# Stripe Checkout Customization and Payment Options

This documentation group focuses on enhancing the Stripe Checkout experience by offering various customization options, flexible payment methods, and advanced features to optimize conversions and streamline the payment process.

## Key Areas Covered:

*   **Checkout Customization:** Tailoring the checkout flow to meet specific business needs, including collecting additional information, displaying product details, and managing cart recovery.
*   **Payment Methods and Options:** Exploring diverse payment methods, including local payment options, subscription management, and advanced payment features like extended authorizations and partial payments.
*   **Financial Connections:** Integrating with financial institutions to access account data and verify ownership.
*   **Promotions and Discounts:** Utilizing discounts, upsells, and optional items to boost sales and improve average order value.
*   **Compliance and Security:** Ensuring secure and compliant payment processing, including handling disputes and adhering to regulatory requirements.

## Related Pages:

*   **/payments/checkout/localize-prices**: Enabling customers to pay in their local currency.
*   **/payments/checkout/upsells**: Configuring subscription upsells to increase average order value.
*   **/payments/checkout/yearly-price-display**: Displaying yearly prices in monthly terms for better customer comparison.
*   **/payments/currencies/localize-prices**: A broader overview of localizing prices for international customers.
*   **/disputes/visual-evidence**: Providing sample evidence packets for handling disputes.
*   **/elements/customer-sheet**: Managing payment methods within an app's settings.
*   **/stripe-js/elements/payment-request-button**: Using the Payment Request Button for faster checkout with wallet options (deprecated).
*   **/financial-connections/deployment-checklist**: A checklist for deploying Financial Connections integrations.
*   **/financial-connections/ownership-match**: Verifying bank account ownership with Financial Connections.
*   **/financial-connections/supported-institutions**: Listing supported financial institutions for Financial Connections.
*   **/financial-connections/tokenized-account-numbers**: Managing bank accounts with Tokenized Account Numbers.
*   **/financial-connections/transactions**: Accessing transactions for a Financial Connections account.
*   **/payments/managed-payments/changelog**: Tracking changes and updates to Managed Payments.
*   **/payments/payment-line-items**: Sending additional transaction metadata for cost savings and reconciliation.
*   **/payments/3d-secure/secure-corporate-payments**: Identifying secure corporate payments on the PaymentIntents API.
*   **/payments/cards/surcharge**: Collecting surcharges to offset card processing costs.
*   **/payments/checkout/abandoned-carts**: Implementing strategies to recover abandoned carts.
*   **/payments/checkout/billing-cycle**: Setting the billing cycle date for subscriptions.
*   **/payments/checkout/compliant-promotional-emails**: Ensuring compliance with promotional email regulations.
*   **/payments/checkout/collect-additional-info**: Collecting additional customer information during checkout.
*   **/payments/checkout/custom-components**: Extending checkout with custom components for additional fields.
*   **/payments/checkout/custom-shipping-options**: Dynamically customizing shipping options based on customer address.
*   **/payments/checkout/customization/product-images**: Adding product images to enhance the checkout experience.
*   **/payments/checkout/dynamic-updates**: Making real-time updates to the checkout during the customer's session.
*   **/payments/checkout/adjustable-quantity**: Allowing customers to adjust line item quantities during checkout.
*   **/payments/checkout/product-catalog**: Managing the product catalog for Checkout.
*   **/payments/checkout/promotions**: Adding discounts, upsells, and optional items to boost sales.
*   **/payments/checkout/receipts**: Automatically sending email receipts and paid invoices.
*   **/payments/extended-authorization**: Placing an extended hold on online card payments.
*   **/payments/partial-authorization**: Allowing partial payments for card transactions.
*   **/payments/link/link-authentication-element**: Exploring the Link Authentication Element for streamlined sign-in and authentication.
*   **/payments/link/instant-bank-payments**: Accepting low-cost US bank payments with instant confirmation via Link.
*   **/payments/link/link-payment-methods**: Utilizing Link to present various payment methods and increase global conversion.
*   **/elements/appearance-api/embedded-mobile**: Customizing the appearance of in-app integrations using the Appearance API.
*   **/payments/mobile/address-element**: Collecting complete billing and shipping addresses for in-app integrations.
*   **/payments/mobile/payment-method-messaging-element**: Displaying buy now, pay later (BNPL) messaging in apps.
*   **/payments/orchestration/retries**: Implementing cross-processor retries for failed payments with Orchestration.
*   **/payment-links/customize**: Customizing the checkout experience for Payment Links.
*   **/payment-links/share**: Sharing payment links across various channels.
*   **/payment-links/url-parameters**: Tracking payment link performance using URL parameters and UTM codes.
*   **/payments/klarna/supplementary-purchase-data**: Providing Klarna-specific supplementary data for improved payment outcomes.
*   **/payments/payment-methods/payment-method-support**: Understanding how integration choices affect payment method support.
*   **/industry-metadata**: Providing industry-specific data for travel and entertainment purchases.
*   **/radar/local-payment-methods**: Extending Radar's fraud prevention to analyze other payment methods.
*   **/sources/customers**: Managing sources and customers (deprecated).
```
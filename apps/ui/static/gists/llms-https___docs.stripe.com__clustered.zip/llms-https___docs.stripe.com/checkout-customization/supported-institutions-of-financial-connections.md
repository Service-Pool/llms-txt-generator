## Financial Connections: Supported Institutions

This document outlines the financial institutions supported by Stripe's Financial Connections product.

### Key Features

*   **Comprehensive Support:** Financial Connections connects to thousands of financial institutions across the US.
*   **Institution Search:** Easily search for specific institutions by name.
*   **Data Availability:** View which institutions support Balance Data and Transaction Data.

### Supported Institutions List

The following table provides a list of some of the most popular institutions. You can filter this list by entering a term in the provided filter box.

| Institution | Account Details | Ownership Details | Balance Data | Transaction Data |
| :---------- | :-------------- | :---------------- | :----------- | :--------------- |
| (List of institutions will be dynamically populated here) | Yes | Yes | Yes | Yes |

### Data Types Supported by Institution

Financial Connections can retrieve various types of data for supported institutions. The table above indicates the availability of Account Details, Ownership Details, Balance Data, and Transaction Data for each institution.

### Next Steps

*   **Explore Supported Institutions:** Use the provided search and filter functionalities to find specific institutions.
*   **Understand Data Access:** Familiarize yourself with the types of data available through Financial Connections.
*   **Integrate Financial Connections:** Refer to the [Financial Connections documentation](link-to-financial-connections-docs) for integration guides and best practices.
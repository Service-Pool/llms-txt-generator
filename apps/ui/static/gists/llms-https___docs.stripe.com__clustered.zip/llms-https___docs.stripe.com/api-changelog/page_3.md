## Stripe API Changelog

This documentation outlines the changes and updates made to the Stripe API over time. Each entry details specific modifications, including new features, renamed fields, deprecated parameters, and bug fixes.

---

### 2025-01-27 Release

**Page 1: Adds support for ownership exemption reason to the Accounts API**

*   **What's New:** The `ownership_exemption_reason` parameter has been added to the `company` field of the Accounts resource. This allows businesses to submit an exemption reason for ultimate beneficial ownership requirements, qualifying for an exception to the standard process.
*   **Impact:** Businesses can now use `qualified_entity_exceeds_ownership_threshold` or `qualifies_as_financial_institution` as exemption reasons. Stripe may request additional documentation for verification.
*   **Changes:**
    *   **REST API:** Added `company.ownership_exemption_reason` parameter to the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** Updates to SDKs to support the new parameter.
*   **Upgrade:** Accounts that can use this process will receive the `ownership_exemption_reason` requirement in their `requirements` field.

**Page 324: Adds directorship declaration to the Accounts API**

*   **What's New:** The `directorship_declaration` parameters (`ip`, `date`, `user_agent`) have been added to the `company` field of the Accounts API. These parameters allow users to attest that the list of directors on their Stripe account accurately reflects the directors of their company, helping to fulfill Know Your Customer (KYC) requirements.
*   **Impact:** Accounts in certain countries may see a new `directorship_declaration` requirement in their `requirements` field.
*   **Changes:**
    *   **REST API:** Added `company.directorship_declaration` parameters to the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** Updates to SDKs to support the new parameters.

**Page 325: Adds advice code to Charges**

*   **What's New:** The `advice_code` property has been added to the `outcome` field of the Charge object. This enumerated value provides more details about unsuccessful transactions.
*   **Impact:** The `advice_code` helps you understand how to proceed if a transaction is unsuccessful.
*   **Changes:**
    *   **REST API:** Added `outcome.advice_code` to the Charge object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** Updates to SDKs to support the new property.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when a transaction using a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_document_issue_or_expiry_date_missing`, `verification_document_not_signed`, `verification_failed_tax_id_not_issued`, `verification_failed_tax_id_match`, `invalid_address_po_boxes_disallowed`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for various verification issues related to accounts.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2023-08-16 Release

**Page 194: Adds new account requirement error codes to the Accounts API**

*   **What's New:** Several new error codes have been added to the `requirements.errors` array in the Accounts API, including `invalid_address_highway_contract_box`, `invalid_address_private_mailbox`, `invalid_business_profile_name`, `invalid_business_profile_name_denylisted`, `invalid_company_name_denylisted`, `invalid_dob_age_over_maximum`, `invalid_dob_age_under_minimum`, `invalid_product_description_length`, `invalid_product_description_url_match`, `invalid_statement_descriptor_business_mismatch`, `invalid_statement_descriptor_denylisted`, `invalid_statement_descriptor_length`, `invalid_statement_descriptor_prefix_denylisted`, `invalid_statement_descriptor_prefix_mismatch`, `invalid_tax_id_format`, `invalid_url_denylisted`, `invalid_url_format`, `invalid_url_web_presence_detected`, `invalid_url_website_business_information_mismatch`, `invalid_url_website_empty`, `invalid_url_website_inaccessible`, `invalid_url_website_inaccessible_geoblocked`, `invalid_url_website_inaccessible_password_protected`, `invalid_url_website_incomplete`, `invalid_url_website_incomplete_cancellation_policy`, `invalid_url_website_incomplete_customer_service_details`, `invalid_url_website_incomplete_legal_restrictions`, `invalid_url_website_incomplete_refund_policy`, `invalid_url_website_incomplete_return_policy`, `invalid_url_website_incomplete_terms_and_conditions`, `invalid_url_website_incomplete_under_construction`, `invalid_url_website_other`.
*   **Impact:** Provides more detailed error messages for various account-related issues, improving debugging and integration.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 208: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**
    *   **REST API:** Added `stripe_s700` to `Terminal.Reader.device_type` and `Terminal.Reader#list.device_type`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new device type.

**Page 222: Adds support for using the Multibanco payment method with billing**

*   **What's New:** The Multibanco payment method has been added as an available option in invoices and subscriptions.
*   **Impact:** This expands payment options for customers in Portugal, potentially increasing conversion rates and improving the payment experience.
*   **Changes:**
    *   **REST API:** Added `multibanco` to `Invoice.payment_settings.payment_method_types[]`, `Subscription.payment_settings.payment_method_types[]`, and related parameters.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new payment method.

**Page 223: Adds webhook events for when an invoice is due or overdue**

*   **What's New:** Two new webhook event types, `invoice.overdue` and `invoice.will_be_due`, have been introduced. These events can be configured to fire based on custom conditions or schedules for custom automations.
*   **Impact:** This allows for more proactive management of invoices by enabling automated notifications and actions when invoices become due or overdue.
*   **Changes:**
    *   **Event Types:** Added `invoice.overdue` and `invoice.will_be_due` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

---

### 2023-08-16 Release

**Page 189: Enables automatic payment methods by default for PaymentIntents and SetupIntents**

*   **What's New:** PaymentIntents and SetupIntents now have `automatic_payment_methods` enabled by default. This allows for dynamic payment method settings configured in the Stripe Dashboard.
*   **Impact:** This change simplifies payment method management by enabling automatic configuration through the Dashboard, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default behavior of `automatic_payment_methods` for Payment Intents and Setup Intents.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 190: One-time payments in Checkout Sessions support no-cost orders**

*   **What's New:** No-cost orders are now supported for one-time payments in Checkout Sessions. The `payment_method_collection` parameter's default value has changed from `always` to `if_required`.
*   **Impact:** This change simplifies the checkout process for free items or zero-cost transactions, potentially reducing friction for users.
*   **Changes:**
    *   **REST API:** Changed the default value of `payment_method_collection` to `if_required` for one-time payments in Checkout Sessions.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

**Page 191: Platform-scope rendering for select PaymentMethod fingerprints**

*   **What's New:** For PaymentMethods of types `us_bank_account`, `acss_debit`, `sepa_debit`, `bacs_debit`, and `au_becs_debit`, fingerprints are now rendered in platform scope (not the owning merchant's scope) when viewed by a platform. This is similar to the change made in 2018-01-23 for cards and bank accounts.
*   **Impact:** This provides platform users with a consistent fingerprint for bank account-based payment methods across all connected accounts, aiding in the identification of unique payment methods.
*   **Changes:**
    *   **REST API:** Updated the fingerprint rendering for specific PaymentMethod types in Connect.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect this change.

**Page 192: Adds specific error codes for failed Klarna payments**

*   **What's New:** New, more specific error codes have been added to the PaymentIntent API for failed Klarna payments.
*   **Impact:** These codes provide more detailed information about Klarna payment failures, improving error handling and debugging.
*   **Changes:**
    *   **REST API:** Added `payment_method_customer_decline`, `payment_method_provider_timeout`, `payment_method_not_available`, `payment_method_provider_decline`, and `payment_intent_payment_attempt_expired` to the PaymentIntent API for Klarna payments.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

**Page 193: Adds new director verification error codes to the Accounts API**

*   **What's New:** New error codes (`verification_missing_directors`, `verification_directors_mismatch`, `verification_document_directors_mismatch`, `verification_extraneous_directors`) have been added to the `requirements.errors` array in the Accounts API.
*   **Impact:** These codes provide more specific error reporting for director verification issues.
*   **Changes:**
    *   **REST API:** Added new error codes to the `requirements.errors` array in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error codes.

---

### 2024-04-10 Release

**Page 197: Renames the rendering_options attribute for invoices to rendering**

*   **What's New:** The `rendering_options` attribute for invoices has been renamed to `rendering`.
*   **Impact:** This change simplifies the attribute's name and requires updates to code that accesses or modifies invoice rendering settings.
*   **Changes:**
    *   **REST API:** Renamed `rendering_options` to `rendering` in the Invoice object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 198: Renames the features attribute of the Product object**

*   **What's New:** The `features` attribute of the Product object has been renamed to `marketing_features`.
*   **Impact:** This change provides more precise terminology for the product's features, improving clarity and organization.
*   **Changes:**
    *   **REST API:** Renamed `features` to `marketing_features` in the Product object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the renaming.

**Page 196: Makes automatic sync the default capture method for PaymentIntents when not specified**

*   **What's New:** `automatic_async` is now the default `capture_method` for PaymentIntents when not explicitly specified during creation.
*   **Impact:** This change allows for asynchronous capture by default, potentially improving payment success rates and reducing declines.
*   **Changes:**
    *   **REST API:** Updated the default `capture_method` for Payment Intents to `automatic_async`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDKs are updated to reflect this change.

---

### 2024-06-20 Release

**Page 204: Deprecates alphanumeric_id for Issuing Authorization**

*   **What's New:** The `fleet.cardholder_prompt_data.alphanumeric_id` property for the Issuing Authorization resource has been deprecated. It is replaced by `driver_id`, `vehicle_number`, `unspecified_id`, or `user_id`.
*   **Impact:** This change provides clearer categorization of identifiers in fleet management scenarios, but requires updates to existing code that uses the deprecated `alphanumeric_id` property.
*   **Changes:**
    *   **REST API:** Deprecated `fleet.cardholder_prompt_data.alphanumeric_id` in Issuing Authorizations.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation.

**Page 205: Adds enum values for disabled reasons**

*   **What's New:** New enum values, `paused.inactivity` and `other`, have been added to the `verification[disabled_reason]` field on the Account object.
*   **Impact:** This change provides more specific reasons for account disabling, improving clarity in account status tracking.
*   **Changes:**
    *   **REST API:** Added new enum values to `verification[disabled_reason]` in the Accounts API.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

**Page 206: Deprecates the bank_transfer_payments capability type in favor of newer capability types**

*   **What's New:** The `bank_transfer_payments` capability type has been deprecated in favor of more specific, location-based capability types in the Capabilities API.
*   **Impact:** This change provides more granular control over account capabilities by introducing specific types for bank transfers based on the buyer's location.
*   **Changes:**
    *   **REST API:** Deprecated `bank_transfer_payments` and introduced new capability types (e.g., `gb_bank_transfer_payments`, `jp_bank_transfer_payments`).
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to reflect the deprecation and new capability types.

**Page 207: Adds new enum values for request history reasons**

*   **What's New:** New enum values (`card_canceled`, `card_expired`, `cardholder_blocked`, `insecure_authorization_method`, `pin_blocked`) have been added to the `request_history.reason` property of the Issuing Authorization object.
*   **Impact:** These values provide more granular information about the reasons for Issuing authorization requests, aiding in fraud analysis and management.
*   **Changes:**
    *   **REST API:** Added new enum values to `request_history.reason` in the Issuing Authorization object.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new enum values.

---

### 2024-09-30 Release (Acacia)

**Page 208: Adds Switzerland UID as a supported customer tax ID**

*   **What's New:** Switzerland's UID number, `CH UID` (`ch_uid`), has been added to the list of supported customer tax IDs.
*   **Impact:** When creating or updating a Customer, you can now select `ch_uid` or `CH VAT` (previously supported VAT number) as tax ID types.
*   **Changes:**
    *   **REST API:** Added `ch_uid` to `customer_details.tax_ids[].type` for Checkout Sessions, `customer_tax_ids[].type` for Invoices, and `tax_id_data[].type` for Customer creation/update.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new tax ID type.

**Page 214: Adds error code for exceeded transaction limits**

*   **What's New:** The `charge_exceeds_transaction_limit` error code has been added as an enum value to several resources, including Invoices, Payment Intents, Setup Attempts, Setup Intents, and Errors. This error occurs when the amount of a transaction that uses a bank debit payment method causes the merchant to exceed their transaction volume limit.
*   **Impact:** This allows for more precise error handling and testing of transaction volume limits.
*   **Changes:**
    *   **REST API:** Added `charge_exceeds_transaction_limit` to `last_finalization_error.code` for Invoices, `last_payment_error.code` for Payment Intents, `setup_error.code` for Setup Attempts, `last_setup_error.code` for Setup Intents, and `StripeError.code`.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new error code.

**Page 216: Adds address validation for physical cards**

*   **What's New:** The `shipping.address_validation` object has been added to the Issuing Card API, allowing for address validation settings during card creation and updates.
*   **Impact:** This enhances the accuracy of shipping addresses by validating and normalizing them.
*   **Changes:**
    *   **REST API:** Added `shipping.address_validation` to Issuing Card creation and update methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new address validation settings.

**Page 217: Adds support for the Payment Element on a Customer Session**

*   **What's New:** The `components.payment_element` object has been added to the Customer Session API, enabling the configuration of the Payment Element within a Customer Session for saving customer payment methods.
*   **Impact:** This facilitates the saving of payment methods within a Customer Session, improving the checkout experience and streamlining recurring payments.
*   **Changes:**
    *   **REST API:** Added `components.payment_element` to Customer Session creation and related methods.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new component.

**Page 218: Adds option to retrieve CVC tokens on Confirmation Tokens**

*   **What's New:** The `payment_method_options.card.cvc_update.token` field has been added to Confirmation Tokens, allowing for the retrieval of CVC tokens collected from the Payment Element.
*   **Impact:** This provides enhanced security by enabling the use of CVC tokens for payment confirmation.
*   **Changes:**
    *   **REST API:** Added `payment_method_options.card.cvc_update.token` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new token retrieval option.

**Page 219: Adds customer ID to payment method preview on a confirmation token**

*   **What's New:** The `payment_method_preview.customer` field has been added to Confirmation Tokens, allowing access to customer-specific information during the preview stage of the confirmation process.
*   **Impact:** This provides greater visibility into customer details during checkout, potentially improving conversion rates and customer experience.
*   **Changes:**
    *   **REST API:** Added `payment_method_preview.customer` to Confirmation Tokens.
    *   **Ruby, Python, PHP, Java, Node.js, Go, .NET:** SDK updates to support the new customer ID field.

**Page 220: Adds a new webhook event for when funds are deducted as part of a dispute**

*   **What's New:** A new webhook event type, `issuing_dispute.funds_rescinded`, has been introduced. This event triggers when funds are deducted from an account due to an Issuing dispute.
*   **Impact:** This allows for more accurate tracking of funds movements related to disputes, enabling better financial reconciliation and automated responses to such events.
*   **Changes:**
    *   **Event Types:** Added `issuing_dispute.funds_rescinded` to `Event.type`.
    *   **Webhook Endpoints:** Added to `WebhookEndpoint#create.enabled_events` and `WebhookEndpoint#update.enabled_events`.

**Page 221: Adds the Stripe S700 reader as a valid device type**

*   **What's New:** The `stripe_s700` enum value has been added to the `device_type` parameter for Reader objects.
*   **Impact:** This allows for the identification and management of Stripe Reader S700 devices within Terminal integrations.
*   **Changes:**

<!-- truncated by AI -->
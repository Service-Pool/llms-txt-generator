```md
# Stripe API Changelog

This document outlines the changes and updates made to the Stripe API over time.

## Key Updates and Features

The Stripe API is constantly evolving to provide more robust and flexible solutions for developers. Below are some of the key updates and features that have been introduced:

### Accounts and Connect

*   **Ownership Exemption Reason for Accounts API**: Added the `ownership_exemption_reason` parameter to the `company` field of the Accounts resource. This allows businesses to qualify for exceptions to standard UBO requirements by providing a reason for exemption. (Acacia, 2025-01-27)
*   **Account Activation Status Terms Updated**: Renamed `charge_enabled` and `transfer_enabled` properties on the Account object to `charges_enabled` and `transfers_enabled` for better clarity. (2014-11-05)
*   **Account Capabilities Updates**: Introduced new `type` values for accounts (Standard, Express, Custom) and refined the `requested_capabilities` parameter for custom account creation. (2017-05-25, 2018-02-05, 2019-02-19, 2019-11-05, 2020-08-27)
*   **Account KYC Data Availability**: Expanded the availability of KYC data, including `business_type`, `company.name`, `individual` details, and `person` relationship information. (2019-02-19)
*   **Accounts API Requires API Version 2014-12-17 or Newer**: Updated the Accounts API to require a minimum API version for creating accounts. (2014-12-17)
*   **New Error Codes for Accounts API**: Introduced `verification_legal_entity_structure_mismatch` and other error codes for improved verification error handling. (2020-08-27, 2023-08-16)
*   **Global Payouts Support**: Expanded Global Payouts to support cross-border payouts to 13 new countries and added multicurrency support for v2 payout methods. (2025-08-27, 2026-01-28)
*   **PayPay Onboarding Parameters**: Added PayPay onboarding parameters to the Accounts API for connected accounts. (2025-11-17)
*   **Accounts v2 API for Connected Accounts**: Introduced Accounts v2 API for managing connected accounts and customers, improving onboarding and data synchronization. (2025-11-17)
*   **Accounts v2 Interoperability**: Added `customer_account` property to v1 APIs for Accounts v2 interoperability. (2025-11-17)
*   **Accounts v2 Responsibilities Field**: Ensured the `responsibilities` field is always returned in Accounts v2 responses when the `defaults` field is included. (2025-12-15)
*   **Accounts v2 Capabilities**: Removed the `requested` field from capabilities hashes and introduced `status` for better clarity. (2025-12-15)
*   **Accounts v2 Identity Properties Restriction**: Restricted certain identity properties for Global Payouts use cases. (2026-03-25)
*   **Accounts v2 Time Zone Support**: Added time zone support to the Accounts v2 API for better management of accounts across different time zones. (2026-03-25)

### Billing and Subscriptions

*   **New Invoice Features**: Introduced sequential invoice numbering, prorated invoice line item updates, and improved handling of failed invoice payments. (2015-09-23, 2015-04-07, 2013-02-11)
*   **Subscription Management Enhancements**: Added support for multiple subscriptions per customer, delayed first invoice dates, and improved trial period handling. (2014-01-31, 2018-02-05)
*   **Plan and Product Updates**: Linked plans to individual products and moved several fields to the Product resource. Introduced a `type` field for products. (2018-02-05)
*   **Invoice Line Item Improvements**: Added unique IDs to invoice line items and ensured descriptions are always set. (2018-05-21, 2017-12-14)
*   **Coupon Behavior Changes**: Updated coupon application logic to only apply to total balance and not zero-cost invoices. (2013-10-29, 2015-03-24)
*   **Flexible Billing Mode**: Introduced flexible billing mode as the default for new subscriptions, offering more accurate prorations and improved metered pricing. (2025-08-27, 2025-03-31)
*   **Billing Thresholds**: Added support for billing thresholds on flexible billing mode subscriptions. (2025-07-30)
*   **Credit Grant APIs**: Introduced APIs for managing billing credits, including allocation and drawdown. (2024-09-30, 2025-04-30)
*   **Invoice Rendering Templates**: Added support for customizable invoice rendering templates. (2024-09-30, 2025-03-31)
*   **Removes Legacy Usage-Based Billing**: Deprecated legacy usage-based billing features in favor of meters. (2025-03-31)
*   **Subscription Item-Level Billing Periods**: Introduced subscription item-level billing periods and removed subscription-level periods. (2025-03-31)
*   **Customer Portal Updates**: Made business profile optional for customer portal configuration and added support for scheduled subscription downgrades. (2025-09-30, 2024-10-28)

### Charges and Payments

*   **New Payment Methods**: Added support for various local payment methods including Multibanco, Twint, Zip, Pay by Bank, Billie, Satispay, and UPI. (2024-09-30, 2025-01-27, 2025-03-31, 2025-06-30, 2025-07-30)
*   **Payment Intents and Setup Intents Enhancements**: Introduced automatic payment methods by default, renamed statuses, and added new decline codes. (2018-02-06, 2019-02-11, 2022-08-01, 2022-11-15)
*   **3D Secure Updates**: Added support for 3D Secure versions 2.3.0 and 2.3.1, and added exemption status to card charges. (2020-08-27, 2022-08-01)
*   **Statement Descriptor Changes**: Introduced `statement_description` field and updated statement descriptor behaviors for card payments. (2014-12-17, 2019-02-19)
*   **Payment Line Items**: Added support for payment line items in Payment Intents, including overcapture and incremental authorization. (2020-08-27, 2025-07-30)
*   **Card and Bank Account Validation**: Enhanced validation for card and bank account details, including postal codes and fingerprints. (2014-10-07, 2015-10-12, 2018-01-23)
*   **Checkout Session Updates**: Introduced various improvements to Checkout Sessions, including support for no-cost orders, deferred PaymentIntent creation, updated shipping properties, and configurable branding. (2023-08-16, 2022-08-01, 2014-06-17, 2014-12-22, 2019-02-19, 2025-09-30, 2025-11-17, 2025-12-15, 2026-03-25)
*   **Klarna and other Payment Method Enhancements**: Added support for Klarna in Hosted Invoice Page, and updated decline codes for various payment methods. (2025-03-31, 2022-08-01, 2025-09-30)
*   **OpenAPI Artifacts**: Added OpenAPI artifacts for v1 and v2 API endpoints. (2026-01-28)

### Disputes and Fraud Prevention

*   **Dispute Status Updates**: Introduced new statuses for disputes and improved tracking of fee details. (2014-08-20, 2013-02-13)
*   **Dispute Evidence Handling**: Added structured evidence details for disputes, including support for front and back document uploads. (2014-12-08, 2019-02-19)
*   **Visa Compelling Evidence 3.0**: Added support for Visa's Compelling Evidence 3.0 to respond to qualifying disputes. (2017-02-14)
*   **Dispute Prevention**: Added support for dispute prevention mechanisms to block or resolve disputes before formal chargebacks. (2025-08-27)

### Financial Connections and Money Management

*   **Financial Address Updates**: Added account holder information to Financial Address credentials for US bank accounts and expanded filtering support for Financial Connections Sessions. (2025-10-29, 2026-01-28)
*   **Global Payouts Expansion**: Added support for cross-border payouts to new countries and introduced multicurrency support for v2 payout methods. (2025-06-30, 2026-01-28)
*   **Payout Method Updates**: Added new event types for Payout Method updates and support for saving/reusing Naver Pay payment methods. (2024-10-28, 2025-03-31, 2025-05-28)
*   **Balance Settings API Enhancements**: Unified billing mode configuration, added per-currency minimum balances, and renamed parameters for custom settlement timing. (2025-06-30, 2025-08-27, 2025-12-15)
*   **Reserves API**: Added support for retrieving information about reserves, including status and balance. (2026-01-28)
*   **Treasury API Updates**: Added top-up field to ReceivedDebit linked flows and new balance transaction types. (2025-06-30, 2025-08-27)

### Tax and Invoicing

*   **Tax ID Support**: Added support for tax ID types in numerous new countries and updated tax handling for Customers. (2024-09-30, 2025-04-30, 2025-10-29, 2025-12-15)
*   **Automatic Tax Enhancements**: Added support for third-party tax providers and updated address validations for Tax. (2024-09-30, 2025-04-30)
*   **Invoice Updates**: Introduced sequential invoice numbering, support for partial payments, and new webhook events for invoice status changes. (2020-03-02, 2019-03-14, 2025-03-31, 2025-09-30)

### Terminal and Issuing

*   **Terminal Features**: Added support for configuring reboot times, managing shipping statuses, and accepting Apple's Tap to Pay on iPhone terms. (2024-09-30, 2022-08-01, 2025-07-30, 2025-11-17, 2025-03-31)
*   **Issuing Card Updates**: Added `design_rejected` as a cancellation reason and support for custom expiration dates for virtual cards. (2022-08-01, 2025-08-27)
*   **Issuing Authorizations**: Added `network_fallback` reason code and support for Visa compliance disputes. (2026-03-25, 2025-08-27)

### Other Notable Changes

*   **Error Handling Improvements**: Introduced new error codes and standardized error handling for various API requests. (2011-06-21, 2015-10-12, 2016-10-19, 2020-08-27, 2022-08-01, 2024-06-20, 2025-09-30, 2026-01-28)
*   **API Versioning**: Introduced a new API versioning model with major updates and continuous feature enhancements. (2024-06-20, 2025-01-27)
*   **Stripe.js Updates**: Renamed and deprecated several methods in Stripe.js for improved clarity and functionality. (2026-03-25)
*   **OpenAPI Artifacts**: Added OpenAPI artifacts for v1 and v2 API endpoints for easier integration with third-party SDKs. (2026-01-28)

This changelog provides a comprehensive overview of the API updates. For detailed information on specific changes and how to implement them, please refer to the individual release notes.
```
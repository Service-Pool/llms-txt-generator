```markdown
## Page 15: Updates to Customer Object for Card Management

This update introduces significant changes to how customer card information is managed within the Stripe API. The `active_card` property on the `Customer` object has been replaced by a `cards` sublist and a `default_card` ID property. This change aims to provide a more robust and flexible way to manage multiple cards associated with a customer.

### Key Changes:

*   **`active_card` replaced by `cards` and `default_card`:**
    *   The `cards` property is now a sublist that contains all card objects associated with a customer. This allows for the storage and retrieval of multiple cards per customer.
    *   The `default_card` property is a new field that holds the ID of the customer's default card. This simplifies the process of identifying and using the primary card for transactions.

### Impact on Integrations:

*   **Existing integrations:** Integrations that rely on the `active_card` property will need to be updated to use the new `cards` sublist and `default_card` ID property. This change is considered a breaking change, and it is recommended to upgrade your API version to `2013-07-05` or later to ensure compatibility.
*   **New integrations:** New integrations should utilize the `cards` sublist and `default_card` ID property for managing customer card information.

### Upgrade Path:

To ensure a smooth transition, Stripe recommends the following steps:

1.  **Review your current API version:** Check your API version in Stripe Workbench.
2.  **Upgrade your API version:** If you are not using the latest API version, upgrade to the corresponding SDK version for this API version. If you are not using an SDK, update your API requests to include `Stripe-Version: 2013-07-05`.
3.  **Update webhook endpoints:** Ensure your webhook endpoints are configured to use the new API version.
4.  **Test your integration:** Thoroughly test your integration, especially the parts that handle customer card management and payments, against the new API version. If you use Stripe Connect, ensure your Connect integration is also tested.

This change provides a more structured and comprehensive approach to managing customer payment methods, allowing for better flexibility and scalability in your payment processing.
```
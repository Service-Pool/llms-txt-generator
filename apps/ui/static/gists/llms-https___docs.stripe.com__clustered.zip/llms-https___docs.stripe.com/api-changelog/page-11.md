```markdown
## Stripe API Changelog: Key Updates and Deprecations

This document outlines significant changes and updates to the Stripe API, focusing on versioning, feature enhancements, and deprecations across various product areas.

---

### API Versioning and Feature Enhancements

Stripe has introduced a new API versioning model with its "Acacia" release (effective 2024-09-30), followed by "Basil" (2025-03-31) and subsequent releases. This model aims for greater predictability by combining major biannual updates with continuous feature enhancements.

**Key updates across releases include:**

*   **Acacia Release (2024-09-30 onwards):**
    *   **New Payment Methods:** Support for Multibanco, Twint, Zip, and Pix (for US sellers accepting Brazilian buyers) has been added.
    *   **Tax Features:** Enhanced support for tax IDs in 19 new countries and tax registrations in 21 countries. Tax calculation now supports third-party providers and event location-based tax for ticket sales.
    *   **Financial Connections:** Filtering by account subcategories (checking, savings, mortgage, line\_of\_credit, credit\_card) is now available.
    *   **Terminal Updates:** Support for the Stripe S700 reader, custom reboot times, and Japanese statement descriptors.
    *   **Billing:** New Alerts API for usage-based billing, with support for subscriptions and subscription items, and contextual filters.
    *   **Account Management:** New parameters for directorship declarations and business profile details for KYC compliance.
    *   **Disputes:** Support for identifying Klarna chargeback loss reasons and Visa compliance disputes.
    *   **Checkout Sessions:** Support for blocking specific card brands, updating shipping options, and customizing submit buttons for recurring payments.
    *   **Payment Intents:** Support for new decline codes and deferred PaymentIntent creation in payment mode.
    *   **Other:** Adds support for Pay by Bank, Satispay, and UPI payment methods, and updates to Account v2 API for better management of connected accounts and customers.

*   **Basil Release (2025-03-31 onwards):**
    *   **Subscriptions:** Flexible billing mode is now the default. Support for mixed intervals within a single subscription and configurable trial offers for subscription items have been introduced.
    *   **Invoicing:** Improved price modeling for invoice items, support for manual tax amounts with jurisdiction and taxability reasons, and the ability to automatically finalize invoices.
    *   **Terminal:** Support for custom WiFi configurations and various new payment methods like Billie and Satispay.
    *   **Accounts:** Refactoring of several fields, including the move of business details to `business_profile`, and new error codes for verification.
    *   **Disputes:** Updates to risk levels for Issuing Authorizations to align with standard values.
    *   **Payments:** New decline codes for Klarna payments and support for Pay by Bank, Satispay, and Billie.
    *   **Other:** Deprecation of legacy usage-based billing, removal of the `iterations` parameter for subscription schedules, and changes to event types for automatic updates.

*   **Clover Release (2025-09-30 onwards):**
    *   **Checkout Sessions:** Support for collecting business and individual names, blocking specific card brands, and updating shipping options.
    *   **Invoicing:** Sequential invoice numbering across accounts, and support for Invoice Rendering Templates.
    *   **Payment Intents:** New decline codes and support for excluding payment methods.
    *   **Accounts:** Updates to requirements collection parameters, and support for PayPay onboarding.
    *   **Terminal:** Support for Japan-specific fields, custom splash screens for BBPOS WisePad 3, and new enum values for risk levels.
    *   **Billing:** Changes to meter usage analytics filtering, and new webhook events for billing meters and credits.
    *   **Other:** Adds support for Croatia NIP tax ID, and updates to Radar manual reviews.

*   **Dahlia Release (2026-03-25 onwards):**
    *   **Checkout Sessions:** Updates to UI mode enum values, and adds support for app-to-web purchases.
    *   **Issuing:** Adds support for limiting payments for Issuing cards and updates to risk levels.
    *   **Financial Connections:** Adds hosted relink flow and support for filtering by account subcategories.
    *   **Terminal:** Adds support for collecting card details and confirming Payment Intents to server-driven integrations.
    *   **Billing:** Adds subscription item-level billing periods and deprecates subscription-level periods.
    *   **Other:** Adds support for marine carbon removal as a Climate Orders pathway, and updates to Events v2 API for filtering.

*   **Clover Release (2025-10-29 onwards):**
    *   **Checkout Sessions:** Adds TWINT payment method options and support for collecting business and individual names.
    *   **Invoices:** Adds support for using Payment Records with Invoices and Credit Notes.
    *   **Payment Links:** Adds support for collecting business and individual names.
    *   **Terminal:** Adds support for tipping in Gibraltar pounds.
    *   **Accounts:** Adds new error codes for missing verification data, and support for managing stablecoin payments with Payment Method Configurations.
    *   **Other:** Adds support for MB WAY to payment method configurations, and new error codes for Klarna chargeback losses.

*   **Clover Release (2025-11-17 onwards):**
    *   **Accounts v2:** Updates requirements collection parameters, adds future requirements field, and adds support for PayPay onboarding.
    *   **Terminal:** Adds support for simulating card payments and PayNow on Terminal readers.
    *   **Payment Intents:** Adds new decline codes and support for excluding payment methods.
    *   **Other:** Adds transaction IDs for Cash App, and updates to Payment Records API.

*   **Clover Release (2025-12-15 onwards):**
    *   **Accounts v2:** Adds support for retrieving and listing closed accounts, and adds account tokens for securely transmitting sensitive data.
    *   **Payouts:** Adds support for cross-border payouts to 15 new countries, and updates to Balance Settings API for custom settlement timing.
    *   **Terminal:** Adds support for Mollie as an iDEAL issuer, and updates to Terminal Configuration for custom splash screens.
    *   **Customer Portal:** Allows modification of billing cycle anchor for subscription updates.
    *   **Other:** Adds support for PayTo payment method, and adds a metadata field to the Vault and Forward API.

*   **Acacia Release (2024-09-30 onwards):**
    *   **Accounts:** Adds Switzerland UID as a supported customer tax ID, and support for directorship declaration.
    *   **Billing:** Adds support for bulk invoice line item operations, and new webhook events for invoice due/overdue status.
    *   **Financial Connections:** Expands filtering support for account categories and adds new enum values for various financial connection types.
    *   **Issuing:** Adds new enum values for fuel units and deprecates alphanumeric\_id.
    *   **Checkout Sessions:** Adds support for updating metadata and allows customers to remove saved payment methods.
    *   **Payment Intents:** Makes automatic sync the default capture method when not specified.
    *   **Other:** Adds new error codes for Accounts API, and support for Klarna in Hosted Invoice Page.

*   **Basil Release (2025-03-31 onwards):**
    *   **Subscriptions:** Adds support for mixed intervals and configurable trial offers.
    *   **Invoicing:** Replaces top-level price fields with improved price modeling, adds jurisdiction level and taxability reason to manual tax amounts, and adds support for automatically finalizing invoices.
    *   **Terminal:** Adds support for WiFi configuration and new payment methods.
    *   **Accounts:** Refactors fields related to legal entity, verification status, and configurable settings.
    *   **Other:** Adds new error codes for Accounts API, and updates to Radar manual reviews.

*   **Clover Release (2025-09-30 onwards):**
    *   **Checkout Sessions:** Adds support for collecting business and individual names, blocking specific card brands, and updating shipping options.
    *   **Invoicing:** Standardizes invoice line item IDs and adds support for using Payment Records with Invoices and Credit Notes.
    *   **Payment Links:** Adds support for collecting business and individual names.
    *   **Terminal:** Adds support for Japan-specific fields and custom splash screens for BBPOS WisePad 3.
    *   **Billing:** Adds new webhook event types for Billing Meters and credits, and makes flexible billing mode the default for new subscriptions.
    *   **Other:** Adds new error codes for Accounts API, and updates to Radar manual reviews.

*   **Clover Release (2025-11-17 onwards):**
    *   **Accounts v2:** Updates requirements collection parameters, adds future requirements field, and supports PayPay onboarding.
    *   **Terminal:** Adds support for simulating card payments and PayNow on Terminal readers.
    *   **Payment Intents:** Adds new decline codes and support for excluding payment methods.
    *   **Other:** Adds transaction IDs for Cash App, and updates to Payment Records API.

*   **Clover Release (2025-12-15 onwards):**
    *   **Accounts v2:** Adds support for retrieving and listing closed accounts, and adds account tokens for securely transmitting sensitive data.
    *   **Payouts:** Adds support for cross-border payouts to 15 new countries, and updates to Balance Settings API for custom settlement timing.
    *   **Terminal:** Adds support for Mollie as an iDEAL issuer, and updates to Terminal Configuration for custom splash screens.
    *   **Customer Portal:** Allows modification of billing cycle anchor for subscription updates.
    *   **Other:** Adds support for PayTo payment method, and adds a metadata field to the Vault and Forward API.

---

### Key Deprecations and Breaking Changes

Several changes have been introduced that may require updates to existing integrations:

*   **`identifier` field removed from Plan objects (2011-06-28):** This redundant field was removed to simplify the data structure.
*   **Unrecognized API parameters now produce exceptions (2011-06-21):** The API will now raise exceptions for unrecognized parameters, improving error handling and preventing silent failures.
*   **`next_recurring_charge` field removed from Customer objects (2012-03-25):** This property was removed to encourage the use of the more accurate upcoming invoice call.
*   **`amount` and `currency` properties removed from Token objects (2012-06-18):** This change streamlines token data.
*   **`uncaptured` field removed from Customer objects (2012-07-09):** This property was removed to eliminate potentially misleading information.
*   **`id` field removed from Discount objects (2012-09-24):** This change reduces data redundancy.
*   **`next_recurring_charge` field removed from Customer objects (2012-03-25):** This property was removed to encourage the use of the more accurate upcoming invoice call.
*   **`disputed` field renamed to `dispute` for Charges (2012-11-07):** This change provides more accurate terminology.
*   **Failed invoice payments now return an HTTP error (2013-02-11):** The Pay invoice call now returns an error for unsuccessful charges, improving error handling and consistency.
*   **Disputes on charges now tracked through `stripe_fee` and included in `fee_total` (2013-02-13):** Disputed charges now include dispute fees in the `fee_details` array and `fee_total`, offering more comprehensive fee information.
*   **Customers now include a `cards` sublist and `default_card` field (2013-07-05):** This change allows for managing multiple cards.
*   **`description` and `email` fields can be null on several objects (2013-08-12):** This allows for more flexibility in data management.
*   **Fee details moved from charges to balance transactions (2013-08-13):** Fee information is now centralized in balance transactions.
*   **Coupons only apply to an invoice's total balance (2013-10-29):** This change prevents unexpected increases in customer account balances.
*   **Application fees now provide an expandable `account` field (2013-12-03):** This allows for more detailed account information.
*   **Application fee refunds are now proportional to the charged amount (2013-12-03):** This provides more accurate fee adjustments.
*   **Customers now support multiple subscriptions (2014-01-31):** This change allows for managing multiple subscriptions per customer.
*   **Trial end dates no longer computed for canceled subscriptions (2014-01-31):** This prevents unexpected trial extensions.
*   **Statement descriptor field renamed on Transfers (2014-03-13):** This change improves consistency.
*   **Lists no longer include the `count` field (2014-03-28):** This streamlines response data.
*   **Transfers now use `bank_account` instead of `account` field (2014-05-19):** This provides more specific transfer destination information.
*   **Cards `type` field renamed to `brand` (2014-06-13):** This enhances clarity.
*   **Invoices now include a sublist of refunds through the `refunds` field (2014-06-17):** This offers more consistent and detailed refund information.
*   **Invoice line items now include subscription plans and quantities (2014-07-22):** This provides more context for prorations.
*   **Application fees now include a sublist of refunds through the `refunds` field (2014-07-26):** This aligns better with the charge refund structure.
*   **Balance histories can now be retrieved instead of relying on Transfer fields (2014-08-04):** This centralizes balance information.
*   **Disputes now provide several new statuses (2014-08-20):** This offers more granular dispute status information.
*   **Disputes now include multiple balance transactions (2014-08-20):** This offers more detailed fund movement information.
*   **Bank Accounts now include a `status` enum that replaces multiple fields (2014-09-08):** This simplifies the account status representation.
*   **Tokens with publishable keys can no longer be retrieved (2014-10-07):** This enhances security.
*   **Creating a Card or Bank Account with a publishable key omits fingerprints in API responses (2014-10-07):** This improves data privacy.
*   **Account activation status terms updated for payments and transfers (2014-11-05):** This better captures how properties function.
*   **Disputes are now reported as won even if the charge is refunded (2014-11-20):** This provides more accurate dispute resolution tracking.
*   **Invoice items now reflect the metadata for their associated subscription, rather than plan (2014-11-20):** This allows access to custom fields directly related to the subscription.
*   **Errors now produce exceptions for unrecognized API parameters (2011-06-21):** This improves error handling and prevents silent failures.
*   **Plans no longer include the `identifier` field (2011-06-28):** This simplifies the data structure.
*   **Lists now provide a `total_count` of items and a `data` field (2011-08-01):** This provides clearer pagination and total count information.
*   **Cards validate differently when creating tokens (2011-09-15):** This enhances security measures.
*   **Fields with null values are now included in API responses (2012-02-23):** This provides more comprehensive data representation.
*   **Customers no longer include a `next_recurring_charge` field (2012-03-25):** This encourages the use of more accurate upcoming invoice calls.
*   **Tokens no longer include the `amount` and `currency` properties (2012-06-18):** This streamlines token data.
*   **Customers no longer include the `uncaptured` field (2012-07-09):** This eliminates potentially misleading information.
*   **Discounts no longer include an extraneous `id` field (2012-09-24):** This reduces data redundancy.
*   **Invoices now include a sublist of invoice line items (2012-10-26):** This offers more detailed and manageable invoice item information.
*   **Renames the `disputed` field for Charges to `dispute` (2012-11-07):** This provides more accurate terminology.
*   **Failed invoice payments now return an HTTP error (2013-02-11):** This improves error handling and consistency.
*   **Disputes on charges are now tracked through the `stripe_fee` field and included in the `fee_total` (2013-02-13):** This offers more comprehensive fee information.
*   **Customers now include a `cards` sublist and `default_card` field (2013-07-05):** This allows for managing multiple cards.
*   **Lets the `description` and `email` fields be null on several objects (2013-08-12):** This provides more flexibility in data management.
*   **Fee details have moved from charges to their corresponding balance transactions (2013-08-13):** This centralizes fee information.
*   **Fee details have moved from transfers to their corresponding balance transactions (2013-08-13):** This centralizes fee information.
*   **Coupons only apply to an invoice's total balance, no longer applying to zero-cost invoices (2013-10-29):** This prevents unexpected increases in customer account balances.
*   **Application fees now provide an expandable `account` field to obtain user details (2013-12-03):** This allows for more detailed account information.
*   **Application fee refunds are now proportional to the charged amount (2013-12-03):** This provides more accurate fee adjustments.
*   **Customers now support multiple subscriptions (2014-01-31):** This allows for managing multiple subscriptions per customer.
*   **Trial end dates are no longer computed for canceled subscriptions (2014-01-31):** This prevents unexpected trial extensions.
*   **Renames the `statement_descriptor` field on Transfers to `statement_description` (2014-03-13):** This improves consistency.
*   **Lists no longer include the `count` field (2014-03-28):** This streamlines response data.
*   **Replaces the `account` field on Transfers with `bank_account` (2014-05-19):** This provides more specific transfer destination information.
*   **Renames the `type` field on cards to `brand` (2014-06-13):** This enhances clarity.
*   **Invoices now include a sublist of refunds through the `refunds` field (2014-06-17):** This offers more consistent and detailed refund information.
*   **Invoice line items now include subscription plans and quantities (2014-07-22):** This provides more context for prorations.
*   **Application fees now include a sublist of refunds through the `refunds` field (2014-07-26):** This aligns better with the charge refund structure.
*   **You can now retrieve balance histories rather than relying on Transfer fields (2014-08-04):** This centralizes balance information.
*   **Disputes now provide several new statuses (2014-08-20):** This offers more granular dispute status information.
*   **Disputes now include multiple balance transactions (2014-08-20):** This offers more detailed fund movement information.
*   **Bank Accounts now include a `status` enum that replaces multiple fields (2014-09-08):** This simplifies the account status representation.
*   **You can no longer retrieve tokens with publishable keys (2014-10-07):** This enhances security.
*   **Creating a Card or Bank Account with a publishable key omits fingerprints in API responses (2014-10-07):** This improves data privacy.
*   **Account activation status terms updated for payments and transfers (2014-11-05):** This better captures how properties function.
*   **Disputes are now reported as won even if the charge is refunded (2014-11-20):** This provides more accurate dispute resolution tracking.
*   **Invoice items now reflect the metadata for their associated subscription, rather than plan (2014-11-20):** This allows access to custom fields directly related to the subscription.
*   **Disputes now include an `evidence_details` object for evidence documentation (2014-12-08):** This provides more detailed evidence submission information.
*   **Introduces the `statement_description` field and logic for how charges, invoices, plans, and transfers render statement descriptors (2014-12-17):** This offers more control over statement appearance.
*   **Creating accounts using the API requires the 2014-12-17 version or newer (2014-12-17):** This ensures the use of updated features.
*   **Cards now use both the `unchecked` and `unavailable` values to describe address and CVC checks by issuing banks (2014-12-22):** This allows for more accurate understanding of check statuses.
*   **Tokens with cards no longer include the `customer` field (2014-12-22):** This simplifies the token structure.
*   **File uploads describe their file type with the simpler `type` field and `format` (2015-01-11):** This allows for working with simplified file type information.
*   **Events with the `previous_attributes` field now only render the differences to objects across updates (2015-01-26):** This provides more focused change information.
*   **Subscriptions now only report the timestamp for API or invoice payment failures for the `canceled_at` field (2015-01-26):** This consistently represents actual cancellation time.
*   **Dispute statuses now include the `warning_closed` value (2015-02-10):** This provides more granular dispute status information.
*   **Transfers now require a sufficient account balance in test mode to better simulate live mode (2015-02-10):** This aligns test mode behavior with live mode.
*   **Renames the `transfer.canceled` event type to `transfer.reversed` (2015-02-16):** This allows for more accurate identification of reversed transfers.
*   **Charges that succeed now have a `succeeded` status (2015-02-18):** This allows for more consistent identification of successful charges.
*   **Charges now have a `source` field that accepts a `source` or `card` (2015-02-18):** This broadens payment source types.
*   **Customers now have a `source` field that accepts a `source` or `card`, and updates related event types (2015-02-18):** This allows for a more flexible and comprehensive representation of payment methods.
*   **By default, coupons no longer apply to invoice items with negative amounts (2015-03-24):** This prevents unexpected discounts.
*   **Updates how ending periods are calculated on prorated invoice line items (2015-04-07):** This provides more accurate proration information.
*   **Changes the sorting order of lines for invoices (2015-04-07):** This allows access to invoice line items in a more logical and consistent order.
*   **Accounts on manual payout schedules now throw a new error (2015-06-15):** This enforces more consistent and logical behavior for manual payout schedules.
*   **Transfers submitted to the bank that haven’t arrived now provide an `in_transit` status (2015-07-07):** This helps differentiate between pending and in-transit transfers.
*   **Accounts now include the `verification[disabled_reason]` field to describe why they can’t make transfers or charges (2015-07-13):** This provides more detailed information about account verification status.
*   **Transfers that are immediately processed now trigger the `balance.available` event (2015-07-28):** This improves real-time balance tracking.
*   **Stripe now ensures the `tos_acceptance[date]` field on accounts is a valid timestamp (2015-08-07):** This enhances the validation of terms of service acceptance dates.
*   **Balance transactions with refunds or disputes now specify the corresponding ID in the `source` field (2015-08-19):** This offers more specific transaction source information.
*   **Requests that reuse idempotency tokens but alter request parameters now throw an error (2015-09-03):** This prevents unintended duplicate requests.
*   **Rate-limited requests now return an HTTP 429 error, no longer including the `rate_limit` field (2015-09-08):** This aligns with standard rate limiting practices.
*   **The `charge` field now always reflects the latest charge on invoices (2015-09-23):** This provides more comprehensive charge information.
*   **Invoices no longer include the `payment` property (2015-09-23):** This simplifies the invoice structure.
*   **Listing all charges now includes payments from all funding sources (2015-09-23):** This provides more comprehensive charge information.
*   **Charges only support an offset for list pagination when filtering by source (2015-09-23):** This encourages the use of newer pagination methods.
*   **Bank account information renamed to external accounts on user profiles (2015-10-01):** This broadens the available account types.
*   **Accounts now include an `external_accounts` field (2015-10-01):** This broadens the available account types.
*   **Using invalid parameters to create cards or bank accounts for tokens, sources, or external bank accounts now throws an HTTP 400 error (2015-10-12):** This allows for quicker error identification and correction.
*   **Creating or updating customers must now include a plan if a tax percentage is specified (2015-10-16):** This prevents inconsistent tax configurations.
*   **Accounts now only show country-specific subfields for the `legal_entity` field (2016-02-03):** This provides more focused account information.
*   **Renames the `name` field on Bank Accounts to `account_holder_name` (2016-02-19):** This provides clearer terminology and reduces potential confusion.
*   **You can no longer add more than 250 invoice items to an invoice (2016-02-22):** This limits the number of items per invoice, aiding system performance and data integrity.
*   **Orders that are paid or fulfilled, and then become canceled or returned, now automatically refund associated charges (2016-02-23):** This streamlines order management.
*   **Creating or updating an account now validates the postal code for its legal entity (2016-02-29):** This enhances data accuracy.
*   **Supported currencies are defined on the country spec for an account's country (2016-03-07):** This streamlines the Account object and simplifies data management.
*   **Deactivating a product no longer automatically deactivates its SKUs (2016-06-15):** This provides more granular product management.
*   **Filter lists of subscriptions for canceled subscriptions (2016-07-06):** This offers more comprehensive subscription management.
*   **Using insufficient permissions to make API requests now throws an HTTP 403 error (2016-10-19):** This provides more accurate error information.
*   **Balance transactions no longer include the `sourced_transfers` field (2017-01-27):** This simplifies the Balance Transaction object.
*   **Charges now specify the ID for the rule blocking a transaction, which can be expanded (2017-02-14):** This supports expandable fields.
*   **Charges now specify the ID for the dispute associated with a transaction, which can be expanded (2017-02-14):** This supports expandable fields.
*   **Transfers are now split into payouts and transfers (2017-04-06):** This introduces a clearer distinction between different types of money movement.
*   **Events for Connect now specify the originating connected account using the `account` field (2017-05-25):** This provides clearer terminology for Stripe Connect integrations.
*   **The `request` field of the Events object now specifies both the request ID and idempotency key (2017-05-25):** This allows access to more detailed information about API requests.
*   **Events with the `previous_attributes` field now render the complete affected sub-array (2017-05-25):** This provides more focused change information.
*   **Accounts must now specify one of three types (Standard, Express, or Custom) (2017-05-25):** This introduces a more nuanced classification system for Account objects.
*   **Accounts can now specify why an account isn't enabled with the new `reason` `under_review` (2017-06-05):** This introduces a more specific status for account verification.
*   **Sources can now specify that an authentication redirect isn't required (2017-08-15):** This introduces a new `not_required` status for redirects.
*   **Invoice line items now must always set a description (2017-12-14):** This ensures that all invoice line items have a description field populated.
*   **Invoice payment failures now return a `card_error` when a charge is declined (2017-12-14):** This aligns error handling with direct charges.
*   **Connect platforms can identify reused card or bank accounts across connected accounts as they now will share the same fingerprint (2018-01-23):** This provides platform users with a consistent fingerprint.
*   **Free plans with prorations now produce zero-dollar invoices (2018-02-05):** This generates a complete record of all plan changes.
*   **Subscriptions can now delay the first full invoice to a future date (and optionally include a free trial) (2018-02-05):** This enables more flexible subscription management.
*   **Products now link to individual products, with several fields moving to the `product` resource (2018-02-05):** This introduces a new relationship between Plan and Product objects.
*   **Products now require a `type` field, differentiating their use with order SKUs or subscriptions and plans (2018-02-05):** This categorizes products more accurately.
*   **Sources now provide a `recommended` value when the issuer advises using 3D Secure (2018-02-06):** This provides more nuanced information about 3D Secure availability.
*   **Updating a canceled subscription on a future date no longer resets its status (2018-02-28):** This maintains the future cancellation status of a subscription.
*   **Products no longer embed lists of SKUs (2018-05-21):** This simplifies the product data structure.
*   **Invoice line items now have unique IDs and can't be used in place of a subscription (2018-05-21):** This alters the meaning of the `id` field for subscription-type invoice line items.
*   **Coupons, SKUs, customers, products, and plans now limit the valid characters for IDs (2018-05-21):** This restricts ID characters to alphanumeric, underscores, and hyphens.
*   **Subscriptions now default to not defining their trial periods depending on a plan (2018-05-21):** This alters the default behavior for subscription trials.
*   **Changing a subscription to a new plan with a trial now extends the trial period (2018-05-21):** This allows for extended trial periods.
*   **Subscriptions no longer support modifying the `source` parameter directly (2018-07-27):** This removes the ability to directly update a subscription's payment source.
*   **Ending a subscription trial now uses the timestamp of that API request (2018-07-27):** This provides precise trial end tracking.
*   **Coupons now use floats rather than integers to specify `percent_off` (2018-07-27):** This allows for more precise discount percentages.
*   **Stripe now validates email addresses when creating or updating customers (2018-07-27):** This ensures valid email formats.
*   **A subscription’s ending period can no longer be configured while canceling it (2018-08-23):** This enforces stricter validation on cancellation requests.
*   **Customers now provide a `tax_info` object with their tax ID details (2018-08-23):** This allows for more comprehensive tax information.
*   **Renames the `amount` field for plan tiers to `unit_amount` (2018-08-23):** This provides clearer terminology.
*   **SKU values no longer need to be unique (2018-09-06):** This allows for more flexible product management.
*   **Renames the `FileUpload` object to `Files`, which now require secret keys to download files (2018-09-24):** This enhances security.
*   **Descriptions for customers now have a character limit (2018-10-31):** This requires concise descriptions.
*   **Product names now have a character limit (2018-10-31):** This requires concise product names.
*   **Descriptions for invoice line items now have a character limit (2018-10-31):** This requires concise line item descriptions.
*   **The `billing_reason` of the first invoice of a subscription is now `subscription_create` (2018-10-31):** This distinguishes initial subscription invoices.
*   **Invoices now specify their automatic collection behavior using the `auto_advance` field (2018-11-08):** This provides more specific control over the invoice lifecycle.
*   **One-off Invoices no longer automatically collect payment by default (2018-11-08):** This gives more control over invoice draft status.
*   **Replaces the `forgiven` field with a new `uncollectible` status for invoices (2018-11-08):** This provides a more specific status for uncollectible invoices.
*   **Renames an invoice error code to `invoice_already_finalized` (2018-11-08):** This provides more accurate error information.
*   **Includes several changes for users of the Payment Intents API private beta (2018-11-08):** These modifications require significant updates to existing code.
*   **Renames several statuses for PaymentIntents (2019-02-11):** This requires updates to status names.
*   **Renames the `save_source_to_customer` field for sources to `save_payment_method` (2019-02-11):** This provides more generalized terminology.
*   **Renames the `allowed_source_types` field for sources to `payment_method_types` (2019-02-11):** This provides more consistent terminology.
*   **Renames the `next_source_action` field for Payment Intents to `next_action` (2019-02-11):** This provides more generalized terminology.
*   **Renames the `authorize_with_url` field for Payment Intents to `redirect_to_url` (2019-02-11):** This provides more generalized terminology.
*   **Changes statement descriptor behaviors for card payments created with Charges (2019-02-19):** This provides more accurate branding for connected accounts.
*   **Several account fields have been refactored to better describe legal entity, verification status and requirements, and configurable settings (2019-02-19):** This provides a more structured approach to account information.
*   **Verification of accounts or persons now supports uploading both front and back sides (2019-02-19):** This restructures the verification document property and expands error reporting.
*   **Accounts no longer provide a `keys` field. Platforms should use their own API key to authenticate as their connected accounts (2019-02-19):** This introduces a new authentication method for platforms.
*   **Accounts in the US now require specifying capabilities at creation time (2019-02-19):** This mandates the inclusion of `requested_capabilities`.
*   **Renames the `business_id_number` for an account's legal entity to `business_registration_number` (2019-02-19):** This provides clearer terminology.
*   **Renames `application_fee` on invoices to `application_fee_amount` (2019-03-14):** This provides more clarity about the value.
*   **Subscriptions are now successfully created even if the first payment fails (2019-03-14):** This introduces an incomplete status for subscriptions with failed first payments.
*   **Invoices now provide timestamps for each state transition (2019-03-14):** This adds precise timing information for invoice state changes.
*   **Renames the `date` field for invoices to `created` (2019-03-14):** This aligns invoice property naming with other objects.
*   **Invoices now specify when they're finalized alongside other status transitions (2019-03-14):** This organizes invoice status change information more coherently.
*   **Makes automatic sync the default capture method for PaymentIntents when not specified (2024-04-10):** This enables asynchronous capture by default.
*   **Renames the `rendering_options` attribute for invoices to `rendering` (2024-04-10):** This simplifies the attribute's name.
*   **Renames the `features` attribute of the Product object (2024-04-10):** This defines the attribute's purpose more precisely.
*   **Adds new endpoints for managing a physical card's shipping status in test mode (2022-08-01):** This allows for more comprehensive testing of shipping-related workflows.
*   **Adds `design_rejected` as a possible cancellation reason for issued cards (2022-08-01):** This provides more granular dispute status information.
*   **Removes the `default_currency` attribute from the Customer object (2022-08-01):** This simplifies the Customer object.
*   **Default customer creation in Checkout Session payment mode changed to `if_required` (2022-08-01):** This provides more flexibility in customer creation.
*   **Deferred PaymentIntent creation in Checkout Session payment mode (2022-08-01):** This provides more flexibility and control over the payment flow.
*   **Removes the `setup_intent` property from Checkout Sessions in subscription mode (2022-08-01):** This simplifies the Checkout Session response.
*   **Replaces line item parameters from the Create Checkout Session endpoint (2022-08-01):** This simplifies the Checkout Session creation process.
*   **Removes the `subscription_data` parameter from the Create Checkout Session endpoint (2022-08-01):** This simplifies the Checkout Session creation process.
*   **Removes the `shipping_rate` parameter from Create Checkout Session endpoint (2022-08-01):** This simplifies the Checkout Session creation process.
*   **Updates Checkout Session shipping properties (2022-08-01):** This allows for clearer differentiation between shipping rate information and broader shipping details.
*   **Adds 3D Secure exemption status to card charges (2022-08-01):** This provides information about 3D Secure exemptions.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Invoices can now be numbered sequentially across your account (2020-03-02):** This provides more flexibility in invoice numbering.
*   **Removes the `tax_percent` attribute (2020-08-27):** This allows for more flexible taxation management.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Makes automatic sync the default capture method for PaymentIntents when not specified (2024-04-10):** This enables asynchronous capture by default.
*   **Renames the `rendering_options` attribute for invoices to `rendering` (2024-04-10):** This simplifies the attribute's name.
*   **Renames the `features` attribute of the Product object (2024-04-10):** This defines the attribute's purpose more precisely.
*   **Adds new endpoints for managing a physical card’s shipping status in test mode (2022-08-01):** This allows for more comprehensive testing of shipping-related workflows.
*   **Adds `design_rejected` as a possible cancellation reason for issued cards (2022-08-01):** This provides more granular dispute status information.
*   **Removes the `default_currency` attribute from the Customer object (2022-08-01):** This simplifies the Customer object.
*   **Default customer creation in Checkout Session payment mode changed to `if_required` (2022-08-01):** This provides more flexibility in customer creation.
*   **Deferred PaymentIntent creation in Checkout Session payment mode (2022-08-01):** This provides more flexibility and control over the payment flow.
*   **Removes the `setup_intent` property from Checkout Sessions in subscription mode (2022-08-01):** This simplifies the Checkout Session response.
*   **Replaces line item parameters from the Create Checkout Session endpoint (2022-08-01):** This simplifies the Checkout Session creation process.
*   **Removes the `subscription_data` parameter from the Create Checkout Session endpoint (2022-08-01):** This simplifies the Checkout Session creation process.
*   **Removes the `shipping_rate` parameter from Create Checkout Session endpoint (2022-08-01):** This simplifies the Checkout Session creation process.
*   **Updates Checkout Session shipping properties (2022-08-01):** This allows for clearer differentiation between shipping rate information and broader shipping details.
*   **Adds 3D Secure exemption status to card charges (2022-08-01):** This provides information about 3D Secure exemptions.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new decline codes to the PaymentIntent and PaymentMethod APIs (2022-11-15):** This provides more detailed information about payment declines.
*   **Adds new decline codes to the SetupIntent API (2022-11-15):** This provides more detailed information about SetupIntent declines.
*   **Adds a new structure error code to the Accounts API (2022-11-15):** This provides specific error reporting for account verification issues.
*   **The Charges object no longer auto-expands refunds by default (2022-11-15):** This improves API response times.
*   **Removes the `charges` attribute from the PaymentIntent object (2022-11-15):** This simplifies the PaymentIntent object.
*   **Adds new account requirement error codes to the Accounts API (2023-10-16):** This provides specific error messages for account issues.
*   **Auto-populates the statement descriptor and prefix in the Accounts API (2023-10-16):** This provides more accurate branding for connected accounts.
*   **Adds new director verification error codes to the Accounts API (2023-08-16):** This provides specific information about director verification problems.
*   **Enables automatic payment methods by default for PaymentIntents and SetupIntents (2023-08-16):** This allows for configuration through the Stripe Dashboard.
*   **One-time payments in Checkout Sessions support no-cost orders (2023-08-16):** This simplifies the checkout process for free items.
*   **Platform-scope rendering for select PaymentMethod fingerprints (2023-08-16):** This aligns with previous changes for cards and bank accounts.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This provides more detailed information about Klarna payment failures.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Customer subscriptions are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Plan tiers are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Customer sources are no longer auto-expanded by default (2020-08-27):** This optimizes API response performance.
*   **Tax IDs are no longer auto-expanded on the Customer object (2020-08-27):** This optimizes API response performance.
*   **Deprecates subscription `prorate` and `subscription_prorate` parameters (2020-08-27):** This allows for more precise configuration of prorating.
*   **Renames `phases` attributes in subscription schedules (2020-08-27):** This provides clearer terminology for subscription schedule management.
*   **Renames event type that triggers on automatic updates (2020-08-27):** This provides a more generic and flexible way to handle payment method updates.
*   **Removes the `display_items` property from Checkout Sessions (2020-08-27):** This consolidates line item information.
*   **Formats requirements for key persons associated with accounts (2020-08-27):** This creates a more intuitive naming convention for requirements.
*   **Adds new error codes to the Accounts, Persons, and Capabilities APIs (2020-08-27):** This provides more granular error reporting.
*   **Updates to 3D Secure details in Charge object (2020-08-27):** This allows for more accurate determination of 3D Secure status.
*   **Adds support for custom UI mode to Checkout Sessions (2019-02-19):** This enables the creation of custom checkout pages.
*   **Adds permissions parameter to Checkout Sessions (2019-02-19):** This allows for server-only configuration of certain properties.
*   **Adds presentment details for Adaptive Pricing Subscriptions (2026-03-25):** This allows for localized pricing.
*   **Adds support for configurable trial offers for subscription items (2026-03-25):** This allows for extended trial periods.
*   **Adds support for custom BBPOS WisePad 3 splash screens (2025-09-30):** This allows for custom splash screens on Terminal readers.
*   **Adds support for MXN currency in Terminal tipping configuration (2025-08-27):** This allows for custom tipping currency configurations.
*   **Adds support for PayNow on Terminal (2025-08-27):** This allows for in-person PayNow payments.
*   **Adds a Charge transaction ID for several payment methods (2025-08-27):** This helps match and reconcile transactions.
*   **Adds a new webhook event type for updated receipt data in Issuing transactions (2020-08-27):** This allows for monitoring changes to receipt data.
*   **Adds new enum values for request history reasons (2019-09-09):** This provides more precise tracking of authorization request reasons.
*   **Deprecates alphanumeric\_id for Issuing Authorization (2024-06-20):** This provides clearer categorization of identifiers.
*   **Adds new enum values for disabled reasons (2024-06-20):** This provides more specific information about capability disability.
*   **Deprecates the `bank_transfer_payments` capability type in favor of newer capability types (2024-06-20):** This provides more specific, location-based capabilities.
*   **Adds specific error codes for failed Klarna payments (2023-08-16):** This

<!-- truncated by AI -->
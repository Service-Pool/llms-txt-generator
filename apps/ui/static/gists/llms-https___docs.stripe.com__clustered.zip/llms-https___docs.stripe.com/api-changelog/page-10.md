## Stripe API Changelog: Key Updates and Changes

This document outlines significant changes and updates to the Stripe API, categorized by product area and type of change (breaking or generally available). The changelog provides a historical overview of API evolution, detailing new features, deprecations, and modifications to existing functionalities.

### Key Areas of API Evolution:

The Stripe API has undergone continuous development to enhance functionality, improve security, and streamline user experience. Key areas of evolution include:

*   **Payments:** This category encompasses changes related to charges, refunds, payment methods, and the overall payment process. Updates often focus on improving transaction handling, introducing new payment options, and refining error reporting for payment-related operations.
*   **Billing:** This area covers changes related to subscriptions, invoices, plans, and coupons. Updates in this category often involve modifications to how recurring payments are managed, how invoices are generated and processed, and how discounts are applied.
*   **Connect:** This section details changes relevant to Stripe Connect, which enables platforms to manage payments and operations for their connected accounts. Updates often focus on improving platform-to-account interactions, data sharing, and compliance features.
*   **Issuing:** This area covers changes related to Stripe Issuing, which allows businesses to create and manage their own physical and virtual cards. Updates typically involve new card features, transaction details, and risk management capabilities.
*   **Other Product Areas:** The Stripe API is constantly evolving, with updates also impacting areas such as:
    *   **Checkout:** Enhancements to the checkout flow, including new payment methods and UI configurations.
    *   **Terminal:** Improvements to in-person payment processing and reader management.
    *   **Tax:** Updates to tax calculation, registration, and reporting functionalities.
    *   **Money Management:** New APIs and features for managing financial accounts, payouts, and transfers.
    *   **Identity:** Enhancements to identity verification processes and data collection.

### Notable Changes and Features:

The following are some of the key changes and features introduced across various Stripe API updates:

*   **Enhanced Data and Functionality:**
    *   **Accounts API:** Introduction of `ownership_exemption_reason` for account ownership exceptions, refined `type` field for account classification (Standard, Express, Custom), and improved verification and risk assessment details.
    *   **Payment Intents & Setup Intents:** Updates to status fields, introduction of `next_action` and `redirect_to_url` for handling authentication redirects, and new decline codes for improved error handling.
    *   **Invoices:** Changes to how prorations and line items are handled, including the introduction of `lines` as a sublist, and the ability to specify `auto_advance` behavior.
    *   **Subscriptions:** Support for multiple subscriptions per customer, delayed first invoice dates, and changes to trial period handling.
    *   **Disputes:** New dispute statuses, including `warning_needs_response` and `charge_refunded`, and improved tracking of dispute-related balance transactions.
    *   **Products & SKUs:** Changes to how products and SKUs are managed, including linking plans to individual products and removing the uniqueness requirement for SKU attribute values.
    *   **Files API:** Renaming of `FileUpload` to `File` and introduction of authenticated URLs for secure file downloads.
    *   **Terminal:** Support for new payment methods (e.g., Pay by Bank, Multibanco, Twint, Zip, Konbini, Satispay, WeChat Pay, Affirm), configurable reboot times, and improved shipping address validation.
    *   **Billing:** Introduction of flexible billing modes, support for subscription item-level billing periods, and new webhook events for billing meters and credits.
    *   **Tax:** Support for new countries in Tax Registration, new tax ID types, and the ability to specify tax calculation providers.
    *   **Connect:** Enhancements to Account Links v2 API, support for PayPay onboarding, and restructuring of account-related fields for better clarity.
    *   **Radar:** New error codes for various scenarios, including invalid parameters and unsupported business types.
    *   **Treasury:** Introduction of new balance transaction types for tracking reserve activity and payout methods.

*   **API Structure and Naming Conventions:**
    *   Several fields and parameters have been renamed for clarity and consistency (e.g., `disputed` to `dispute`, `statement_descriptor` to `statement_description`, `next_source_action` to `next_action`).
    *   Some properties have been moved to nested objects or subhashes (e.g., `legal_entity` fields, `verification` to `requirements`, `billing` to `collection_method`, `statement_descriptor` to `settings`).
    *   Deprecated fields and parameters have been removed or replaced with newer alternatives to streamline API usage.

*   **Security and Compliance:**
    *   Improvements in security by preventing publishable keys from retrieving Token objects and omitting fingerprints in API responses when creating cards or bank accounts with publishable keys.
    *   Stricter validation for email addresses and postal codes to ensure data accuracy.
    *   Introduction of features to comply with Know Your Customer (KYC) requirements, such as directorship declarations and support for various identity document types.

This comprehensive changelog reflects Stripe's commitment to continuously improving its API, providing developers with powerful tools and a robust platform for managing payments and financial operations. It is recommended to review these changes and update integrations accordingly to leverage new features and maintain compatibility.
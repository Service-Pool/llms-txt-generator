```markdown
# Stripe API Changelog

This document outlines the changes and updates made to the Stripe API over time. It is organized by release date, with each entry detailing the specific modifications and their impact.

## Key Changes and Updates

The Stripe API has undergone numerous changes to improve functionality, security, and user experience. Here's a summary of significant updates:

### Accounts and Connect

*   **Ownership Exemption Reason (2025-01-27):** Added `ownership_exemption_reason` parameter to the `company` field of the Accounts resource to support exceptions to Know Your Customer (KYC) requirements.
*   **Account Activation Status Terms Updated (2014-11-05):** Renamed `charge_enabled` and `transfer_enabled` properties on the Account object to `charges_enabled` and `transfers_enabled` for better clarity.
*   **Account Capabilities Requirements (2019-02-19, 2019-09-09, 2020-08-27, 2023-08-16):** Introduced requirements for `requested_capabilities` during account creation for specific countries and account types.
*   **Account Verification Fields Refactored (2019-02-19):** Refactored verification-related fields, including `verification[disabled_reason]` to `requirements[disabled_reason]`, and introduced new error types for document verification.
*   **Accounts Now Support Digital Attestation (2025-10-29):** Added `representative_declaration` parameters to the Accounts API for recording attestation of authorized company representatives.
*   **Accounts v2 Improvements (2025-08-27, 2025-09-30, 2025-10-29, 2025-11-17, 2025-12-15):** Introduced significant updates to the Accounts v2 API, including support for deactivating configurations, new event types, improved identity field handling, and more.
*   **Global Payouts Expansion (2025-04-30, 2025-12-15, 2026-01-28):** Added support for new countries and currencies for cross-border payouts, and introduced the `payout_method` field for v2 Payout Methods.
*   **PayPay Onboarding Parameters (2025-11-17):** Added PayPay onboarding parameters to the Accounts API for connected accounts.
*   **Statement Descriptor Logic Updated (2014-12-17):** Introduced the `statement_description` field and updated logic for how charges, invoices, plans, and transfers render statement descriptors.

### Billing and Subscriptions

*   **Ownership Exemption Reason (2025-01-27):** Added `ownership_exemption_reason` to the `company` field of Accounts API.
*   **Coupons Behavior Changes (2013-10-29, 2015-03-24):** Modified coupon behavior to apply only to an invoice's total balance and not to zero-cost invoices.
*   **Customer Balance Transactions (2015-08-19, 2019-12-03, 2025-11-17):** Updated `source` field for balance transactions to specify the corresponding ID for refunds or disputes. Introduced new transaction types for payments from Stripe balance and added filtering by creation date.
*   **Disputes Updates (2012-11-07, 2014-08-20, 2014-11-20, 2015-02-10, 2018-01-23, 2025-09-30):** Renamed `disputed` to `dispute` for Charges, added new statuses for disputes, updated dispute reporting to include refunded charges, and introduced dispute prevention features.
*   **Events API Enhancements (2017-05-25):** Updated the `request` field to include both request ID and idempotency key, and improved rendering of `previous_attributes` to show complete sub-arrays.
*   **Failed Invoice Payments (2013-02-11):** Now return an HTTP error for failed invoice payments.
*   **Invoice Line Items Updates (2012-10-26, 2014-07-22, 2017-12-14, 2018-05-21, 2019-03-14, 2019-12-03, 2025-06-30, 2026-03-25):** Invoices now include a sublist of invoice line items, and invoice line items must always have a description. Also standardized invoice line item IDs and added decimal quantity support.
*   **Invoices and Automatic Collection (2018-11-08):** Introduced the `auto_advance` field to control automatic collection behavior, and made one-off invoices not automatically collect payment by default.
*   **New Billing Features (2024-09-30, 2025-03-31, 2025-04-30, 2025-06-30, 2025-07-30, 2025-08-27, 2025-09-30, 2025-10-29, 2025-11-17, 2025-12-15, 2026-01-28, 2026-03-25):** Introduced several enhancements to Billing, including new alerts API, support for subscriptions and subscription items in billing alerts, contextual filters for billing alerts, invoice rendering templates, webhook events for due/overdue invoices, and more.
*   **Plans and Products Restructuring (2018-02-05):** Plans now link to individual products, with several fields moved to the product resource. Products now require a `type` field.
*   **Subscriptions Updates (2014-01-31, 2018-02-05, 2018-02-28, 2018-07-27, 2019-03-14, 2020-08-27, 2025-03-31, 2025-06-30, 2025-07-30, 2026-03-25):** Customers now support multiple subscriptions, trial end dates are no longer computed for canceled subscriptions, and updates to canceled subscriptions no longer reset their status. Flexible billing mode is now the default for new subscriptions.
*   **Tax Features Expansion (2015-10-16, 2019-12-03, 2020-08-27, 2022-08-01, 2023-10-16, 2024-09-30, 2025-04-30, 2025-09-30, 2025-10-29, 2025-12-15):** Added support for tax IDs in new countries, updated address validations for tax, introduced new error codes for tax-related issues, and added support for third-party tax providers.

### Payments and Checkout

*   **Application Fees (2013-12-03, 2014-07-26):** Application fees now provide an expandable account field and refunds are proportional to the charged amount.
*   **Cards and Tokens (2011-09-15, 2012-06-18, 2014-12-22):** Cards validate differently when creating tokens, tokens no longer include amount and currency properties, and tokens with cards no longer include the customer field.
*   **Charges Updates (2012-11-07, 2015-02-18, 2018-02-14, 2018-05-21, 2019-02-19, 2020-08-27, 2022-11-15):** Renamed `disputed` to `dispute` for Charges, charges that succeed now have a `succeeded` status, and statement descriptor behaviors have changed.
*   **Checkout Sessions Enhancements (2022-08-01, 2023-08-16, 2024-06-20, 2024-09-30, 2025-02-24, 2025-03-31, 2025-09-30, 2025-10-29, 2025-11-17, 2025-12-15, 2026-03-25):** Introduced features like default customer creation to `if_required`, deferred PaymentIntent creation, removal of `setup_intent` and `shipping_rate` parameters, support for line item updates, branding settings, and more.
*   **Payment Intents and Sources (2015-02-18, 2018-02-11, 2018-07-27, 2019-02-11):** Charges now have a `source` field, statuses for PaymentIntents have been renamed, and subscription trial ending uses the API request timestamp.
*   **New Payment Methods:** Added support for various local payment methods including Multibanco, Twint, Zip, Pay by Bank, Billie, Satispay, and more.

### Other Notable Updates

*   **API Parameter Changes:** Several API parameters have been renamed, deprecated, or had their behavior modified to improve clarity and consistency.
*   **Error Handling Improvements:** New error codes and more specific error messages have been introduced to aid in debugging and integration.
*   **SDK Enhancements:** Support for new features and API versions has been added to Stripe SDKs.

This changelog provides a comprehensive overview of the API updates. For detailed information on each change, please refer to the specific release notes.
```
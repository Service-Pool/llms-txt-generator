```markdown
## Stripe API Changelog: Key Updates and Changes

This document outlines significant updates and changes to the Stripe API across various product areas, including Payments, Billing, Connect, Issuing, Terminal, and more. These updates range from new feature introductions and parameter renames to deprecations and breaking changes that may require adjustments to your integrations.

### Key Changes and New Features:

**Payments**

*   **Ownership Exemption Reason for Accounts API (Acacia):** The `ownership_exemption_reason` parameter has been added to the `company` field of the Accounts resource. This allows businesses to provide an exemption reason for Ultimate Beneficial Ownership (UBO) requirements.
*   **Unrecognized API Parameters Error Handling (2011-06-21):** The API now raises exceptions for unrecognized parameters, improving error handling and preventing silent failures.
*   **Plan Object Changes (2011-06-28):** The `identifier` field has been removed from the Plan object, as it was a duplicate of the `id` field.
*   **List Format Updates (2011-08-01):** List objects now include a `data` property (an array of objects) and a `count` property (total count of items).
*   **Token Validation Changes (2011-09-15):** Card validation behavior when creating tokens has been updated.
*   **Null Values in API Responses (2012-02-23):** Fields with null values are now included in API responses for more comprehensive data representation.
*   **Customer Object Changes (2012-03-25, 2012-07-09):** The `next_recurring_charge` and `uncaptured` fields have been removed from the Customer object.
*   **Token Properties Removal (2012-06-18):** The `amount` and `currency` properties have been removed from the Token object.
*   **Discount Object Change (2012-09-24):** The extraneous `id` property has been removed from the Discount object.
*   **Invoice Line Items Sublist (2012-10-26):** The `lines` property on the Invoice object is now a paginated sublist.
*   **Charge Field Rename (2012-11-07):** The `disputed` field for Charges has been renamed to `dispute`.
*   **Failed Invoice Payments (2013-02-11):** Failed invoice payments now return an HTTP error.
*   **Dispute Fee Tracking (2013-02-13):** Disputes on charges are now tracked through the `stripe_fee` field and included in the fee total.
*   **Customer Cards and Default Card (2013-07-05):** The `active_card` property on the Customer object has been replaced with `cards` (a sublist) and `default_card` (an ID).
*   **Null Description and Email Fields (2013-08-12):** The `description` and `email` fields can now be null on several objects.
*   **Fee Details Moved to Balance Transactions (2013-08-13, 2013-08-13):** Fee details have moved from Charges and Transfers to their corresponding balance transactions.
*   **Coupon Behavior Change (2013-10-29):** Coupons only apply to an invoice's total balance and no longer apply to zero-cost invoices.
*   **Application Fees and Account Field (2013-12-03):** Application fees now provide an expandable `account` field to obtain user details.
*   **Application Fee Refunds Proportionality (2013-12-03):** Application fee refunds are now proportional to the charged amount.
*   **Customer Subscriptions Support (2014-01-31):** Customers now support multiple subscriptions.
*   **Subscription Trial End Dates (2014-01-31):** Trial end dates are no longer computed for canceled subscriptions.
*   **Statement Descriptor Field Rename (2014-03-13):** The `statement_descriptor` field on Transfers has been renamed to `statement_description`.
*   **List Count Field Removal (2014-03-28):** Lists no longer include the `count` field.
*   **Transfer Account Field Replacement (2014-05-19):** The `account` field on Transfers has been replaced with `bank_account`.
*   **Card Type Field Rename (2014-06-13):** The `type` field on Cards has been renamed to `brand`.
*   **Invoice Refunds Sublist (2014-06-17):** Invoices now include a sublist of refunds through the `refunds` field.
*   **Invoice Line Items Include Subscription Details (2014-07-22):** Invoice line items now include subscription plans and quantities.
*   **Application Fees Include Refunds Sublist (2014-07-26):** Application fees now include a sublist of refunds through the `refunds` field.
*   **Balance Histories Retrieval (2014-08-04):** Balance histories can now be retrieved rather than relying on Transfer fields.
*   **Dispute Statuses Update (2014-08-20):** Disputes now provide several new statuses.
*   **Disputes Include Multiple Balance Transactions (2014-08-20):** Disputes now include multiple balance transactions.
*   **Bank Accounts Status Enum (2014-09-08):** Bank Accounts now include a `status` enum that replaces multiple fields.
*   **Token Retrieval with Publishable Keys (2014-10-07):** Tokens can no longer be retrieved with publishable keys.
*   **Card/Bank Account Creation Fingerprint Omission (2014-10-07):** Creating a Card or Bank Account with a publishable key omits fingerprints in API responses.
*   **Account Activation Status Terms Updated (2014-11-05):** Account activation status terms have been updated for payments and transfers.
*   **Disputes Won with Refunded Charge (2014-11-20):** Disputes are now reported as won even if the charge is refunded.
*   **Invoice Items Reflect Subscription Metadata (2014-11-20):** Invoice items now reflect the metadata for their associated subscription, rather than plan.
*   **Dispute Evidence Details Object (2014-12-08):** Disputes now include an `evidence_details` object for evidence documentation.
*   **Statement Descriptor Field Introduction (2014-12-17):** The `statement_description` field and logic for how charges, invoices, plans, and transfers render statement descriptors have been introduced.
*   **Account Creation API Version Requirement (2014-12-17):** Creating accounts using the API requires the 2014-12-17 version or newer.
*   **Card Address/CVC Check Values (2014-12-22):** Cards now use both the `unchecked` and `unavailable` values to describe address and CVC checks by issuing banks.
*   **Token Customer Field Removal (2014-12-22):** Tokens with cards no longer include the `customer` field.
*   **File Upload Type and Format (2015-01-11):** File uploads describe their file type with the simpler `type` field and format.
*   **Event Previous Attributes Rendering (2015-01-26):** Events with the `previous_attributes` field now only render the differences to objects across updates.
*   **Subscription API Invoice Failures (2015-01-26):** Subscriptions now only report the timestamp for API or invoice payment failures for the `canceled_at` field.
*   **Dispute Statuses Include Warning Closed (2015-02-10):** Dispute statuses now include the `warning_closed` value.
*   **Transfers Require Sufficient Balance (2015-02-10):** Transfers now require a sufficient account balance in test mode to better simulate live mode.
*   **Transfer Canceled Event Rename (2015-02-16):** The `transfer.canceled` event type is now `transfer.reversed`.
*   **Charge Succeeded Status (2015-02-18):** Charges that succeed now have a `succeeded` status.
*   **Charge Source Field (2015-02-18):** Charges now have a `source` field that accepts a source or card.
*   **Customer Source Field (2015-02-18):** Customers now have a `source` field that accepts a source or card, and updates related event types.
*   **Coupon Negative Invoice Items (2015-03-24):** By default, coupons no longer apply to invoice items with negative amounts.
*   **Invoice Line Item Ending Periods (2015-04-07):** Updates how ending periods are calculated on prorated invoice line items.
*   **Invoice Lines Sorting Order (2015-04-07):** Changes the sorting order of lines for invoices.
*   **Account Manual Payout Schedules Error (2015-06-15):** Accounts on manual payout schedules now throw a new error.
*   **Transfer In Transit Status (2015-07-07):** Transfers submitted to the bank that haven't arrived now provide an `in_transit` status.
*   **Account Verification Disabled Reason (2015-07-13):** Accounts now include the `verification[disabled_reason]` field to describe why they can't make transfers or charges.
*   **Balance Available Event for Immediate Transfers (2015-07-28):** Transfers that are immediately processed now trigger the `balance.available` event.
*   **Account TOS Acceptance Date Validation (2015-08-07):** Stripe now ensures the `tos_acceptance[date]` field on accounts is a valid timestamp.
*   **Balance Transactions Source Field (2015-08-19):** Balance transactions with refunds or disputes now specify the corresponding ID in the `source` field.
*   **Idempotency Token Reuse Error (2015-09-03):** Requests that reuse idempotency tokens but alter request parameters now throw an error.
*   **Rate-Limited Requests HTTP 429 Error (2015-09-08):** Rate-limited requests now return an HTTP 429 error, no longer including the `rate_limit` field.
*   **Invoice Charge Field Latest Charge (2015-09-23):** The `charge` field now always reflects the latest charge on invoices.
*   **Invoice Payment Property Removal (2015-09-23):** Invoices no longer include the `payment` property.
*   **Listing Charges Funding Sources (2015-09-23):** Listing all charges now includes payments from all funding sources.
*   **Charges List Pagination Offset (2015-09-23):** Charges only support an offset for list pagination when filtering by source.
*   **Bank Account Information Renamed to External Accounts (22015-10-01):** Bank account information renamed to external accounts on user profiles.
*   **Accounts Include External Accounts Field (2015-10-01):** Accounts now include an `external_accounts` field.
*   **Invalid Parameters Throw HTTP 400 Error (2015-10-12):** Using invalid parameters to create cards or bank accounts for tokens, sources, or external bank accounts now throws an HTTP 400 error.
*   **Customer Plan Tax Percentage Requirement (2015-10-16):** Creating or updating customers must now include a plan if a tax percentage is specified.
*   **Account Legal Entity Country-Specific Subfields (2016-02-03):** Accounts now only show country-specific subfields for the `legal_entity` field.
*   **Bank Account Name Field Rename (2016-02-19):** Renames the `name` field on Bank Accounts to `account_holder_name`.
*   **Invoice Items Limit (2016-02-22):** You can no longer add more than 250 invoice items to an invoice.
*   **Order Cancellation Refunds (2016-02-23):** Orders that are paid or fulfilled, and then become canceled or returned, now automatically refund associated charges.
*   **Account Postal Code Validation (2016-02-29):** Creating or updating an account now validates the postal code for its legal entity.
*   **Supported Currencies Defined by Country Spec (2016-03-07):** Supported currencies are defined on the country spec for an account's country.
*   **Product Deactivation SKU Deactivation (2016-06-15):** Deactivating a product no longer automatically deactivates its SKUs.
*   **Filter Canceled Subscriptions (2016-07-06):** Filter lists of subscriptions for canceled subscriptions.
*   **Insufficient Permissions HTTP 403 Error (2016-10-19):** Using insufficient permissions to make API requests now throws an HTTP 403 error.
*   **Balance Transactions Sourced Transfers Removal (2017-01-27):** Balance transactions no longer include the `sourced_transfers` field.
*   **Charge Rule Blocking Transaction ID (2017-02-14):** Charges now specify the ID for the rule blocking a transaction, which can be expanded.
*   **Charge Dispute Association (2017-02-14):** Charges now specify the ID for the dispute associated with a transaction, which can be expanded.
*   **Transfers Split into Payouts and Transfers (2017-04-06):** Transfers are now split into payouts and transfers.
*   **Connect Events Originating Account (2017-05-25):** Events for Connect now specify the originating connected account using the `account` field.
*   **Events Request ID and Idempotency Key (2017-05-25):** The `request` field of the Events object now specifies both the request ID and idempotency key.
*   **Events Previous Attributes Sub-array Rendering (2017-05-25):** Events with the `previous_attributes` field now render the complete affected sub-array.
*   **Account Types (Standard, Express, Custom) (2017-05-25):** Accounts must now specify one of three types (Standard, Express, or Custom).
*   **Account Under Review Reason (2017-06-05):** Accounts can now specify why an account isn't enabled with the new `reason under_review`.
*   **Source Authentication Redirect (2017-08-15):** Sources can now specify that an authentication redirect isn't required.
*   **Invoice Line Items Description Requirement (2017-12-14):** Invoice line items now must always set a description.
*   **Invoice Payment Failures Card Error (2017-12-14):** Invoice payment failures now return a `card_error` when a charge is declined.
*   **Connect Reused Card/Bank Account Fingerprint (2018-01-23):** Connect platforms can identify reused card or bank accounts across connected accounts as they now will share the same fingerprint.
*   **Free Plans with Prorations Zero-Dollar Invoices (2018-02-05):** Free plans with prorations now produce zero-dollar invoices.
*   **Subscription Delay First Full Invoice (2018-02-05):** Subscriptions can now delay the first full invoice to a future date (and optionally include a free trial).
*   **Plan Link to Products (2018-02-05):** Plans now link to individual products, with several fields moving to the product resource.
*   **Product Type Field Requirement (2018-02-05):** Products now require a `type` field, differentiating their use with order SKUs or subscriptions and plans.
*   **Source Recommended 3D Secure (2018-02-06):** Sources now provide a recommended value when the issuer advises using 3D Secure.
*   **Canceled Subscription Update Status (2018-02-28):** Updating a canceled subscription on a future date no longer resets its status.
*   **Product SKU List Removal (2018-05-21):** Products no longer embed lists of SKUs.
*   **Invoice Line Items Unique IDs (2018-05-21):** Invoice line items now have unique IDs and can't be used in place of a subscription.
*   **Coupon, SKU, Customer, Product, Plan ID Character Limits (2018-05-21):** Coupons, SKUs, customers, products, and plans now limit the valid characters for IDs.
*   **Subscription Trial Period Default (2018-05-21):** Subscriptions now default to not defining their trial periods depending on a plan.
*   **Subscription Plan Change Trial Extension (2018-05-21):** Changing a subscription to a new plan with a trial now extends the trial period.
*   **Subscription Source Parameter Modification (2018-07-27):** Subscriptions no longer support modifying the `source` parameter directly.
*   **Subscription Trial End Timestamp (2018-07-27):** Ending a subscription trial now uses the timestamp of that API request.
*   **Coupon Percent Off Floats (2018-07-27):** Coupons now use floats rather than integers to specify `percent_off`.
*   **Customer Email Validation (2018-07-27):** Stripe now validates email addresses when creating or updating customers.
*   **Subscription Ending Period Configuration (2018-08-23):** A subscription's ending period can no longer be configured while canceling it.
*   **Customer Tax Info Object (2018-08-23):** Customers now provide a `tax_info` object with their tax ID details.
*   **Plan Tiers Amount Field Rename (2018-08-23):** Renames the `amount` field for plan tiers to `unit_amount`.
*   **SKU Values Uniqueness Removed (2018-09-06):** SKU values no longer need to be unique.
*   **FileUpload Object Rename to Files (2018-09-24):** Renames the FileUpload object to Files, which now require secret keys to download files.
*   **Customer Description Character Limit (2018-10-31):** Descriptions for customers now have a character limit.
*   **Product Name Character Limit (2018-10-31):** Product names now have a character limit.
*   **Invoice Line Item Description Character Limit (2018-10-31):** Descriptions for invoice line items now have a character limit.
*   **Subscription First Invoice Billing Reason (2018-10-31):** The `billing_reason` of the first invoice of a subscription is now `subscription_create`.
*   **Invoice Auto Advance Field (2018-11-08):** Invoices now specify their automatic collection behavior using the `auto_advance` field.
*   **One-off Invoice Payment Default (2018-11-08):** One-off Invoices no longer automatically collect payment by default.
*   **Invoice Forgiven Field Replaced (2018-11-08):** Replaces the `forgiven` field with a new `uncollectible` status for invoices.
*   **Invoice Error Code Rename (2018-11-08):** Renames an invoice error code to `invoice_already_finalized`.
*   **Payment Intents API Private Beta Changes (2018-11-08):** Includes several changes for users of the Payment Intents API private beta.
*   **Payment Intents Status Renames (2019-02-11):** Renames several statuses for PaymentIntents.
*   **Source Save Field Rename (2019-02-11):** Renames the `save_source_to_customer` field for sources to `save_payment_method`.
*   **Source Allowed Types Field Rename (2019-02-11):** Renames the `allowed_source_types` field for sources to `payment_method_types`.
*   **Payment Intents Next Source Action Rename (2019-02-11):** Renames the `next_source_action` field for Payment Intents to `next_action`.
*   **Payment Intents Authorize With URL Rename (2019-02-11):** Renames the `authorize_with_url` field for Payment Intents to `redirect_to_url`.
*   **Charges Statement Descriptor Behaviors (2019-02-19):** Changes statement descriptor behaviors for card payments created with Charges.
*   **Account Fields Refactored (2019-02-19):** Several account fields have been refactored to better describe legal entity, verification status and requirements, and configurable settings.
*   **Account Business Details Moved (2019-02-19):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Account/Person Verification Front/Back Support (2019-02-19):** Verification of accounts or persons now supports uploading both front and back sides.
*   **Account Keys Field Removal (2019-02-19):** Accounts no longer provide a `keys` field. Platforms should use their own API key to authenticate as their connected accounts.
*   **US Accounts Requested Capabilities (2019-02-19):** Accounts in the US now require specifying capabilities at creation time.
*   **Account Legal Entity Business ID Number Rename (2019-02-19):** Renames the `business_id_number` for an account's legal entity to `business_registration_number`.
*   **Invoice Application Fee Rename (2019-03-14):** Renames `application_fee` on invoices to `application_fee_amount`.
*   **Subscription First Payment Failure (2019-03-14):** Subscriptions are now successfully created even if the first payment fails.
*   **Invoice State Transition Timestamps (2019-03-14):** Invoices now provide timestamps for each state transition.
*   **Invoice Date Field Rename (2019-03-14):** Renames the `date` field for invoices to `created`.
*   **Invoice Finalized Alongside Status Transitions (2019-03-14):** Invoices now specify when they're finalized alongside other status transitions.
*   **Connect Platform Payments Capability Rename (2019-08-14):** Renames the `platform_payments` capability for accounts to `card_payments`, requiring the manual specification of the added `transfers` capability.
*   **Person Account Opener Executive Setting (2019-08-14):** Configuring a person as an account opener no longer automatically sets them as an executive.
*   **Accounts Many Countries Capabilities (2019-09-09):** Accounts in many countries now require specifying capabilities at creation time.
*   **Person Document Verification Details Code (2019-09-09):** Adds new `details_code` values to person document verification.
*   **Person Object Relationship Attribute Rename (2019-10-08):** Renames a Person object relationship attribute.
*   **Subscription Schedule Renewal Properties Update (2019-10-17):** Renames and updates subscription schedule renewal properties.
*   **Subscription Start Field Replaced (2019-10-17):** Replaces the `subscription start` field with `start_date`.
*   **Billing Attribute Rename (2019-10-17):** Renames `billing` to `collection_method` on invoices, subscriptions, and subscription schedules.
*   **Invoice Due Date Null (2019-10-17):** The `due_date` property is always null on auto-billed invoices.
*   **Customer Account Balance Rename (2019-10-17):** Renames `account_balance` to `balance` on Customer object.
*   **Custom Account Creation Requested Capabilities (2019-11-05):** Adds requirement for `requested_capabilities` on custom account creation.
*   **Subscription Schedule Settings Nesting (2019-11-05):** Nested subscription schedule settings under `default_settings`.
*   **Invoice Line Item IDs Standardized (2019-12-03):** Standardizes invoice line item IDs.
*   **Post-Payment Credit Note Requirement (2019-12-03):** New requirement for `out_of_band_amount` when creating post-payment credit notes.
*   **Customer Balances Returned Voided Invoices (2019-12-03):** Customer balances are now returned when voiding invoices.
*   **Deprecated Tax Information Fields Removal (2019-12-03):** Removes deprecated tax information fields from the Customer object.
*   **Sequential Invoice Numbering (2020-03-02):** Invoices can now be numbered sequentially across your account.
*   **Tax Percent Attribute Removal (2020-08-27):** Removes the `tax_percent` attribute.
*   **Customer Sources Auto-Expansion Deprecation (2020-08-27):** Customer sources are no longer auto-expanded by default.
*   **Customer Tax IDs Auto-Expansion Deprecation (2020-08-27):** Tax IDs are no longer auto-expanded on the Customer object.
*   **Subscription Prorate Parameters Deprecation (2020-08-27):** Deprecates `prorate` and `subscription_prorate` parameters.
*   **Subscription Schedule Phases Attributes Rename (2020-08-27):** Renames phases attributes in subscription schedules.
*   **Automatic Updates Event Type Rename (2020-08-27):** Renames event type that triggers on automatic updates.
*   **Checkout Session Display Items Removal (2020-08-27):** Removes the `display_items` property from Checkout Sessions.
*   **Requirements Key Persons Formatting (2020-08-27):** Formats requirements for key persons associated with accounts.
*   **Accounts Persons Capabilities Error Codes (2020-08-27):** Adds new error codes to the Accounts, Persons, and Capabilities APIs.
*   **3D Secure Details Charge Object Update (2020-08-27):** Updates to 3D Secure details in Charge object.
*   **Customer Subscriptions Auto-Expansion Deprecation (2020-08-27):** Customer subscriptions are no longer auto-expanded by default.
*   **Plan Tiers Auto-Expansion Deprecation (2020-08-27):** Plan tiers are no longer auto-expanded by default.
*   **Invoice Include Require Value Removal (2022-08-01):** Removes the `include_and_require` value when creating invoices.
*   **Checkout Session Default Customer Creation (2022-08-01):** Default customer creation in Checkout Session payment mode changed to `if_required`.
*   **Deferred PaymentIntent Creation Checkout Session (2022-08-01):** Deferred PaymentIntent creation in Checkout Session payment mode.
*   **Checkout Session Setup Intent Removal (2022-08-01):** Removes the `setup_intent` property from Checkout Sessions in subscription mode.
*   **Checkout Session Line Item Parameters Replacement (2022-08-01):** Replaces line item parameters from the Create Checkout Session endpoint.
*   **Checkout Session Subscription Data Removal (2022-08-01):** Removes the `subscription_data` parameter from the Create Checkout Session endpoint.
*   **Checkout Session Shipping Rate Removal (2022-08-01):** Removes the `shipping_rate` parameter from Create Checkout Session endpoint.
*   **3D Secure Exemption Status Charges (2022-08-01):** Adds 3D Secure exemption status to card charges.
*   **Charges Auto-Expand Refunds Deprecation (2022-11-15):** The Charges object no longer auto-expands refunds by default.
*   **PaymentIntent Charges Attribute Removal (2022-11-15):** Removes the `charges` attribute from the PaymentIntent object.
*   **PaymentIntent/PaymentMethod Decline Codes (2022-11-15):** Adds new decline codes to the PaymentIntent and PaymentMethod APIs.
*   **SetupIntent Decline Codes (2022-11-15):** Adds new decline codes to the SetupIntent API.
*   **Accounts API Structure Error Code (2022-11-15):** Adds a new structure error code to the Accounts API.
*   **Automatic Payment Methods Default (2023-08-16):** Enables automatic payment methods by default for PaymentIntents and SetupIntents.
*   **Checkout Sessions No-Cost Orders (2023-08-16):** One-time payments in Checkout Sessions support no-cost orders.
*   **Platform-Scope PaymentMethod Fingerprints (2023-08-16):** Platform-scope rendering for select PaymentMethod fingerprints.
*   **Klarna Payment Failure Error Codes (2023-08-16):** Adds specific error codes for failed Klarna payments.
*   **Accounts Persons Capabilities Error Codes (2023-08-16):** Adds new director verification error codes to the Accounts API.
*   **Accounts Requirement Error Codes (2023-10-16):** Adds new account requirement error codes to the Accounts API.
*   **Statement Descriptor Auto-Population (2023-10-16):** Auto-populates the statement descriptor and prefix in the Accounts API.
*   **PaymentIntent Automatic Capture Default (2024-04-10):** Makes automatic sync the default capture method for PaymentIntents when not specified.
*   **Invoice Rendering Options Rename (2024-04-10):** Renames the `rendering_options` attribute for invoices to `rendering`.
*   **Product Features Attribute Rename (2024-04-10):** Renames the `features` attribute of the Product object.
*   **Authorization Fuel Attribute Rename (2024-06-20):** Renames a fuel attribute of the Authorization object.
*   **Transaction Purchase Details Attribute Rename (2024-06-20):** Renames a `purchase_details` attribute of the Transaction object.
*   **Undocumented Fuel Fields Removal (2024-06-20):** Removes undocumented fuel fields.
*   **Undocumented Fleet Fields Removal (2024-06-20):** Removes undocumented fleet fields.
*   **Fuel Units Enum Values (2024-06-20):** Adds enum values for fuel units.
*   **Issuing Authorization Alphanumeric ID Deprecation (2024-06-20):** Deprecates `alphanumeric_id` for Issuing Authorization.
*   **Person Document Verification Details Code Additions (2024-06-20):** Adds new `details_code` values to person document verification.
*   **Accounts Capabilities Requirement (2024-09-30):** Adds requirement for `requested_capabilities` on custom account creation.
*   **Accounts Country Capabilities Requirement (2024-09-30):** Accounts in many countries now require specifying capabilities at creation time.
*   **Person Object Relationship Attribute Rename (2024-09-30):** Renames a Person object relationship attribute.
*   **Subscription Schedule Renewal Properties Update (2024-09-30):** Renames and updates subscription schedule renewal properties.
*   **Invoice Due Date Null (2024-09-30):** The `due_date` property is always null on auto-billed invoices.
*   **Customer Account Balance Rename (2024-09-30):** Renames `account_balance` to `balance` on Customer object.
*   **Invoice Line Item IDs Standardized (2024-09-30):** Standardizes invoice line item IDs.
*   **Post-Payment Credit Note Requirement (2024-09-30):** New requirement for `out_of_band_amount` when creating post-payment credit notes.
*   **Customer Balances Returned Voided Invoices (2024-09-30):** Customer balances are now returned when voiding invoices.
*   **Deprecated Tax Information Fields Removal (2024-09-30):** Removes deprecated tax information fields from the Customer object.
*   **Sequential Invoice Numbering (2024-09-30):** Invoices can now be numbered sequentially across your account.
*   **Tax Percent Attribute Removal (2024-08-27):** Removes the `tax_percent` attribute.
*   **Customer Sources Auto-Expansion Deprecation (2020-08-27):** Customer sources are no longer auto-expanded by default.
*   **Customer Tax IDs Auto-Expansion Deprecation (2020-08-27):** Tax IDs are no longer auto-expanded on the Customer object.
*   **Subscription Prorate Parameters Deprecation (2020-08-27):** Deprecates `prorate` and `subscription_prorate` parameters.
*   **Subscription Schedule Phases Attributes Rename (2020-08-27):** Renames phases attributes in subscription schedules.
*   **Automatic Updates Event Type Rename (2020-08-27):** Renames event type that triggers on automatic updates.
*   **Checkout Session Display Items Removal (2020-08-27):** Removes the `display_items` property from Checkout Sessions.
*   **Accounts Persons Capabilities Error Codes (2020-08-27):** Adds new error codes to the Accounts, Persons, and Capabilities APIs.
*   **3D Secure Details Charge Object Update (2020-08-27):** Updates to 3D Secure details in Charge object.
*   **Customer Subscriptions Auto-Expansion Deprecation (2020-08-27):** Customer subscriptions are no longer auto-expanded by default.
*   **Plan Tiers Auto-Expansion Deprecation (2020-08-27):** Plan tiers are no longer auto-expanded by default.
*   **Invoice Include Require Value Removal (2022-08-01):** Removes the `include_and_require` value when creating invoices.
*   **Checkout Session Default Customer Creation (2022-08-01):** Default customer creation in Checkout Session payment mode changed to `if_required`.
*   **Deferred PaymentIntent Creation Checkout Session (2022-08-01):** Deferred PaymentIntent creation in Checkout Session payment mode.
*   **Checkout Session Setup Intent Removal (2022-08-01):** Removes the `setup_intent` property from Checkout Sessions in subscription mode.
*   **Checkout Session Line Item Parameters Replacement (2022-08-01):** Replaces line item parameters from the Create Checkout Session endpoint.
*   **Checkout Session Subscription Data Removal (2022-08-01):** Removes the `subscription_data` parameter from the Create Checkout Session endpoint.
*   **Checkout Session Shipping Rate Removal (2022-08-01):** Removes the `shipping_rate` parameter from Create Checkout Session endpoint.
*   **3D Secure Exemption Status Charges (2022-08-01):** Adds 3D Secure exemption status to card charges.
*   **Charges Object No Auto-Expand Refunds (2022-11-15):** The Charges object no longer auto-expands refunds by default.
*   **PaymentIntent Charges Attribute Removal (2022-11-15):** Removes the `charges` attribute from the PaymentIntent object.
*   **PaymentIntent/PaymentMethod Decline Codes (2022-11-15):** Adds new decline codes to the PaymentIntent and PaymentMethod APIs.
*   **SetupIntent Decline Codes (2022-11-15):** Adds new decline codes to the SetupIntent API.
*   **Accounts API Structure Error Code (2022-11-15):** Adds a new structure error code to the Accounts API.
*   **Automatic Payment Methods Default (2023-08-16):** Enables automatic payment methods by default for PaymentIntents and SetupIntents.
*   **Checkout Sessions No-Cost Orders (2023-08-16):** One-time payments in Checkout Sessions support no-cost orders.
*   **Platform-Scope PaymentMethod Fingerprints (2023-08-16):** Platform-scope rendering for select PaymentMethod fingerprints.
*   **Klarna Payment Failure Error Codes (2023-08-16):** Adds specific error codes for failed Klarna payments.
*   **Accounts Persons Capabilities Error Codes (2023-08-16):** Adds new director verification error codes to the Accounts API.
*   **Accounts Requirement Error Codes (2023-10-16):** Adds new account requirement error codes to the Accounts API.
*   **Statement Descriptor Auto-Population (2023-10-16):** Auto-populates the statement descriptor and prefix in the Accounts API.
*   **Switzerland UID Tax ID (2024-09-30):** Adds Switzerland UID as a supported customer tax ID.
*   **Credit Notes Email Types (2024-09-30):** Adds support for email types to Credit Notes.
*   **Terminal Reboot Time Setting (2024-09-30):** Adds support for configuring the reboot time setting.
*   **Payment Links New Payment Methods (2024-09-30):** Adds support for three new payment methods: Multibanco, Twint, and Zip.
*   **Financial Connections Account Subcategories Filtering (2024-09-30):** Adds support for filtering by account subcategories on Financial Connections.
*   **Financial Connections Sessions Filtering Expansion (2024-09-30):** Expands filtering support for Financial Connections Sessions.
*   **Bulk Invoice Line Item Operations (2024-09-30):** Adds support for bulk invoice line item operations.
*   **Tax Transaction Creation Posting Time (2024-09-30):** Adds support for posting time on tax transaction creation.
*   **Issuing Card Address Validation (2024-09-30):** Adds address validation for physical cards.
*   **Payment Element Customer Session Support (2024-09-30):** Adds support for the Payment Element on a Customer Session.
*   **Confirmation Tokens CVC Retrieval (2024-09-30):** Adds option to retrieve CVC tokens on Confirmation Tokens.
*   **Disputes Case Type for Cards (2024-09-30):** Adds support for identifying the case type for card disputes.
*   **Affirm Transaction IDs (2024-09-30):** Adds support for Affirm transaction IDs.
*   **Twint Payment Method Configuration (2024-09-30):** Adds Twint to the PaymentMethodConfiguration API.
*   **Interac Present Support (2024-09-30):** Adds support for in-person payment methods, including Interac cards.
*   **Accounts Business Profile Refactoring (2024-09-30):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Person Document Verification Error Codes (2024-09-30):** Adds new `details_code` values to person document verification.
*   **Payment Intents and Setup Intents Automatic Payment Methods (2023-08-16):** Enables automatic payment methods by default for PaymentIntents and SetupIntents.
*   **Checkout Sessions No-Cost Orders (2023-08-16):** One-time payments in Checkout Sessions support no-cost orders.
*   **PaymentMethod Fingerprints Platform Scope (2023-08-16):** Platform-scope rendering for select PaymentMethod fingerprints.
*   **Klarna Payment Failure Error Codes (2023-08-16):** Adds specific error codes for failed Klarna payments.
*   **Accounts Director Verification Error Codes (2023-08-16):** Adds new director verification error codes to the Accounts API.
*   **Accounts Requirement Error Codes (2023-10-16):** Adds new account requirement error codes to the Accounts API.
*   **Statement Descriptor Auto-Population (2023-10-16):** Auto-populates the statement descriptor and prefix in the Accounts API.
*   **Payment Intents and Setup Intents Status Renames (2019-02-11):** Renames several statuses for PaymentIntents.
*   **Source Save Field Rename (2019-02-11):** Renames the `save_source_to_customer` field for sources to `save_payment_method`.
*   **Source Allowed Types Field Rename (2019-02-11):** Renames the `allowed_source_types` field for sources to `payment_method_types`.
*   **Payment Intents Next Source Action Rename (2019-02-11):** Renames the `next_source_action` field for Payment Intents to `next_action`.
*   **Payment Intents Authorize With URL Rename (2019-02-11):** Renames the `authorize_with_url` field for Payment Intents to `redirect_to_url`.
*   **Charges Statement Descriptor Behaviors (2019-02-19):** Changes statement descriptor behaviors for card payments created with Charges.
*   **Account Fields Refactored (2019-02-19):** Several account fields have been refactored to better describe legal entity, verification status and requirements, and configurable settings.
*   **Account Business Details Moved (2019-02-19):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Account/Person Verification Front/Back Support (2019-02-19):** Verification of accounts or persons now supports uploading both front and back sides.
*   **Account Keys Field Removal (2019-02-19):** Accounts no longer provide a `keys` field. Platforms should use their own API key to authenticate as their connected accounts.
*   **US Accounts Requested Capabilities (2019-02-19):** Accounts in the US now require specifying capabilities at creation time.
*   **Account Legal Entity Business ID Number Rename (2019-02-19):** Renames the `business_id_number` for an account's legal entity to `business_registration_number`.
*   **Invoice Application Fee Rename (2019-03-14):** Renames `application_fee` on invoices to `application_fee_amount`.
*   **Subscription First Payment Failure (2019-03-14):** Subscriptions are now successfully created even if the first payment fails.
*   **Invoice State Transition Timestamps (2019-03-14):** Invoices now provide timestamps for each state transition.
*   **Invoice Date Field Rename (2019-03-14):** Renames the `date` field for invoices to `created`.
*   **Invoice Finalized Alongside Status Transitions (2019-03-14):** Invoices now specify when they're finalized alongside other status transitions.
*   **Connect Platform Payments Capability Rename (2019-08-14):** Renames the `platform_payments` capability for accounts to `card_payments`, requiring the manual specification of the added `transfers` capability.
*   **Person Account Opener Executive Setting (2019-08-14):** Configuring a person as an account opener no longer automatically sets them as an executive.
*   **Accounts Many Countries Capabilities (2019-09-09):** Accounts in many countries now require specifying capabilities at creation time.
*   **Person Document Verification Details Code (2019-09-09):** Adds new `details_code` values to person document verification.
*   **Person Object Relationship Attribute Rename (2019-10-08):** Renames a Person object relationship attribute.
*   **Subscription Schedule Renewal Properties Update (2019-10-17):** Renames and updates subscription schedule renewal properties.
*   **Subscription Start Field Replaced (2019-10-17):** Replaces the `subscription start` field with `start_date`.
*   **Billing Attribute Rename (2019-10-17):** Renames `billing` to `collection_method` on invoices, subscriptions, and subscription schedules.
*   **Invoice Due Date Null (2019-10-17):** The `due_date` property is always null on auto-billed invoices.
*   **Customer Account Balance Rename (2019-10-17):** Renames `account_balance` to `balance` on Customer object.
*   **Custom Account Creation Requested Capabilities (2019-11-05):** Adds requirement for `requested_capabilities` on custom account creation.
*   **Subscription Schedule Settings Nesting (2019-11-05):** Nested subscription schedule settings under `default_settings`.
*   **Invoice Line Item IDs Standardized (2019-12-03):** Standardizes invoice line item IDs.
*   **Post-Payment Credit Note Requirement (2019-12-03):** New requirement for `out_of_band_amount` when creating post-payment credit notes.
*   **Customer Balances Returned Voided Invoices (2019-12-03):** Customer balances are now returned when voiding invoices.
*   **Deprecated Tax Information Fields Removal (2019-12-03):** Removes deprecated tax information fields from the Customer object.
*   **Sequential Invoice Numbering (2020-03-02):** Invoices can now be numbered sequentially across your account.
*   **Tax Percent Attribute Removal (2020-08-27):** Removes the `tax_percent` attribute.
*   **Customer Sources Auto-Expansion Deprecation (2020-08-27):** Customer sources are no longer auto-expanded by default.
*   **Customer Tax IDs Auto-Expansion Deprecation (2020-08-27):** Tax IDs are no longer auto-expanded on the Customer object.
*   **Subscription Prorate Parameters Deprecation (2020-08-27):** Deprecates `prorate` and `subscription_prorate` parameters.
*   **Subscription Schedule Phases Attributes Rename (2020-08-27):** Renames phases attributes in subscription schedules.
*   **Automatic Updates Event Type Rename (2020-08-27):** Renames event type that triggers on automatic updates.
*   **Checkout Session Display Items Removal (2020-08-27):** Removes the `display_items` property from Checkout Sessions.
*   **Accounts Persons Capabilities Error Codes (2020-08-27):** Adds new error codes to the Accounts, Persons, and Capabilities APIs.
*   **3D Secure Details Charge Object Update (2020-08-27):** Updates to 3D Secure details in Charge object.
*   **Customer Subscriptions Auto-Expansion Deprecation (2020-08-27):** Customer subscriptions are no longer auto-expanded by default.
*   **Plan Tiers Auto-Expansion Deprecation (2020-08-27):** Plan tiers are no longer auto-expanded by default.
*   **Invoice Include Require Value Removal (2022-08-01):** Removes the `include_and_require` value when creating invoices.
*   **Checkout Session Default Customer Creation (2022-08-01):** Default customer creation in Checkout Session payment mode changed to `if_required`.
*   **Deferred PaymentIntent Creation Checkout Session (2022-08-01):** Deferred PaymentIntent creation in Checkout Session payment mode.
*   **Checkout Session Setup Intent Removal (2022-08-01):** Removes the `setup_intent` property from Checkout Sessions in subscription mode.
*   **Checkout Session Line Item Parameters Replacement (2022-08-01):** Replaces line item parameters from the Create Checkout Session endpoint.
*   **Checkout Session Subscription Data Removal (2022-08-01):** Removes the `subscription_data` parameter from the Create Checkout Session endpoint.
*   **Checkout Session Shipping Rate Removal (2022-08-01):** Removes the `shipping_rate` parameter from Create Checkout Session endpoint.
*   **3D Secure Exemption Status Charges (2022-08-01):** Adds 3D Secure exemption status to card charges.
*   **Charges Object No Auto-Expand Refunds (2022-11-15):** The Charges object no longer auto-expands refunds by default.
*   **PaymentIntent Charges Attribute Removal (2022-11-15):** Removes the `charges` attribute from the PaymentIntent object.
*   **PaymentIntent/PaymentMethod Decline Codes (2022-11-15):** Adds new decline codes to the PaymentIntent and PaymentMethod APIs.
*   **SetupIntent Decline Codes (2022-11-15):** Adds new decline codes to the SetupIntent API.
*   **Accounts API Structure Error Code (2022-11-15):** Adds a new structure error code to the Accounts API.
*   **Automatic Payment Methods Default (2023-08-16):** Enables automatic payment methods by default for PaymentIntents and SetupIntents.
*   **Checkout Sessions No-Cost Orders (2023-08-16):** One-time payments in Checkout Sessions support no-cost orders.
*   **Platform-Scope PaymentMethod Fingerprints (2023-08-16):** Platform-scope rendering for select PaymentMethod fingerprints.
*   **Klarna Payment Failure Error Codes (2023-08-16):** Adds specific error codes for failed Klarna payments.
*   **Accounts Persons Capabilities Error Codes (2023-08-16):** Adds new director verification error codes to the Accounts API.
*   **Accounts Requirement Error Codes (2023-10-16):** Adds new account requirement error codes to the Accounts API.
*   **Statement Descriptor Auto-Population (2023-10-16):** Auto-populates the statement descriptor and prefix in the Accounts API.
*   **Switzerland UID Tax ID (2024-09-30):** Adds Switzerland UID as a supported customer tax ID.
*   **Credit Notes Email Types (2024-09-30):** Adds support for email types to Credit Notes.
*   **Terminal Reboot Time Setting (2024-09-30):** Adds support for configuring the reboot time setting.
*   **Payment Links New Payment Methods (2024-09-30):** Adds support for three new payment methods: Multibanco, Twint, and Zip.
*   **Financial Connections Account Subcategories Filtering (2024-09-30):** Adds support for filtering by account subcategories on Financial Connections.
*   **Financial Connections Sessions Filtering Expansion (2024-09-30):** Expands filtering support for Financial Connections Sessions.
*   **Bulk Invoice Line Item Operations (2024-09-30):** Adds support for bulk invoice line item operations.
*   **Tax Transaction Creation Posting Time (2024-09-30):** Adds support for posting time on tax transaction creation.
*   **Issuing Card Address Validation (2024-09-30):** Adds address validation for physical cards.
*   **Payment Element Customer Session Support (2024-09-30):** Adds support for the Payment Element on a Customer Session.
*   **Confirmation Tokens CVC Retrieval (2024-09-30):** Adds option to retrieve CVC tokens on Confirmation Tokens.
*   **Disputes Case Type for Cards (2024-09-30):** Adds support for identifying the case type for card disputes.
*   **Affirm Transaction IDs (2024-09-30):** Adds support for Affirm transaction IDs.
*   **Twint Payment Method Configuration (2024-09-30):** Adds Twint to the PaymentMethodConfiguration API.
*   **Interac Present Support (2024-09-30):** Adds support for in-person payment methods, including Interac cards.
*   **Accounts Business Profile Refactoring (2024-09-30):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Person Document Verification Details Code Additions (2024-09-30):** Adds new `details_code` values to person document verification.
*   **Accounts Capabilities Requirement (2019-02-19):** Adds requirement for `requested_capabilities` on custom account creation.
*   **Accounts Country Capabilities Requirement (2019-09-09):** Accounts in many countries now require specifying capabilities at creation time.
*   **Person Object Relationship Attribute Rename (2019-10-08):** Renames a Person object relationship attribute.
*   **Subscription Schedule Renewal Properties Update (2019-10-17):** Renames and updates subscription schedule renewal properties.
*   **Subscription Start Field Replaced (2019-10-17):** Replaces the `subscription start` field with `start_date`.
*   **Billing Attribute Rename (2019-10-17):** Renames `billing` to `collection_method` on invoices, subscriptions, and subscription schedules.
*   **Invoice Due Date Null (2019-10-17):** The `due_date` property is always null on auto-billed invoices.
*   **Customer Account Balance Rename (2019-10-17):** Renames `account_balance` to `balance` on Customer object.
*   **Payment Intents API Private Beta Changes (2018-11-08):** Includes several changes for users of the Payment Intents API private beta.
*   **Subscription Ending Period Configuration (2018-08-23):** A subscription's ending period can no longer be configured while canceling it.
*   **Customer Tax Info Object (2018-08-23):** Customers now provide a `tax_info` object with their tax ID details.
*   **Plan Tiers Amount Field Rename (2018-08-23):** Renames the `amount` field for plan tiers to `unit_amount`.
*   **SKU Values Uniqueness Removed (2018-09-06):** SKU values no longer need to be unique.
*   **FileUpload Object Rename to Files (2018-09-24):** Renames the FileUpload object to Files, which now require secret keys to download files.
*   **Customer Description Character Limit (2018-10-31):** Descriptions for customers now have a character limit.
*   **Product Name Character Limit (2018-10-31):** Product names now have a character limit.
*   **Invoice Line Item Description Character Limit (2018-10-31):** Descriptions for invoice line items now have a character limit.
*   **Subscription First Invoice Billing Reason (2018-10-31):** The `billing_reason` of the first invoice of a subscription is now `subscription_create`.
*   **Invoice Auto Advance Field (2018-11-08):** Invoices now specify their automatic collection behavior using the `auto_advance` field.
*   **One-off Invoice Payment Default (2018-11-08):** One-off Invoices no longer automatically collect payment by default.
*   **Invoice Forgiven Field Replaced (2018-11-08):** Replaces the `forgiven` field with a new `uncollectible` status for invoices.
*   **Invoice Error Code Rename (2018-11-08):** Renames an invoice error code to `invoice_already_finalized`.
*   **Subscription Trial Period Default (2018-05-21):** Subscriptions now default to not defining their trial periods depending on a plan.
*   **Subscription Plan Change Trial Extension (2018-05-21):** Changing a subscription to a new plan with a trial now extends the trial period.
*   **Subscription Source Parameter Modification (2018-07-27):** Subscriptions no longer support modifying the `source` parameter directly.
*   **Subscription Trial End Timestamp (2018-07-27):** Ending a subscription trial now uses the timestamp of that API request.
*   **Coupon Percent Off Floats (2018-07-27):** Coupons now use floats rather than integers to specify `percent_off`.
*   **Customer Email Validation (2018-07-27):** Stripe now validates email addresses when creating or updating customers.
*   **Connect Events Originating Account (2017-05-25):** Events for Connect now specify the originating connected account using the `account` field.
*   **Events Request ID and Idempotency Key (2017-05-25):** The `request` field of the Events object now specifies both the request ID and idempotency key.
*   **Events Previous Attributes Sub-array Rendering (2017-05-25):** Events with the `previous_attributes` field now render the complete affected sub-array.
*   **Account Types (Standard, Express, Custom) (2017-05-25):** Accounts must now specify one of three types (Standard, Express, or Custom).
*   **Account Under Review Reason (2017-06-05):** Accounts can now specify why an account isn't enabled with the new `reason under_review`.
*   **Source Authentication Redirect (2017-08-15):** Sources can now specify that an authentication redirect isn't required.
*   **Invoice Line Items Description Requirement (2017-12-14):** Invoice line items now must always set a description.
*   **Invoice Payment Failures Card Error (2017-12-14):** Invoice payment failures now return a `card_error` when a charge is declined.
*   **Connect Reused Card/Bank Account Fingerprint (2018-01-23):** Connect platforms can identify reused card or bank accounts across connected accounts as they now will share the same fingerprint.
*   **Free Plans with Prorations Zero-Dollar Invoices (2018-02-05):** Free plans with prorations now produce zero-dollar invoices.
*   **Subscription Delay First Full Invoice (2018-02-05):** Subscriptions can now delay the first full invoice to a future date (and optionally include a free trial).
*   **Plan Link to Products (2018-02-05):** Plans now link to individual products, with several fields moving to the product resource.
*   **Product Type Field Requirement (2018-02-05):** Products now require a `type` field, differentiating their use with order SKUs or subscriptions and plans.
*   **Source Recommended 3D Secure (2018-02-06):** Sources now provide a recommended value when the issuer advises using 3D Secure.
*   **Canceled Subscription Update Status (2018-02-28):** Updating a canceled subscription on a future date no longer resets its status.
*   **Product SKU List Removal (2018-05-21):** Products no longer embed lists of SKUs.
*   **Invoice Line Items Unique IDs (2018-05-21):** Invoice line items now have unique IDs and can't be used in place of a subscription.
*   **Coupon, SKU, Customer, Product, Plan ID Character Limits (2018-05-21):** Coupons, SKUs, customers, products, and plans now limit the valid characters for IDs.
*   **Subscription Trial Period Default (2018-05-21):** Subscriptions now default to not defining their trial periods depending on a plan.
*   **Subscription Plan Change Trial Extension (2018-05-21):** Changing a subscription to a new plan with a trial now extends the trial period.
*   **Subscription Source Parameter Modification (2018-07-27):** Subscriptions no longer support modifying the `source` parameter directly.
*   **Subscription Trial End Timestamp (2018-07-27):** Ending a subscription trial now uses the timestamp of that API request.
*   **Coupon Percent Off Floats (2018-07-27):** Coupons now use floats rather than integers to specify `percent_off`.
*   **Customer Email Validation (2018-07-27):** Stripe now validates email addresses when creating or updating customers.
*   **Subscription Ending Period Configuration (2018-08-23):** A subscription's ending period can no longer be configured while canceling it.
*   **Customer Tax Info Object (2018-08-23):** Customers now provide a `tax_info` object with their tax ID details.
*   **Plan Tiers Amount Field Rename (2018-08-23):** Renames the `amount` field for plan tiers to `unit_amount`.
*   **SKU Values Uniqueness Removed (2018-09-06):** SKU values no longer need to be unique.
*   **FileUpload Object Rename to Files (2018-09-24):** Renames the FileUpload object to Files, which now require secret keys to download files.
*   **Customer Description Character Limit (2018-10-31):** Descriptions for customers now have a character limit.
*   **Product Name Character Limit (2018-10-31):** Product names now have a character limit.
*   **Invoice Line Item Description Character Limit (2018-10-31):** Descriptions for invoice line items now have a character limit.
*   **Subscription First Invoice Billing Reason (2018-10-31):** The `billing_reason` of the first invoice of a subscription is now `subscription_create`.
*   **Invoice Auto Advance Field (2018-11-08):** Invoices now specify their automatic collection behavior using the `auto_advance` field.
*   **One-off Invoice Payment Default (2018-11-08):** One-off Invoices no longer automatically collect payment by default.
*   **Invoice Forgiven Field Replaced (2018-11-08):** Replaces the `forgiven` field with a new `uncollectible` status for invoices.
*   **Invoice Error Code Rename (2018-11-08):** Renames an invoice error code to `invoice_already_finalized`.
*   **Payment Intents API Private Beta Changes (2018-11-08):** Includes several changes for users of the Payment Intents API private beta.
*   **Payment Intents Status Renames (2019-02-11):** Renames several statuses for PaymentIntents.
*   **Source Save Field Rename (2019-02-11):** Renames the `save_source_to_customer` field for sources to `save_payment_method`.
*   **Source Allowed Types Field Rename (2019-02-11):** Renames the `allowed_source_types` field for sources to `payment_method_types`.
*   **Payment Intents Next Source Action Rename (2019-02-11):** Renames the `next_source_action` field for Payment Intents to `next_action`.
*   **Payment Intents Authorize With URL Rename (2019-02-11):** Renames the `authorize_with_url` field for Payment Intents to `redirect_to_url`.
*   **Charges Statement Descriptor Behaviors (2019-02-19):** Changes statement descriptor behaviors for card payments created with Charges.
*   **Account Fields Refactored (2019-02-19):** Several account fields have been refactored to better describe legal entity, verification status and requirements, and configurable settings.
*   **Account Business Details Moved (2019-02-19):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Account/Person Verification Front/Back Support (2019-02-19):** Verification of accounts or persons now supports uploading both front and back sides.
*   **Account Keys Field Removal (2019-02-19):** Accounts no longer provide a `keys` field. Platforms should use their own API key to authenticate as their connected accounts.
*   **US Accounts Requested Capabilities (2019-02-19):** Accounts in the US now require specifying capabilities at creation time.
*   **Account Legal Entity Business ID Number Rename (2019-02-19):** Renames the `business_id_number` for an account's legal entity to `business_registration_number`.
*   **Invoice Application Fee Rename (2019-03-14):** Renames `application_fee` on invoices to `application_fee_amount`.
*   **Subscription First Payment Failure (2019-03-14):** Subscriptions are now successfully created even if the first payment fails.
*   **Invoice State Transition Timestamps (2019-03-14):** Invoices now provide timestamps for each state transition.
*   **Invoice Date Field Rename (2019-03-14):** Renames the `date` field for invoices to `created`.
*   **Invoice Finalized Alongside Status Transitions (2019-03-14):** Invoices now specify when they're finalized alongside other status transitions.
*   **Connect Platform Payments Capability Rename (2019-08-14):** Renames the `platform_payments` capability for accounts to `card_payments`, requiring the manual specification of the added `transfers` capability.
*   **Person Account Opener Executive Setting (2019-08-14):** Configuring a person as an account opener no longer automatically sets them as an executive.
*   **Accounts Many Countries Capabilities (2019-09-09):** Accounts in many countries now require specifying capabilities at creation time.
*   **Person Document Verification Details Code Additions (2019-09-09):** Adds new `details_code` values to person document verification.
*   **Person Object Relationship Attribute Rename (2019-10-08):** Renames a Person object relationship attribute.
*   **Subscription Schedule Renewal Properties Update (2019-10-17):** Renames and updates subscription schedule renewal properties.
*   **Subscription Start Field Replaced (2019-10-17):** Replaces the `subscription start` field with `start_date`.
*   **Billing Attribute Rename (2019-10-17):** Renames `billing` to `collection_method` on invoices, subscriptions, and subscription schedules.
*   **Invoice Due Date Null (2019-10-17):** The `due_date` property is always null on auto-billed invoices.
*   **Customer Account Balance Rename (2019-10-17):** Renames `account_balance` to `balance` on Customer object.
*   **Custom Account Creation Requested Capabilities (2019-11-05):** Adds requirement for `requested_capabilities` on custom account creation.
*   **Subscription Schedule Settings Nesting (2019-11-05):** Nested subscription schedule settings under `default_settings`.
*   **Invoice Line Item IDs Standardized (2019-12-03):** Standardizes invoice line item IDs.
*   **Post-Payment Credit Note Requirement (2019-12-03):** New requirement for `out_of_band_amount` when creating post-payment credit notes.
*   **Customer Balances Returned Voided Invoices (2019-12-03):** Customer balances are now returned when voiding invoices.
*   **Deprecated Tax Information Fields Removal (2019-12-03):** Removes deprecated tax information fields from the Customer object.
*   **Sequential Invoice Numbering (2020-03-02):** Invoices can now be numbered sequentially across your account.
*   **Tax Percent Attribute Removal (2020-08-27):** Removes the `tax_percent` attribute.
*   **Customer Sources Auto-Expansion Deprecation (2020-08-27):** Customer sources are no longer auto-expanded by default.
*   **Customer Tax IDs Auto-Expansion Deprecation (2020-08-27):** Tax IDs are no longer auto-expanded on the Customer object.
*   **Subscription Prorate Parameters Deprecation (2020-08-27):** Deprecates `prorate` and `subscription_prorate` parameters.
*   **Subscription Schedule Phases Attributes Rename (2020-08-27):** Renames phases attributes in subscription schedules.
*   **Automatic Updates Event Type Rename (2020-08-27):** Renames event type that triggers on automatic updates.
*   **Checkout Session Display Items Removal (2020-08-27):** Removes the `display_items` property from Checkout Sessions.
*   **Accounts Persons Capabilities Error Codes (2020-08-27):** Adds new error codes to the Accounts, Persons, and Capabilities APIs.
*   **3D Secure Details Charge Object Update (2020-08-27):** Updates to 3D Secure details in Charge object.
*   **Customer Subscriptions Auto-Expansion Deprecation (2020-08-27):** Customer subscriptions are no longer auto-expanded by default.
*   **Plan Tiers Auto-Expansion Deprecation (2020-08-27):** Plan tiers are no longer auto-expanded by default.
*   **Invoice Include Require Value Removal (2022-08-01):** Removes the `include_and_require` value when creating invoices.
*   **Checkout Session Default Customer Creation (2022-08-01):** Default customer creation in Checkout Session payment mode changed to `if_required`.
*   **Deferred PaymentIntent Creation Checkout Session (2022-08-01):** Deferred PaymentIntent creation in Checkout Session payment mode.
*   **Checkout Session Setup Intent Removal (2022-08-01):** Removes the `setup_intent` property from Checkout Sessions in subscription mode.
*   **Checkout Session Line Item Parameters Replacement (2022-08-01):** Replaces line item parameters from the Create Checkout Session endpoint.
*   **Checkout Session Subscription Data Removal (2022-08-01):** Removes the `subscription_data` parameter from the Create Checkout Session endpoint.
*   **Checkout Session Shipping Rate Removal (2022-08-01):** Removes the `shipping_rate` parameter from Create Checkout Session endpoint.
*   **3D Secure Exemption Status Charges (2022-08-01):** Adds 3D Secure exemption status to card charges.
*   **Charges Object No Auto-Expand Refunds (2022-11-15):** The Charges object no longer auto-expands refunds by default.
*   **PaymentIntent Charges Attribute Removal (2022-11-15):** Removes the `charges` attribute from the PaymentIntent object.
*   **PaymentIntent/PaymentMethod Decline Codes (2022-11-15):** Adds new decline codes to the PaymentIntent and PaymentMethod APIs.
*   **SetupIntent Decline Codes (2022-11-15):** Adds new decline codes to the SetupIntent API.
*   **Accounts API Structure Error Code (2022-11-15):** Adds a new structure error code to the Accounts API.
*   **Automatic Payment Methods Default (2023-08-16):** Enables automatic payment methods by default for PaymentIntents and SetupIntents.
*   **Checkout Sessions No-Cost Orders (2023-08-16):** One-time payments in Checkout Sessions support no-cost orders.
*   **Platform-Scope PaymentMethod Fingerprints (2023-08-16):** Platform-scope rendering for select PaymentMethod fingerprints.
*   **Klarna Payment Failure Error Codes (2023-08-16):** Adds specific error codes for failed Klarna payments.
*   **Accounts Persons Capabilities Error Codes (2023-08-16):** Adds new director verification error codes to the Accounts API.
*   **Accounts Requirement Error Codes (2023-10-16):** Adds new account requirement error codes to the Accounts API.
*   **Statement Descriptor Auto-Population (2023-10-16):** Auto-populates the statement descriptor and prefix in the Accounts API.
*   **Switzerland UID Tax ID (2024-09-30):** Adds Switzerland UID as a supported customer tax ID.
*   **Credit Notes Email Types (2024-09-30):** Adds support for email types to Credit Notes.
*   **Terminal Reboot Time Setting (2024-09-30):** Adds support for configuring the reboot time setting.
*   **Payment Links New Payment Methods (2024-09-30):** Adds support for three new payment methods: Multibanco, Twint, and Zip.
*   **Financial Connections Account Subcategories Filtering (2024-09-30):** Adds support for filtering by account subcategories on Financial Connections.
*   **Financial Connections Sessions Filtering Expansion (2024-09-30):** Expands filtering support for Financial Connections Sessions.
*   **Bulk Invoice Line Item Operations (2024-09-30):** Adds support for bulk invoice line item operations.
*   **Tax Transaction Creation Posting Time (2024-09-30):** Adds support for posting time on tax transaction creation.
*   **Issuing Card Address Validation (2024-09-30):** Adds address validation for physical cards.
*   **Payment Element Customer Session Support (2024-09-30):** Adds support for the Payment Element on a Customer Session.
*   **Confirmation Tokens CVC Retrieval (2024-09-30):** Adds option to retrieve CVC tokens on Confirmation Tokens.
*   **Disputes Case Type for Cards (2024-09-30):** Adds support for identifying the case type for card disputes.
*   **Affirm Transaction IDs (2024-09-30):** Adds support for Affirm transaction IDs.
*   **Twint Payment Method Configuration (2024-09-30):** Adds Twint to the PaymentMethodConfiguration API.
*   **Interac Present Support (2024-09-30):** Adds support for in-person payment methods, including Interac cards.
*   **Accounts Business Profile Refactoring (2024-09-30):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Person Document Verification Details Code Additions (2024-09-30):** Adds new `details_code` values to person document verification.
*   **Accounts Capabilities Requirement (2019-02-19):** Adds requirement for `requested_capabilities` on custom account creation.
*   **Accounts Country Capabilities Requirement (2019-09-09):** Accounts in many countries now require specifying capabilities at creation time.
*   **Person Object Relationship Attribute Rename (2019-10-08):** Renames a Person object relationship attribute.
*   **Subscription Schedule Renewal Properties Update (2019-10-17):** Renames and updates subscription schedule renewal properties.
*   **Subscription Start Field Replaced (2019-10-17):** Replaces the `subscription start` field with `start_date`.
*   **Billing Attribute Rename (2019-10-17):** Renames `billing` to `collection_method` on invoices, subscriptions, and subscription schedules.
*   **Invoice Due Date Null (2019-10-17):** The `due_date` property is always null on auto-billed invoices.
*   **Customer Account Balance Rename (2019-10-17):** Renames `account_balance` to `balance` on Customer object.
*   **Custom Account Creation Requested Capabilities (2019-11-05):** Adds requirement for `requested_capabilities` on custom account creation.
*   **Subscription Schedule Settings Nesting (2019-11-05):** Nested subscription schedule settings under `default_settings`.
*   **Invoice Line Item IDs Standardized (2019-12-03):** Standardizes invoice line item IDs.
*   **Post-Payment Credit Note Requirement (2019-12-03):** New requirement for `out_of_band_amount` when creating post-payment credit notes.
*   **Customer Balances Returned Voided Invoices (2019-12-03):** Customer balances are now returned when voiding invoices.
*   **Deprecated Tax Information Fields Removal (2019-12-03):** Removes deprecated tax information fields from the Customer object.
*   **Sequential Invoice Numbering (2020-03-02):** Invoices can now be numbered sequentially across your account.
*   **Tax Percent Attribute Removal (2020-08-27):** Removes the `tax_percent` attribute.
*   **Customer Sources Auto-Expansion Deprecation (2020-08-27):** Customer sources are no longer auto-expanded by default.
*   **Customer Tax IDs Auto-Expansion Deprecation (2020-08-27):** Tax IDs are no longer auto-expanded on the Customer object.
*   **Subscription Prorate Parameters Deprecation (2020-08-27):** Deprecates `prorate` and `subscription_prorate` parameters.
*   **Subscription Schedule Phases Attributes Rename (2020-08-27):** Renames phases attributes in subscription schedules.
*   **Automatic Updates Event Type Rename (2020-08-27):** Renames event type that triggers on automatic updates.
*   **Checkout Session Display Items Removal (2020-08-27):** Removes the `display_items` property from Checkout Sessions.
*   **Accounts Persons Capabilities Error Codes (2020-08-27):** Adds new error codes to the Accounts, Persons, and Capabilities APIs.
*   **3D Secure Details Charge Object Update (2020-08-27):** Updates to 3D Secure details in Charge object.
*   **Customer Subscriptions Auto-Expansion Deprecation (2020-08-27):** Customer subscriptions are no longer auto-expanded by default.
*   **Plan Tiers Auto-Expansion Deprecation (2020-08-27):** Plan tiers are no longer auto-expanded by default.
*   **Invoice Include Require Value Removal (2022-08-01):** Removes the `include_and_require` value when creating invoices.
*   **Checkout Session Default Customer Creation (2022-08-01):** Default customer creation in Checkout Session payment mode changed to `if_required`.
*   **Deferred PaymentIntent Creation Checkout Session (2022-08-01):** Deferred PaymentIntent creation in Checkout Session payment mode.
*   **Checkout Session Setup Intent Removal (2022-08-01):** Removes the `setup_intent` property from Checkout Sessions in subscription mode.
*   **Checkout Session Line Item Parameters Replacement (2022-08-01):** Replaces line item parameters from the Create Checkout Session endpoint.
*   **Checkout Session Subscription Data Removal (2022-08-01):** Removes the `subscription_data` parameter from the Create Checkout Session endpoint.
*   **Checkout Session Shipping Rate Removal (2022-08-01):** Removes the `shipping_rate` parameter from Create Checkout Session endpoint.
*   **3D Secure Exemption Status Charges (2022-08-01):** Adds 3D Secure exemption status to card charges.
*   **Charges Object No Auto-Expand Refunds (2022-11-15):** The Charges object no longer auto-expands refunds by default.
*   **PaymentIntent Charges Attribute Removal (2022-11-15):** Removes the `charges` attribute from the PaymentIntent object.
*   **PaymentIntent/PaymentMethod Decline Codes (2022-11-15):** Adds new decline codes to the PaymentIntent and PaymentMethod APIs.
*   **SetupIntent Decline Codes (2022-11-15):** Adds new decline codes to the SetupIntent API.
*   **Accounts API Structure Error Code (2022-11-15):** Adds a new structure error code to the Accounts API.
*   **Automatic Payment Methods Default (2023-08-16):** Enables automatic payment methods by default for PaymentIntents and SetupIntents.
*   **Checkout Sessions No-Cost Orders (2023-08-16):** One-time payments in Checkout Sessions support no-cost orders.
*   **Platform-Scope PaymentMethod Fingerprints (2023-08-16):** Platform-scope rendering for select PaymentMethod fingerprints.
*   **Klarna Payment Failure Error Codes (2023-08-16):** Adds specific error codes for failed Klarna payments.
*   **Accounts Persons Capabilities Error Codes (2023-08-16):** Adds new director verification error codes to the Accounts API.
*   **Accounts Requirement Error Codes (2023-10-16):** Adds new account requirement error codes to the Accounts API.
*   **Statement Descriptor Auto-Population (2023-10-16):** Auto-populates the statement descriptor and prefix in the Accounts API.
*   **Switzerland UID Tax ID (2024-09-30):** Adds Switzerland UID as a supported customer tax ID.
*   **Credit Notes Email Types (2024-09-30):** Adds support for email types to Credit Notes.
*   **Terminal Reboot Time Setting (2024-09-30):** Adds support for configuring the reboot time setting.
*   **Payment Links New Payment Methods (2024-09-30):** Adds support for three new payment methods: Multibanco, Twint, and Zip.
*   **Financial Connections Account Subcategories Filtering (2024-09-30):** Adds support for filtering by account subcategories on Financial Connections.
*   **Financial Connections Sessions Filtering Expansion (2024-09-30):** Expands filtering support for Financial Connections Sessions.
*   **Bulk Invoice Line Item Operations (2024-09-30):** Adds support for bulk invoice line item operations.
*   **Tax Transaction Creation Posting Time (2024-09-30):** Adds support for posting time on tax transaction creation.
*   **Issuing Card Address Validation (2024-09-30):** Adds address validation for physical cards.
*   **Payment Element Customer Session Support (2024-09-30):** Adds support for the Payment Element on a Customer Session.
*   **Confirmation Tokens CVC Retrieval (2024-09-30):** Adds option to retrieve CVC tokens on Confirmation Tokens.
*   **Disputes Case Type for Cards (2024-09-30):** Adds support for identifying the case type for card disputes.
*   **Affirm Transaction IDs (2024-09-30):** Adds support for Affirm transaction IDs.
*   **Twint Payment Method Configuration (2024-09-30):** Adds Twint to the PaymentMethodConfiguration API.
*   **Interac Present Support (2024-09-30):** Adds support for in-person payment methods, including Interac cards.
*   **Accounts Business Profile Refactoring (2024-09-30):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Person Document Verification Details Code Additions (2024-09-30):** Adds new `details_code` values to person document verification.

**Billing**

*   **Coupon Behavior Change (2013-10-29):** Coupons only apply to an invoice's total balance and no longer apply to zero-cost invoices.
*   **Invoice Line Item Ending Periods (2015-04-07):** Updates how ending periods are calculated on prorated invoice line items.
*   **Invoice Lines Sorting Order (2015-04-07):** Changes the sorting order of lines for invoices.
*   **Account Manual Payout Schedules Error (2015-06-15):** Accounts on manual payout schedules now throw a new error.
*   **Subscription Trial End Dates (2014-01-31):** Trial end dates are no longer computed for canceled subscriptions.
*   **Subscription Source Parameter Modification (2018-07-27):** Subscriptions no longer support modifying the `source` parameter directly.
*   **Subscription Ending Period Configuration (2018-08-23):** A subscription's ending period can no longer be configured while canceling it.
*   **Plan Link to Products (2018-02-05):** Plans now link to individual products, with several fields moving to the product resource.
*   **Product Type Field Requirement (2018-02-05):** Products now require a `type` field, differentiating their use with order SKUs or subscriptions and plans.
*   **Invoice Line Item IDs Standardized (2019-12-03):** Standardizes invoice line item IDs.
*   **Post-Payment Credit Note Requirement (2019-12-03):** New requirement for `out_of_band_amount` when creating post-payment credit notes.
*   **Customer Balances Returned Voided Invoices (2019-12-03):** Customer balances are now returned when voiding invoices.
*   **Invoice Auto Advance Field (2018-11-08):** Invoices now specify their automatic collection behavior using the `auto_advance` field.
*   **One-off Invoice Payment Default (2018-11-08):** One-off Invoices no longer automatically collect payment by default.
*   **Invoice Forgiven Field Replaced (2018-11-08):** Replaces the `forgiven` field with a new `uncollectible` status for invoices.
*   **Invoice Error Code Rename (2018-11-08):** Renames an invoice error code to `invoice_already_finalized`.
*   **Subscription First Invoice Billing Reason (2018-10-31):** The `billing_reason` of the first invoice of a subscription is now `subscription_create`.
*   **Customer Subscriptions Auto-Expansion Deprecation (2020-08-27):** Customer subscriptions are no longer auto-expanded by default.
*   **Plan Tiers Auto-Expansion Deprecation (2020-08-27):** Plan tiers are no longer auto-expanded by default.
*   **Invoice Include Require Value Removal (2022-08-01):** Removes the `include_and_require` value when creating invoices.
*   **Subscription Trial Period Default (2018-05-21):** Subscriptions now default to not defining their trial periods depending on a plan.
*   **Subscription Plan Change Trial Extension (2018-05-21):** Changing a subscription to a new plan with a trial now extends the trial period.
*   **Flexible Billing Mode Default (2025-08-27, 2025-09-30):** Makes flexible billing mode the default for new subscriptions.
*   **Billing Thresholds Flexible Billing Mode (2025-07-30):** Adds support for billing thresholds on flexible billing mode Subscriptions.
*   **Invoice Rendering Templates (2024-09-30, 2025-03-31, 2025-10-29):** Adds Invoice Rendering Templates for Invoices, including methods to retrieve and archive them, and support for templates on Invoices and Customers.
*   **Credit Grants API and Resources (2024-10-28):** Adds new API for managing billing credits.
*   **Pre-tax Credit Amount Information to Invoices (2024-10-28):** Adds support for pre-tax credit amount information to invoices.
*   **Pre-tax Credit Amount Information to Credit Notes (2024-10-28):** Adds support for pre-tax credit amount information to credit notes.
*   **Billing Meter Webhook Event Types (2025-03-31):** Adds new webhook event types for Billing Meters.
*   **Billing Credits Webhook Event Types (2025-03-31):** Adds new webhook event types for billing credits.
*   **Subscription Item-Level Billing Periods (2025-03-31):** Adds subscription item-level billing periods and removes subscription-level periods.
*   **Deprecates Legacy Usage-Based Billing (2025-03-31):** Removes legacy usage-based billing.
*   **Payment Line Items Support (2025-04-30, 2025-07-30, 2025-10-29):** Adds support for payment line items.
*   **Invoice Payment Records (2025-10-29):** Adds support for using Payment Records with Invoices and Credit Notes.
*   **Credit Grant Optional Category (2025-10-29):** Updates the category field of Credit Grants to be optional.
*   **Invoice Payment Attempt Required Event (2025-10-29):** Adds a webhook event type for Invoices that require a non-Stripe payment.
*   **Customer Portal Subscription Downgrades (2024-10-28):** Adds scheduled subscription downgrades in the customer portal.
*   **Tax Registration New Countries (2024-10-28, 2025-04-30, 2025-10-29):** Adds support for new countries to the Tax Registration API.
*   **Tax ID Types in New Countries (2024-10-28, 2025-04-30):** Adds support for tax ID types in several new countries.
*   **Checkout Sessions Branding Settings (2025-09-30):** Adds support for configuring branding settings for Checkout Sessions.
*   **Invoice Rendering Templates (2024-09-30, 2025-03-31, 2025-10-29):** Adds Invoice Rendering Templates for Invoices, including methods to retrieve and archive them, and support for templates on Invoices and Customers.
*   **Subscription Item Interval Support (2025-07-30):** Adds support for mixed intervals on the same subscription.
*   **Customer Portal Configuration Trial Behavior (2025-09-30):** Adds customer portal configuration trial behavior.
*   **Klarna Chargeback Losses Reason (2025-09-30):** Adds a documented reason for Klarna chargeback losses to Disputes API.
*   **Risk Requirements Descriptions (2020-08-27):** Adds specific descriptions for risk requirements during legal, PEP, and sanctions review.
*   **Accounts API New Error Codes (2020-08-27):** Adds new error codes to the Accounts, Persons, and Capabilities APIs.
*   **PaymentIntent/PaymentMethod Decline Codes (2022-11-15):** Adds new decline codes to the PaymentIntent and PaymentMethod APIs.
*   **SetupIntent Decline Codes (2022-11-15):** Adds new decline codes to the SetupIntent API.
*   **Accounts API Structure Error Code (2022-11-15):** Adds a new structure error code to the Accounts API.
*   **Payment Intents Automatic Payment Methods Default (2023-08-16):** Enables automatic payment methods by default for PaymentIntents and SetupIntents.
*   **Checkout Sessions No-Cost Orders (2023-08-16):** One-time payments in Checkout Sessions support no-cost orders.
*   **Platform-Scope PaymentMethod Fingerprints (2023-08-16):** Platform-scope rendering for select PaymentMethod fingerprints.
*   **Klarna Payment Failure Error Codes (2023-08-16):** Adds specific error codes for failed Klarna payments.
*   **Accounts Persons Capabilities Error Codes (2023-08-16):** Adds new director verification error codes to the Accounts API.
*   **Accounts Requirement Error Codes (2023-10-16):** Adds new account requirement error codes to the Accounts API.
*   **Statement Descriptor Auto-Population (2023-10-16):** Auto-populates the statement descriptor and prefix in the Accounts API.
*   **PaymentIntent Capture Method (2025-11-17):** Adds the ability to specify the capture method for card present payments with Payment Intents.
*   **Issuing Authorizations Fraud Risk Assessments (2025-11-17):** Adds fraud risk assessments to Issuing Authorizations.
*   **Accounts v2 Payment Method Billing Details for Tax (2025-10-29):** Adds support for using Accounts v2 payment method billing details for Stripe Tax location.
*   **Checkout Session Custom UI Mode (2025-03-31):** Adds custom UI mode to Checkout Sessions.
*   **Checkout Session Permissions Parameter (2025-09-30):** Adds permissions parameter to Checkout Sessions.
*   **Invoice Rendering Templates (2024-09-30, 2025-03-31, 2025-10-29):** Adds Invoice Rendering Templates for Invoices, including methods to retrieve and archive them, and support for templates on Invoices and Customers.
*   **Credit Grants API and Resources (2024-10-28):** Adds new API for managing billing credits.
*   **Pre-tax Credit Amount Information to Invoices (2024-10-28):** Adds support for pre-tax credit amount information to invoices.
*   **Pre-tax Credit Amount Information to Credit Notes (2024-10-28):** Adds support for pre-tax credit amount information to credit notes.
*   **Billing Meter Webhook Event Types (2025-03-31):** Adds new webhook event types for Billing Meters.
*   **Billing Credits Webhook Event Types (2025-03-31):** Adds new webhook event types for billing credits.
*   **Subscription Item-Level Billing Periods (2025-03-31):** Adds subscription item-level billing periods and removes subscription-level periods.
*   **Deprecates Legacy Usage-Based Billing (2025-03-31):** Removes legacy usage-based billing.
*   **Payment Line Items Support (2025-04-30, 2025-07-30, 2025-10-29):** Adds support for payment line items.
*   **Invoice Payment Records (2025-10-29):** Adds support for using Payment Records with Invoices and Credit Notes.
*   **Credit Grant Optional Category (2025-10-29):** Updates the category field of Credit Grants to be optional.
*   **Invoice Payment Attempt Required Event (2025-10-29):** Adds a webhook event type for Invoices that require a non-Stripe payment.
*   **Accounts v2 Capabilities Requirement (2019-02-19):** Adds requirement for `requested_capabilities` on custom account creation.
*   **Accounts Country Capabilities Requirement (2019-09-09):** Accounts in many countries now require specifying capabilities at creation time.
*   **Person Object Relationship Attribute Rename (2019-10-08):** Renames a Person object relationship attribute.
*   **Subscription Schedule Renewal Properties Update (2019-10-17):** Renames and updates subscription schedule renewal properties.
*   **Subscription Start Field Replaced (2019-10-17):** Replaces the `subscription start` field with `start_date`.
*   **Billing Attribute Rename (2019-10-17):** Renames `billing` to `collection_method` on invoices, subscriptions, and subscription schedules.
*   **Invoice Due Date Null (2019-10-17):** The `due_date` property is always null on auto-billed invoices.
*   **Customer Account Balance Rename (2019-10-17):** Renames `account_balance` to `balance` on Customer object.
*   **Custom Account Creation Requested Capabilities (2019-11-05):** Adds requirement for `requested_capabilities` on custom account creation.
*   **Subscription Schedule Settings Nesting (2019-11-05):** Nested subscription schedule settings under `default_settings`.
*   **Invoice Line Item IDs Standardized (2019-12-03):** Standardizes invoice line item IDs.
*   **Post-Payment Credit Note Requirement (2019-12-03):** New requirement for `out_of_band_amount` when creating post-payment credit notes.
*   **Customer Balances Returned Voided Invoices (2019-12-03):** Customer balances are now returned when voiding invoices.
*   **Deprecated Tax Information Fields Removal (2019-12-03):** Removes deprecated tax information fields from the Customer object.
*   **Sequential Invoice Numbering (2020-03-02):** Invoices can now be numbered sequentially across your account.
*   **Tax Percent Attribute Removal (2020-08-27):** Removes the `tax_percent` attribute.
*   **Customer Sources Auto-Expansion Deprecation (2020-08-27):** Customer sources are no longer auto-expanded by default.
*   **Customer Tax IDs Auto-Expansion Deprecation (2020-08-27):** Tax IDs are no longer auto-expanded on the Customer object.
*   **Subscription Prorate Parameters Deprecation (2020-08-27):** Deprecates `prorate` and `subscription_prorate` parameters.
*   **Subscription Schedule Phases Attributes Rename (2020-08-27):** Renames phases attributes in subscription schedules.
*   **Automatic Updates Event Type Rename (2020-08-27):** Renames event type that triggers on automatic updates.
*   **Checkout Session Display Items Removal (2020-08-27):** Removes the `display_items` property from Checkout Sessions.
*   **Accounts Persons Capabilities Error Codes (2020-08-27):** Adds new error codes to the Accounts, Persons, and Capabilities APIs.
*   **3D Secure Details Charge Object Update (2020-08-27):** Updates to 3D Secure details in Charge object.
*   **Customer Subscriptions Auto-Expansion Deprecation (2020-08-27):** Customer subscriptions are no longer auto-expanded by default.
*   **Plan Tiers Auto-Expansion Deprecation (2020-08-27):** Plan tiers are no longer auto-expanded by default.
*   **Invoice Include Require Value Removal (2022-08-01):** Removes the `include_and_require` value when creating invoices.
*   **Checkout Session Default Customer Creation (2022-08-01):** Default customer creation in Checkout Session payment mode changed to `if_required`.
*   **Deferred PaymentIntent Creation Checkout Session (2022-08-01):** Deferred PaymentIntent creation in Checkout Session payment mode.
*   **Checkout Session Setup Intent Removal (2022-08-01):** Removes the `setup_intent` property from Checkout Sessions in subscription mode.
*   **Checkout Session Line Item Parameters Replacement (2022-08-01):** Replaces line item parameters from the Create Checkout Session endpoint.
*   **Checkout Session Subscription Data Removal (2022-08-01):** Removes the `subscription_data` parameter from the Create Checkout Session endpoint.
*   **Checkout Session Shipping Rate Removal (2022-08-01):** Removes the `shipping_rate` parameter from Create Checkout Session endpoint.
*   **3D Secure Exemption Status Charges (2022-08-01):** Adds 3D Secure exemption status to card charges.
*   **Charges Object No Auto-Expand Refunds (2022-11-15):** The Charges object no longer auto-expands refunds by default.
*   **PaymentIntent Charges Attribute Removal (2022-11-15):** Removes the `charges` attribute from the PaymentIntent object.
*   **PaymentIntent/PaymentMethod Decline Codes (2022-11-15):** Adds new decline codes to the PaymentIntent and PaymentMethod APIs.
*   **SetupIntent Decline Codes (2022-11-15):** Adds new decline codes to the SetupIntent API.
*   **Accounts API Structure Error Code (2022-11-15):** Adds a new structure error code to the Accounts API.
*   **Automatic Payment Methods Default (2023-08-16):** Enables automatic payment methods by default for PaymentIntents and SetupIntents.
*   **Checkout Sessions No-Cost Orders (2023-08-16):** One-time payments in Checkout Sessions support no-cost orders.
*   **Platform-Scope PaymentMethod Fingerprints (2023-08-16):** Platform-scope rendering for select PaymentMethod fingerprints.
*   **Klarna Payment Failure Error Codes (2023-08-16):** Adds specific error codes for failed Klarna payments.
*   **Accounts Persons Capabilities Error Codes (2023-08-16):** Adds new director verification error codes to the Accounts API.
*   **Accounts Requirement Error Codes (2023-10-16):** Adds new account requirement error codes to the Accounts API.
*   **Statement Descriptor Auto-Population (2023-10-16):** Auto-populates the statement descriptor and prefix in the Accounts API.
*   **Switzerland UID Tax ID (2024-09-30):** Adds Switzerland UID as a supported customer tax ID.
*   **Credit Notes Email Types (2024-09-30):** Adds support for email types to Credit Notes.
*   **Terminal Reboot Time Setting (2024-09-30):** Adds support for configuring the reboot time setting.
*   **Payment Links New Payment Methods (2024-09-30):** Adds support for three new payment methods: Multibanco, Twint, and Zip.
*   **Financial Connections Account Subcategories Filtering (2024-09-30):** Adds support for filtering by account subcategories on Financial Connections.
*   **Financial Connections Sessions Filtering Expansion (2024-09-30):** Expands filtering support for Financial Connections Sessions.
*   **Bulk Invoice Line Item Operations (2024-09-30):** Adds support for bulk invoice line item operations.
*   **Tax Transaction Creation Posting Time (2024-09-30):** Adds support for posting time on tax transaction creation.
*   **Issuing Card Address Validation (2024-09-30):** Adds address validation for physical cards.
*   **Payment Element Customer Session Support (2024-09-30):** Adds support for the Payment Element on a Customer Session.
*   **Confirmation Tokens CVC Retrieval (2024-09-30):** Adds option to retrieve CVC tokens on Confirmation Tokens.
*   **Disputes Case Type for Cards (2024-09-30):** Adds support for identifying the case type for card disputes.
*   **Affirm Transaction IDs (2024-09-30):** Adds support for Affirm transaction IDs.
*   **Twint Payment Method Configuration (2024-09-30):** Adds Twint to the PaymentMethodConfiguration API.
*   **Interac Present Support (2024-09-30):** Adds support for in-person payment methods, including Interac cards.
*   **Accounts Business Profile Refactoring (2024-09-30):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Person Document Verification Details Code Additions (2024-09-30):** Adds new `details_code` values to person document verification.

**Connect**

*   **Ownership Exemption Reason for Accounts API (Acacia):** The `ownership_exemption_reason` parameter has been added to the `company` field of the Accounts resource. This allows businesses to provide an exemption reason for Ultimate Beneficial Ownership (UBO) requirements.
*   **Connect Events Originating Account (2017-05-25):** Events for Connect now specify the originating connected account using the `account` field.
*   **Account Activation Status Terms Updated (2014-11-05):** Account activation status terms have been updated for payments and transfers.
*   **US Accounts Requested Capabilities (2019-02-19):** Accounts in the US now require specifying capabilities at creation time.
*   **Account Fields Refactored (2019-02-19):** Several account fields have been refactored to better describe legal entity, verification status and requirements, and configurable settings.
*   **Account Business Details Moved (2019-02-19):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Account/Person Verification Front/Back Support (2019-02-19):** Verification of accounts or persons now supports uploading both front and back sides.
*   **Account Keys Field Removal (2019-02-19):** Accounts no longer provide a `keys` field. Platforms should use their own API key to authenticate as their connected accounts.
*   **Accounts Persons Capabilities Error Codes (2020-08-27):** Adds new error codes to the Accounts, Persons, and Capabilities APIs.
*   **Accounts Requirement Error Codes (2023-10-16):** Adds new account requirement error codes to the Accounts API.
*   **Statement Descriptor Auto-Population (2023-10-16):** Auto-populates the statement descriptor and prefix in the Accounts API.
*   **Accounts v2 API for Connected Accounts (2025-11-17):** Connect platforms can now use Accounts v2 to manage connected accounts and customers.
*   **Accounts v2 API Interoperability (2025-11-17):** Adds the `customer_account` property to v1 APIs for Accounts v2 interoperability.
*   **Accounts v2 Responsibilities Field (2025-11-17):** Accounts v2 now always returns the `responsibilities` field when the `defaults` field is included.
*   **Accounts v2 Capabilities Requested Field Removal (2025-11-17):** Removes `requested` field from Accounts v2 capabilities hashes.
*   **PayPay Onboarding Parameters to Accounts API (2025-11-17):** Adds PayPay onboarding parameters to the Accounts API.
*   **Accounts v2 Identity Properties Restriction (2026-03-25):** Restricts Accounts v2 identity properties for some Global Payouts use cases.
*   **Accounts v2 Time Zone Support (2026-03-25):** Adds time zone support to the Accounts v2 API.
*   **Accounts v2 Proof of Registration and Beneficial Ownership (2025-10-29):** Adds the ability to attest to an Account's authorized company representative for Accounts v2.

**Invoicing**

*   **Invoice Line Item Ending Periods (2015-04-07):** Updates how ending periods are calculated on prorated invoice line items.
*   **Invoice Lines Sorting Order (2015-04-07):** Changes the sorting order of lines for invoices.
*   **Invoice Charge Field Latest Charge (2015-09-23):** The `charge` field now always reflects the latest charge on invoices.
*   **Invoice Payment Property Removal (2015-09-23):** Invoices no longer include the `payment` property.
*   **Invoice State Transition Timestamps (2019-03-14):** Invoices now provide timestamps for each state transition.
*   **Invoice Date Field Rename (2019-03-14):** Renames the `date` field for invoices to `created`.
*   **Invoice Finalized Alongside Status Transitions (2019-03-14):** Invoices now specify when they're finalized alongside other status transitions.
*   **Invoice Line Item IDs Standardized (2019-12-03):** Standardizes invoice line item IDs.
*   **Post-Payment Credit Note Requirement (2019-12-03):** New requirement for `out_of_band_amount` when creating post-payment credit notes.
*   **Customer Balances Returned Voided Invoices (2019-12-03):** Customer balances are now returned when voiding invoices.
*   **Invoice Auto Advance Field (2018-11-08):** Invoices now specify their automatic collection behavior using the `auto_advance` field.
*   **One-off Invoice Payment Default (2018-11-08):** One-off Invoices no longer automatically collect payment by default.
*   **Invoice Forgiven Field Replaced (2018-11-08):** Replaces the `forgiven` field with a new `uncollectible` status for invoices.
*   **Invoice Error Code Rename (2018-11-08):** Renames an invoice error code to `invoice_already_finalized`.
*   **Customer Tax Info Object (2018-08-23):** Customers now provide a `tax_info` object with their tax ID details.
*   **Tax Calculation Provider to Tax Settings (2025-10-29):** Adds tax calculation provider to Tax settings.
*   **Invoice Rendering Templates (2024-09-30, 2025-03-31, 2025-10-29):** Adds Invoice Rendering Templates for Invoices, including methods to retrieve and archive them, and support for templates on Invoices and Customers.
*   **Customer Portal Subscription Downgrades (2024-10-28):** Adds scheduled subscription downgrades in the customer portal.
*   **Invoice Payment Attempt Required Event (2025-10-29):** Adds a webhook event type for Invoices that require a non-Stripe payment.
*   **Invoice Line Item Subtotal Property (2025-12-15):** Adds subtotal property to Invoice Line Items.

**Other Product Areas**

*   **Ownership Exemption Reason for Accounts API (Acacia):** The `ownership_exemption_reason` parameter has been added to the `company` field of the Accounts resource. This allows businesses to provide an exemption reason for Ultimate Beneficial Ownership (UBO) requirements.
*   **Unrecognized API Parameters Error Handling (2011-06-21):** The API now raises exceptions for unrecognized parameters, improving error handling and preventing silent failures.
*   **Plan Object Changes (2011-06-28):** The `identifier` field has been removed from the Plan object, as it was a duplicate of the `id` field.
*   **List Format Updates (2011-08-01):** List objects now include a `data` property (an array of objects) and a `count` property (total count of items).
*   **Token Validation Changes (2011-09-15):** Card validation behavior when creating tokens has been updated.
*   **Null Values in API Responses (2012-02-23):** Fields with null values are now included in API responses for more comprehensive data representation.
*   **Customer Object Changes (2012-03-25, 2012-07-09):** The `next_recurring_charge` and `uncaptured` fields have been removed from the Customer object.
*   **Token Properties Removal (2012-06-18):** The `amount` and `currency` properties have been removed from the Token object.
*   **Discount Object Change (2012-09-24):** The extraneous `id` property has been removed from the Discount object.
*   **Invoice Line Items Sublist (2012-10-26):** The `lines` property on the Invoice object is now a paginated sublist.
*   **Charge Field Rename (2012-11-07):** The `disputed` field for Charges has been renamed to `dispute`.
*   **Failed Invoice Payments (2013-02-11):** Failed invoice payments now return an HTTP error.
*   **Dispute Fee Tracking (2013-02-13):** Disputes on charges are now tracked through the `stripe_fee` field and included in the fee total.
*   **Customer Cards and Default Card (2013-07-05):** The `active_card` property on the Customer object has been replaced with `cards` (a sublist) and `default_card` (an ID).
*   **Null Description and Email Fields (2013-08-12):** The `description` and `email` fields can now be null on several objects.
*   **Fee Details Moved to Balance Transactions (2013-08-13, 2013-08-13):** Fee details have moved from Charges and Transfers to their corresponding balance transactions.
*   **Application Fees and Account Field (2013-12-03):** Application fees now provide an expandable `account` field to obtain user details.
*   **Application Fee Refunds Proportionality (2013-12-03):** Application fee refunds are now proportional to the charged amount.
*   **Customer Subscriptions Support (2014-01-31):** Customers now support multiple subscriptions.
*   **Subscription Trial End Dates (2014-01-31):** Trial end dates are no longer computed for canceled subscriptions.
*   **Statement Descriptor Field Rename (2014-03-13):** The `statement_descriptor` field on Transfers has been renamed to `statement_description`.
*   **List Count Field Removal (2014-03-28):** Lists no longer include the `count` field.
*   **Transfer Account Field Replacement (2014-05-19):** The `account` field on Transfers has been replaced with `bank_account`.
*   **Card Type Field Rename (2014-06-13):** The `type` field on Cards has been renamed to `brand`.
*   **Invoice Refunds Sublist (2014-06-17):** Invoices now include a sublist of refunds through the `refunds` field.
*   **Invoice Line Items Include Subscription Details (2014-07-22):** Invoice line items now include subscription plans and quantities.
*   **Application Fees Include Refunds Sublist (2014-07-26):** Application fees now include a sublist of refunds through the `refunds` field.
*   **Balance Histories Retrieval (2014-08-04):** Balance histories can now be retrieved rather than relying on Transfer fields.
*   **Dispute Statuses Update (2014-08-20):** Disputes now provide several new statuses.
*   **Disputes Include Multiple Balance Transactions (2014-08-20):** Disputes now include multiple balance transactions.
*   **Bank Accounts Status Enum (2014-09-08):** Bank Accounts now include a `status` enum that replaces multiple fields.
*   **Token Retrieval with Publishable Keys (2014-10-07):** Tokens can no longer be retrieved with publishable keys.
*   **Card/Bank Account Creation Fingerprint Omission (2014-10-07):** Creating a Card or Bank Account with a publishable key omits fingerprints in API responses.
*   **Account Activation Status Terms Updated (2014-11-05):** Account activation status terms have been updated for payments and transfers.
*   **Disputes Won with Refunded Charge (2014-11-20):** Disputes are now reported as won even if the charge is refunded.
*   **Invoice Items Reflect Subscription Metadata (2014-11-20):** Invoice items now reflect the metadata for their associated subscription, rather than plan.
*   **Dispute Evidence Details Object (2014-12-08):** Disputes now include an `evidence_details` object for evidence documentation.
*   **Statement Descriptor Field Introduction (2014-12-17):** The `statement_description` field and logic for how charges, invoices, plans, and transfers render statement descriptors have been introduced.
*   **Account Creation API Version Requirement (2014-12-17):** Creating accounts using the API requires the 2014-12-17 version or newer.
*   **Card Address/CVC Check Values (2014-12-22):** Cards now use both the `unchecked` and `unavailable` values to describe address and CVC checks by issuing banks.
*   **Token Customer Field Removal (2014-12-22):** Tokens with cards no longer include the `customer` field.
*   **File Upload Type and Format (2015-01-11):** File uploads describe their file type with the simpler `type` field and format.
*   **Event Previous Attributes Rendering (2015-01-26):** Events with the `previous_attributes` field now only render the differences to objects across updates.
*   **Subscription API Invoice Failures (2015-01-26):** Subscriptions now only report the timestamp for API or invoice payment failures for the `canceled_at` field.
*   **Dispute Statuses Include Warning Closed (2015-02-10):** Dispute statuses now include the `warning_closed` value.
*   **Transfers Require Sufficient Balance (2015-02-10):** Transfers now require a sufficient account balance in test mode to better simulate live mode.
*   **Transfer Canceled Event Rename (2015-02-16):** The `transfer.canceled` event type is now `transfer.reversed`.
*   **Charge Succeeded Status (2015-02-18):** Charges that succeed now have a `succeeded` status.
*   **Charge Source Field (2015-02-18):** Charges now have a `source` field that accepts a source or card.
*   **Customer Source Field (2015-02-18):** Customers now have a `source` field that accepts a source or card, and updates related event types.
*   **Coupon Negative Invoice Items (2015-03-24):** By default, coupons no longer apply to invoice items with negative amounts.
*   **Invoice Line Item Ending Periods (2015-04-07):** Updates how ending periods are calculated on prorated invoice line items.
*   **Invoice Lines Sorting Order (2015-04-07):** Changes the sorting order of lines for invoices.
*   **Account Manual Payout Schedules Error (2015-06-15):** Accounts on manual payout schedules now throw a new error.
*   **Transfer In Transit Status (2015-07-07):** Transfers submitted to the bank that haven't arrived now provide an `in_transit` status.
*   **Account Verification Disabled Reason (2015-07-13):** Accounts now include the `verification[disabled_reason]` field to describe why they can't make transfers or charges.
*   **Balance Available Event for Immediate Transfers (2015-07-28):** Transfers that are immediately processed now trigger the `balance.available` event.
*   **Account TOS Acceptance Date Validation (2015-08-07):** Stripe now ensures the `tos_acceptance[date]` field on accounts is a valid timestamp.
*   **Balance Transactions Source Field (2015-08-19):** Balance transactions with refunds or disputes now specify the corresponding ID in the `source` field.
*   **Idempotency Token Reuse Error (2015-09-03):** Requests that reuse idempotency tokens but alter request parameters now throw an error.
*   **Rate-Limited Requests HTTP 429 Error (2015-09-08):** Rate-limited requests now return an HTTP 429 error, no longer including the `rate_limit` field.
*   **Invoice Charge Field Latest Charge (2015-09-23):** The `charge` field now always reflects the latest charge on invoices.
*   **Invoice Payment Property Removal (2015-09-23):** Invoices no longer include the `payment` property.
*   **Listing Charges Funding Sources (2015-09-23):** Listing all charges now includes payments from all funding sources.
*   **Charges List Pagination Offset (2015-09-23):** Charges only support an offset for list pagination when filtering by source.
*   **Bank Account Information Renamed to External Accounts (2015-10-01):** Bank account information renamed to external accounts on user profiles.
*   **Accounts Include External Accounts Field (2015-10-01):** Accounts now include an `external_accounts` field.
*   **Invalid Parameters Throw HTTP 400 Error (2015-10-12):** Using invalid parameters to create cards or bank accounts for tokens, sources, or external bank accounts now throws an HTTP 400 error.
*   **Customer Plan Tax Percentage Requirement (2015-10-16):** Creating or updating customers must now include a plan if a tax percentage is specified.
*   **Account Legal Entity Country-Specific Subfields (2016-02-03):** Accounts now only show country-specific subfields for the `legal_entity` field.
*   **Bank Account Name Field Rename (2016-02-19):** Renames the `name` field on Bank Accounts to `account_holder_name`.
*   **Invoice Items Limit (2016-02-22):** You can no longer add more than 250 invoice items to an invoice.
*   **Order Cancellation Refunds (2016-02-23):** Orders that are paid or fulfilled, and then become canceled or returned, now automatically refund associated charges.
*   **Account Postal Code Validation (2016-02-29):** Creating or updating an account now validates the postal code for its legal entity.
*   **Supported Currencies Defined by Country Spec (2016-03-07):** Supported currencies are defined on the country spec for an account's country.
*   **Product Deactivation SKU Deactivation (2016-06-15):** Deactivating a product no longer automatically deactivates its SKUs.
*   **Filter Canceled Subscriptions (2016-07-06):** Filter lists of subscriptions for canceled subscriptions.
*   **Insufficient Permissions HTTP 403 Error (2016-10-19):** Using insufficient permissions to make API requests now throws an HTTP 403 error.
*   **Balance Transactions Sourced Transfers Removal (2017-01-27):** Balance transactions no longer include the `sourced_transfers` field.
*   **Charge Rule Blocking Transaction ID (2017-02-14):** Charges now specify the ID for the rule blocking a transaction, which can be expanded.
*   **Charge Dispute Association (2017-02-14):** Charges now specify the ID for the dispute associated with a transaction, which can be expanded.
*   **Transfers Split into Payouts and Transfers (2017-04-06):** Transfers are now split into payouts and transfers.
*   **Connect Events Originating Account (2017-05-25):** Events for Connect now specify the originating connected account using the `account` field.
*   **Events Request ID and Idempotency Key (2017-05-25):** The `request` field of the Events object now specifies both the request ID and idempotency key.
*   **Events Previous Attributes Sub-array Rendering (2017-05-25):** Events with the `previous_attributes` field now render the complete affected sub-array.
*   **Account Types (Standard, Express, Custom) (2017-05-25):** Accounts must now specify one of three types (Standard, Express, or Custom).
*   **Account Under Review Reason (2017-06-05):** Accounts can now specify why an account isn't enabled with the new `reason under_review`.
*   **Source Authentication Redirect (2017-08-15):** Sources can now specify that an authentication redirect isn't required.
*   **Invoice Line Items Description Requirement (2017-12-14):** Invoice line items now must always set a description.
*   **Invoice Payment Failures Card Error (2017-12-14):** Invoice payment failures now return a `card_error` when a charge is declined.
*   **Connect Reused Card/Bank Account Fingerprint (2018-01-23):** Connect platforms can identify reused card or bank accounts across connected accounts as they now will share the same fingerprint.
*   **Free Plans with Prorations Zero-Dollar Invoices (2018-02-05):** Free plans with prorations now produce zero-dollar invoices.
*   **Subscription Delay First Full Invoice (2018-02-05):** Subscriptions can now delay the first full invoice to a future date (and optionally include a free trial).
*   **Plan Link to Products (2018-02-05):** Plans now link to individual products, with several fields moving to the product resource.
*   **Product Type Field Requirement (2018-02-05):** Products now require a `type` field, differentiating their use with order SKUs or subscriptions and plans.
*   **Source Recommended 3D Secure (2018-02-06):** Sources now provide a recommended value when the issuer advises using 3D Secure.
*   **Canceled Subscription Update Status (2018-02-28):** Updating a canceled subscription on a future date no longer resets its status.
*   **Product SKU List Removal (2018-05-21):** Products no longer embed lists of SKUs.
*   **Invoice Line Items Unique IDs (2018-05-21):** Invoice line items now have unique IDs and can't be used in place of a subscription.
*   **Coupon, SKU, Customer, Product, Plan ID Character Limits (2018-05-21):** Coupons, SKUs, customers, products, and plans now limit the valid characters for IDs.
*   **Subscription Trial Period Default (2018-05-21):** Subscriptions now default to not defining their trial periods depending on a plan.
*   **Subscription Plan Change Trial Extension (2018-05-21):** Changing a subscription to a new plan with a trial now extends the trial period.
*   **Subscription Source Parameter Modification (2018-07-27):** Subscriptions no longer support modifying the `source` parameter directly.
*   **Subscription Trial End Timestamp (2018-07-27):** Ending a subscription trial now uses the timestamp of that API request.
*   **Coupon Percent Off Floats (2018-07-27):** Coupons now use floats rather than integers to specify `percent_off`.
*   **Customer Email Validation (2018-07-27):** Stripe now validates email addresses when creating or updating customers.
*   **Subscription Ending Period Configuration (2018-08-23):** A subscription's ending period can no longer be configured while canceling it.
*   **Customer Tax Info Object (2018-08-23):** Customers now provide a `tax_info` object with their tax ID details.
*   **Plan Tiers Amount Field Rename (2018-08-23):** Renames the `amount` field for plan tiers to `unit_amount`.
*   **SKU Values Uniqueness Removed (2018-09-06):** SKU values no longer need to be unique.
*   **FileUpload Object Rename to Files (2018-09-24):** Renames the FileUpload object to Files, which now require secret keys to download files.
*   **Customer Description Character Limit (2018-10-31):** Descriptions for customers now have a character limit.
*   **Product Name Character Limit (2018-10-31):** Product names now have a character limit.
*   **Invoice Line Item Description Character Limit (2018-10-31):** Descriptions for invoice line items now have a character limit.
*   **Subscription First Invoice Billing Reason (2018-10-31):** The `billing_reason` of the first invoice of a subscription is now `subscription_create`.
*   **Invoice Auto Advance Field (2018-11-08):** Invoices now specify their automatic collection behavior using the `auto_advance` field.
*   **One-off Invoice Payment Default (2018-11-08):** One-off Invoices no longer automatically collect payment by default.
*   **Invoice Forgiven Field Replaced (2018-11-08):** Replaces the `forgiven` field with a new `uncollectible` status for invoices.
*   **Invoice Error Code Rename (2018-11-08):** Renames an invoice error code to `invoice_already_finalized`.
*   **Payment Intents API Private Beta Changes (2018-11-08):** Includes several changes for users of the Payment Intents API private beta.
*   **Payment Intents Status Renames (2019-02-11):** Renames several statuses for PaymentIntents.
*   **Source Save Field Rename (2019-02-11):** Renames the `save_source_to_customer` field for sources to `save_payment_method`.
*   **Source Allowed Types Field Rename (2019-02-11):** Renames the `allowed_source_types` field for sources to `payment_method_types`.
*   **Payment Intents Next Source Action Rename (2019-02-11):** Renames the `next_source_action` field for Payment Intents to `next_action`.
*   **Payment Intents Authorize With URL Rename (2019-02-11):** Renames the `authorize_with_url` field for Payment Intents to `redirect_to_url`.
*   **Charges Statement Descriptor Behaviors (2019-02-19):** Changes statement descriptor behaviors for card payments created with Charges.
*   **Account Fields Refactored (2019-02-19):** Several account fields have been refactored to better describe legal entity, verification status and requirements, and configurable settings.
*   **Account Business Details Moved (2019-02-19):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Account/Person Verification Front/Back Support (2019-02-19):** Verification of accounts or persons now supports uploading both front and back sides.
*   **Account Keys Field Removal (2019-02-19):** Accounts no longer provide a `keys` field. Platforms should use their own API key to authenticate as their connected accounts.
*   **US Accounts Requested Capabilities (2019-02-19):** Accounts in the US now require specifying capabilities at creation time.
*   **Account Legal Entity Business ID Number Rename (2019-02-19):** Renames the `business_id_number` for an account's legal entity to `business_registration_number`.
*   **Invoice Application Fee Rename (2019-03-14):** Renames `application_fee` on invoices to `application_fee_amount`.
*   **Subscription First Payment Failure (2019-03-14):** Subscriptions are now successfully created even if the first payment fails.
*   **Invoice State Transition Timestamps (2019-03-14):** Invoices now provide timestamps for each state transition.
*   **Invoice Date Field Rename (2019-03-14):** Renames the `date` field for invoices to `created`.
*   **Invoice Finalized Alongside Status Transitions (2019-03-14):** Invoices now specify when they're finalized alongside other status transitions.
*   **Connect Platform Payments Capability Rename (2019-08-14):** Renames the `platform_payments` capability for accounts to `card_payments`, requiring the manual specification of the added `transfers` capability.
*   **Person Account Opener Executive Setting (2019-08-14):** Configuring a person as an account opener no longer automatically sets them as an executive.
*   **Accounts Many Countries Capabilities (2019-09-09):** Accounts in many countries now require specifying capabilities at creation time.
*   **Person Document Verification Details Code Additions (2019-09-09):** Adds new `details_code` values to person document verification.
*   **Person Object Relationship Attribute Rename (2019-10-08):** Renames a Person object relationship attribute.
*   **Subscription Schedule Renewal Properties Update (2019-10-17):** Renames and updates subscription schedule renewal properties.
*   **Subscription Start Field Replaced (2019-10-17):** Replaces the `subscription start` field with `start_date`.
*   **Billing Attribute Rename (2019-10-17):** Renames `billing` to `collection_method` on invoices, subscriptions, and subscription schedules.
*   **Invoice Due Date Null (2019-10-17):** The `due_date` property is always null on auto-billed invoices.
*   **Customer Account Balance Rename (2019-10-17):** Renames `account_balance` to `balance` on Customer object.
*   **Custom Account Creation Requested Capabilities (2019-11-05):** Adds requirement for `requested_capabilities` on custom account creation.
*   **Subscription Schedule Settings Nesting (2019-11-05):** Nested subscription schedule settings under `default_settings`.
*   **Invoice Line Item IDs Standardized (2019-12-03):** Standardizes invoice line item IDs.
*   **Post-Payment Credit Note Requirement (2019-12-03):** New requirement for `out_of_band_amount` when creating post-payment credit notes.
*   **Customer Balances Returned Voided Invoices (2019-12-03):** Customer balances are now returned when voiding invoices.
*   **Deprecated Tax Information Fields Removal (2019-12-03):** Removes deprecated tax information fields from the Customer object.
*   **Sequential Invoice Numbering (2020-03-02):** Invoices can now be numbered sequentially across your account.
*   **Tax Percent Attribute Removal (2020-08-27):** Removes the `tax_percent` attribute.
*   **Customer Sources Auto-Expansion Deprecation (2020-08-27):** Customer sources are no longer auto-expanded by default.
*   **Customer Tax IDs Auto-Expansion Deprecation (2020-08-27):** Tax IDs are no longer auto-expanded on the Customer object.
*   **Subscription Prorate Parameters Deprecation (2020-08-27):** Deprecates `prorate` and `subscription_prorate` parameters.
*   **Subscription Schedule Phases Attributes Rename (2020-08-27):** Renames phases attributes in subscription schedules.
*   **Automatic Updates Event Type Rename (2020-08-27):** Renames event type that triggers on automatic updates.
*   **Checkout Session Display Items Removal (2020-08-27):** Removes the `display_items` property from Checkout Sessions.
*   **Accounts Persons Capabilities Error Codes (2020-08-27):** Adds new error codes to the Accounts, Persons, and Capabilities APIs.
*   **3D Secure Details Charge Object Update (2020-08-27):** Updates to 3D Secure details in Charge object.
*   **Customer Subscriptions Auto-Expansion Deprecation (2020-08-27):** Customer subscriptions are no longer auto-expanded by default.
*   **Plan Tiers Auto-Expansion Deprecation (2020-08-27):** Plan tiers are no longer auto-expanded by default.
*   **Invoice Include Require Value Removal (2022-08-01):** Removes the `include_and_require` value when creating invoices.
*   **Checkout Session Default Customer Creation (2022-08-01):** Default customer creation in Checkout Session payment mode changed to `if_required`.
*   **Deferred PaymentIntent Creation Checkout Session (2022-08-01):** Deferred PaymentIntent creation in Checkout Session payment mode.
*   **Checkout Session Setup Intent Removal (2022-08-01):** Removes the `setup_intent` property from Checkout Sessions in subscription mode.
*   **Checkout Session Line Item Parameters Replacement (2022-08-01):** Replaces line item parameters from the Create Checkout Session endpoint.
*   **Checkout Session Subscription Data Removal (2022-08-01):** Removes the `subscription_data` parameter from the Create Checkout Session endpoint.
*   **Checkout Session Shipping Rate Removal (2022-08-01):** Removes the `shipping_rate` parameter from Create Checkout Session endpoint.
*   **3D Secure Exemption Status Charges (2022-08-01):** Adds 3D Secure exemption status to card charges.
*   **Charges Object No Auto-Expand Refunds (2022-11-15):** The Charges object no longer auto-expands refunds by default.
*   **PaymentIntent Charges Attribute Removal (2022-11-15):** Removes the `charges` attribute from the PaymentIntent object.
*   **PaymentIntent/PaymentMethod Decline Codes (2022-11-15):** Adds new decline codes to the PaymentIntent and PaymentMethod APIs.
*   **SetupIntent Decline Codes (2022-11-15):** Adds new decline codes to the SetupIntent API.
*   **Accounts API Structure Error Code (2022-11-15):** Adds a new structure error code to the Accounts API.
*   **Automatic Payment Methods Default (2023-08-16):** Enables automatic payment methods by default for PaymentIntents and SetupIntents.
*   **Checkout Sessions No-Cost Orders (2023-08-16):** One-time payments in Checkout Sessions support no-cost orders.
*   **Platform-Scope PaymentMethod Fingerprints (2023-08-16):** Platform-scope rendering for select PaymentMethod fingerprints.
*   **Klarna Payment Failure Error Codes (2023-08-16):** Adds specific error codes for failed Klarna payments.
*   **Accounts Persons Capabilities Error Codes (2023-08-16):** Adds new director verification error codes to the Accounts API.
*   **Accounts Requirement Error Codes (2023-10-16):** Adds new account requirement error codes to the Accounts API.
*   **Statement Descriptor Auto-Population (2023-10-16):** Auto-populates the statement descriptor and prefix in the Accounts API.
*   **Switzerland UID Tax ID (2024-09-30):** Adds Switzerland UID as a supported customer tax ID.
*   **Credit Notes Email Types (2024-09-30):** Adds support for email types to Credit Notes.
*   **Terminal Reboot Time Setting (2024-09-30):** Adds support for configuring the reboot time setting.
*   **Payment Links New Payment Methods (2024-09-30):** Adds support for three new payment methods: Multibanco, Twint, and Zip.
*   **Financial Connections Account Subcategories Filtering (2024-09-30):** Adds support for filtering by account subcategories on Financial Connections.
*   **Financial Connections Sessions Filtering Expansion (2024-09-30):** Expands filtering support for Financial Connections Sessions.
*   **Bulk Invoice Line Item Operations (2024-09-30):** Adds support for bulk invoice line item operations.
*   **Tax Transaction Creation Posting Time (2024-09-30):** Adds support for posting time on tax transaction creation.
*   **Issuing Card Address Validation (2024-09-30):** Adds address validation for physical cards.
*   **Payment Element Customer Session Support (2024-09-30):** Adds support for the Payment Element on a Customer Session.
*   **Confirmation Tokens CVC Retrieval (2024-09-30):** Adds option to retrieve CVC tokens on Confirmation Tokens.
*   **Disputes Case Type for Cards (2024-09-30):** Adds support for identifying the case type for card disputes.
*   **Affirm Transaction IDs (2024-09-30):** Adds support for Affirm transaction IDs.
*   **Twint Payment Method Configuration (2024-09-30):** Adds Twint to the PaymentMethodConfiguration API.
*   **Interac Present Support (2024-09-30):** Adds support for in-person payment methods, including Interac cards.
*   **Accounts Business Profile Refactoring (2024-09-30):** Several fields describing an account's business details have moved to the `business_profile` subhash.
*   **Person Document Verification Details Code Additions (2024-09-30):** Adds new `details_code` values to person document verification.

**General API Changes**

*   **API Versioning:** The API versioning model has been updated, with the introduction of "Acacia" and "Basil" releases, indicating a shift towards more structured and additive changes.
*   **Breaking Changes:** Several updates are noted as breaking changes, requiring developers to review and potentially update their integrations. These include parameter renames, field removals, and changes in default behaviors.
*   **New Features:** Numerous new features have been introduced across various products, enhancing functionality and providing more granular control over Stripe's services.
*   **Deprecations:** Several parameters and fields have been deprecated, with recommendations to migrate to newer alternatives to ensure future compatibility.

This changelog provides a comprehensive overview of the API updates. It is crucial for developers to review these changes and update their integrations accordingly to leverage new features and maintain compatibility with the Stripe API.
```
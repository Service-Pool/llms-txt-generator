## Stripe API Changelog: Key Updates and Changes

This document provides a summary of significant changes and updates to the Stripe API, categorized by product area and type of change (breaking or generally available). The changelog is organized chronologically by release date.

### Key Themes and Updates:

*   **Enhanced Data and Functionality:** Many updates focus on adding new fields, parameters, and enum values to provide more granular data, better error handling, and increased flexibility in managing financial transactions, subscriptions, customer data, and Connect accounts.
*   **API Restructuring and Renaming:** Several changes involve refactoring and renaming of API fields and objects to improve clarity, consistency, and adherence to modern API design principles. This includes changes to how account information, payment methods, and subscription details are represented.
*   **Deprecation and Removal of Legacy Features:** Stripe is actively deprecating older fields and methods in favor of newer, more robust alternatives. This includes changes to how certain data is handled, such as the removal of `source_type` from Stripe balance payment methods and the deprecation of `iterations` for subscription schedules.
*   **Improved Error Handling and Validation:** Several updates introduce more specific error codes and improved validation for API requests, helping developers identify and resolve issues more efficiently.
*   **Expanded Payment Method Support:** Stripe continues to expand its support for various local and international payment methods, including new additions for specific regions and payment types.
*   **Connect and Embedded Finance Enhancements:** Several updates focus on improving the functionality and usability of Stripe Connect for platforms, including new embedded components and improved handling of connected account data.

### Notable Changes by Category:

**Payments:**

*   **New Payment Methods:** Support for new payment methods has been added across various regions and for different integration types (e.g., Multibanco, Twint, Zip, Pay by Bank, Klarna, Satispay, Konbini, Pix, Naver Pay, Kakao Pay, Samsung Pay, PAYCO, South Korean cards, US Bank Accounts, GB Bank Accounts, Interac cards, PayTo, Cash App, BLIK, SEPA Direct Debit, Bacs Direct Debit, WeChat Pay, Affirm, BNPL options).
*   **3D Secure Enhancements:** Added support for 3D Secure versions 2.3.0 and 2.3.1, and introduced the `exempted` field for 3D Secure status.
*   **Statement Descriptors:** Changes to how statement descriptors are handled for card payments, with improved logic for Connect platforms and clearer naming conventions.
*   **Payment Intents and Setup Intents:** Numerous updates including new decline codes, renaming of statuses, changes to automatic payment methods, and support for new payment methods.
*   **Checkout Sessions:** Significant updates to Checkout Sessions, including support for no-cost orders, new payment method types, optional shipping information, changes to UI modes, and the introduction of `integration_identifier` and `brand_restrictions`.
*   **Payment Records and Records:** Introduction of Payment Records and Payment Attempt Records for tracking off-Stripe payments, and updates to include more details for card payments and other payment methods.
*   **Card and Bank Account Handling:** Changes to how card and bank account data is handled, including fingerprinting for reused accounts, optional CVC for simulated readers, and improved validation for postal codes and identity information.

**Billing and Subscriptions:**

*   **Subscription Management:** Enhancements to subscription management, including support for multiple subscriptions per customer, delayed first invoices, and changes to trial period handling.
*   **Invoicing:** Updates to invoice line items, including unique IDs, support for subscription plans and quantities, and the addition of a `status_transitions` hash.
*   **Coupons and Discounts:** Changes to how coupons apply to invoice items and the introduction of more flexible discount application.
*   **Flexible Billing Mode:** Introduction and default enablement of flexible billing mode for subscriptions, offering more accurate prorations and improved handling of metered pricing.
*   **Billing Alerts:** New API and webhook events for usage-based billing alerts, allowing for more granular monitoring and automated responses.
*   **Credit Grants:** Enhancements to credit grant management, including the ability to apply credits to specific prices, prioritize credit grants, and track their status.
*   **Tax Features:** Expansion of tax support to new countries, including new tax ID types and registration capabilities. Updates to how tax is calculated and applied, including support for third-party tax providers and retail delivery fees.

**Connect and Platform Features:**

*   **Account Management:** Refactoring of account fields for better clarity on legal entity, verification status, and configurable settings. Introduction of new account types (Standard, Express, Custom) and improved handling of person verification data.
*   **Global Payouts:** Expanded support for cross-border payouts to new countries, and updates to how payout methods and financial accounts are managed.
*   **Embedded Components:** General availability of Issuing and Treasury embedded components, and support for new payment methods within these components.

**Other Key Updates:**

*   **API Versioning:** Introduction of a new API versioning model for Stripe.js.
*   **OpenAPI Specifications:** Addition of OpenAPI artifacts for v2 API endpoints.
*   **Terminal Enhancements:** Support for new payment methods, currencies, and device types on Terminal readers, along with improved configuration options for WiFi and admin passcodes.

This changelog provides a high-level overview of the updates. For detailed information on specific changes, including API references and migration guides, please refer to the individual release notes linked within this document.
```markdown
## Stripe API Changelog: 2013-02-13 Release

**Date:** 2013-02-13

**Category:** Payments

**Breaking Changes:**

*   **Disputes on charges are now tracked through the `stripe_fee` field and included in the fee total.**

    *   **What's new:** Updates the Charge object so disputed charges include another `stripe_fee` object in the `fee_details` array, representing the dispute fees. Includes the dispute fees in the fee total on the Charge object.
    *   **Impact:** Disputed charges now include dispute fees in the `fee_details` array and fee total, offering more comprehensive fee information.
    *   **Upgrade:** View your current API version in Workbench. If you use an SDK, upgrade to the corresponding SDK version for this API version. If you don’t use an SDK, update your API requests to include `Stripe-Version: 2013-02-13`. Upgrade the API version used for webhook endpoints. Test your integration against the new version. If you use Connect, test your Connect integration. In Workbench, perform the upgrade. You can roll back the version for 72 hours. Learn more about Stripe API upgrades.
```
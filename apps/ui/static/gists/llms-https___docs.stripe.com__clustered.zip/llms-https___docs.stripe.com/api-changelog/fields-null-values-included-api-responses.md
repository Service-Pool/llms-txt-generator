## Fields with null values are now included in API responses

Fields with null values are now included in API responses. Previously, the API hid fields with null values.

Impact: All response fields are now shown, including null values, for more comprehensive data representation.

Upgrade:
View your current API version in Workbench.
If you use an SDK, upgrade to the corresponding SDK version for this API version.
If you don’t use an SDK, update your API requests to include Stripe-Version: 2012-02-23
Upgrade the API version used for webhook endpoints.
Test your integration against the new version.
If you use Connect, test your Connect integration.
In Workbench, perform the upgrade. You can roll back the version for 72 hours.
Learn more about Stripe API upgrades.

On this page
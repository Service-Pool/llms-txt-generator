```markdown
## Stripe API Changelog: 2013-02-11

This release introduces a significant change to how failed invoice payments are handled. Previously, the API would return a 200 status code and set the `paid` property of an invoice to `false` if a payment failed. With this update, failed invoice payments will now return an HTTP error, providing clearer feedback and improving error handling consistency.

**Key Changes:**

*   **Failed Invoice Payments:** The Pay invoice call now returns an error for unsuccessful charges, rather than a 200 status with `paid: false`.

**Impact:**

This change improves error handling and consistency in your integration. You should update any error handling logic that specifically checks for a 200 status code on failed invoice payments. Instead, you should now expect and handle appropriate HTTP error codes.

**Upgrade:**

To ensure your integration is compatible with this change, it is recommended to:

1.  **Review your API version:** Check your current API version in Stripe Workbench.
2.  **Upgrade your API version:** If you are not using the latest API version, upgrade to `2013-02-11` or a newer version.
3.  **Test your integration:** Thoroughly test your payment processing and error handling logic, particularly for scenarios involving failed invoice payments.

For more information on Stripe API upgrades, refer to the [Stripe API versioning documentation](https://stripe.com/docs/versioning).
```
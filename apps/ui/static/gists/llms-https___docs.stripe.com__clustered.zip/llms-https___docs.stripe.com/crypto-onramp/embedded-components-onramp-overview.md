## Stripe Crypto Onramp: Embedded Components

This documentation section focuses on integrating Stripe's **Embedded Components Onramp** for fiat-to-crypto purchases within your applications. This approach allows customers to purchase cryptocurrency directly within your app's interface, providing a seamless user experience.

### Overview

The Embedded Components Onramp enables you to build a native onramp flow within your application. It utilizes customizable components that handle authentication and secure data collection, tailored to your app's design.

**Customer Flow:**

1.  A customer visits your app and wishes to convert fiat to crypto or purchase crypto.
2.  Your app prompts them to onboard by signing up or logging into Link.
3.  They sign up or log into Link without leaving your app.
4.  They grant your app permission to use their saved payment methods and wallets. If they are missing required data (such as KYC information, payment methods, or wallets), they complete account configuration within your app.
5.  They purchase or convert crypto in a `CryptoOnramp` session within your app. Returning customers have the option for one-click checkout.

### Integration Options

You can choose how to get started with your integration:

*   **Quickstart:** Provides minimal code to run and see the full flow, allowing you to explore the integration.
*   **Integration Guide:** Offers step-by-step instructions for React Native, Android, and iOS apps.
*   **Example App:** A complete React Native project demonstrating the full crypto purchase flow.

### Mobile SDK Configuration

To integrate the Embedded Components Onramp, you will need to:

1.  **Add the Onramp dependency:**
    *   **React Native:** Via Gradle/Podfile or Expo.
    *   **Native iOS/Android:** Add the relevant SDK dependency.
2.  **Wrap your app with `StripeProvider`:** This makes Stripe and Onramp functionalities available throughout your application.
3.  **Customize your business display name and appearance:** Configure elements like colors to match your app's branding.

### Key Features and Considerations

*   **Native Experience:** Embed the onramp directly into your app's UI.
*   **Link Integration:** Leverages Stripe's Link for faster checkouts and secure data storage.
*   **KYC Verification:** All users must pass KYC verification to buy crypto. The system supports multiple KYC tiers for varying purchase limits.
*   **Platform Support:** Guides are available for React Native, Android, and iOS.
*   **Preview Status:** The Embedded Components API is currently in private preview. Onboarding and application submission are required before development can begin.
*   **Regional Availability:** Generally available in the US (excluding Hawaii) and the EU. Specific regional limitations may apply (e.g., New York for React Native).

### Related Documentation

*   [Stripe Crypto Overview](/crypto)
*   [Stripe fiat-to-crypto onramp](/crypto/onramp)
*   [Stripe-hosted onramp](/crypto/onramp/stripe-hosted)
*   [Embedded onramp (general guide)](/crypto/onramp/embedded)
*   [Integrate the Android onramp](/crypto/onramp/embedded-components-android-integration-guide)
*   [Integrate the iOS onramp](/crypto/onramp/embedded-components-ios-integration-guide)
*   [Integrate the React Native Embedded Components onramp](/crypto/onramp/embedded-components-react-native-integration-guide)
*   [Integrate the KYC tier system](/crypto/onramp/kyc-integration-guide)
*   [Upgrade your onramp integration](/crypto/onramp/upgrade-onramp-integration)
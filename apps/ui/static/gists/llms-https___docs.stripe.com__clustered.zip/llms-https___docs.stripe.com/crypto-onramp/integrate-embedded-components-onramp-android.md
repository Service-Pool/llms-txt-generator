The Stripe Crypto Onramp allows your users to purchase cryptocurrency directly from your platform or Dapp. This section of the documentation provides guides for integrating various onramp solutions, including the Stripe-hosted onramp, embedded onramp, and embedded components onramp.

**Key Features:**

*   **Fiat-to-Crypto Onramp:** Enable users to convert fiat currency into cryptocurrency.
*   **Customizable Integrations:** Choose between a Stripe-hosted page, an embedded onramp on your website, or an embedded components onramp within your mobile application.
*   **Stripe as Merchant of Record:** Stripe handles all fraud, disputes, and regulatory requirements, including KYC verifications and sanctions screening.
*   **Saved Customer Data:** Customers can save payment methods, KYC data, and wallet information with Stripe for faster future checkouts.

**Integration Options:**

*   **Stripe-hosted onramp:** Redirect users to a standalone Stripe-hosted page for checkout.
    *   [Use the Stripe-hosted onramp](/crypto/onramp/stripe-hosted)
*   **Embedded onramp:** Integrate the onramp directly into your website for a seamless checkout experience.
    *   [Set up an Embedded onramp integration](/crypto/onramp/embedded)
*   **Embedded components onramp:** Utilize mobile SDKs to embed the onramp directly within your native Android, iOS, or React Native applications.
    *   [Embedded Components onramp Overview](/crypto/onramp/embedded-components)
    *   [Integrate the Android onramp](/crypto/onramp/embedded-components-android-integration-guide)
    *   [Integrate the iOS onramp](/crypto/onramp/embedded-components-ios-integration-guide)
    *   [Integrate the React Native Embedded Components onramp](/crypto/onramp/embedded-components-react-native-integration-guide)
    *   [Integrate the Embedded Components onramp (General Guide)](/crypto/onramp/embedded-components-integration-guide)

**Additional Resources:**

*   **KYC Integration:** Understand and integrate the KYC tier system for the Embedded Components onramp to manage user purchase limits.
    *   [Integrate the KYC tier system for the Embedded Components onramp](/crypto/onramp/kyc-integration-guide)
*   **Upgrade Onramp Integration:** Information on API changes for upgrading from the beta onramp API.
    *   [Upgrade your onramp integration](/crypto/onramp/upgrade-onramp-integration)
*   **Stablecoin Payments:** Learn about accepting payments in stablecoins, which settle in your Stripe balance in USD.
    *   [Stablecoins on Link](/payments/link/stablecoins)
    *   [Accept stablecoin payments](/payments/accept-stablecoin-payments)
    *   [Stablecoin payments](/payments/stablecoin-payments)
    *   [Deposit mode stablecoin payments](/payments/deposit-mode-stablecoin-payments)
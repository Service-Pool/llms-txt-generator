## Stripe Crypto Onramp Documentation

This section of the Stripe documentation provides comprehensive guidance on integrating Stripe's crypto onramp solutions into your platform or application. It covers various integration methods, from hosted solutions to embedded components for web and mobile, and details the necessary steps for setup, configuration, and customization.

### Key Features and Integrations:

*   **Fiat-to-Crypto Onramp:** Allows your users to securely purchase cryptocurrencies directly from your platform.
*   **Stripe-Hosted Onramp:** A standalone, pre-built frontend integration hosted at `crypto.link.com`. You can integrate by redirecting users to this page.
*   **Embedded Onramp:** Enables users to check out directly within your website, offering a more integrated experience.
*   **Embedded Components Onramp:** Provides a native in-app experience for users to purchase crypto, with SDKs available for web, iOS, and Android.
    *   **Web Integration:** Guides for setting up the embedded onramp using script tags or npm packages.
    *   **Mobile SDK Integration:**
        *   **Android:** Instructions for integrating the Android Crypto Onramp SDK.
        *   **iOS:** Instructions for integrating the iOS Crypto Onramp SDK.
        *   **React Native:** Step-by-step guide for integrating the React Native Embedded Components onramp.
*   **KYC Integration:** Details on integrating the KYC tier system to manage user purchase limits and ensure compliance.
*   **Stablecoin Payments:** Information on accepting stablecoin payments, including how they settle in your Stripe balance in USD.
    *   **Stablecoins on Link:** How to leverage Link for stablecoin payments.
    *   **Accepting Stablecoin Payments:** General guidance on enabling stablecoin payments through various Stripe products.
    *   **Deposit Mode Stablecoin Payments:** An API-only flow for accepting stablecoin payments with deposit addresses.
*   **API Updates:** Information on upgrading from the beta onramp API to the latest version.

### Getting Started:

1.  **Submit Onramp Application:** All onramp integrations require an application submission and approval process.
2.  **Onboarding and API Keys:** Obtain necessary API keys and complete any required onboarding steps.
3.  **Choose Integration Method:** Select the onramp integration that best suits your platform (Stripe-hosted, Embedded, or Embedded Components).
4.  **Follow Integration Guides:** Utilize the specific guides for web, Android, iOS, or React Native to implement the chosen onramp solution.
5.  **Integrate KYC (if applicable):** Implement KYC verification for compliance and to manage user limits.
6.  **Configure Payment Methods:** Set up and enable stablecoin payments if desired.
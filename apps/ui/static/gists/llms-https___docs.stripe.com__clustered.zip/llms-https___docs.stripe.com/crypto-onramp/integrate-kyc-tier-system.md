### Integrating KYC for Embedded Components Onramp

This section details how to integrate the Know Your Customer (KYC) tier system for Stripe's Embedded Components Onramp. This is crucial as all users must pass KYC verification before purchasing cryptocurrency through the onramp, with higher verification tiers enabling increased purchase limits.

**Key aspects covered:**

*   **KYC Tiers and Requirements:** Understanding the different verification levels (L0, L1, L2) and the user information required for each (name, phone, email, address, date of birth, ID, selfie).
*   **`attachKYCInfo` API:** Guidance on using the `attachKYCInfo` API to initiate L0 and L1 KYC verification processes. This includes specifying the necessary fields based on the target tier.
*   **Asynchronous Verification:** Information on how L0 and L1 verifications are asynchronous and the importance of checking their status before creating an onramp session to avoid errors.
*   **Integration Prerequisites:** Emphasizes that the Embedded Components Onramp must be integrated *before* implementing the KYC system.

This documentation is essential for ensuring compliance and providing a seamless, tiered purchasing experience for users engaging with the fiat-to-crypto onramp.
## Integrating Stripe's Fiat-to-Crypto Onramp

This section provides comprehensive documentation for integrating Stripe's fiat-to-crypto onramp solutions. It covers various integration methods, platform-specific guides, and essential prerequisites.

### Core Concepts

*   **Stripe Crypto:** Enables businesses to build crypto functionalities into their Stripe integrations, allowing users to pay with or receive crypto, or embed a fiat-to-crypto onramp.
*   **Fiat-to-Crypto Onramp:** Allows users to purchase cryptocurrencies directly from a platform or Dapp using fiat currency. Stripe handles the merchant of record responsibilities, fraud, disputes, and regulatory requirements.

### Integration Methods

Stripe offers three primary ways to integrate the fiat-to-crypto onramp:

1.  **Stripe-Hosted Onramp:**
    *   **Description:** A pre-built, standalone hosted page for crypto onramp transactions. Merchants redirect users to `crypto.link.com` for checkout.
    *   **Use Cases:** Suitable for businesses that prefer not to host the onramp within their application.
    *   **Documentation:**
        *   [Use the Stripe-hosted onramp](/crypto/onramp/stripe-hosted)

2.  **Embedded Onramp:**
    *   **Description:** Allows customers to check out directly within the merchant's website.
    *   **Documentation:**
        *   [Set up an Embedded onramp integration](/crypto/onramp/embedded)

3.  **Embedded Components Onramp (Mobile SDK):**
    *   **Description:** Enables customers to check out directly within a mobile application using dedicated SDKs.
    *   **Key Features:** Provides native components for authentication, secure data collection, and a tailored user experience. Supports React Native, Android, and iOS.
    *   **Documentation:**
        *   [Embedded Components onramp Overview](/crypto/onramp/embedded-components)
        *   [Integrate the React Native Embedded Components onramp](/crypto/onramp/embedded-components-react-native-integration-guide)
        *   [Integrate the Android onramp](/crypto/onramp/embedded-components-android-integration-guide)
        *   [Integrate the iOS onramp](/crypto/onramp/embedded-components-ios-integration-guide)
        *   [Integrate the Embedded Components onramp (General Guide)](/crypto/onramp/embedded-components-integration-guide) (Covers iOS, Android, React Native)

### Key Features and Considerations

*   **Stablecoin Payments:**
    *   **Description:** Allows businesses to accept payments in stablecoins (e.g., USDC) which settle in USD in the Stripe balance.
    *   **Supported Integrations:** Payment Links, Stripe Checkout, and Elements.
    *   **Documentation:**
        *   [Stablecoins on Link](/payments/link/stablecoins)
        *   [Accept stablecoin payments](/payments/accept-stablecoin-payments)
        *   [Stablecoin payments](/payments/stablecoin-payments)
        *   [Deposit mode stablecoin payments](/payments/deposit-mode-stablecoin-payments) (API-only flow)
*   **KYC Integration:**
    *   **Description:** All users must pass Know Your Customer (KYC) verification to purchase crypto with the onramp. Tiers of verification exist, with higher tiers allowing for larger purchase limits.
    *   **Documentation:**
        *   [Integrate the KYC tier system for the Embedded Components onramp](/crypto/onramp/kyc-integration-guide)
*   **API Versioning and Upgrades:**
    *   **Description:** Information on API changes for those upgrading from the onramp beta to the public release.
    *   **Documentation:**
        *   [Upgrade your onramp integration](/crypto/onramp/upgrade-onramp-integration)

### Getting Started

1.  **Submit Onramp Application:** Access to any of the onramp integrations requires submitting an application through your Stripe account.
2.  **Onboarding and API Keys:** After approval, obtain your secret and publishable API keys. For embedded integrations, you may also need OAuth credentials.
3.  **Platform-Specific Setup:** Follow the integration guides relevant to your chosen platform (web, React Native, Android, iOS).
4.  **SDK Installation:** Install the necessary Stripe SDKs and client libraries for your development environment.

### Regional Availability

*   The Embedded onramp and Embedded Components onramp are generally available in the EU and the US (excluding Hawaii).
*   Specific restrictions may apply (e.g., New York exclusion for React Native integration).
*   Stablecoin payments are primarily available for US businesses to accept from customers globally.
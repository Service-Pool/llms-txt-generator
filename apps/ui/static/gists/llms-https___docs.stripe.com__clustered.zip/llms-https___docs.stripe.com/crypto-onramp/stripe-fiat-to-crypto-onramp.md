## Stripe Crypto: Fiat-to-Crypto Onramp

This section of the Stripe documentation covers the **Fiat-to-Crypto Onramp** product, which allows your users to securely purchase and exchange cryptocurrencies directly from your platform or decentralized application (Dapp). Stripe acts as the merchant of record, handling fraud, disputes, regulatory requirements, KYC verifications, and sanctions screening.

### Key Features:

*   **Seamless Integration:** Integrate the onramp into your product or service for a smooth user experience.
*   **Stripe as Merchant of Record:** Stripe assumes full liability for fraud and disputes.
*   **Automated Compliance:** Stripe handles all regulatory requirements, KYC verifications, and sanctions screening.
*   **Saved Customer Data:** Customers can save payment methods, KYC data, and wallet information with Stripe for faster future checkouts.

### Integration Options:

There are three primary ways to integrate with Stripe's Fiat-to-Crypto Onramp:

1.  **Stripe-Hosted Onramp:** Redirect your customers to a standalone Stripe-hosted page for checkout. This is ideal for a quick integration without embedding the onramp directly into your application.
    *   **Use the Stripe-hosted onramp:** [Link to /crypto/onramp/stripe-hosted]
2.  **Embedded Onramp:** Allow your customers to check out directly within your website. This provides a more integrated experience than the Stripe-hosted option.
    *   **Set up an Embedded onramp integration:** [Link to /crypto/onramp/embedded]
3.  **Embedded Components Onramp (Mobile SDK):** Enable your customers to check out directly within your mobile application using dedicated SDKs for iOS, Android, and React Native.
    *   **Embedded Components onramp overview:** [Link to /crypto/onramp/embedded-components]
    *   **Integrate the Android onramp:** [Link to /crypto/onramp/embedded-components-android-integration-guide]
    *   **Integrate the iOS onramp:** [Link to /crypto/onramp/embedded-components-ios-integration-guide]
    *   **Integrate the React Native Embedded Components onramp:** [Link to /crypto/onramp/embedded-components-react-native-integration-guide]

### Getting Started:

To access any of the onramp integrations, you must first **submit an onramp application** through your Stripe account. This process involves creating or signing in to your Stripe account and completing the application form. Stripe reviews applications typically within 48 hours.

### Additional Information:

*   **KYC Integration Guide:** Learn about KYC verification tiers and how to integrate them for the Embedded Components onramp. [Link to /crypto/onramp/kyc-integration-guide]
*   **Upgrade Your Onramp Integration:** Information on API changes for users who integrated with the onramp beta API before June 21, 2023. [Link to /crypto/onramp/upgrade-onramp-integration]
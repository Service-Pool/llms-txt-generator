## Integrating Stripe's Fiat-to-Crypto Onramp

This documentation section provides a comprehensive guide to integrating Stripe's fiat-to-crypto onramp solutions, enabling your users to seamlessly purchase cryptocurrencies directly from your platform.

### Overview

Stripe's fiat-to-crypto onramp allows your customers to securely purchase and exchange cryptocurrencies directly from your platform or Dapp. Stripe handles all regulatory requirements, including Know Your Customer (KYC) verifications and sanctions screening, and acts as the merchant of record, assuming liability for fraud and disputes.

### Integration Options

There are three primary ways to integrate with Stripe's fiat-to-crypto onramp:

*   **Stripe-hosted onramp:** Redirect your customers to a standalone Stripe-hosted page for checkout. This is a prebuilt frontend integration hosted at `https://crypto.link.com`.
*   **Embedded onramp:** Allow your customers to check out directly within your website. This offers a more integrated experience without leaving your domain.
*   **Embedded Components onramp (Mobile SDK):** Enable your customers to check out directly within your mobile application using dedicated SDKs for Android, iOS, and React Native.

### Getting Started

Before you can access any of the onramp integrations, you must **submit an onramp application** to Stripe. This typically involves:

1.  Creating or signing in to your Stripe account.
2.  Setting up your Stripe account if you haven't already.
3.  Submitting the onramp application through your Stripe Dashboard. Stripe reviews applications, usually within 48 hours, and notifies you of the approval status.

Once your application is approved, you can begin development using a sandbox environment.

### Integration Guides

#### 1. Stripe-Hosted Onramp

*   **Purpose:** Redirect users to a standalone Stripe-hosted page for crypto purchases.
*   **How it works:** Generate a redirect URL with customizable parameters (e.g., destination currency, source/destination amount) and share it with your users.
*   **Relevant Pages:**
    *   [Use the Stripe-hosted onramp](/crypto/onramp/stripe-hosted)

#### 2. Embedded Onramp (Web)

*   **Purpose:** Integrate the onramp checkout experience directly into your website.
*   **How it works:** This guide covers customizing the embeddable onramp, including SDK installation, UI customization, and handling customer support and fraud.
*   **Relevant Pages:**
    *   [Stripe fiat-to-crypto onramp](/crypto/onramp) (Overview of options)
    *   [Set up an Embedded onramp integration](/crypto/onramp/embedded) (Extended guide)

#### 3. Embedded Components Onramp (Mobile SDKs)

*   **Purpose:** Build a native onramp flow within your mobile applications.
*   **How it works:** Utilize dedicated SDKs for Android, iOS, and React Native to provide authentication, secure data collection, and a seamless checkout experience tailored to your app's design.
*   **Key Features:**
    *   Native integration within your app.
    *   Handles authentication, KYC, and payment.
    *   Supports one-click checkout for returning customers.
*   **Relevant Pages:**
    *   [Stripe fiat-to-crypto onramp](/crypto/onramp) (Overview of options)
    *   [Embedded Components onramp](/crypto/onramp/embedded-components) (Overview)
    *   [Integrate the Embedded Components onramp](/crypto/onramp/embedded-components-integration-guide) (General Integration Guide)
    *   [Integrate the Android onramp](/crypto/onramp/embedded-components-android-integration-guide) (Android SDK Guide)
    *   [Integrate the iOS onramp](/crypto/onramp/embedded-components-ios-integration-guide) (iOS SDK Guide)
    *   [Integrate the React Native Embedded Components onramp](/crypto/onramp/embedded-components-react-native-integration-guide) (React Native SDK Guide)

#### 4. KYC Integration

*   **Purpose:** Understand and implement KYC verification tiers for the Embedded Components onramp.
*   **How it works:** All users must pass KYC verification to buy crypto. This guide details the different KYC tiers, required information, and how to detect purchase limits based on verification levels. It also covers using the `attachKYCInfo` API for L0 and L1 verifications.
*   **Relevant Pages:**
    *   [Integrate the KYC tier system for the Embedded Components onramp](/crypto/onramp/kyc-integration-guide)

#### 5. Upgrading Beta Integrations

*   **Purpose:** Migrate from the beta onramp API to the latest public release.
*   **How it works:** This guide outlines API changes, their impact on existing integrations, and provides instructions for migrating to the current version.
*   **Relevant Pages:**
    *   [Upgrade your onramp integration](/crypto/onramp/upgrade-onramp-integration)

### Stablecoin Payments

Stripe also supports accepting payments in stablecoins.

*   **Purpose:** Allow customers to pay with stablecoins, which settle in your Stripe balance in USD.
*   **How it works:** Customers can pay with their preferred crypto wallet, token, and payment network. Stripe handles the conversion and settlement.
*   **Integration:** Can be enabled through Payment Links, Checkout, Elements, or the Payment Intents API.
*   **Relevant Pages:**
    *   [Stablecoins on Link](/payments/link/stablecoins)
    *   [Accept stablecoin payments](/payments/accept-stablecoin-payments)
    *   [Stablecoin payments](/payments/stablecoin-payments)
    *   [Deposit mode stablecoin payments](/payments/deposit-mode-stablecoin-payments)

**Note:** Stablecoin payments are generally available globally for customers, but only US businesses can currently accept them.
## Stripe Crypto

Stripe Crypto offers a suite of products designed to integrate cryptocurrency functionalities into your existing Stripe integration. This includes enabling customers to pay with crypto, allowing payouts in crypto, and embedding a fiat-to-crypto onramp.

### Fiat-to-Crypto Onramp

The fiat-to-crypto onramp allows your users to securely purchase cryptocurrencies directly from your platform or Dapp. Stripe handles the merchant of record responsibilities, including fraud, disputes, regulatory requirements, KYC, and sanctions screening.

There are three primary ways to integrate the fiat-to-crypto onramp:

*   **Stripe-hosted onramp:** Redirects your customers to a standalone Stripe-hosted page for checkout.
*   **Embedded onramp:** Allows customers to check out directly within your website.
*   **Embedded Components onramp (Mobile SDK):** Enables customers to check out directly within your mobile application.

**Key Features and Considerations:**

*   **Stablecoin Payments:** Accept stablecoins (like USDC) as a payment method. Funds settle in your Stripe balance in USD. This is supported via Payment Links, Stripe Checkout, Elements, or the Payment Intents API.
*   **Deposit Mode Stablecoin Payments:** An API-only flow where Stripe provides deposit addresses for specific networks. Payments are automatically captured once funds settle on-chain.
*   **Embedded Components:** Offers a customizable onramp experience within your app, handling authentication and secure data collection. Supports React Native, Android, and iOS integrations.
*   **KYC Integration:** All users must pass KYC verification to buy crypto with the onramp. Different tiers of verification (L0, L1, L2) exist, requiring varying levels of user information.
*   **API Changes:** Be aware of API changes if you integrated with the onramp beta before June 21, 2023.

**Getting Started:**

To access any of the onramp features, you must first submit an onramp application through your Stripe account. After approval, you can begin development using a sandbox environment.

**Supported Regions:**

*   **Embedded onramp:** Available in the EU and the US (excluding Hawaii).
*   **Embedded Components onramp:** Available in the US (excluding Hawaii).
*   **Stablecoin Payments:** Customers can use stablecoins globally, but only US businesses can accept them.
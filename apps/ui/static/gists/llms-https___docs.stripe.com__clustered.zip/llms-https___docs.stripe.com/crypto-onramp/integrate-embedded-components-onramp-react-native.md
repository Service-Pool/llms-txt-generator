## Integrate the React Native Embedded Components Onramp

This guide provides step-by-step instructions for building your integration with the React Native Embedded Components onramp. Use this guide when you need full control over the onramp flow, want to understand each API, or want to customize the flow for your app.

Alternatively, see the [quickstart](/crypto/onramp/embedded-components-quickstart) for a minimal example that shows the full flow, or explore the [example app](/crypto/onramp/embedded-components-example-app) for a complete React Native project that demonstrates the full crypto purchase flow.

### Before you begin

The Embedded Components onramp is only available in the US (excluding New York).

The Embedded Components API is in private preview. No API calls can succeed until onboarding is complete, including in a sandbox. To request access:

1.  Submit your application.
2.  Sign up to join the waitlist.
3.  Work with your Stripe account executive or solutions architect to complete the onboarding process before starting your integration. This includes, but isn’t limited to:
    *   Confirm your account is enrolled in the required feature gates for the Embedded Components onramp APIs and Link OAuth APIs.
    *   Confirm your app is registered as a trusted application. We require this before you can use the SDK, including for simulator testing.
    *   Enable Link as a payment method in your Dashboard.
    *   Obtain your OAuth client ID and client secret, which are provisioned by Stripe and required for the authentication flow.

After onboarding is complete, obtain your secret and publishable API keys from the API keys page.

### Mobile SDK configuration

#### Step 1: Install the Stripe React Native SDK

For Expo projects, run the following to automatically install the version compatible with your Expo SDK:

```bash
npx expo install @stripe/stripe-react-native
```

For bare React Native projects, follow the installation instructions in the README. See the requirements.
## Stripe Crypto: Fiat-to-Crypto Onramp

This documentation section covers Stripe's offerings for integrating fiat-to-crypto functionality into your platform or application. Stripe provides several ways to enable your users to purchase cryptocurrencies, streamlining the process and handling regulatory requirements.

### Key Features and Integrations:

*   **Stripe Crypto Overview:** General information about Stripe's crypto products, allowing users to pay in crypto, pay out in crypto, or embed a fiat-to-crypto onramp.
*   **Fiat-to-Crypto Onramp:** The core offering for enabling users to buy cryptocurrency. This includes:
    *   **Stripe-Hosted Onramp:** A standalone, Stripe-hosted page that users are redirected to for checkout. This is integrated by generating a redirect URL.
    *   **Embedded Onramp:** Allows users to check out directly within your website, offering a more integrated experience.
    *   **Embedded Components Onramp:** Enables users to check out directly within your mobile application using SDKs for iOS, Android, and React Native. This provides a highly customizable flow.

### Integration Guides:

*   **Embedded Onramp Integration Guide:** Provides extended instructions for customizing the embeddable onramp, including SDK installation, UI configuration, and handling customer support.
*   **Embedded Components Onramp:** An overview of the Embedded Components onramp, outlining the customer flow and integration options (Quickstart, Integration Guide).
*   **Mobile SDK Integrations:**
    *   **Android Onramp Integration Guide:** Step-by-step instructions for integrating the Android Crypto Onramp SDK.
    *   **iOS Onramp Integration Guide:** Step-by-step instructions for integrating the iOS Crypto Onramp SDK.
    *   **React Native Embedded Components Onramp Integration Guide:** Step-by-step instructions for integrating the Embedded Components onramp into React Native applications.
*   **KYC Integration Guide:** Details how to integrate the KYC (Know Your Customer) tier system for the Embedded Components onramp, explaining verification tiers and requirements.
*   **Upgrade Onramp Integration:** A guide for users who integrated with the beta onramp API before June 21, 2023, detailing API changes and migration instructions.

### Stablecoin Payments:

*   **Stablecoins on Link:** Information on accepting stablecoin payments through Link, where customers pay with crypto and funds settle in your Stripe balance in USD.
*   **Accept Stablecoin Payments:** General guide on enabling stablecoin payments through various Stripe products like Payment Links, Checkout, Elements, and the Payment Intents API.
*   **Stablecoin Payments:** A comprehensive overview of accepting stablecoin payments, including supported currencies, networks, and the payment flow.
*   **Deposit Mode Stablecoin Payments:** Details on accepting stablecoin payments via an API-only flow using deposit addresses, suitable for machine payments.

### Getting Started:

To access any of the onramp features, you must first **submit an onramp application** through your Stripe account. This involves creating or signing in to your Stripe account and completing the application review process. Regional considerations, such as availability in the EU and US (excluding Hawaii for some features), should be noted.
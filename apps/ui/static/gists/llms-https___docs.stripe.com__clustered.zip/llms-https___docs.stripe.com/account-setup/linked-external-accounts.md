## Linked External Accounts

To facilitate payouts from your Stripe balance, you must connect one or more external bank accounts. Additionally, you can grant Stripe access to supplementary financial information for credit and risk assessments, or for other Stripe products, which can reduce future information collection needs.

Stripe may utilize your financial account information for the following purposes:

*   **Linking your financial account for payouts:** This is a primary function to ensure you can receive funds from your Stripe balance.
*   **Evaluating eligibility for loans or other Stripe products:** Certain Stripe financial services may require an assessment of your financial standing.
*   **Enabling additional Stripe product features:** Some advanced features might depend on access to your financial account data.
*   **Re-evaluating reserve balances during risk reviews:** To manage risk effectively, Stripe may review your linked account's balance history.

**Note:** The handling of data from your linked financial accounts is governed by the Stripe Services Agreement, Stripe Privacy Policy, and partner terms. Stripe's partners can only access financial account information with your explicit authorization. Stripe does not sell your data to unaffiliated third parties.

### Financial Account Data

With your consent, Stripe can access your linked account to retrieve the following information:

*   **Account details:** This includes the account type, account number, current balance, and historical balances.
*   **Contact information:** This encompasses your name, email address, phone number, physical address, and other details held by your financial institution.
*   **Account transactions:** This includes the amount, date, and description of each transaction.

### Stripe Products and Services Relying on Financial Account Information

Several Stripe products and services are dependent on your financial account information, including:

*   **Payouts:** Stripe uses your financial account information (specifically, the account details) to process payouts to your linked bank account.
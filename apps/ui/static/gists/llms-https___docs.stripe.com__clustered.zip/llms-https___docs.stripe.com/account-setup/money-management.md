## Money Management

This section covers how to manage your finances directly through Stripe, offering tools for holding funds, sending and receiving money globally, creating spend cards, and accessing financing options.

### Key Features:

*   **Stripe Treasury:** Utilize Treasury to hold funds in local accounts, instantly convert currencies, and manage expenses with cards. It also provides building blocks for financial services.
*   **Global Payouts:** Send money to anyone, anywhere in the world.
*   **Issuing:** Create and manage virtual and physical cards for managing expenses and paying bills.
*   **Capital:** Access business financing options.

### For Platforms:

*   **Treasury for platforms:** Embed Treasury capabilities within your platform, allowing your customers to hold funds, pay bills, earn cash back, and manage cash flow.
*   **Issuing for platforms:** Launch a scalable card issuing program, enabling your customers to create, distribute, and manage virtual and physical cards.
*   **Capital for platforms:** Build and monetize a program that offers your customers access to financing.
## Adding Funds to Your Stripe Balance

This section covers how to add funds to your Stripe balance to manage potential negative balances, increased refunds, or chargebacks.

### Key Concepts:

*   **Negative Balance Management:** Proactively add funds to ensure your account remains stable.
*   **Refund and Chargeback Coverage:** Maintain sufficient balance to cover potential customer refunds and disputes.
*   **Payment Methods for Adding Funds:** Understand the available methods like wire transfers and local bank credit transfers.
*   **Regional Availability:** Learn which methods are available in different regions (AMER, EMEA, APAC, LatAm).
*   **Stripe VBAN:** Understand its role in reconciliation speed and its availability by region.
*   **Payments Balance:** Learn about adding funds directly to the payments balance for streamlined processing.

### Related Pages:

*   **Account Checklist (`/get-started/account/checklist`):** Ensure all necessary steps are completed before going live.
*   **Set up your account (`/get-started/account/set-up`):** General guidance on setting up your Stripe account.
*   **Linked external accounts (`/get-started/account/linked-external-accounts`):** How to connect bank accounts for payouts.
*   **Money management (`/money-management`):** Broader overview of managing finances with Stripe.
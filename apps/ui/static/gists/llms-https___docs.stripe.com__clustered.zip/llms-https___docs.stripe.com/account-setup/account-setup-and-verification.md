# Account Setup and Verification

This section covers the essential steps for setting up and verifying your Stripe account, ensuring you can operate securely and effectively.

## Getting Started with Your Stripe Account

Once you create a Stripe account, you can immediately begin using it in a testing environment (sandbox) to simulate transactions without using real money. To move beyond the sandbox and process live payments, you'll need to set up and verify your account.

## Account Checklist

Before taking your Stripe account live, complete the following checklist to ensure best business practices and security:

*   **Enable Two-Step Authentication:** For enhanced security, enable two-factor authentication (2FA) on your Stripe account. Stripe supports passkeys, security keys, authenticator apps, and SMS. Passkeys or security keys are recommended for their phishing resistance.
*   **Confirm Statement Descriptor and Public Information:** The statement descriptor appears on customer bank statements. Ensure it's clear, accurate, and adheres to the 5-22 character limit, containing at least five letters and no special characters like `<`, `>`, `'`, or `"`.

## Setting Up Your Account

To use Stripe services outside of a sandbox, you must verify your business and complete any necessary requirements for live account activation.

1.  **Create a Stripe Account:** If you haven't already, create your Stripe account.
2.  **Complete the Account Checklist:** Follow the steps outlined in the Account Checklist to prepare your account.
3.  **Verify Your Business:** In the Stripe Dashboard, provide information about your business, products, and your relationship to the business. Stripe's "Know Your Customer" (KYC) obligations require this information for regulatory and financial partner compliance.

## Acceptable Verification Documents

Stripe requires specific documents for identity, address, and legal entity verification. These documents vary by country.

**Common Requirements:**

*   Documents must be no more than one step removed from the original.
*   Copies and scans must be in PDF format and taken directly from the original.
*   Photos of physical documents must be in JPEG or PNG format, original, and unprocessed.
*   Screenshots are not acceptable.
*   Photos and scans of Photo IDs must be in color.
*   Photos of paper documents must be in color; scans of paper documents (not Photo IDs) can be black and white.
*   Images must be of good quality, readable, and in a valid upload file format.
*   Documents must not be cropped, missing crucial information, or have borders that are not visible.
*   Identity and legal entity documents must not be expired.
*   If the back of a document contains required information, include an image of the back side using the `document_back` parameter when submitting via API.

## Stripe Profiles

A Stripe profile serves as your business's public identity on Stripe. It allows you to input basic business information once and use it across Stripe, and enables other businesses to find and verify you.

*   **Benefits:** Input business information once, publish selected charts and metrics, and facilitate connections with other businesses.
*   **Management:** Create or update your profile in the Stripe Dashboard under "Stripe profile." You can choose to make your profile visible to other businesses.

## Linked External Accounts

To facilitate payouts from your Stripe balance, you need to connect one or more external bank accounts. Stripe may also request access to additional financial information for risk reviews or other product features.

*   **Data Access:** With your consent, Stripe can access account details, contact information, and account transactions from your linked financial accounts.
*   **Stripe Products:** Payouts, eligibility for loans, and other Stripe product features rely on this information.

## Statement Descriptors

Statement descriptors help customers identify charges on their bank statements. Clear and accurate descriptors can reduce disputes.

*   **Requirements:** Descriptors must contain only Latin characters, be between 5 and 22 characters long, include at least one letter, and avoid specific special characters.
*   **Types:** You can set a static statement descriptor for all charges or use a dynamic suffix for specific transactions.

## Adding Funds to Your Balance

You can add funds directly to your Stripe balance via wire or bank transfer to cover increased refunds and chargebacks, or to maintain a positive balance.

*   **Methods:** Funds are added via local bank credit transfer or wire transfer, depending on your market.
*   **Recommendations:** For businesses with automatic payouts, setting a minimum balance is recommended for timely refund processing.

## Custom Email Domain

By default, Stripe sends customer communications from the `stripe.com` domain. You can configure Stripe to send emails (invoices, receipts, notifications) from your own custom domain for a more branded experience.

*   **Setup:** Add your domain in the Dashboard, verify it by configuring DNS records, and then set it as your sending domain.

## Stripe Verified

Stripe Verified offers specialized risk and compliance controls and benefits tailored to your business needs, helping you navigate evolving payment and financial service requirements.

*   **Benefits:** Access to specialized risk and compliance controls, fewer paused capabilities for connected accounts, faster onboarding reviews, personalized monitoring, enhanced protections, and expert help.
*   **Availability:** Currently in private preview, with a monthly fee after the preview period.
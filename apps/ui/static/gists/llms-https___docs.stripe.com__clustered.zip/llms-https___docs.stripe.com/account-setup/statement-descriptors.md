## Statement Descriptors

Statement descriptors are crucial for clear customer communication and dispute reduction. They appear on customer bank statements, explaining the charge. Stripe requires specific information in these descriptors to help customers identify their transactions.

### How Statement Descriptors Work

When you set up your Stripe account, you can define a static statement descriptor that applies to all customer charges. For card charges, you also have the option to use a dynamic suffix, which allows you to add specific details about the product or service for each transaction. This provides greater clarity on customer statements.

### Statement Descriptor Requirements

A complete statement descriptor must adhere to the following rules:

*   **Character Set:** Must contain only Latin characters.
*   **Length:** Must be between 5 and 22 characters, inclusive.
*   **Content:** Must contain at least one letter. If using a prefix and suffix, both require at least one letter.
*   **Special Characters:** Cannot contain any of the following special characters: `<`, `>`, `\`, `'`, `"`, `*`.
*   **Relevance:** Should reflect your Doing Business As (DBA) name.

By following these guidelines, you can ensure your statement descriptors are effective in informing your customers and minimizing potential disputes.
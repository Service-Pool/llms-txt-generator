## Configure Optional Items

Enable customers to purchase complementary products at checkout by using optional items.

### Hosted page
### Embedded page

Customers can add optional items to their order during checkout.

Configuring optional items on a Checkout Session allows customers to add multiple optional products to their order during checkout. This can increase your average order value and revenue. For example, if you’re selling a subscription service, you might also want to offer optional add-ons to customers during checkout like a one-time setup fee and recurring priority support plan.

### Create a Checkout Session with optional items

When creating a Checkout Session, you configure `optional_items` in the same way you configure `line_items`, specifying a price and quantity for each optional item you want to offer to the customer. You can offer up to 10 optional items on a single Checkout Session.

```
Command Line
Select a language
cURL
Stripe CLI
Ruby
Python
PHP
Java
Node.js
Go
.NET
No results
curl https://api.stripe.com/v1/checkout/sessions \
  -u "sk_test_RXHltS2OKzISvxWQ7NmRN57i001oa6x7o4:" \
  -d "line_items[0][price]={{PRICE_ID}}" \
  -d "line_items[0][quantity]=1" \
  -d "optional_items[0][price]={{PRICE_ID}}" \
  -d "optional_items[0][quantity]=1" \
  -d
```
## Building an Integration with a Checkout Form

This guide explains how to use a checkout form to collect all necessary information during checkout while maintaining control over the look and feel of the UI.

### Key Features of Checkout Forms:

*   **End-to-end checkout in a single iframe:** Streamlines the payment process for customers.
*   **Built-in returning UIs:** Offers saved payment methods and an address book for returning customers, enhancing convenience.
*   **Dynamic UI:** Adapts to different device types, ensuring a consistent checkout experience across web and mobile.
*   **UI customization:** Leverages the Stripe Appearance API for a branded and tailored look.
*   **Integration with Stripe products:** Seamlessly works with features like Adaptive Pricing, Stripe Tax, and Billing.
*   **Localization:** Supports both content translation and localized product UIs (e.g., local payment methods and currency display).
*   **Layout options:** Offers single-step and multi-step layouts for flexible checkout flows.

### Checkout Form Layouts:

Checkout forms can be presented in two primary layouts:

*   **Single-page layout:**
    *   UI for new customers
    *   UI for returning customers
*   **Multi-step layout:**
    *   UI for new customers
    *   UI for returning customers
## Stripe Elements: Currency Selector Element

The Currency Selector Element is an embeddable UI component that automatically displays prices in your customer’s local currency based on their location. For details about how to enable the Currency Selector Element, see the integration guide.

**Note:** Adaptive Pricing and the Currency Selector Element are only available when using Elements with the Checkout Sessions API.

You’re responsible for complying with laws that apply to price localization in your or your customers’ regions. You must render the Currency Selector Element in your use of Adaptive Pricing with Elements. Stripe recommends you consult your legal advisor for advice specific to your business.

### Appearance

Use the Appearance API to control the style of all elements. Choose a theme or update specific details.

For instance,
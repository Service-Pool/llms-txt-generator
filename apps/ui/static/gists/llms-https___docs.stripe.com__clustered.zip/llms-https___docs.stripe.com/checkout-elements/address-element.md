The Address Element is an embeddable UI component for accepting complete addresses. Use it to collect shipping addresses, or when you need a complete billing address, such as for tax purposes.

**Theme**
Stripe

**Size**
Desktop

**Customer Location**
United States

**Phone number**
Autocomplete

**Contacts**

**Option** | **Description**
------- | --------
Theme | Use the dropdown to choose a theme or customize the theme with the Elements Appearance API.
Desktop and mobile size | Use the dropdown to set the max pixel width of the parent element that the Address Element is mounted to. You can set it to 750px (desktop) or 320px (mobile).
Customer location | Use this option to choose a location for accepting complete addresses. Changing the location localizes the UI language.
Phone number | Enable this option to allow phone number collection when an address is entered or when using an existing contact.
Autocomplete | Enable this option to decrease checkout time, reduce validation errors, and increase checkout
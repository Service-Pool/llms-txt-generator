## Manually Approve Payments on Your Server

You can run custom logic on your server before finalizing a payment. This is useful for:

*   **Running fraud prevention logic:** Implement your own or third-party fraud checks.
*   **Performing inventory checks:** Ensure you have sufficient stock before confirming a payment.
*   **Validating payment information:** Verify that you can support the customer's chosen payment details.

Manual approval is compatible with the dynamic line items feature.

**Note:** Manual approval is not available for the Payment Intents API. However, you can achieve similar functionality by finalizing payments on your server with the Payment Intents API.
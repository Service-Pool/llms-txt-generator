## Guest Customers

Checkout Sessions that do not create a new customer are associated with a guest customer. Stripe automatically groups guest customers in the Dashboard based on them having used the same card, email, or phone to make payments. This unified view helps you review purchasing behavior, refunds, chargebacks, or fraud.

Guest customers are a read-only grouping for completed transactions. Stripe does not save payment methods for guest customers, so you cannot initiate new charges against them. To save payment details for future use, create a customer-configured Account object or Customer object and save the customer’s payment method.

Checkout supports passing in a `customer_account` or `customer` to enable you to prefill customer information on the Checkout page and to associate the payment or subscription with a specific customer.

If you do not pass in a `customer_account` or `customer`, set `customer_creation` to configure whether Checkout automatically creates a customer-configured Account or Customer when the session is confirmed.

### Managing and monitoring guest customers

Even though you cannot manage or monitor guest
## Customize Checkout

Stripe Checkout offers a range of options to customize the look and feel of your checkout pages, allowing you to align them with your brand and improve the customer experience.

### Appearance Customization

You can tailor the visual elements of your Checkout page to match your brand's aesthetic. This includes:

*   **Branding:** Upload your logo and customize colors, fonts, and shapes to reflect your brand identity. You can access these settings in your Stripe Dashboard under Branding Settings. For Connect platforms, branding can be configured via the Accounts API for connected accounts.
*   **Brand Name:** Ensure your business name is consistent and recognizable by customers. You can update this in your Business Details settings or by setting `branding_settings.display_name` in your API calls.
*   **Custom Domain:** For a more seamless experience, you can use a custom domain with Stripe Checkout, Payment Links, and the customer portal.
*   **Product Images:** Displaying product images on your checkout page can provide customers with a visual representation of what they are purchasing, potentially increasing conversion rates.

### Card Brand Customization

You have the flexibility to control which card brands are displayed to your customers during the checkout process.

*   **Blocking Specific Card Brands:** If you wish to exclude certain card brands, you can use the `brands_blocked` parameter when creating a Checkout Session. You can specify an array of card brand values, such as `['visa', 'mastercard', 'american_express', 'discover_global_network']`. If a customer enters a card number for a blocked brand, they will receive an error message.

By leveraging these customization options, you can create a more branded and user-friendly checkout experience for your customers.
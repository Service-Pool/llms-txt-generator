## Stripe Issuing and Treasury for Platforms

This documentation group provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and card program customization to advanced fraud management and money movement strategies.

### Key Areas:

*   **Getting Started with Issuing:** This section covers the fundamentals of Stripe Issuing, including how it works, onboarding processes, and choosing the right card types (physical vs. virtual).
*   **Card Program Management:** Details on customizing your card program, adding funds to your Issuing balance, and managing card artwork and bundles.
*   **Integration Guides:** Specific guides for integrating Issuing into various use cases like B2B payments, Embedded Finance, and Fleet management.
*   **Controls and Fraud Management:** Information on implementing spending controls, lifecycle controls, advanced fraud tools, real-time authorizations, and handling fraud challenges and PIN management.
*   **Stripe Connect Integration:** Guidance on setting up and managing Issuing and Treasury for Platforms with Stripe Connect, including connected accounts, cardholders, funding, and embedded components.
*   **Treasury for Platforms:** Comprehensive documentation on Treasury for Platforms, covering its features, account structures, money movement capabilities (inbound and outbound transfers, payouts), and bank partner integrations.
*   **Compliance and Guidelines:** Essential information on product marketing, design, and compliance guidelines for both Issuing and Treasury for Platforms, including regulated customer notices and marketing best practices.
*   **Testing and Support:** Resources for testing your integrations in sandbox environments and accessing customer support.

### Core Concepts:

*   **Issuing:** Enables platforms to create, manage, and distribute payment cards for their users, offering features like custom card designs, real-time transaction approval, and spending controls.
*   **Treasury for Platforms:** A suite of APIs that allows platforms to embed financial services into their products, enabling connected accounts to hold funds, pay bills, and manage cash flow.
*   **Stripe Connect:** The foundation for integrating Issuing and Treasury for Platforms, allowing platforms to manage funds flows and compliance requirements for their connected accounts.
*   **Financial Accounts:** Separate balances within Treasury for Platforms that store funds for connected accounts, distinct from the platform's main balance.
*   **Cardholders:** Individuals or companies authorized to use the issued cards.
*   **Real-time Authorizations:** The ability to approve or decline authorization requests in real-time via webhooks, providing granular control over transactions.
*   **Spending Controls:** Tools to set rules and limits on card usage, such as blocking specific merchant categories or setting spending limits.
*   **Fraud Management:** A comprehensive set of tools and strategies to identify, prevent, and mitigate transaction fraud.
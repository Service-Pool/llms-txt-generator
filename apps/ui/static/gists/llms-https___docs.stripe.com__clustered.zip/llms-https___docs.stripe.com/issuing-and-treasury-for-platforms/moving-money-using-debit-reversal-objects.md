## Stripe Issuing and Treasury for Platforms

This documentation group provides comprehensive guidance on leveraging Stripe Issuing and Treasury for Platforms to build and manage sophisticated financial services. It covers everything from initial integration and card program customization to advanced fraud management and cross-border operations.

### Key Areas Covered:

*   **Getting Started & Integration:**
    *   **Onboarding Overview:** Understand the steps to take your Issuing or Treasury for Platforms integration live.
    *   **Integration Guides:** Explore specific guides for building integrations with Embedded Finance, B2B Payments, and Fleet management solutions.
    *   **Sample App:** Utilize the Issuing and Treasury for Platforms sample app to understand API usage and onboard customers.
    *   **Testing:** Learn how to test your Issuing integration in a sandbox environment.
    *   **Beta Migration:** Guides for migrating from older beta versions of Issuing.
    *   **API Access:** How to get started with API access to Treasury for Platforms.

*   **Card Management & Issuance:**
    *   **Issuing Overview:** A general introduction to Stripe Issuing and its capabilities.
    *   **Card Types:** Decide between physical and virtual cards for your cardholders.
    *   **Virtual Cards:** Learn how to create and manage virtual cards.
    *   **Physical Cards:** Comprehensive details on issuing, customizing, and shipping physical cards.
    *   **Card Bundles:** Customize your physical card bundles, including artwork and design.
    *   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **Replacement Cards:** Procedures for replacing expired, damaged, lost, or stolen cards.
    *   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers.
    *   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for various use cases.
    *   **Consumer Credit Issuing:** Understand and implement credit programs for consumers.
    *   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.

*   **Funding & Money Movement:**
    *   **Issuing Balance:** Learn how to fund your Issuing balance to enable card spend.
    *   **Adding Funds:** Explore different funding options for your card program.
    *   **Post-funding:** Understand how to post-fund your integration with Stripe and Dynamic Reserves.
    *   **Treasury for Platforms:** An overview of providing financial services to connected accounts.
    *   **Financial Accounts:** Learn how to set up and manage financial accounts for your platform and connected accounts.
    *   **Moving Money:** Detailed guides on moving money into and out of financial accounts using various methods (ACH, wire, Stripe network).
    *   **Payouts and Top-ups:** Manage money movement between payments balances and financial accounts.
    *   **Stablecoin-backed Cards:** Issue cards backed by stablecoin balances.

*   **Program Management & Customization:**
    *   **Program Management:** Choose between Stripe program management and processor-only models.
    *   **Customize Your Program:** Tailor your Stripe Issuing card program to your business needs.
    *   **Cardholder Controls:** Understand how to screen and manage cardholder information.
    *   **Connect Integrations:** Set up Issuing and Connect integrations for issuing cards to third parties.
    *   **Funding with Connect:** Learn how to fund Issuing balances for connected accounts.
    *   **Terms of Service Acceptance:** Update Issuing terms of service for connected accounts.

*   **Controls & Fraud Management:**
    *   **Manage Fraud:** Understand fraud risks and how to combat them with Stripe Issuing tools.
    *   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud.
    *   **Spending Controls:** Set rules on cards and cardholders to control spending.
    *   **Lifecycle Controls:** Implement automatic usage-based cancellation of virtual cards.
    *   **Real-time Authorizations:** Approve or decline authorization requests in real time.
    *   **Authorization Rules:** Limit authorization approvals using custom Issuing authorization rules.
    *   **Fraud Challenges:** Implement additional verification for high-risk authorizations.
    *   **3D Secure:** Understand cardholder authentication using 3D Secure for online transactions.
    *   **Token Management:** Manage network tokens on your cards for secure payments.
    *   **Issuing Watchlist:** Learn about automatic screening against sanctions lists.

*   **Transactions & Disputes:**
    *   **Authorizations:** How Stripe Issuing handles authorization requests.
    *   **Transactions:** Understand the lifecycle of a transaction after authorization.
    *   **Disputes:** Learn how to dispute transactions and manage the resolution process.
    *   **ATM Usage:** Enable and manage ATM cash withdrawals for your cards.
    *   **Enriched Merchant Data:** Utilize comprehensive merchant data for fraud prevention and insights.
    *   **Merchant Categories:** Understand MCC codes and how they are used for controls.

*   **Compliance & Guidelines:**
    *   **Product Marketing, Design, and Compliance Guidelines (US):** Adhere to guidelines for launching compliant Issuing and Treasury programs.
    *   **Marketing Guidelines (Europe/UK):** Understand marketing regulations for Issuing programs in the UK and Europe.
    *   **Regulated Customer Notices:** Learn about sending regulatory notifications to your customers.
    *   **Treasury for Platforms Compliance:** Ensure your Treasury for Platforms program and marketing campaigns are compliant.
    *   **Fifth Third Bank Integration:** Integrate with Fifth Third Bank for Treasury for Platforms.

*   **Customer Support:**
    *   **Customer Support for Issuing and Treasury:** Find information to resolve common issues.
```markdown
# Create Virtual Cards

You can create virtual cards using the Dashboard or the Cardholders API. For details about how to create a cardholder, create a card, and activate a card, see [Create virtual cards](/issuing/cards/virtual/issue-cards).

After you create a virtual card, it’s generated immediately and is available for use.

## Display virtual card details to cardholders

You can use Issuing Elements to display virtual card details to your cardholders without this information passing through your servers. This method is fully PCI-DSS compliant, and we recommend it.
```
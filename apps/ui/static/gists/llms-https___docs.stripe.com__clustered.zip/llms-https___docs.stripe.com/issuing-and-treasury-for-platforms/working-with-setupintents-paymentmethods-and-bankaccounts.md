# Stripe Issuing and Treasury for Platforms

This documentation group provides comprehensive information on integrating Stripe Issuing and Treasury for Platforms. It covers everything from initial setup and onboarding to advanced features like fraud management, credit programs, and international usage.

## Key Areas

*   **Getting Started:**
    *   [Onboarding overview](/issuing/onboarding-overview)
    *   [Issuing beta migration guide](/issuing/migration-from-beta)
    *   [Customer support for Issuing and Treasury for platforms](/issuing/customer-support)
    *   [Issuing and Treasury for platforms sample app](/issuing/sample-app)
    *   [Test your Issuing integration](/issuing/testing)
    *   [Get started with API access to Treasury for platforms](/treasury/connect/access)
    *   [Treasury for platforms requirements](/treasury/connect/requirements)
    *   [Treasury for platforms connected account onboarding guide](/treasury/connect/examples/onboarding-guide)
    *   [Treasury for platforms product marketing, design, and compliance guidelines](/treasury/connect/compliance)

*   **Issuing Core Functionality:**
    *   [Issuing overview](/issuing)
    *   [How Issuing works](/issuing/how-issuing-works)
    *   [Choose your card type](/issuing/choose-cards)
    *   [Virtual cards with Issuing](/issuing/cards/virtual)
    *   [Physical cards](/issuing/cards/physical)
    *   [Fund your Issuing balance](/issuing/funding/balance)
    *   [Add funds to your card program](/issuing/adding-funds-to-your-card-program)
    *   [Program management](/issuing/program-management)
    *   [Customize your card program](/issuing/customize-your-program)
    *   [Replacement cards](/issuing/cards/replacements)
    *   [PIN management](/issuing/cards/pin-management)
    *   [Use digital wallets with Issuing](/issuing/cards/digital-wallets)
    *   [Artwork templates](/issuing/cards/artwork-templates)
    *   [Customize card bundle](/issuing/cards/physical/card-bundle-selections)
    *   [Choose your physical bundle](/issuing/cards/physical/choose-bundle)
    *   [Create a design](/issuing/cards/physical/create-design)
    *   [Create physical cards](/issuing/cards/physical/issue-cards)
    *   [Order a custom bundle](/issuing/cards/physical/order-custom-bundle)
    *   [Ship cards](/issuing/cards/physical/ship-cards)
    *   [Physical cards address validation](/issuing/cards/physical/address-validation)
    *   [Issuing merchant categories](/issuing/categories)

*   **Integration Guides:**
    *   [Integration guides](/issuing/integration-guides)
    *   [Embedded Finance integration guide](/issuing/integration-guides/embedded-finance)
    *   [B2B payments integration guide](/issuing/integration-guides/b2b-payments)
    *   [Fleet integration guide](/issuing/integration-guides/fleet)
    *   [Integrate processor-only Issuing](/issuing/processor-only-integration-guide)
    *   [Processor-only Issuing](/issuing/processor-only-issuing)
    *   [Set up an Issuing and Connect integration](/issuing/connect)

*   **Fraud Management and Controls:**
    *   [Manage fraud with Stripe Issuing controls and tools](/issuing/manage-fraud)
    *   [Advanced fraud tools](/issuing/controls/advanced-fraud-tools)
    *   [Issuing authorization rules](/issuing/controls/authorization-rules)
    *   [Fraud challenges](/issuing/controls/fraud-challenges)
    *   [Issuing lifecycle controls](/issuing/controls/lifecycle-controls)
    *   [Issuing real-time authorizations](/issuing/controls/real-time-authorizations)
    *   [Migrate to direct webhook response](/issuing/controls/real-time-authorizations/direct-webhook-migration)
    *   [Issuing spending controls](/issuing/controls/spending-controls)
    *   [Token management](/issuing/controls/token-management)
    *   [Issuing watchlist](/issuing/issuing-watchlist)

*   **Stripe Connect Integration:**
    *   [Connected accounts, cardholders, and cards](/issuing/connect/cardholders-and-cards)
    *   [Cardholder controls](/issuing/connect/cardholders-controls)
    *   [Fund Issuing balances with Connect](/issuing/connect/funding)
    *   [Update the Issuing terms of service acceptance](/issuing/connect/tos_acceptance)
    *   [Inactive connected accounts offboarding](/issuing/connect/inactive-accounts-management)
    *   [Embed Issuing card management into your website](/issuing/connect/embedded-components)

*   **Credit Programs:**
    *   [Issuing Credit overview](/issuing/credit)
    *   [Credit Consumer Issuing](/issuing/credit/consumer-issuing)
    *   [How Credit Consumer Issuing works](/issuing/credit/consumer-issuing/how-it-works)
    *   [Consumer prepaid debit cards](/issuing/consumer-prepaid-debit-cards)
    *   [Manage account obligations](/issuing/credit/manage-account-obligations)
    *   [Available credit and flow of funds](/issuing/credit/manage-account-obligations/available-credit)
    *   [Obligation payments](/issuing/credit/manage-account-obligations/obligation-payments)
    *   [Obligation amounts, transactions, and adjustments](/issuing/credit/manage-account-obligations/obligations-transactions-adjustments)
    *   [Manage credit terms](/issuing/credit/manage-credit-terms)
    *   [Set up credit for connected accounts](/issuing/credit/connect-credit-setup)
    *   [Report other credit decisions and manage adverse action notices](/issuing/credit/report-credit-decisions-and-manage-aans)
    *   [Report required regulatory data for credit decisions](/issuing/credit/report-required-regulatory-data-for-credit-decisions)
    *   [Test your integration](/issuing/credit/test-credit)

*   **Treasury for Platforms:**
    *   [Treasury for platforms overview](/treasury/connect)
    *   [How Treasury for platforms works](/treasury/connect/how-financial-accounts-for-platforms-works)
    *   [Accounts structure](/treasury/connect/account-management/accounts-structure)
    *   [Working with connected accounts](/treasury/connect/account-management/connected-accounts)
    *   [Working with financial accounts](/treasury/connect/account-management/financial-accounts)
    *   [Financial account features](/treasury/connect/account-management/financial-account-features)
    *   [Platform financial accounts](/treasury/connect/account-management/platform-financial-account)
    *   [Working with Stripe Issuing cards](/treasury/connect/account-management/issuing-cards)
    *   [Working with balances and transactions](/treasury/connect/account-management/working-with-balances-and-transactions)
    *   [Treasury for platforms supportability for connected accounts](/treasury/connect/account-management/supportability)
    *   [Moving money into financial accounts](/treasury/connect/moving-money/moving-money-into-financial-accounts)
    *   [Moving money using InboundTransfer objects](/treasury/connect/moving-money/into/inbound-transfers)
    *   [Moving money using ReceivedCredit objects](/treasury/connect/moving-money/into/received-credits)
    *   [Moving money using CreditReversal objects](/treasury/connect/moving-money/into/credit-reversals)
    *   [Moving money out of Treasury for platforms](/treasury/connect/moving-money/moving-money-out)
    *   [Moving money using OutboundTransfer objects](/treasury/connect/moving-money/out-of/outbound-transfers)
    *   [Moving money using OutboundPayment objects](/treasury/connect/moving-money/out-of/outbound-payments)
    *   [Moving money using ReceivedDebit objects](/treasury/connect/moving-money/out-of/received-debits)
    *   [Moving money using DebitReversal objects](/treasury/connect/moving-money/out-of/debit-reversals)
    *   [Payouts and top-ups from payments balance](/treasury/connect/moving-money/payouts)
    *   [Working with SetupIntents, PaymentMethods, and BankAccounts](/treasury/connect/moving-money/working-with-bankaccount-objects)
    *   [ACH NOC and SEC handling](/treasury/connect/moving-money/noc-sec-handling)
    *   [Money movement timelines](/treasury/connect/money-movement/timelines)
    *   [Sample integrations](/treasury/connect/sample-integrations)
    *   [Use Treasury for platforms to move money](/treasury/connect/examples/moving-money)
    *   [Issuing and Treasury for platforms sample app](/treasury/connect/examples/sample-app)
    *   [Webhooks for Stripe Issuing and Treasury for platforms](/treasury/connect/examples/webhooks)
    *   [Treasury for platforms fraud guide](/treasury/connect/examples/fraud-guide)
    *   [Integrate with Fifth Third Bank](/treasury/connect/fifth-third)
    *   [Build a new Treasury for platforms integration with Fifth Third Bank](/treasury/connect/fifth-third-get-started)
    *   [Handling complaints](/treasury/connect/handling-complaints)
    *   [Marketing Treasury for platforms](/treasury/connect/marketing-financial-accounts)
    *   [Regulatory receipts](/treasury/connect/moving-money/regulatory-receipts)

*   **Global Issuing:**
    *   [Use Stripe Issuing in different countries](/issuing/global)
    *   [Issuing and Treasury product marketing, design, and compliance guidelines](/issuing/compliance-us)
    *   [Issuing regulated customer notices](/issuing/compliance-us/issuing-regulated-customer-notices)
    *   [Stripe Issuing marketing guidelines](/issuing/marketing-guidance-europe-uk)

*   **Specific Use Cases:**
    *   [Issuing for your business](/issuing/direct)
    *   [Issuing for agents](/issuing/agents)
    *   [Stablecoin-backed cards for Stripe Stablecoin Financial Accounts](/issuing/stablecoin-cards-for-financial-accounts)
    *   [Stablecoin-backed cards for Bridge, Privy, or third-party wallets](/issuing/bridge-stablecoin-cards)
    *   [Stablecoin-backed card issuing](/issuing/stablecoin-cards)
    *   [Post-fund your integration with Stripe](/issuing/funding/post-fund)
    *   [Post-fund your integration with Dynamic Reserves](/issuing/funding/post-fund-with-dynamic-reserves)

*   **Purchases and Transactions:**
    *   [Issuing authorizations](/issuing/purchases/authorizations)
    *   [Issuing transactions](/issuing/purchases/transactions)
    *   [Issuing disputes](/issuing/purchases/disputes)
    *   [Use cards at automated teller machines (ATMs)](/issuing/purchases/atm-usage)
    *   [Enriched merchant data](/issuing/purchases/enriched-merchant-data)

*   **Issuing Elements:**
    *   [Using Issuing Elements](/issuing/elements)

*   **Customer Support:**
    *   [Customer support for Issuing and Treasury for platforms](/issuing/customer-support)
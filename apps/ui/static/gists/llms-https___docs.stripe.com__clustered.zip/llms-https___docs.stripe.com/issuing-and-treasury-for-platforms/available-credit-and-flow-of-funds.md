## Stripe Issuing and Treasury for Platforms Documentation

This section of the Stripe documentation provides comprehensive resources for integrating and managing Stripe Issuing and Treasury for Platforms. These products enable businesses to issue payment cards and manage financial accounts for their customers or internal use.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing, including creating, managing, and distributing payment cards. (Page 66)
*   **How Issuing Works:** Delve into the mechanics of building a card program with Stripe Issuing, including partnerships with banks and card networks. (Page 67)
*   **Treasury for Platforms Overview:** Learn how to provide financial services to connected accounts by embedding financial services into your platform. (Page 120)
*   **Integration Guides:** Access specific guides for integrating Issuing for various use cases:
    *   **Embedded Finance:** Build an embedded financial services integration. (Page 3)
    *   **B2B Payments:** Create cards for business purchases. (Page 2)
    *   **Fleet:** Build a fleet financial services integration. (Page 4)
*   **Onboarding Overview:** Understand the process for developing and launching an Issuing or Treasury for Platforms integration, including use case approval and going live. (Page 6)
*   **Customer Support:** Find resources for resolving common Issuing and Treasury for Platforms questions. (Page 1)
*   **Sample App:** Explore a sample application to understand how to use Issuing and Treasury for Platforms APIs for onboarding, card creation, and payments. (Page 7)
*   **Testing Your Integration:** Learn how to test your Issuing integration in a sandbox environment without making real purchases. (Page 84)
*   **Treasury for Platforms Sandbox:** Set up and test Treasury for Platforms and Issuing functionality in a sandbox environment. (Page 85)

### Card Management and Issuance

*   **Choose Card Type:** Decide between physical or virtual cards for your cardholders. (Page 12)
*   **Virtual Cards:** Learn about creating and managing virtual cards. (Page 33)
    *   **Issue Virtual Cards:** Steps to create virtual cards for cardholders. (Page 34)
*   **Physical Cards:** Understand the options for issuing physical cards. (Page 28)
    *   **Choose Card Bundle:** Select standard or custom physical card bundles. (Page 24)
    *   **Customize Card Bundle:** Make selections for your card bundle design. (Page 23)
    *   **Artwork Templates:** Utilize design templates for cards, carriers, and envelopes. (Page 22)
    *   **Create a Design:** Steps to create and name your card design. (Page 25)
    *   **Issue Physical Cards:** Create cardholders and issue physical cards. (Page 26)
    *   **Ship Cards:** Select shipping speeds for your cards. (Page 29)
    *   **Address Validation:** Enable and manage address validation for physical card delivery. (Page 21)
*   **Replacement Cards:** Learn how to replace expired, damaged, lost, or stolen cards. (Page 32)
*   **PIN Management:** Allow cardholders to manage their personal identification numbers. (Page 30)
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay. (Page 17)
*   **Token Management:** Understand how to manage network tokens on your cards. (Page 50)

### Funding and Balances

*   **Issuing Balance:** Learn how to make funds available for your cards. (Page 61)
*   **Add Funds to Your Card Program:** Explore options for funding your Issuing balance, including pull-funded, push-funded, and balance transfers. (Page 11)
*   **Post-fund Your Integration:** Understand how to accrue a negative Issuing balance on card spend and post-fund Stripe later. (Page 64)
    *   **Dynamic Reserves:** Utilize dynamic reserves to post-fund card spend. (Page 63)

### Stripe Connect Integrations

*   **Set Up Issuing and Connect Integration:** Learn how to issue cards on connected accounts using Stripe Connect. (Page 41)
*   **Connected Accounts, Cardholders, and Cards:** Understand how connected accounts, cardholders, and cards interact within a Connect integration. (Page 39)
*   **Cardholder Controls:** Manage cardholder information in accordance with legal and regulatory guidelines. (Page 36)
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity affects connected accounts and Issuing capabilities. (Page 38)
*   **Fund Issuing Balances with Connect:** Discover how to fund connected accounts for Issuing. (Page 40)
*   **Embed Issuing Card Management:** Use prebuilt UI components to embed card management into your website. (Page 37)

### Treasury for Platforms Integrations

*   **Treasury for Platforms Overview:** A comprehensive guide to embedding financial services for connected accounts. (Page 120)
*   **How Treasury for Platforms Works:** Understand connected accounts, financial accounts for platforms, and money movement. (Page 106)
*   **Treasury for Platforms Requirements:** Learn about the compliance requirements and restrictions for using Treasury for Platforms. (Page 121)
*   **Get Started with API Access:** Access Treasury for Platforms via API and test in a sandbox environment. (Page 85)
*   **Accounts Structure:** Understand the different account types within Treasury for Platforms. (Page 86)
*   **Working with Connected Accounts:** Request the treasury capability and collect onboarding requirements for connected accounts. (Page 92)
*   **Working with Financial Accounts:** Use financial accounts to store, send, and receive funds. (Page 93)
*   **Financial Account Features:** Explore the features available for financial accounts. (Page 87)
*   **Platform Financial Accounts:** Learn about the financial account provisioned for your platform. (Page 89)
*   **Working with Balances and Transactions:** Understand financial account balances and the impact of transactions. (Page 91)
*   **Moving Money:** Comprehensive guides on money movement within Treasury for Platforms:
    *   **Moving Money into Financial Accounts:** Learn about `InboundTransfer` and `ReceivedCredit` objects. (Page 111)
    *   **Moving Money out of Treasury for Platforms:** Explore `OutboundTransfer`, `OutboundPayment`, `ReceivedDebit`, and `DebitReversal` objects. (Page 112)
    *   **Payouts and Top-ups:** Move money between payments balance and financial account balances. (Page 118)
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated. (Page 113)
*   **Money Movement Timelines:** Understand the processing and cutoff times for various money movement types. (Page 110)
*   **Sample Integrations:**
    *   **Set up Financial Accounts and Cards:** Follow a sample integration to set up a financial account and create cards. (Page 100)
    *   **Using Treasury for Platforms to Move Money:** Learn about basic money movement using Treasury endpoints. (Page 101)
*   **Treasury for Platforms Fraud Guide:** Best practices for managing fraud as a platform. (Page 103)
*   **Treasury for Platforms Connected Account Onboarding Guide:** Implement a Treasury for Platforms onboarding process for connected accounts. (Page 102)
*   **Marketing and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant. (Page 96)
*   **Handling Complaints:** Learn how to properly handle complaints related to Treasury for Platforms or Issuing. (Page 97)
*   **Marketing Treasury for Platforms:** Create compliant messaging for your users. (Page 98)
*   **Regulatory Receipts:** Understand hosted transaction receipts for regulated transactions. (Page 99)
*   **Fifth Third Bank:** Integrate with Fifth Third Bank for Treasury for Platforms. (Page 94, Page 95)

### Controls and Fraud Management

*   **Manage Fraud:** Understand transaction fraud risks and how to combat them using Stripe Issuing controls. (Page 20)
*   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud. (Page 42)
*   **Issuing Authorization Rules:** Limit authorization approvals using custom rules. (Page 43)
*   **Real-time Authorizations:** Approve or decline authorization requests in real time using synchronous webhooks. (Page 48)
    *   **Migrate to Direct Webhook Response:** Transition from deprecated API calls to direct webhook responses for real-time authorizations. (Page 44)
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations. (Page 45)
*   **3D Secure:** Learn about 3D Secure for cardholder authentication in online transactions. (Page 10)
*   **Spending Controls:** Set rules on cards and cardholders to control spending by category, country, or amount. (Page 49)
*   **Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards. (Page 47)

### Specific Use Cases and Features

*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for users to receive and spend money. (Page 13)
*   **Credit Consumer Issuing:** Create, launch, and manage a credit program for your consumers. (Page 15, Page 14)
*   **B2B Payments:** Build a B2B payments integration using Stripe Issuing. (Page 2)
*   **Fleet:** Build a fleet financial services integration. (Page 4)
*   **Embedded Finance:** Build an embedded financial services integration. (Page 3)
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents. (Page 69)
*   **Processor-only Issuing:** Integrate with Stripe Issuing where you manage your program's regulatory requirements. (Page 19, Page 18)
*   **Customize Your Card Program:** Tailor your Stripe Issuing card program to your business needs. (Page 16)
*   **Stablecoin-backed Cards:** Issue prepaid or debit cards backed by stablecoin balances. (Page 81, Page 83)
    *   **Stablecoin-backed Cards for Financial Accounts:** Issue cards backed by Stablecoin Financial Accounts. (Page 81)
    *   **Stablecoin-backed Cards for Bridge, Privy, or Third-Party Wallets:** Integrate Stripe Issuing with Bridge for stablecoin-backed card programs. (Page 82)
*   **Global Availability:** Understand integration options for issuing cards across different countries. (Page 65)
*   **Merchant Categories:** Learn about Merchant Category Codes (MCCs) and how to use them for spending controls. (Page 35)
*   **ATM Usage:** Enable and use US-issued cards for ATM cash withdrawals. (Page 76)
*   **Issuing Watchlist:** Understand the process for automatic screening against sanctions lists. (Page 74)
*   **Customer Communications:** Learn about sending regulated customer notices. (Page 72)
*   **Product Marketing and Compliance:** Adhere to guidelines for marketing and launching compliant Issuing and Treasury programs. (Page 71, Page 96)

### API and Developer Resources

*   **Issuing Elements:** Display sensitive Issuing card details in your web application in a PCI-compliant way. (Page 46)
*   **API Access to Treasury for Platforms:** Get started with API access to Treasury for Platforms. (Page 85)
*   **Webhooks:** Handle asynchronous events for Stripe Issuing and Treasury for Platforms. (Page 105)
*   **Issuing Beta Migration Guide:** Learn how to migrate from the Issuing beta program. (Page 68)
## Stripe Issuing and Treasury for Platforms: A Comprehensive Guide

This documentation set provides a detailed overview of Stripe Issuing and Treasury for Platforms, covering everything from initial setup and integration to advanced features and compliance. Whether you're looking to issue physical or virtual cards, manage funds, or build embedded financial services, these guides offer the necessary information to get started and scale your program.

### Key Areas Covered:

*   **Getting Started with Issuing:**
    *   Understand the core concepts of Stripe Issuing and how it works.
    *   Navigate the onboarding process and prepare for launch.
    *   Choose between physical and virtual cards to suit your needs.
    *   Learn how to fund your Issuing balance and manage card programs.
    *   Explore integration guides for specific use cases like B2B payments, fleet management, and embedded finance.
    *   Utilize the sample app to see Issuing and Treasury for Platforms APIs in action.

*   **Card Management and Customization:**
    *   Create and manage cardholders and their cards.
    *   Customize your card program with unique designs and branding.
    *   Order and ship physical cards, including custom bundles.
    *   Manage PINs for cardholders.
    *   Integrate with digital wallets like Apple Pay and Google Pay.
    *   Handle card replacements for expired, damaged, lost, or stolen cards.

*   **Fraud Prevention and Controls:**
    *   Implement advanced fraud tools to identify and prevent transaction fraud.
    *   Configure real-time authorizations and authorization rules.
    *   Utilize fraud challenges and 3D Secure for enhanced cardholder authentication.
    *   Manage spending controls to set limits and restrict card usage.
    *   Understand lifecycle controls for automatic card cancellation.
    *   Learn about token management for secure payments.

*   **Stripe Connect Integration:**
    *   Set up and manage Issuing and Connect integrations for issuing cards to third parties.
    *   Understand how connected accounts, cardholders, and cards interact.
    *   Fund Issuing balances with Connect.
    *   Embed Issuing card management into your website using Connect embedded components.
    *   Manage inactive connected accounts and offboarding.

*   **Treasury for Platforms:**
    *   Understand the core concepts of Treasury for Platforms and its eligibility requirements.
    *   Get started with API access and set up financial accounts and cards.
    *   Manage accounts, including platform and connected accounts, and their structure.
    *   Explore financial account features and working with balances and transactions.
    *   Learn about moving money in and out of financial accounts using various methods.
    *   Integrate with bank partners like Fifth Third Bank.

*   **Credit Features:**
    *   Explore Issuing Credit features, including setting up credit for connected accounts.
    *   Manage account obligations, credit terms, and available credit.
    *   Report credit decisions and manage adverse action notices.
    *   Test your credit integration in sandbox environments.

*   **Compliance and Best Practices:**
    *   Adhere to product marketing, design, and compliance guidelines for Issuing and Treasury for Platforms.
    *   Understand Issuing merchant categories and their use in spending controls.
    *   Learn about Issuing watchlist processes and best practices.
    *   Navigate marketing guidelines for the UK and Europe.
    *   Handle customer communications and regulated notices.
    *   Implement robust fraud management processes.
    *   Understand ACH NOC and SEC handling.

This documentation set aims to be a comprehensive resource for developers and businesses looking to leverage Stripe's Issuing and Treasury for Platforms products to create innovative financial solutions.
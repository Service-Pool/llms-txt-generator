## Issuing for Agents

This section provides guidance on how to issue programmable cards with built-in controls to agents, enabling them to autonomously discover, evaluate, and source products and services.

### Key Capabilities

*   **One-time use cards:** Issue single-use cards that agents can use to pay at any business.
*   **Real-time spending controls:** Set dynamic limits per transaction or per merchant category. Approve or decline authorization requests as they happen using webhooks.
*   **Full transaction visibility:** Get real-time authorization events and detailed transaction information.

### Use Cases

*   **Agentic commerce workflows:** Provide agents with payment credentials to transact online for tasks such as product sourcing or service evaluation.
*   **Controlled spending:** Ensure agents stay within defined budgets and adhere to specific spending rules.
*   **Real-time monitoring:** Maintain full visibility and control over agent-initiated spend.
## Stripe Issuing: Disputes

This section details how to manage disputes within Stripe Issuing, covering the process for initiating and monitoring disputes, and key considerations.

### Understanding Disputes

A dispute occurs when a cardholder or user questions a transaction. Common reasons for disputes include:

*   **Fraud:** Unauthorized transactions.
*   **Product/Service Not Received:** The cardholder did not receive the goods or services purchased.
*   **Processing Error:** Issues with how the transaction was processed.

### Initiating a Dispute

Stripe provides both a guided Dashboard process and an API for submitting and managing disputes.

*   **Dashboard:** Recommended for low-volume dispute management.
*   **API:** Recommended for high-volume dispute management.

**Important Note:** You cannot dispute an authorization. Authorizations are reversed at the discretion of acquiring businesses. Disputes can only be filed after the authorization is complete and the transaction has been captured.

### Key Considerations for Disputes

*   **Network Rules:** Stripe processes disputes according to the rules set by card networks (e.g., Visa, Mastercard). Adhering to these rules is crucial for a successful dispute resolution.
*   **Dispute Timeline:** The dispute resolution process typically takes between 30 and 90 days.

### Dispute Lifecycle

1.  **Initiation:** The cardholder or user initiates a dispute.
2.  **Submission:** Stripe submits the dispute to the card network.
3.  **Evidence Gathering:** Both the merchant and the cardholder may be asked to provide evidence.
4.  **Resolution:** The card network makes a decision based on the evidence.
5.  **Outcome:** The dispute is either won by the cardholder (chargeback) or the merchant (reversal).

### Managing Disputes with Stripe

Stripe's tools and APIs help you streamline the dispute management process, providing visibility into dispute status and facilitating evidence submission.
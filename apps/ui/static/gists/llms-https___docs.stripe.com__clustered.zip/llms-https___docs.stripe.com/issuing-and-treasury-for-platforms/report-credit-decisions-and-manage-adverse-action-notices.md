## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and integration to advanced features like fraud management, credit offerings, and international expansion.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing, how it works, and its capabilities for creating, managing, and distributing payment cards. (Page 66, Page 67)
*   **Treasury for Platforms Overview:** Learn how to embed financial services into your platform, enabling connected accounts to hold funds, pay bills, and manage cash flow. (Page 120, Page 106)
*   **Integration Guides:**
    *   **Embedded Finance:** Build integrated financial services with Issuing and Treasury for Platforms. (Page 3, Page 5)
    *   **B2B Payments:** Create cards for business-related purchases. (Page 2, Page 5)
    *   **Fleet:** Develop fleet card programs. (Page 4, Page 5)
*   **Onboarding Overview:** Navigate the process of getting your Issuing or Treasury for Platforms integration live, including use case approval and live mode access. (Page 6)
*   **Customer Support:** Find resources for resolving common Issuing and Treasury for Platforms questions. (Page 1)
*   **Sample App:** Explore a sample application to understand how to use Issuing and Treasury for Platforms APIs for onboarding, card issuance, and payments. (Page 7, Page 104)
*   **Testing:** Learn how to test your Issuing integration in a sandbox environment without making real purchases. (Page 84)
*   **API Access:** Get started with API access to Treasury for Platforms, including sandbox testing. (Page 85)

### Issuing Product Details

*   **Card Types:**
    *   **Virtual Cards:** Understand how to create and manage virtual cards. (Page 33, Page 34)
    *   **Physical Cards:** Learn about issuing, customizing, and shipping physical cards. (Page 28, Page 26, Page 29, Page 21, Page 23, Page 24, Page 25, Page 27)
    *   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for users to receive and spend money. (Page 13)
    *   **Stablecoin-Backed Cards:** Explore issuing cards backed by stablecoin balances. (Page 81, Page 82, Page 83)
*   **Card Management:**
    *   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers. (Page 30)
    *   **Replacement Cards:** Learn how to replace expired, damaged, lost, or stolen cards. (Page 32)
    *   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay. (Page 17)
    *   **Token Management:** Understand how to manage network tokens for secure payments. (Page 50)
*   **Funding Your Issuing Balance:** Learn about different methods to fund your Issuing balance. (Page 11, Page 61)
    *   **Post-funding:** Understand how to post-fund your integration with Stripe and Dynamic Reserves. (Page 63, Page 64)
*   **Customization:**
    *   **Customize Your Card Program:** Tailor your card program to meet specific business needs. (Page 16)
    *   **Artwork Templates:** Utilize provided templates for card design. (Page 22)
*   **Controls and Fraud Management:**
    *   **Spending Controls:** Set rules for card and cardholder spending. (Page 49)
    *   **Lifecycle Controls:** Control automatic usage-based cancellation of cards. (Page 47)
    *   **Real-time Authorizations:** Approve or decline authorization requests in real time. (Page 48, Page 9, Page 44)
    *   **Authorization Rules:** Limit authorization approvals with custom rules. (Page 43)
    *   **Fraud Challenges:** Implement additional verification steps for authorizations. (Page 45)
    *   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud. (Page 42)
    *   **Manage Fraud:** Understand transaction fraud risks and mitigation strategies. (Page 20)
    *   **Issuing Watchlist:** Learn about automatic screening against sanctions lists. (Page 74)
*   **Purchases and Transactions:**
    *   **Authorizations:** Handle authorization requests for card purchases. (Page 77)
    *   **Transactions:** Understand the lifecycle of a transaction after authorization. (Page 80)
    *   **Disputes:** Learn how to dispute transactions. (Page 78)
    *   **ATM Usage:** Enable and manage ATM cash withdrawals. (Page 76)
    *   **Enriched Merchant Data:** Use comprehensive merchant data for fraud prevention. (Page 79)
*   **Merchant Categories:** Understand Merchant Category Codes (MCCs) and their use in spending controls. (Page 35)
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents. (Page 69)
*   **Credit Consumer Issuing:** Explore the private preview for launching credit programs for consumers. (Page 14, Page 15, Page 51, Page 52, Page 53, Page 54, Page 55, Page 56, Page 57, Page 58, Page 59, Page 60)
*   **Global Availability:** Understand options for issuing cards in different countries. (Page 65)
*   **Compliance:**
    *   **US Guidelines:** Adhere to product marketing, design, and compliance guidelines for the US. (Page 71)
    *   **EU/UK Marketing:** Follow marketing guidelines for Issuing programs in the UK and Europe. (Page 75)
    *   **Regulated Customer Notices:** Understand sending regulatory notifications to customers. (Page 72)
*   **Program Management:** Choose between Stripe program management and processor-only models. (Page 31)
*   **Beta Migration:** Guide for migrating from the Issuing beta. (Page 68)
*   **Customer Support:** Resolve common Issuing and Treasury for platforms questions. (Page 1)

### Treasury for Platforms Product Details

*   **Account Management:**
    *   **Accounts Structure:** Understand the interaction between platform and connected accounts. (Page 86)
    *   **Connected Accounts:** Learn how to onboard and manage connected accounts. (Page 92, Page 102)
    *   **Financial Accounts:** Use financial accounts to store, send, and receive funds. (Page 93, Page 87)
    *   **Platform Financial Accounts:** Understand the financial account provisioned for your platform. (Page 89)
    *   **Supportability:** Review requirements for connected accounts to be supported by Treasury for Platforms. (Page 90)
*   **Money Movement:**
    *   **Moving Money In:** Learn about inbound transfers and received credits. (Page 111, Page 108, Page 109)
    *   **Moving Money Out:** Understand methods for moving funds out of financial accounts. (Page 112, Page 115, Page 116, Page 117)
    *   **Payouts and Top-ups:** Move money between payments balance and financial account balances. (Page 118)
    *   **Timelines:** Understand the processing times for various money movement types. (Page 110)
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated. (Page 113)
*   **Working with Cards:** Integrate Stripe Issuing with Treasury for Platforms. (Page 88)
*   **Balances and Transactions:** Understand financial account balances and transaction effects. (Page 91)
*   **Bank Partners:**
    *   **Fifth Third Bank:** Integrate with Fifth Third Bank for Treasury for Platforms. (Page 94, Page 95)
*   **Compliance:**
    *   **Marketing and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant. (Page 96)
    *   **Handling Complaints:** Learn how to properly handle complaints related to Treasury for Platforms or Issuing. (Page 97)
    *   **Regulatory Receipts:** Understand hosted transaction receipts. (Page 99)
    *   **Marketing Treasury for Platforms:** Create compliant messaging for your users. (Page 98)
*   **Sample Integrations:**
    *   **Set up Financial Accounts and Cards:** Follow a sample integration to set up financial accounts and cards. (Page 100)
    *   **Moving Money:** Learn basic money movement using Treasury endpoints. (Page 101)
    *   **Webhooks:** Understand webhook events for Issuing and Treasury for Platforms. (Page 105)
    *   **Fraud Guide:** Best practices for managing fraud as a platform. (Page 103)

### Stripe Connect Integration

*   **Issuing and Connect:** Set up an Issuing and Connect integration to issue cards on connected accounts. (Page 41)
*   **Connect Funding:** Learn how to fund Issuing balances for connected accounts. (Page 40)
*   **Connected Accounts, Cardholders, and Cards:** Create and manage cardholders and cards with Stripe Connect. (Page 39)
*   **Cardholder Controls:** Understand how cardholder controls affect your integration and compliance. (Page 36)
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity affects connected accounts' Issuing capabilities. (Page 38)
*   **Embed Issuing Card Management:** Use prebuilt UI components to embed card management into your website. (Page 37)
## Stripe Issuing and Treasury for Platforms Documentation

This section of the Stripe documentation provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It caters to developers and businesses looking to embed financial services, issue payment cards, and manage funds for their users or connected accounts.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing, including card creation, management, and transaction processing.
*   **How Issuing Works:** Delve into the mechanics of Stripe Issuing, covering its partnership with banks and card networks, and regional availability.
*   **Treasury for Platforms Overview:** Learn about the suite of APIs that enable platforms to embed financial services for their connected accounts, including holding funds, paying bills, and managing cash flow.
*   **Get Started with API Access to Treasury for Platforms:** Begin your integration by understanding sandbox environments and enabling Issuing and Treasury for Platforms capabilities.
*   **Onboarding Overview:** A crucial guide for launching your Issuing or Treasury for Platforms integration, covering use case approval, live mode access, and testing.
*   **Integration Guides:**
    *   **Embedded Finance:** Build embedded financial services using Issuing and Treasury for Platforms.
    *   **B2B Payments:** Create B2B payment solutions with Stripe Issuing.
    *   **Fleet:** Develop fleet management integrations with Issuing.
*   **Issuing and Treasury for Platforms Sample App:** Explore a sample application to understand how to onboard customers, issue cards, and make outbound payments.

### Issuing Card Management

*   **Choose Card Type:** Decide between physical and virtual cards for your cardholders, understanding the trade-offs and use cases for each.
    *   **Virtual Cards:** Learn about creating and managing virtual cards.
    *   **Physical Cards:** Comprehensive information on issuing, customizing, and shipping physical cards.
        *   **Choose Card Bundle:** Select standard or custom physical card bundles.
        *   **Order a Custom Bundle:** Guide to ordering custom physical card bundles.
        *   **Customize Card Bundle:** Options for customizing card bundles.
        *   **Artwork Templates:** Guidelines for creating card artwork.
        *   **Create a Design:** Steps to create and name your card design.
        *   **Issue Cards:** How to create physical cards for cardholders.
        *   **Ship Cards:** Options for shipping physical cards.
        *   **Address Validation:** Ensuring accurate addresses for physical card delivery.
*   **Replacement Cards:** Understand the process for replacing expired, damaged, lost, or stolen cards.
*   **Digital Wallets:** Learn how to integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **PIN Management:** Enable cardholders to manage their Personal Identification Numbers.

### Funding and Balances

*   **Issuing Balance:** Learn how to make funds available for card spend, including push and pull funding methods.
*   **Add Funds to Your Card Program:** Explore various options for funding your Issuing balance.
*   **Postfund your integration with Stripe:** Understand how to accrue a negative Issuing balance and post-fund Stripe later.
*   **Post-fund your integration with Dynamic Reserves:** Utilize dynamic reserves to manage cash flow between Stripe and authorization availability.

### Controls and Fraud Management

*   **Manage Fraud:** Understand transaction fraud risks and how to combat them using Stripe Issuing's tools.
*   **Spending Controls:** Set rules on cards and cardholders to control spending by category, country, or limits.
*   **Lifecycle Controls:** Implement automatic usage-based cancellation of virtual cards.
*   **Advanced Fraud Tools:** Leverage API signals and tooling to identify and prevent transaction fraud.
*   **Real-time Authorizations:** Approve or decline authorization requests in real time using webhooks.
    *   **Quickstart:** Set up and manage real-time authorizations.
    *   **Migrate to Direct Webhook Response:** Transition from deprecated API calls to direct webhook responses.
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations to minimize accidental blocks.
*   **3D Secure:** Learn about cardholder authentication using 3D Secure for online transactions.
*   **Issuing Authorization Rules:** Limit authorization approvals by defining custom conditions.
*   **Issuing Watchlist:** Understand the process for screening Issuing users against sanctions lists.
*   **Token Management:** Manage network tokens for cards, which are virtual representations used in digital wallets and online storefronts.

### Stripe Connect Integration

*   **Set up an Issuing and Connect Integration:** Learn how to issue cards on connected accounts using Stripe Connect.
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and the cards issued to them.
*   **Cardholder Controls:** Ensure compliance by handling cardholder screening and error management.
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity affects connected accounts and their Issuing capabilities.
*   **Embed Issuing Card Management into Your Website:** Utilize Connect embedded components to integrate card management functionality.
*   **Fund Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing.
*   **Update the Issuing Terms of Service Acceptance:** Present accurate business information for connected accounts and accept Issuing terms.

### Treasury for Platforms Specifics

*   **Treasury for Platforms Overview:** Learn how to provide financial services to connected accounts.
*   **Eligibility Requirements:** Understand the requirements for using Treasury for Platforms.
*   **Accounts Structure:** Comprehend the interaction of account components within Treasury for Platforms.
*   **Working with Connected Accounts:** Request treasury capabilities and collect onboarding requirements for connected accounts.
*   **Working with Financial Accounts:** Utilize financial accounts to store, send, and receive funds.
*   **Financial Account Features:** Explore the features available for financial accounts.
*   **Platform Financial Accounts:** Understand the financial account provisioned for your platform.
*   **Working with Balances and Transactions:** Learn about financial account balances and the impact of transactions.
*   **Moving Money:**
    *   **Moving Money into Financial Accounts:** Learn requests to move money into financial accounts using InboundTransfer and ReceivedCredit.
    *   **Moving Money Out of Treasury for Platforms:** Explore methods to move funds from financial accounts using OutboundTransfer, OutboundPayment, ReceivedDebit, and card transactions.
    *   **Money Movement Timelines:** Understand the processing and cutoff times for various money movement types.
    *   **Payouts and Top-ups from Payments Balance:** Learn how to move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated.
    *   **Moving Money using CreditReversal objects:** Reverse received credits to return funds.
    *   **Moving money using InboundTransfer objects:** Transfer money from external accounts into financial accounts.
    *   **Moving money using ReceivedCredit objects:** Move money into financial accounts from other accounts.
    *   **Moving money using DebitReversal objects:** Retrieve funds taken from a financial account.
    *   **Moving money using OutboundPayment objects:** Create outbound payments to third parties.
    *   **Moving money using OutboundTransfer objects:** Transfer money out of financial accounts to external accounts.
    *   **Moving money using ReceivedDebit objects:** Observe money pulled from financial accounts.
*   **Sample Integrations:**
    *   **Use Treasury for Platforms and Issuing to set up financial accounts and cards:** Follow a sample integration to set up financial accounts and create cards.
    *   **Using Treasury for Platforms to Move Money:** Learn basic money movement using treasury endpoints.
    *   **Treasury for Platforms Connected Account Onboarding Guide:** Implement an onboarding process for connected accounts.
    *   **Treasury for Platforms Fraud Guide:** Best practices for managing fraud as a platform.
    *   **Issuing and Treasury for Platforms Sample App:** Utilize a Next.js sample app for integration.
    *   **Webhooks for Stripe Issuing and Treasury for Platforms:** Understand webhook events for Issuing and Treasury for Platforms.
*   **Marketing and Compliance Guidelines:**
    *   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant.
    *   **Handling Complaints:** Learn how to properly handle complaints related to Treasury for Platforms or Issuing.
    *   **Marketing Treasury for Platforms:** Create compliant messaging for your users.
    *   **Regulatory Receipts:** Learn about hosted transaction receipts.
*   **Bank Partners:**
    *   **Integrate with Fifth Third Bank:** Add Fifth Third Bank to your Treasury for Platforms integration.
    *   **Build a new Treasury for Platforms integration with Fifth Third Bank:** Get started with Treasury for Platforms using Fifth Third Bank.

### Specific Use Cases

*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for users to receive and spend money.
*   **Credit Consumer Issuing:** Create, launch, and manage a credit program for your customers.
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.
*   **B2B Payments:** Build B2B payment integrations using Stripe Issuing.
*   **Fleet:** Develop fleet financial services integrations with Issuing.
*   **Embedded Finance:** Build embedded financial services integrations with Issuing and Treasury for Platforms.
*   **Stablecoin-backed Cards:** Issue prepaid or debit cards backed by stablecoin balances.
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts:** Issue cards backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrate Issuing with Bridge for stablecoin-backed card programs.

### Customization and Program Management

*   **Customize Your Card Program:** Tailor your Stripe Issuing card program to your business needs.
*   **Program Management:** Choose between Stripe program management and processor-only models.
*   **Processor-only Issuing:** Integrate and manage your Issuing program with Stripe as the processor.
*   **Issuing Merchant Categories:** Understand how businesses are categorized for spending controls.

### Testing and Support

*   **Test Your Issuing Integration:** Simulate purchases and test your integration in a sandbox environment.
*   **Test Credit Integration:** Validate your automated platform funding in testing environments.
*   **Customer Support for Issuing and Treasury for Platforms:** Find solutions for common Issuing and Treasury for Platforms questions.

### Compliance and Guidelines

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US):** Launch and maintain compliant Issuing and Treasury programs in the US.
*   **Issuing Regulated Customer Notices:** Understand how to send regulatory notifications to your customers.
*   **Stripe Issuing Marketing Guidelines (Europe/UK):** Adhere to marketing guidelines for Issuing programs in the UK and Europe.
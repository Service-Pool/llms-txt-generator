## Stripe Issuing and Treasury for Platforms: Comprehensive Guide

This documentation suite provides in-depth information and guides for integrating Stripe Issuing and Treasury for Platforms. It covers everything from initial setup and card management to advanced fraud controls and money movement.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamental concepts of Stripe Issuing and how it enables you to create and manage payment cards for your business or users.
*   **How Issuing Works:** Delve into the mechanics of Stripe Issuing, including its partnership with card networks and banks, and regional considerations.
*   **Treasury for Platforms Overview:** Learn how Treasury for Platforms allows you to embed financial services into your product, enabling connected accounts to hold funds, pay bills, and manage cash flow.
*   **Get Started with API Access to Treasury for Platforms:** Begin your integration journey by understanding how to access Treasury for Platforms via API and test in a sandbox environment.
*   **Onboarding Overview:** Navigate the process of getting your Issuing or Treasury for Platforms integration live, including use case approval and live mode access.
*   **Issuing and Treasury for Platforms Sample App:** Utilize a sample application to understand how to onboard customers, issue cards, and make outbound payments.

### Issuing Card Management

*   **Choose Your Card Type:** Decide between physical and virtual cards, understanding the use cases and trade-offs for each.
*   **Virtual Cards:** Learn how to create and manage virtual cards for immediate use.
*   **Physical Cards:** Explore the process of issuing physical cards, including design, ordering, and shipping.
    *   **Artwork Templates:** Utilize provided templates to design your custom cards.
    *   **Customize Card Bundle:** Select and customize the components of your physical card bundle.
    *   **Choose Your Physical Bundle:** Understand the options for standard and custom physical card bundles.
    *   **Create a Design:** Guide through the process of creating and naming your card designs.
    *   **Issue Cards:** Learn how to issue both standard and custom physical cards.
    *   **Ship Cards:** Understand the options for individual and bulk card shipping.
    *   **Address Validation:** Ensure successful delivery of physical cards with address normalization and validation.
*   **Replacement Cards:** Manage the process of replacing expired, damaged, lost, or stolen cards.
*   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers.
*   **Use Digital Wallets with Issuing:** Integrate cards with digital wallets like Apple Pay and Google Pay.
*   **Token Management:** Understand how to manage network tokens for enhanced security.

### Integration and Customization

*   **Integration Guides:** Access specific guides for integrating Issuing for various use cases:
    *   **Embedded Finance:** Build embedded financial services with Issuing and Treasury for Platforms.
    *   **B2B Payments:** Create cards for business, employee, or contractor purchases.
    *   **Fleet:** Build a fleet financial services integration.
*   **Customize Your Card Program:** Tailor your Stripe Issuing card program to meet specific business needs.
*   **Processor-Only Issuing:** Understand and integrate with the processor-only Issuing model.
*   **Set up an Issuing and Connect Integration:** Integrate Stripe Issuing with Stripe Connect to issue cards on behalf of connected accounts.
*   **Embed Issuing Card Management into Your Website:** Use prebuilt UI components to embed card management functionality.

### Funding and Money Movement

*   **Fund Your Issuing Balance:** Learn how to make funds available for card spend.
    *   **Add Funds to Your Card Program:** Explore different funding options for your Issuing balance.
    *   **Issuing Balance:** Understand how the Issuing balance works and how to fund it.
    *   **Post-Fund Your Integration with Stripe:** Accrue a negative Issuing balance and post-fund later.
    *   **Post-fund Your Integration with Dynamic Reserves:** Utilize dynamic reserves to manage cash between Stripe and authorization availability.
*   **Treasury for Platforms Money Movement:**
    *   **Financial Accounts:** Understand how to use financial accounts to store, send, and receive funds.
    *   **Platform Financial Accounts:** Learn about the dedicated financial account for your platform.
    *   **Working with Balances and Transactions:** Understand financial account balances and how transactions affect them.
    *   **Moving Money Into Financial Accounts:** Learn the requests available to move money into financial accounts.
        *   **Moving money using InboundTransfer objects:** Transfer money from an external US bank account into a financial account.
        *   **Moving money using ReceivedCredit objects:** Understand how funds move into a financial account.
        *   **Moving money using CreditReversal objects:** Reverse ReceivedCredits to return funds.
    *   **Moving Money Out of Treasury for Platforms:** Explore methods to move funds from a financial account.
        *   **Moving money using OutboundTransfer objects:** Transfer funds to an external bank account owned by a connected account.
        *   **Moving money using OutboundPayment objects:** Create outbound payments to third parties.
        *   **Moving money using ReceivedDebit objects:** Observe funds being pulled from a financial account.
    *   **Payouts and Top-ups from Payments Balance:** Move money between payments account balances and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated via ACH.
    *   **Money Movement Timelines:** Understand the processing and cutoff times for various money movement types.
*   **Fund Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing.

### Credit Issuing

*   **Issuing Credit:** Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
*   **Credit Consumer Issuing:** Create, launch, and manage a credit program for your consumers.
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for your connected accounts.
    *   **Obligation amounts, transactions, and adjustments:** View details about a FundingObligation and make adjustments.
    *   **Obligation payments:** Make payments to your FundingObligation.
    *   **Available credit and flow of funds:** Understand how funds flow and use the available credit amount field.
*   **Manage Credit Terms:** Update credit limits and terms for connected accounts.
*   **Set up Credit for Connected Accounts:** Configure credit terms for your connected accounts and fund their spend from your platform.
*   **Report other Credit Decisions and Manage Adverse Action Notices:** Record application and decision details, and send adverse action notice emails.
*   **Report Required Regulatory Data for Credit Decisions:** Report required regulatory data if your platform is subject to additional reporting for credit programs.
*   **Test Credit Integration:** Validate your automated platform funding in testing environments.

### Fraud Management and Controls

*   **Manage Fraud with Stripe Issuing Controls and Tools:** Understand transaction fraud and how to combat it.
*   **Advanced Fraud Tools:** Reduce fraud with Issuing's advanced tooling and API signals.
*   **Issuing Authorization Rules:** Limit authorization approvals using custom rules.
*   **Real-time Authorizations:** Approve or decline authorization requests in real time using synchronous webhooks.
    *   **Migrate to Direct Webhook Response:** Transition from deprecated API calls to direct webhook responses.
*   **Fraud Challenges:** Turn on additional verification for authorizations.
*   **3D Secure:** Learn about 3D Secure for cardholder authentication.
*   **Spending Controls:** Set rules on cards and cardholders to control spending by category, country, or amount.
*   **Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards.

### Connect and Platform Integrations

*   **Set up an Issuing and Connect Integration:** Integrate Stripe Issuing with Stripe Connect for issuing cards to third parties.
*   **Connected Accounts, Cardholders, and Cards:** Learn how to create and manage cardholders and cards with Stripe Connect.
*   **Cardholder Controls:** Understand how cardholder controls affect your integration and ensure compliance.
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity affects connected accounts' Issuing capabilities.
*   **Treasury for Platforms Requirements:** Understand the compliance requirements and restrictions for using Treasury for Platforms.
*   **Accounts Structure:** Learn how the account components of Treasury for Platforms interact.
*   **Working with Connected Accounts:** Request the treasury capability and collect onboarding requirements for your connected accounts.
*   **Working with Financial Accounts:** Understand how financial accounts are provisioned and used.
*   **Financial Account Features:** Learn about the features available for financial accounts.
*   **Working with Stripe Issuing Cards:** Integrate Stripe Issuing with Treasury for Platforms.
*   **Treasury for Platforms Connected Account Onboarding Guide:** Implement a Treasury for Platforms onboarding process for your connected accounts.
*   **Treasury for Platforms Fraud Guide:** Learn best practices for managing fraud as a platform.
*   **Webhooks for Stripe Issuing and Treasury for Platforms:** Understand webhook events for Issuing and Treasury for Platforms.

### Compliance and Support

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines:** Learn how to launch and maintain compliant Issuing and Treasury programs.
*   **Issuing Regulated Customer Notices:** Understand how to send regulatory notifications to your customers.
*   **Marketing Guidelines (Europe/UK):** Adhere to marketing guidelines for Issuing programs in the UK and Europe.
*   **Customer Support for Issuing and Treasury for Platforms:** Resolve common Issuing and Treasury for Platforms questions and issues.
*   **Issuing Watchlist:** Understand the Issuing watchlist process and best practices for sanctions screening.
*   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines:** Keep your Treasury for Platforms program and marketing campaigns compliant.
*   **Handling Complaints:** Learn how to properly handle complaints about Treasury for Platforms or Stripe Issuing.
*   **Marketing Treasury for Platforms:** Create precise messaging for your users that complies with regulations.
*   **Regulatory Receipts:** Learn about hosted transaction receipts for regulated money movements.

### Specific Use Cases and Features

*   **B2B Payments Integration Guide:** Build a B2B payments integration with Issuing.
*   **Embedded Finance Integration Guide:** Build an embedded financial services integration with Issuing and Treasury for Platforms.
*   **Fleet Integration Guide:** Build a Fleet financial services integration with Issuing.
*   **Consumer Prepaid Debit Cards:** Learn how to issue prepaid debit cards to your users.
*   **Issuing for Your Business:** Programmatically create virtual cards for your business, employees, contractors, or AI agents.
*   **Issuing Merchant Categories:** Understand the categories businesses are grouped into for spending controls.
*   **Use Cards at Automated Teller Machines (ATMs):** Enable and use US-issued cards for ATM cash withdrawals.
*   **Issuing Authorizations:** Handle authorization requests when a card is used for a purchase.
*   **Issuing Transactions:** Understand how transactions are created after an authorization is captured.
*   **Issuing Disputes:** Learn how to dispute transactions.
*   **Enriched Merchant Data:** Use comprehensive merchant data to understand spending patterns and prevent fraud.
*   **Stablecoin-backed Cards:** Issue prepaid or debit cards backed by stablecoin balances.
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts:** Issue cards backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrate Stripe Issuing with Bridge for stablecoin-backed card programs.
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.
*   **Choose a Cardholder Type:** Select the best cardholder type (individual or company) for your use case.
*   **Issuing Beta Migration Guide:** Learn how to migrate from the Issuing beta to the generally available version.
*   **Test Your Issuing Integration:** Issue cards and simulate purchases in a sandbox environment.
*   **Test Your Integration (Treasury for Platforms):** Validate your automated platform funding in testing environments.
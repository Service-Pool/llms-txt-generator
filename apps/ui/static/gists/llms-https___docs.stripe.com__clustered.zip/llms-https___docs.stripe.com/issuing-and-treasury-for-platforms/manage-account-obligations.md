## Managing Account Obligations with Stripe Treasury

This section of the Stripe documentation provides comprehensive guidance on managing account obligations within the Treasury for platforms product. It details how platforms can track, manage, and understand the credit spend, lifecycle, and balances for their connected accounts.

### Key Topics Covered:

*   **Understanding Funding Obligations:** The documentation explains how Stripe creates a `FundingObligation` for each connected account after a `CreditPolicy` is activated. This obligation tracks the amount owed by the account throughout a credit period and triggers an `issuing_funding_obligation.created` event. It's important to note that `FundingObligation` only tracks cleared transactions, not pending authorizations.
*   **Credit Policies and Funding Obligations Interaction:** A diagram illustrates the relationship between `CreditPolicies` and `FundingObligations`, showing how platforms create and manage `CreditPolicies` that define credit limits and terms, which in turn influence `FundingObligations`.
*   **Obligation Amounts, Transactions, and Adjustments:** Detailed information is provided on how to view the specifics of a `FundingObligation`, including total amount, outstanding amount, and paid amount. It also covers how transactions and adjustments impact these figures.
*   **Obligation Payments:** The documentation outlines the platform's responsibility for collecting repayments from connected accounts. It suggests using Stripe's Payment Intents API, Stripe Checkout, or Stripe Invoicing for this purpose and emphasizes the importance of recording all received payments in the `FundingObligation` to accurately reflect available credit.
*   **Available Credit and Flow of Funds:** This section explains how card-based transactions, credits, and debits affect a connected account's available credit. It provides an example of how to retrieve an account's credit ledger to confirm available credit.
*   **Testing Credit Integrations:** Guidance is offered on how to test credit integrations in a sandbox environment using the Credit API, including steps for creating connected accounts, requesting capabilities, updating `CreditPolicies`, and paying off `FundingObligations`.
*   **Reporting Credit Decisions and Adverse Action Notices:** The documentation covers how to use the `CreditUnderwritingRecord` API to record application and decision details, including adverse actions that require sending adverse action notice emails (AANs).
*   **Reporting Required Regulatory Data:** For platforms subject to additional reporting for credit programs, instructions are provided on how to upload regulatory data files to Stripe's Files API and include the file ID when reporting credit decisions.

This section is crucial for platforms that offer credit-based financial services to their connected accounts, ensuring compliance, accurate financial tracking, and effective management of credit extended to users.
## Stripe Issuing and Treasury for Platforms

This documentation section provides a comprehensive guide to Stripe's Issuing and Treasury for Platforms products, enabling businesses to create and manage payment card programs and financial services for their customers.

### Core Concepts

*   **Stripe Issuing**: Allows platforms to programmatically create, manage, and distribute payment cards (physical and virtual) for businesses, employees, contractors, or agents. It offers features like customizable card designs, real-time transaction approvals, spending controls, and fraud management tools.
*   **Treasury for Platforms**: A suite of APIs that enables platforms to embed financial services into their products. This includes providing connected accounts with the ability to hold funds, pay bills, earn cash back, and manage cash flow through financial accounts.
*   **Stripe Connect**: The foundational infrastructure for managing funds flows and compliance requirements when issuing cards or providing financial services to third parties represented as connected accounts.

### Key Features and Functionality

#### Card Issuance and Management

*   **Card Types**: Supports both physical and virtual cards, with options for customization and immediate issuance of virtual cards.
*   **Card Programs**: Enables the creation of custom card programs, including BIN setup, account ranges, and program management.
*   **Customization**: Offers options for custom card bundles, artwork templates, and branding.
*   **Digital Wallets**: Facilitates adding Issuing cards to digital wallets like Apple Pay and Google Pay through manual or push provisioning.
*   **Replacement Cards**: Provides processes for replacing expired, damaged, lost, or stolen cards.
*   **PIN Management**: Allows cardholders to manage their personal identification numbers for physical cards.

#### Funding and Money Movement

*   **Issuing Balance**: Funds must be added to an Issuing balance to enable card spending. Various funding options are available, including pull-funded top-ups, push-funded top-ups, Stripe balance transfers, and Connect balance transfers.
*   **Post-funding**: Supports post-funding of card spend, allowing platforms to accrue a negative Issuing balance and fund Stripe later. Dynamic Reserves offer real-time credit limit adjustments.
*   **Treasury for Platforms Money Movement**: Enables moving money into and out of financial accounts using InboundTransfers, OutboundPayments, OutboundTransfers, and ReceivedCredits.
*   **Financial Accounts**: Platforms are automatically provisioned with a financial account, and can create financial accounts for eligible connected accounts to store, send, and receive funds.

#### Integration and Development

*   **Integration Guides**: Provides specific guides for various use cases, including Embedded Finance, B2B Payments, and Fleet management.
*   **Sample App**: Offers a sample application to demonstrate how to use Issuing and Treasury for Platforms APIs.
*   **API Access**: Detailed documentation on API endpoints for managing accounts, financial accounts, cards, and money movement.
*   **Webhooks**: Utilizes webhooks to notify applications of events related to Issuing and Treasury for Platforms.
*   **Testing**: Supports testing integrations in a sandbox environment before going live.

#### Controls and Security

*   **Spending Controls**: Allows setting rules on cards and cardholders to control spending by blocking merchant categories, countries, or setting spending limits.
*   **Fraud Management**: Offers advanced fraud tools, including real-time authorization signals, fraud challenges, and the ability to manage transaction fraud.
*   **Real-time Authorizations**: Enables real-time approval or decline of authorization requests via synchronous webhooks.
*   **3D Secure**: Implements an additional layer of authentication for online transactions to combat fraud.
*   **Token Management**: Manages network tokens for secure payments in digital wallets and online storefronts.
*   **Cardholder Controls**: Ensures compliance with legal and regulatory guidelines for screening cardholder information.
*   **Issuing Watchlist**: Automatically screens Issuing users against sanctions lists.

#### Compliance and Guidelines

*   **Onboarding Overview**: Guides users through the process of developing and launching an Issuing or Treasury for Platforms integration.
*   **Compliance Guidelines**: Provides product marketing, design, and compliance guidelines for Issuing and Treasury for Platforms to navigate financial regulations.
*   **Customer Communications**: Outlines requirements for sending regulated customer notices.
*   **Marketing Guidelines**: Offers specific marketing guidelines for Issuing programs in the UK and Europe.
*   **Adverse Action Notices**: Details on reporting credit decisions and managing adverse action notices.
*   **Regulatory Reporting**: Instructions on reporting required regulatory data for credit decisions.

#### Program Management and Support

*   **Program Management Models**: Offers two operating models: Stripe program management and processor-only.
*   **Customer Support**: Provides resources for resolving common Issuing and Treasury for Platforms questions.
*   **Agent Issuing**: Enables issuing programmable cards with built-in controls for agents to complete purchases on behalf of the business.
*   **Credit Consumer Issuing**: A private preview feature for creating, launching, and managing a credit program for consumers.
*   **Credit for Connected Accounts**: Allows platforms to extend credit to connected accounts and manage credit terms.

### Specific Use Cases

*   **B2B Payments**: Guides for building B2B payment integrations using Stripe Issuing.
*   **Embedded Finance**: Guides for building embedded financial services integrations with Issuing and Treasury for Platforms.
*   **Fleet Management**: Guides for building fleet financial services integrations with Stripe Issuing.
*   **Consumer Prepaid Debit Cards**: Instructions on issuing prepaid debit cards for rewards, disbursements, or branded card programs.
*   **Stablecoin-backed Cards**: Enables issuing cards backed by stablecoin balances, integrating with Bridge, Privy, or third-party wallets.
## Managing Credit Terms for Connected Accounts

This section details how to manage credit terms for connected accounts within your Stripe Treasury for platforms integration.

### Updating Credit Limits

You can increase or decrease a connected account's credit limit at any time by updating their `CreditPolicy`'s `credit_limit_amount`.

**Example: Increasing a credit limit from 1,000 USD to 2,000 USD**

```bash
curl https://api.stripe.com/v1/issuing/credit_policy \
  -u "sk_test_RXHltS2OKzISvxWQ7NmRN57i001oa6x7o4:" \
  -H "Stripe-Version: 2026-04-22.dahlia; issuing_credit_beta=v1" \
  -H "Stripe-Account: {{CONNECTED_ACCOUNT_ID}}" \
  -d credit_limit_amount=200000
```

**Example Response:**

```json
{
  "livemode": true,
  "credit_limit_amount": 200000, // 2,000.00 USD
  "credit_limit_currency": "usd",
  "credit_period_interval": "month",
  "credit_period_interval_count": 1,
  "days_until_due": 1,
  "last_effective_attributes": {
    "effective_until": time_of_update_to_credit_limit,
    "credit_limit_amount": 100000,
    "credit_period_interval": "month",
    "credit_period_interval_count": 1
  }
}
```

### Deactivating Credit Spending

You can also deactivate a connected account's ability to spend funds supported by your platform's Issuing account. This is achieved by updating their `CreditPolicy`.
## Stripe Issuing and Treasury for Platforms

This documentation suite provides comprehensive guidance on leveraging Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and integration to advanced features like fraud management, credit offerings, and global expansion.

### Key Areas:

*   **Getting Started:**
    *   **Onboarding Overview:** Understand the steps required to launch your Issuing or Treasury for Platforms integration.
    *   **Integration Guides:** Explore specific guides for B2B payments, Embedded Finance, and Fleet management.
    *   **Sample App:** Utilize the provided sample app to understand how to onboard customers, issue cards, and make outbound payments.
    *   **Sandbox Testing:** Learn how to test your integration in a sandbox environment before going live.

*   **Issuing Cards:**
    *   **Card Types:** Decide between physical and virtual cards for your cardholders.
    *   **Customization:** Customize your card program with unique designs, card bundles, and branding.
    *   **Issuing:** Create and manage cards for your business, employees, or customers.
    *   **Digital Wallets:** Integrate Issuing cards with popular digital wallets like Apple Pay and Google Pay.
    *   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers.

*   **Funding and Money Movement:**
    *   **Issuing Balance:** Learn how to fund your Issuing balance to enable card spend.
    *   **Funding Options:** Explore various methods for adding funds to your card program.
    *   **Treasury for Platforms:** Understand how to set up financial accounts and move money for your connected accounts.
    *   **Connect Funding:** Learn how to fund Issuing balances for connected accounts.
    *   **Post-Funding:** Discover options for post-funding your integration with Stripe and Dynamic Reserves.

*   **Controls and Fraud Management:**
    *   **Spending Controls:** Set rules to manage cardholder spending by blocking categories, countries, or setting limits.
    *   **Lifecycle Controls:** Implement automatic card cancellation based on usage.
    *   **Real-time Authorizations:** Approve or decline authorization requests in real time.
    *   **Advanced Fraud Tools:** Utilize Stripe's tooling to identify and prevent transaction fraud.
    *   **Fraud Challenges:** Implement an additional layer of verification for authorizations.
    *   **3D Secure:** Understand cardholder authentication using 3D Secure for online transactions.
    *   **Manage Fraud:** Learn about transaction fraud and how to combat it.
    *   **Issuing Watchlist:** Understand the process for screening Issuing users against sanctions lists.

*   **Stripe Connect Integration:**
    *   **Issuing and Connect:** Set up an Issuing integration with Stripe Connect to issue cards on behalf of connected accounts.
    *   **Connected Accounts, Cardholders, and Cards:** Learn how to manage these entities within a Connect integration.
    *   **Cardholder Controls:** Understand how cardholder information is screened and managed.
    *   **Inactive Account Management:** Learn how inactivity affects connected accounts' Issuing capabilities.
    *   **Embedded Components:** Embed Issuing card management functionality into your website using prebuilt UI components.

*   **Credit Offerings:**
    *   **Credit Consumer Issuing:** Explore the solution for launching credit programs for your customers.
    *   **Manage Credit Terms:** Configure credit limits and terms for connected accounts.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Available Credit and Flow of Funds:** Understand how available credit changes and how funds flow.
    *   **Reporting:** Learn how to report credit decisions and manage adverse action notices, as well as required regulatory data.

*   **Global Issuing:**
    *   **Global Availability:** Understand how Stripe Issuing works in different countries and explore local and cross-border issuing options.

*   **Customer Support and Compliance:**
    *   **Customer Support:** Find resources for resolving common Issuing and Treasury for Platforms questions.
    *   **Compliance Guidelines:** Adhere to product marketing, design, and compliance guidelines for Issuing and Treasury for Platforms.
    *   **Marketing Guidelines:** Understand specific marketing guidelines for the UK and Europe.
    *   **Regulated Customer Notices:** Learn about sending regulatory notifications to your customers.

*   **Specific Use Cases:**
    *   **B2B Payments:** Integrate Stripe Issuing for business-to-business payments.
    *   **Embedded Finance:** Build embedded financial services integrations.
    *   **Fleet:** Create fleet financial services integrations.
    *   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for users to receive and spend money.
    *   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.
    *   **Stablecoin-Backed Cards:** Issue cards backed by stablecoin balances.

*   **Developer Resources:**
    *   **APIs & SDKs:** Access documentation for the Stripe API and SDKs.
    *   **Webhooks:** Understand webhook events for Issuing and Treasury for Platforms.
    *   **Testing:** Learn how to test your Issuing integration.
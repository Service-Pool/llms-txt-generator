## Stripe Issuing: Card Program Management

This documentation section provides comprehensive guidance on managing Stripe Issuing card programs, from initial setup and card creation to advanced controls and compliance. It caters to platforms looking to issue cards to their users, employees, or contractors, enabling various use cases such as B2B payments, fleet management, and embedded financial services.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing for creating, managing, and distributing payment cards.
*   **How Issuing Works:** Delve into the mechanics of building and scaling a card program, including physical/virtual card issuance, spending management, and real-time transaction approval/denial.
*   **Onboarding Overview:** Learn the essential steps to take your Issuing integration live, including use case approval and obtaining live mode access.
*   **Integration Guides:** Explore specific guides for integrating Issuing into various business models:
    *   **Embedded Finance:** Build embedded financial services using Issuing and Treasury for platforms.
    *   **B2B Payments:** Create cards for business expenses, employee purchases, or contractor payments.
    *   **Fleet:** Develop fleet management solutions with customized fleet cards.
*   **Customer Support:** Access resources for resolving common Issuing and Treasury for platforms questions.

### Card Management and Issuance

*   **Choose Card Offering:** Decide between issuing physical or virtual cards, understanding the tradeoffs and use cases for each.
    *   **Virtual Cards:** Learn about creating and managing virtual cards for immediate use.
    *   **Physical Cards:**
        *   **Overview:** Understand the process of issuing physical cards, from standard options to fully custom designs.
        *   **Choose Card Bundle:** Select standard or custom physical card bundles, including card body options.
        *   **Order a Custom Bundle:** Follow the process for ordering bespoke physical card bundles.
        *   **Customize Card Bundle:** Make selections for your card bundle design.
        *   **Artwork Templates:** Utilize provided templates for card, carrier, and envelope designs.
        *   **Create a Design:** Learn how to create and name your card bundle design.
        *   **Issue Cards:** Create physical cards for cardholders using the Dashboard or API.
        *   **Ship Cards:** Select shipping speeds and methods for card delivery (individual or bulk).
        *   **Address Validation:** Ensure successful physical card delivery through address normalization and validation.
*   **Replacement Cards:** Understand the process for replacing expired, damaged, lost, or stolen cards.
*   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers (PINs).

### Funding and Balances

*   **Fund Your Issuing Balance:** Learn how to make funds available for card spend by adding funds to your Issuing balance.
*   **Add Funds to Your Card Program:** Explore different funding options, including pull-funded top-ups, push-funded top-ups, Stripe balance transfers, and Connect balance transfers.
*   **Issuing Balance:** Understand how the Issuing balance represents reserved funds, separated from other Stripe products.
*   **Post-fund Your Integration:**
    *   **Postfund your integration with Stripe:** Learn to accrue a negative Issuing balance on card spend and post-fund Stripe later.
    *   **Post-fund your integration with Dynamic Reserves:** Utilize dynamic reserves to manage cash between Stripe and authorization availability.

### Controls and Fraud Management

*   **Manage Fraud:** Understand transaction fraud risks and how to combat them using Stripe Issuing controls and tools.
*   **Advanced Fraud Tools:** Leverage API signals and tooling to identify and prevent transaction fraud.
*   **Issuing Authorization Rules:** Limit authorization approvals by configuring custom rules based on various conditions.
*   **Real-time Authorizations:** Approve or decline authorization requests in real-time using synchronous webhooks.
    *   **Migrate to direct webhook response:** Transition from deprecated API calls to direct webhook responses for real-time authorizations.
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations to minimize accidental blocks and verify high-risk transactions.
*   **Spending Controls:** Set rules on cards and cardholders to control spending by blocking categories, countries, merchant IDs, or setting spending limits.
*   **Lifecycle Controls:** Automatically cancel virtual cards after a specified number of payments for single-use or n-use scenarios.
*   **Issuing Watchlist:** Understand the automatic screening process against sanctions lists and manual review procedures.
*   **3D Secure:** Implement cardholder authentication using 3D Secure for online transactions.
*   **Token Management:** Manage network tokens, which are secure virtual representations of cards used in digital wallets and online storefronts.

### Stripe Connect and Treasury for Platforms Integration

*   **Set up an Issuing and Connect Integration:** Learn how to issue cards on connected accounts using Stripe Connect for managing fund flows and compliance.
*   **Connect Funding:** Fund Issuing balances for connected accounts using pull or push funding methods.
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and the cards issued to them.
*   **Cardholder Controls:** Ensure compliance by handling cardholder screening and error responses.
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity impacts Issuing capabilities on connected accounts.
*   **Embed Issuing Card Management:** Use prebuilt UI components to embed card management functionality into your website.
*   **Treasury for Platforms Overview:** Understand how to provide financial services to connected accounts using Treasury for platforms APIs.
*   **Treasury for Platforms Requirements:** Familiarize yourself with compliance requirements and restrictions for Treasury for platforms.
*   **Treasury for Platforms Account Management:**
    *   **Accounts Structure:** Understand the interaction between platform and connected accounts.
    *   **Working with Connected Accounts:** Request capabilities and collect onboarding requirements.
    *   **Working with Financial Accounts:** Learn how to use financial accounts to store, send, and receive funds.
    *   **Financial Account Features:** Explore features available for financial accounts, such as moving money and attaching cards.
    *   **Platform Financial Accounts:** Understand the financial account provisioned for your platform.
*   **Treasury for Platforms Money Movement:**
    *   **Moving Money Into Financial Accounts:** Learn about `InboundTransfer` and `ReceivedCredit` objects.
    *   **Moving Money Out of Financial Accounts:** Explore `OutboundTransfer`, `OutboundPayment`, `ReceivedDebit`, and `DebitReversal` objects.
    *   **Payouts and Top-ups from Payments Balance:** Move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for platforms.
    *   **Money Movement Timelines:** Understand the processing and cutoff times for various money movement types.
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated.
*   **Treasury for Platforms Sample App:** Utilize the provided sample app to onboard users, create cards, and simulate transactions.
*   **Treasury for Platforms Fraud Guide:** Best practices for managing fraud as a platform.
*   **Treasury for Platforms Marketing and Compliance Guidelines:** Ensure your program and marketing campaigns are compliant.

### Specific Use Cases and Features

*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for rewards, disbursements, or branded card programs.
*   **Credit Consumer Issuing:** Create, launch, and manage a credit program for your consumers.
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents to conduct purchases.
*   **Stablecoin-Backed Cards:** Issue cards backed by stablecoin balances, integrating with Bridge, Privy, or third-party wallets.
*   **Issuing Merchant Categories:** Understand Merchant Category Codes (MCCs) for spending controls and data enrichment.
*   **ATM Usage:** Learn how to enable and use US-issued cards for ATM cash withdrawals.
*   **Enriched Merchant Data:** Utilize comprehensive merchant data for improved fraud prevention and spending controls.
*   **Issuing Transactions:** Understand the lifecycle of authorizations and captured transactions.
*   **Issuing Program Management:** Choose between Stripe program management and processor-only models.
*   **Customization:** Customize your card program with BIN setup and account ranges.
*   **Digital Wallets:** Add Issuing cards to digital wallets like Apple Pay and Google Pay.
*   **Processor-Only Issuing:** Integrate a processor-only Issuing model, managing regulatory requirements and compliance.
*   **Global Availability:** Explore options for issuing cards in different countries, including local and cross-border issuing.
*   **Compliance Guidelines:** Adhere to product marketing, design, and compliance guidelines for Issuing and Treasury for platforms.
*   **Customer Communications:** Understand regulated customer notices and how Stripe can assist in sending them.

### Testing and Migration

*   **Test Your Issuing Integration:** Simulate purchases and test your integration in a sandbox environment.
*   **Test Your Credit Integration:** Validate automated platform funding in testing environments.
*   **Issuing Beta Migration Guide:** Learn how to migrate from the Issuing beta to the generally available version.
# Stripe Issuing and Treasury for Platforms Documentation

This documentation group provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and integration to advanced features, fraud management, and compliance.

## Key Areas of Documentation:

*   **Getting Started & Integration:**
    *   [Onboarding overview](/issuing/onboarding-overview): Understand the steps to get your Issuing or Treasury for Platforms integration live.
    *   [Integration guides](/issuing/integration-guides): Access specific guides for Embedded Finance, B2B Payments, and Fleet integrations.
    *   [Set up an Issuing and Connect integration](/issuing/connect): Learn how to issue cards on connected accounts using Stripe Connect.
    *   [Treasury for platforms](/treasury/connect): Discover how to provide financial services to connected accounts.
    *   [Get started with API access to Treasury for platforms](/treasury/connect/access): Learn how to test in a sandbox environment.
    *   [Issuing beta migration guide](/issuing/migration-from-beta): Guidance for migrating from the Issuing beta.

*   **Issuing Cards:**
    *   [Issuing](/issuing): The main entry point for Stripe Issuing, covering card creation, management, and distribution.
    *   [How Issuing works](/issuing/how-issuing-works): Understand the core mechanics of building a card program.
    *   [Choose your card type](/issuing/choose-cards): Decide between physical and virtual cards.
    *   [Virtual cards with Issuing](/issuing/cards/virtual): Details on creating and managing virtual cards.
    *   [Physical cards](/issuing/cards/physical): Information on issuing and managing physical cards.
    *   [Artwork templates](/issuing/cards/artwork-templates): Guidelines for designing custom card artwork.
    *   [Customize your card program](/issuing/customize-your-program): Tailor your card program to your business needs.
    *   [Replacement cards](/issuing/cards/replacements): How to handle expired, damaged, lost, or stolen cards.
    *   [PIN management](/issuing/cards/pin-management): Managing PINs for cardholders.
    *   [Consumer prepaid debit cards](/issuing/consumer-prepaid-debit-cards): Issuing prepaid cards for consumers.
    *   [Credit Consumer Issuing](/issuing/consumer-issuing): Information on launching a credit program for consumers.
    *   [Issuing for agents](/issuing/agents): Issuing programmable cards with built-in controls for agents.
    *   [Stablecoin-backed card issuing](/issuing/stablecoin-cards): Issuing cards backed by stablecoin balances.

*   **Treasury for Platforms:**
    *   [Treasury for platforms](/treasury/connect): The main entry point for Treasury for Platforms, covering financial services for connected accounts.
    *   [How Treasury for platforms works](/treasury/connect/how-financial-accounts-for-platforms-works): Understand connected accounts, financial accounts, and money movement.
    *   [Accounts structure](/treasury/connect/account-management/accounts-structure): Learn about the different account types in Treasury for Platforms.
    *   [Financial account features](/treasury/connect/account-management/financial-account-features): Explore the capabilities of financial accounts.
    *   [Working with financial accounts](/treasury/connect/account-management/financial-accounts): How to use financial accounts to store, send, and receive funds.
    *   [Moving money](/treasury/connect/moving-money): Comprehensive guides on money movement within Treasury for Platforms.
    *   [Sample application with Issuing and Treasury for platforms](/treasury/connect/examples/sample-app): A sample app to start your integration.

*   **Funding and Balances:**
    *   [Fund your Issuing balance](/issuing/funding/balance): Learn how to make funds available for your cards.
    *   [Add funds to your card program](/issuing/adding-funds-to-your-card-program): Options for funding your Issuing balance.
    *   [Postfund your integration with Stripe](/issuing/funding/post-fund): Learn how to post-fund Stripe for card spend.
    *   [Post-fund your integration with Dynamic Reserves](/issuing/funding/post-fund-with-dynamic-reserves): Using dynamic reserves for post-funding.
    *   [Connect funding](/issuing/connect/funding): How to fund Issuing balances with Connect.

*   **Controls and Fraud Management:**
    *   [Manage fraud with Stripe Issuing controls and tools](/issuing/manage-fraud): Understand and combat transaction fraud.
    *   [Advanced fraud tools](/issuing/controls/advanced-fraud-tools): Reduce fraud with Issuing's advanced tooling.
    *   [Issuing authorization rules](/issuing/controls/authorization-rules): Limit authorization approvals using custom rules.
    *   [Real-time authorizations](/issuing/controls/real-time-authorizations): Approve or decline authorization requests in real time.
    *   [Fraud challenges](/issuing/controls/fraud-challenges): Additional verification for authorizations.
    *   [Issuing spending controls](/issuing/controls/spending-controls): Set rules on cards and cardholders to control spending.
    *   [Issuing lifecycle controls](/issuing/controls/lifecycle-controls): Control automatic usage-based cancellation of cards.
    *   [Token management](/issuing/controls/token-management): Manage network tokens on your cards.

*   **Connect Integrations:**
    *   [Set up an Issuing and Connect integration](/issuing/connect): Foundational infrastructure for managing funds flows and compliance.
    *   [Connected accounts, cardholders, and cards](/issuing/connect/cardholders-and-cards): Create and manage cardholders and cards with Stripe Connect.
    *   [Cardholder controls](/issuing/connect/cardholders-controls): How cardholder controls affect your integration.
    *   [Inactive connected accounts offboarding](/issuing/connect/inactive-accounts-management): How inactivity affects connected accounts.
    *   [Embed Issuing card management into your website](/issuing/connect/embedded-components): Use prebuilt UI components for card management.

*   **Purchases and Transactions:**
    *   [Issuing authorizations](/issuing/purchases/authorizations): Handle authorization requests for card purchases.
    *   [Issuing transactions](/issuing/purchases/transactions): Understand how transactions are created after authorization.
    *   [Issuing disputes](/issuing/purchases/disputes): Learn how to dispute transactions.
    *   [Use cards at automated teller machines (ATMs)](/issuing/purchases/atm-usage): How to use Issuing cards for ATM withdrawals.
    *   [Enriched merchant data](/issuing/purchases/enriched-merchant-data): Use comprehensive merchant data for fraud prevention.

*   **Compliance and Guidelines:**
    *   [Issuing and Treasury product marketing, design, and compliance guidelines](/issuing/compliance-us): Guidelines for launching compliant Issuing and Treasury programs.
    *   [Stripe Issuing marketing guidelines](/issuing/marketing-guidance-europe-uk): Marketing guidelines for Issuing programs in the UK and Europe.
    *   [Treasury for platforms product marketing, design, and compliance guidelines](/treasury/connect/compliance): Keep your Treasury for Platforms program and marketing compliant.
    *   [Issuing regulated customer notices](/issuing/issuing-compliance-us/issuing-regulated-customer-notices): Sending regulatory notifications to customers.

*   **Testing and Support:**
    *   [Test your Issuing integration](/issuing/testing): Simulate purchases and test your integration in a sandbox.
    *   [Test your integration](/treasury/credit/test-credit): Validate automated platform funding in testing environments.
    *   [Customer support for Issuing and Treasury for platforms](/issuing/customer-support): Resolve common Issuing and Treasury questions.

This documentation set aims to provide a clear and comprehensive resource for developers and businesses looking to leverage Stripe's Issuing and Treasury for Platforms solutions.
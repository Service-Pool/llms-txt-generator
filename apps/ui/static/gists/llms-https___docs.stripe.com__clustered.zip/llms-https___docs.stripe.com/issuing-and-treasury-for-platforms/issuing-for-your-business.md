## Stripe Issuing: Card Issuance and Management

This documentation group provides comprehensive guidance on utilizing Stripe Issuing to create, manage, and distribute payment cards for your business or for your customers. It covers everything from initial setup and integration to advanced features like fraud management and credit programs.

### Key Areas:

*   **Getting Started with Issuing:**
    *   **Issuing Overview:** Understand the core functionalities and benefits of Stripe Issuing.
    *   **How Issuing Works:** A detailed explanation of the Issuing lifecycle and its integration with Stripe Treasury.
    *   **Onboarding Overview:** Steps to prepare for and launch your Issuing integration.
    *   **Issuing for your business:** Guidance on issuing cards for internal business use.
    *   **Issuing for agents:** Enabling agents with programmable cards for transactions.
    *   **Issuing beta migration guide:** Instructions for migrating from the beta version of Issuing.
    *   **Customer support for Issuing and Treasury for platforms:** Resources for resolving common issues.
    *   **Issuing watchlist:** Understanding how Stripe screens users against sanctions lists.
    *   **Product marketing, design, and compliance guidelines (US & Europe/UK):** Essential information for compliant marketing and user interface design.

*   **Card Types and Customization:**
    *   **Choose your card type:** Decide between physical and virtual cards.
    *   **Virtual cards:** Learn how to create and manage virtual cards.
    *   **Physical cards:** Details on issuing and managing physical cards.
    *   **Artwork templates:** Guidelines for designing custom card artwork.
    *   **Customize your card program:** Tailor your card program to specific business needs.
    *   **Choose card bundle:** Options for standard and custom physical card bundles.
    *   **Order a custom bundle:** Process for ordering uniquely designed physical card bundles.
    *   **Create a design:** Steps to create and name your card designs.
    *   **Issue cards:** How to create and issue physical cards.
    *   **Ship cards:** Options for card shipping, including individual and bulk.
    *   **Address validation:** Ensuring accurate delivery of physical cards.
    *   **PIN management:** Enabling cardholders to manage their PINs.

*   **Integration and Development:**
    *   **Integration guides:** A central hub for various integration scenarios.
        *   **Embedded Finance:** Building embedded financial services.
        *   **B2B payments:** Integrating Issuing for business-to-business payments.
        *   **Fleet:** Creating fleet management card programs.
    *   **Sample app:** A practical example to help you get started with Issuing and Treasury for platforms.
    *   **Using Issuing Elements:** Displaying card details securely in your web application.
    *   **Processor-only Issuing:** Integrating Issuing where you manage more of the program.
    *   **Set up an Issuing and Connect integration:** Issuing cards for third-party users via Stripe Connect.
    *   **Test your Issuing integration:** Simulating purchases and testing your integration in a sandbox.
    *   **Migrate to direct webhook response:** Updating real-time authorization handling.

*   **Funding and Financial Management:**
    *   **Fund your Issuing balance:** Making funds available for card spend.
    *   **Add funds to your card program:** Options for funding your Issuing balance.
    *   **Issuing balance:** Understanding the balance reserved for Issuing.
    *   **Postfund your integration with Stripe:** Funding your Issuing balance after card spend.
    *   **Post-fund your integration with Dynamic Reserves:** Managing cash flow with dynamic reserves.

*   **Controls and Fraud Management:**
    *   **Manage fraud:** Strategies and tools to combat transaction fraud.
    *   **Spending controls:** Setting rules to manage cardholder spending.
    *   **Lifecycle controls:** Automating card cancellation based on usage.
    *   **Advanced fraud tools:** Utilizing API signals and tooling to prevent fraud.
    *   **Issuing authorization rules:** Limiting authorization approvals with custom rules.
    *   **Real-time authorizations:** Approving or declining authorization requests in real-time.
    *   **Fraud challenges:** Implementing additional verification steps for high-risk transactions.
    *   **3D Secure:** Cardholder authentication for online transactions.
    *   **Token management:** Managing network tokens for secure payments.

*   **Issuing with Stripe Connect:**
    *   **Set up an Issuing and Connect integration:** Integrating Issuing with Stripe Connect.
    *   **Connected accounts, cardholders, and cards:** Managing these entities within a Connect integration.
    *   **Cardholder controls:** Handling cardholder screening and validation.
    *   **Embed Issuing card management into your website:** Using Connect embedded components.
    *   **Inactive connected accounts offboarding:** Managing Issuing capabilities for inactive accounts.
    *   **Fund Issuing balances with Connect:** Allocating funds to connected accounts' Issuing balances.
    *   **Update the Issuing terms of service acceptance:** Presenting business information and accepting terms.

*   **Credit Programs:**
    *   **Issuing Credit:** Overview of credit solutions for Issuing.
    *   **Credit Consumer Issuing:** Launching credit programs for your consumers.
    *   **How Credit Consumer Issuing works:** Features and APIs for credit programs.
    *   **Manage credit terms:** Configuring credit limits and intervals for connected accounts.
    *   **Manage account obligations:** Tracking credit spend and balances for connected accounts.
    *   **Available credit and flow of funds:** Understanding how credit impacts available funds.
    *   **Obligation payments:** Collecting repayments from connected accounts.
    *   **Obligation amounts, transactions, and adjustments:** Viewing and adjusting FundingObligation details.
    *   **Report other credit decisions and manage adverse action notices:** Recording credit decisions and sending AANs.
    *   **Report required regulatory data for credit decisions:** Complying with regulatory reporting.
    *   **Test credit integration:** Validating your credit integration in sandbox environments.

*   **Stripe Treasury for Platforms:**
    *   **Treasury for platforms:** Overview of providing financial services to connected accounts.
    *   **How Treasury for platforms works:** Understanding connected accounts, financial accounts, and money movement.
    *   **Get started with API access to Treasury for platforms:** Setting up API access and sandbox environments.
    *   **Accounts structure:** Understanding the account components of Treasury for platforms.
    *   **Financial account features:** Features available for financial accounts.
    *   **Working with Stripe Issuing cards:** Integrating Issuing with Treasury for platforms.
    *   **Platform financial accounts:** Details on the financial account for your platform.
    *   **Working with balances and transactions:** Managing financial account balances and transactions.
    *   **Working with connected accounts:** Requesting capabilities and collecting onboarding requirements.
    *   **Working with financial accounts:** Provisioning and managing financial accounts.
    *   **Treasury for platforms fraud guide:** Best practices for managing fraud.
    *   **Treasury for platforms connected account onboarding guide:** Implementing an onboarding process.
    *   **Marketing Treasury for platforms:** Creating compliant messaging for your users.
    *   **Handling complaints:** Properly addressing complaints related to Treasury for platforms or Issuing.
    *   **Regulatory receipts:** Understanding hosted transaction receipts.
    *   **Moving money:** Comprehensive guides on money movement within Treasury for platforms.
        *   **Moving money into financial accounts:** Using InboundTransfer and ReceivedCredit.
        *   **Moving money out of Treasury for platforms:** Using OutboundTransfer, OutboundPayment, ReceivedDebit, and DebitReversal.
        *   **Money movement timelines:** Understanding processing and cutoff times.
    *   **Sample integrations:**
        *   **Use Treasury for platforms and Issuing to set up financial accounts and cards:** A sample integration walkthrough.
        *   **Using Treasury for platforms to move money:** An example of basic money movement.
        *   **Issuing and Treasury for platforms sample app:** A Next.js sample app for integration.
        *   **Webhooks for Stripe Issuing and Treasury for platforms:** Understanding webhook events.
    *   **Bank partners:** Information on integrating with banking partners like Fifth Third Bank.

*   **Purchases and Transactions:**
    *   **Issuing authorizations:** Handling authorization requests.
    *   **Issuing transactions:** Understanding the lifecycle of authorizations after capture.
    *   **Issuing disputes:** Submitting and managing transaction disputes.
    *   **Enriched merchant data:** Using detailed merchant information for fraud prevention.
    *   **Use cards at automated teller machines (ATMs):** Enabling and using cards for ATM withdrawals.

*   **Specialized Card Types:**
    *   **Consumer prepaid debit cards:** Issuing prepaid debit cards for user disbursements or rewards.
    *   **Stablecoin-backed cards:** Issuing cards backed by stablecoin balances.
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts:** Issuing cards for connected accounts backed by stablecoins.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrating with Bridge for stablecoin card programs.
## Reporting Regulatory Data for Credit Decisions

This section details how to report required regulatory data for credit decisions when your platform is subject to additional reporting requirements for credit programs.

### Overview

Certain platforms utilizing the `CreditUnderwritingRecord` API are mandated by regulators to provide additional reporting data for credit programs. If your platform falls under this requirement, you must upload a file containing the necessary regulatory reporting data to Stripe's Files API. Subsequently, you will include the ID of this uploaded file in your request to report a credit decision to the `CreditUnderwritingRecord` API.

This regulatory reporting data is a mandatory requirement at the following endpoints:

*   **Application-based credit decisions:** When reporting credit decisions derived from customer applications.
*   **Proactive credit decisions:** When making credit decisions proactively without a customer application.
*   **Corrections to existing credit decisions (Optional):** If you need to correct previously reported data.

### Uploading Regulatory Data to the Files API

The Files API allows you to upload files that can then be associated with various Stripe objects. To report regulatory data, you will first upload your file to the Files API.

**Steps to upload a file:**

1.  **Prepare your file:** Ensure your file contains the required regulatory data in a format compatible with Stripe's specifications. Refer to Stripe's documentation for specific file format requirements.
2.  **Make a POST request to the Files API:**
    *   **Endpoint:** `https://files.stripe.com/v1/files`
    *   **Parameters:**
        *   `purpose`: Set this to `credit_underwriting_regulatory_report`.
        *   `file`: The file containing the regulatory data.

**Example using `curl`:**

```bash
curl https://files.stripe.com/v1/files \
  -u "sk_test_YOUR_SECRET_KEY:" \
  -F purpose="credit_underwriting_regulatory_report" \
  -F file=@/path/to/your/regulatory_report.csv
```

**Response:**

Upon successful upload, Stripe will return a File object, which includes a unique `id` for the uploaded file. This `id` is crucial for the next step.

### Reporting a Credit Decision with Regulatory Data

Once you have successfully uploaded your regulatory data file, you can report a credit decision that includes this data.

**Endpoint:** `POST /v1/credit_underwriting_records`

When making the API call to report a credit decision, include the `regulatory_reporting_file` parameter with the ID of the file you uploaded via the Files API.

**Example:**

```bash
curl https://api.stripe.com/v1/credit_underwriting_records \
  -u "sk_test_YOUR_SECRET_KEY:" \
  -d "customer='cus_abc123'" \
  -d "decision='approved'" \
  -d "regulatory_reporting_file='file_abc123'"
```

By following these steps, you can ensure that your credit decisions comply with regulatory reporting requirements.
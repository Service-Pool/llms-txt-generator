## Stripe Issuing: Card Program Management and Transactions

This documentation group provides comprehensive guidance on utilizing Stripe Issuing to create, manage, and distribute payment cards for businesses and their users. It covers the entire lifecycle of card programs, from initial setup and funding to transaction processing, fraud management, and advanced controls.

### Core Concepts and Setup

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing, including creating custom card designs, real-time transaction approval, and integration with Stripe Treasury for enhanced money movement options.
*   **How Issuing Works:** Delve into the mechanics of Stripe Issuing, explaining how to build and scale card programs, partner with banks and card networks, and manage regional considerations for global reach.
*   **Onboarding Overview:** Learn the essential steps and requirements for launching an Issuing integration, including use case approval, obtaining live mode access, and testing with real funds.
*   **Integration Guides:** Access specific guides for integrating Issuing into various use cases, such as B2B Payments, Embedded Finance, and Fleet management.
*   **Sample App:** Utilize the provided sample app to explore how Issuing and Treasury for platforms APIs can be integrated into your application, allowing for onboarding, card creation, and transaction testing.
*   **Customer Support:** Find information on resolving common Issuing and Treasury for platforms questions and issues.

### Card Program Management

*   **Choose Card Type:** Decide between physical and virtual cards, understanding the use cases and trade-offs for each.
*   **Add Funds to Card Program:** Learn about various funding options, including pull-funded top-ups, push-funded top-ups, and Stripe balance transfers, to make funds available for card spend.
*   **Issuing Balance:** Understand how the Issuing balance represents reserved funds for card programs, separate from other Stripe balances.
*   **Program Management:** Explore the different operating models for Issuing: Stripe program management and processor-only, each with unique advantages and responsibilities.
*   **Customize Your Card Program:** Discover how to tailor your card program to specific business needs, including BIN setup and account ranges.
*   **Physical Cards:** Get detailed information on issuing physical cards, including standard and custom options, design templates, and shipping.
    *   **Choose Card Bundle:** Select standard or custom physical card bundles, including card, carrier, and envelope.
    *   **Order a Custom Bundle:** Understand the process and timeline for ordering custom physical card bundles.
    *   **Create a Design:** Learn how to create and name your card bundle designs using standard or custom options.
    *   **Issue Cards:** Issue physical cards to cardholders via the Dashboard or API.
    *   **Ship Cards:** Choose between individual and bulk shipping options for your cards.
    *   **Address Validation:** Ensure successful delivery of physical cards with built-in address normalization and validation.
*   **Virtual Cards:** Learn how to create and display virtual card details in a PCI-compliant manner.
    *   **Issue Virtual Cards:** Create virtual cards for cardholders using the Dashboard or Cardholders API.
*   **Replacement Cards:** Understand the process for replacing expired, damaged, lost, or stolen cards.
*   **PIN Management:** Allow cardholders to manage their personal identification numbers (PINs) for physical and virtual cards.
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay using manual or push provisioning.
*   **Token Management:** Learn how to manage network tokens for cards, which are virtual representations used for secure payments.

### Transaction Processing and Controls

*   **Issuing Authorizations:** Understand how authorization requests are handled, including real-time approval or decline decisions via webhooks.
*   **Issuing Transactions:** Learn how authorization requests become closed Transaction objects after capture.
*   **Issuing Disputes:** Discover how to initiate and manage disputes for transactions through the Dashboard or API.
*   **Issuing Spending Controls:** Set rules and limits on cards and cardholders to control spending by merchant category, country, merchant ID, or spending limits.
*   **Issuing Lifecycle Controls:** Automatically cancel virtual cards after a specified number of payments for single-use or n-use scenarios.
*   **Real-time Authorizations:** Implement real-time authorization decisions by responding directly to `issuing_authorization.request` webhook events.
*   **Migrate to Direct Webhook Response:** Learn how to migrate from deprecated API calls to direct webhook responses for real-time authorizations.
*   **Issuing Authorization Rules:** Prevent unauthorized activity by blocking authorizations that match custom conditions.
*   **Fraud Challenges:** Enable an additional layer of verification for high-risk authorizations to minimize accidental blocks.
*   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud while minimizing impact on legitimate transactions.
*   **Manage Fraud:** Understand transaction fraud risks, liabilities, and how to monitor and prevent fraud using Stripe's resources.
*   **Issuing Merchant Categories:** Learn about Merchant Category Codes (MCCs) and how they are used for spending controls.
*   **ATM Usage:** Enable and use US-issued cards for ATM cash withdrawals.
*   **Enriched Merchant Data:** Leverage comprehensive merchant data to understand spending patterns and improve fraud prevention.

### Stripe Connect and Treasury for Platforms Integration

*   **Set up an Issuing and Connect Integration:** Learn how to issue cards on connected accounts using Stripe Connect for managing fund flows and compliance.
*   **Connect Funding:** Understand how to fund Issuing balances for connected accounts using pull or push funding methods.
*   **Connected Accounts, Cardholders, and Cards:** Differentiate between connected accounts (business entities) and cardholders (individuals) and how to create and manage them.
*   **Cardholder Controls:** Ensure compliance with legal and regulatory guidelines by managing cardholder information and handling specific error types.
*   **Inactive Connected Accounts Offboarding:** Understand how inactivity impacts Issuing capabilities on connected accounts and how Stripe disables them.
*   **Embed Issuing Card Management:** Use Connect embedded components to integrate Issuing card management functionality into your website.
*   **Treasury for Platforms Overview:** Learn how to provide financial services to connected accounts by embedding financial services into your product.
*   **Treasury for Platforms Requirements:** Understand the compliance requirements and restrictions for using Treasury for platforms.
*   **Accounts Structure:** Learn how platform and connected accounts interact within the Treasury for platforms framework.
*   **Working with Connected Accounts:** Request the treasury capability and collect onboarding requirements for your connected accounts.
*   **Working with Financial Accounts:** Understand how financial accounts store, send, and receive funds, separate from the main account balance.
*   **Financial Account Features:** Discover features available for financial accounts, such as moving money and attaching payment cards.
*   **Platform Financial Accounts:** Learn about the automatically provisioned financial account for your platform.
*   **Working with Balances and Transactions:** Understand financial account balances and how transactions affect them.
*   **Moving Money:** Explore various methods for moving money within Treasury for platforms, including inbound transfers, outbound payments, and payouts.
    *   **Moving Money into Financial Accounts:** Learn about using `InboundTransfer` and `ReceivedCredit` objects.
    *   **Moving Money Out of Treasury for Platforms:** Discover methods like `OutboundTransfer`, `OutboundPayment`, and card transactions.
    *   **Money Movement Timelines:** Understand the processing and cutoff times for various money movement methods.
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated via Notifications of Change (NOCs).
    *   **Payouts and Top-ups from Payments Balance:** Move money between payments account balances and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for platforms.
*   **Sample App:** Use the provided sample app to explore Issuing and Treasury for platforms integration, including onboarding, card creation, and money movement simulations.
*   **Webhooks:** Understand webhook events for Stripe Issuing and Treasury for platforms to handle asynchronous events.
*   **Marketing and Compliance Guidelines:** Adhere to guidelines for marketing and promoting Treasury for platforms and Issuing products to ensure compliance with financial regulations.
    *   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US):** Navigate financial regulations for product branding and offering financial services.
    *   **Issuing Regulated Customer Notices:** Learn about sending regulatory notifications to customers.
    *   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines:** Ensure your Treasury for platforms program and marketing campaigns are compliant.
    *   **Handling Complaints:** Properly handle complaints related to Treasury for platforms or Stripe Issuing.
    *   **Marketing Treasury for Platforms:** Create precise and compliant messaging for your users.
    *   **Regulatory Receipts:** Learn about hosted transaction receipts for regulated money movements.
*   **Credit Consumer Issuing:** Explore the private preview of Stripe's consumer credit solution for launching credit programs.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Available Credit and Flow of Funds:** Understand how funds flow and use the available credit amount to prevent declines.
    *   **Manage Credit Terms:** Configure credit limits and terms for connected accounts.
    *   **Obligation Payments:** Make payments to your FundingObligation.
    *   **Obligation Amounts, Transactions, and Adjustments:** View FundingObligation details and make adjustments.
    *   **Report Other Credit Decisions and Manage Adverse Action Notices:** Record application and decision details and send adverse action notices.
    *   **Report Required Regulatory Data for Credit Decisions:** Report regulatory data for credit programs.
    *   **Test Credit Integration:** Validate your automated platform funding in testing environments.
*   **Issuing for your business:** Learn how to programmatically create virtual cards for your business, employees, or contractors.
*   **Issuing Watchlist:** Understand the process of automatic screening against sanctions lists and manual review for Issuing users.
*   **Issuing Marketing Guidelines (Europe/UK):** Adhere to marketing guidelines for Issuing programs in the UK and Europe.
*   **Stablecoin-backed Cards:** Issue prepaid or debit cards backed by stablecoin balances in partnership with Bridge.
    *   **Stablecoin-backed Cards for Stripe Stablecoin Financial Accounts:** Issue cards backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed Cards for Bridge, Privy, or Third-Party Wallets:** Integrate Stripe Issuing with Bridge for stablecoin-backed card programs.
*   **Issuing for Agents:** Provide agents with programmable cards and built-in controls for autonomous discovery and sourcing.
*   **Test Your Issuing Integration:** Simulate purchases and test your integration in a sandbox environment without making real purchases.
*   **Credit Issuing:** Apply your platform Issuing account balance or exposure limit to cards issued to connected accounts.

This documentation group offers a comprehensive resource for developers and businesses looking to leverage Stripe Issuing and Treasury for Platforms to build sophisticated card programs and financial services.
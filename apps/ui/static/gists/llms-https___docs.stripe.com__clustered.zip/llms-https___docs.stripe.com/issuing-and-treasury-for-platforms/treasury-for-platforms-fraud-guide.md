# Stripe Issuing and Treasury for Platforms Documentation

This documentation suite provides comprehensive guidance on utilizing Stripe Issuing and Treasury for Platforms. It covers everything from initial setup and integration to advanced features like fraud management, custom card programs, and money movement.

## Core Concepts and Getting Started

*   **Issuing Overview** (`/issuing`): An introduction to Stripe Issuing, enabling you to create, manage, and distribute payment cards for your business.
*   **How Issuing Works** (`/issuing/how-issuing-works`): Explains the fundamental mechanics of building a card program with Stripe Issuing, including partnerships with banks and card networks.
*   **Onboarding Overview** (`/issuing/onboarding-overview`): Details the steps required to take your Issuing integration live, including use case approval and live mode access.
*   **Integration Guides** (`/issuing/integration-guides`): A central hub for various integration scenarios, including:
    *   **Embedded Finance** (`/issuing/integration-guides/embedded-finance`): Building embedded financial services.
    *   **B2B Payments** (`/issuing/integration-guides/b2b-payments`): Creating cards for business purchases.
    *   **Fleet** (`/issuing/integration-guides/fleet`): Building fleet financial services integrations.
*   **Issuing and Treasury for Platforms Sample App** (`/issuing/sample-app`, `/treasury/connect/examples/sample-app`): A practical resource to understand how to use Issuing and Treasury for Platforms APIs, allowing you to onboard customers, create cards, and test payments.
*   **Test Your Issuing Integration** (`/issuing/testing`): Guidance on testing your Issuing integration in a sandbox environment.
*   **Customer Support for Issuing and Treasury for Platforms** (`/issuing/customer-support`): Resources for resolving common Issuing and Treasury for Platforms questions.
*   **Issuing Beta Migration Guide** (`/issuing/migration-from-beta`): Information for users migrating from the Issuing beta.
*   **Issuing for your business** (`/issuing/direct`): How to issue cards programmatically for your business needs.

## Card Management and Customization

*   **Choose Your Card Type** (`/issuing/choose-cards`): Deciding between physical and virtual cards for your cardholders.
*   **Virtual Cards with Issuing** (`/issuing/cards/virtual`): Details on creating and displaying virtual card details.
    *   **Create Virtual Cards** (`/issuing/cards/virtual/issue-cards`): Step-by-step guide to issuing virtual cards.
*   **Physical Cards** (`/issuing/cards/physical`): Information on issuing physical cards.
    *   **Choose Card Bundle** (`/issuing/cards/physical/card-bundle-selections`, `/issuing/cards/physical/choose-bundle`): Selecting standard or custom physical card bundles.
    *   **Order a Custom Bundle** (`/issuing/cards/physical/order-custom-bundle`): Process for ordering custom physical card bundles.
    *   **Create a Design** (`/issuing/cards/physical/create-design`): Designing your physical cards.
    *   **Issue Cards** (`/issuing/cards/physical/issue-cards`): Creating physical cards for cardholders.
    *   **Ship Cards** (`/issuing/cards/physical/ship-cards`): Options for shipping physical cards.
    *   **Address Validation** (`/issuing/cards/physical/address-validation`): Ensuring accurate addresses for physical card delivery.
*   **Artwork Templates** (`/issuing/cards/artwork-templates`): Design templates for card customization.
*   **Replacement Cards** (`/issuing/cards/replacements`): How to replace expired, damaged, lost, or stolen cards.
*   **PIN Management** (`/issuing/cards/pin-management`): Allowing cardholders to manage their PINs.
*   **Use Digital Wallets with Issuing** (`/issuing/cards/digital-wallets`): Integrating Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **Customize Your Card Program** (`/issuing/customize-your-program`): Tailoring your Stripe Issuing card program to business needs.
*   **Program Management** (`/issuing/program-management`): Choosing between Stripe program management and processor-only models.

## Funding and Money Movement

*   **Fund Your Issuing Balance** (`/issuing/funding/balance`): Making funds available for card spend.
*   **Add Funds to Your Card Program** (`/issuing/adding-funds-to-your-card-program`): Options for funding your Issuing balance.
*   **Postfund your integration with Stripe** (`/issuing/funding/post-fund`): Accruing a negative Issuing balance and funding Stripe later.
*   **Post-fund your integration with Dynamic Reserves** (`/issuing/funding/post-fund-with-dynamic-reserves`): Using dynamic reserves to post-fund card spend.

## Treasury for Platforms

*   **Treasury for Platforms Overview** (`/treasury/connect`): An introduction to providing financial services to connected accounts.
*   **How Treasury for Platforms Works** (`/treasury/connect/how-financial-accounts-for-platforms-works`): Understanding connected accounts, financial accounts, and money movement.
*   **Eligibility Requirements** (`/treasury/connect/requirements`): Understanding the requirements for using Treasury for Platforms.
*   **Get Started with API Access** (`/treasury/connect/access`): Setting up API access for Treasury for Platforms.
*   **Onboarding Users** (`/treasury/connect/examples/onboarding-guide`): Guide to onboarding connected accounts for Treasury for Platforms.
*   **Account Management**
    *   **Accounts Structure** (`/treasury/connect/account-management/accounts-structure`): How account components interact.
    *   **Working with Connected Accounts** (`/treasury/connect/account-management/connected-accounts`): Managing connected accounts for Treasury for Platforms.
    *   **Working with Financial Accounts** (`/treasury/connect/account-management/financial-accounts`): Using financial accounts to store, send, and receive funds.
    *   **Financial Account Features** (`/treasury/connect/account-management/financial-account-features`): Features available for financial accounts.
    *   **Platform Financial Accounts** (`/treasury/connect/account-management/platform-financial-account`): Understanding the financial account for your platform.
*   **Moving Money**
    *   **Working with Balances and Transactions** (`/treasury/connect/account-management/working-with-balances-and-transactions`): Understanding financial account balances and transactions.
    *   **Moving Money Into Financial Accounts** (`/treasury/connect/moving-money/moving-money-into-financial-accounts`): Requests to move money into financial accounts.
        *   **Moving money using InboundTransfer objects** (`/treasury/connect/moving-money/into/inbound-transfers`): Transferring money from external accounts.
        *   **Moving money using ReceivedCredit objects** (`/treasury/connect/moving-money/into/received-credits`): Receiving funds into financial accounts.
        *   **Moving money using CreditReversal objects** (`/treasury/connect/moving-money/into/credit-reversals`): Reversing received credits.
    *   **Moving Money Out of Treasury for Platforms** (`/treasury/connect/moving-money/moving-money-out`): Methods to move funds from financial accounts.
        *   **Moving money using OutboundTransfer objects** (`/treasury/connect/moving-money/out-of/outbound-transfers`): Transferring money to external accounts.
        *   **Moving money using OutboundPayment objects** (`/treasury/connect/moving-money/out-of/outbound-payments`): Creating outbound payments to third parties.
        *   **Moving money using ReceivedDebit objects** (`/treasury/connect/moving-money/out-of/received-debits`): Handling funds pulled from financial accounts.
        *   **Moving money using DebitReversal objects** (`/treasury/connect/moving-money/out-of/debit-reversals`): Retrieving funds from received debits.
    *   **Payouts and Top-ups from Payments Balance** (`/treasury/connect/moving-money/payouts`): Moving money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts** (`/treasury/connect/moving-money/working-with-bankaccount-objects`): Setting up money movements.
    *   **ACH NOC and SEC Handling** (`/treasury/connect/moving-money/noc-sec-handling`): Handling external account information updates.
    *   **Money Movement Timelines** (`/treasury/connect/money-movement/timelines`): Timelines for various money movement types.
*   **Integrate with Fifth Third Bank** (`/treasury/connect/fifth-third`, `/treasury/connect/fifth-third-get-started`): Integrating with Fifth Third Bank for Treasury for Platforms.

## Issuing with Connect

*   **Set up an Issuing and Connect Integration** (`/issuing/connect`): Issuing cards on connected accounts.
*   **Connect Funding** (`/issuing/connect/funding`): Funding Issuing balances with Connect.
*   **Connected Accounts, Cardholders, and Cards** (`/issuing/connect/cardholders-and-cards`): Creating and managing cardholders and cards with Stripe Connect.
*   **Cardholder Controls** (`/issuing/connect/cardholders-controls`): How cardholder controls affect your integration.
*   **Inactive Connected Accounts Offboarding** (`/issuing/connect/inactive-accounts-management`): How inactivity affects connected accounts.
*   **Embed Issuing Card Management into Your Website** (`/issuing/connect/embedded-components`): Using prebuilt UI components for card management.
*   **Update Issuing Terms of Service Acceptance** (`/issuing/connect/tos_acceptance`): Presenting business information and accepting terms.

## Controls and Fraud Management

*   **Manage Fraud** (`/issuing/manage-fraud`): Understanding and combating transaction fraud.
*   **Advanced Fraud Tools** (`/issuing/controls/advanced-fraud-tools`): Identifying and preventing transaction fraud with API signals.
*   **Issuing Authorization Rules** (`/issuing/controls/authorization-rules`): Limiting authorization approvals with custom rules.
*   **Real-time Authorizations** (`/issuing/controls/real-time-authorizations`): Approving or declining authorization requests in real time.
    *   **Migrate to Direct Webhook Response** (`/issuing/controls/real-time-authorizations/direct-webhook-migration`): Migrating to direct webhook responses for authorizations.
    *   **Quickstart** (`/issuing/controls/real-time-authorizations/quickstart`): Setting up and managing real-time authorizations.
*   **Fraud Challenges** (`/issuing/controls/fraud-challenges`): Additional verification for authorizations.
*   **Issuing Lifecycle Controls** (`/issuing/controls/lifecycle-controls`): Controlling automatic usage-based cancellation of cards.
*   **Issuing Spending Controls** (`/issuing/controls/spending-controls`): Setting rules for card and cardholder spending.
*   **Token Management** (`/issuing/controls/token-management`): Managing network tokens on your cards.
*   **3D Secure** (`/issuing/3d-secure`): Cardholder authentication for online transactions.

## Specific Use Cases and Features

*   **Consumer Prepaid Debit Cards** (`/issuing/consumer-prepaid-debit-cards`): Issuing prepaid debit cards to users.
*   **Credit Consumer Issuing** (`/issuing/credit/`, `/issuing/credit/manage-account-obligations/`, `/issuing/credit/manage-credit-terms/`, `/issuing/credit/manage-account-obligations/obligation-payments/`, `/issuing/credit/manage-account-obligations/obligations-transactions-adjustments/`, `/issuing/credit/report-credit-decisions-and-manage-aans/`, `/issuing/credit/report-required-regulatory-data-for-credit-decisions/`, `/issuing/credit/test-credit/`, `/issuing/credit/set-up-credit-for-connected-accounts/`, `/issuing/credit/available-credit-and-flow-of-funds/`): Solutions for launching credit programs for consumers.
*   **B2B Payments** (`/issuing/integration-guides/b2b-payments`): Building B2B payment integrations.
*   **Fleet** (`/issuing/integration-guides/fleet`): Building fleet financial services integrations.
*   **Embedded Finance** (`/issuing/integration-guides/embedded-finance`): Building embedded financial services integrations.
*   **Issuing for Agents** (`/issuing/agents`): Issuing programmable cards with built-in controls for agents.
*   **Stablecoin-backed Cards** (`/issuing/stablecoin-cards-for-financial-accounts`, `/issuing/bridge-stablecoin-cards`, `/issuing/stablecoin-cards`): Issuing cards backed by stablecoin balances.
*   **Issuing Merchant Categories** (`/issuing/categories`): Understanding merchant categories for spending controls.
*   **Use Cards at Automated Teller Machines (ATMs)** (`/issuing/purchases/atm-usage`): Enabling ATM cash withdrawals.
*   **Issuing Watchlist** (`/issuing/issuing-watchlist`): Understanding the watchlist screening process.

## Compliance and Guidelines

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US)** (`/issuing/compliance-us`): Guidelines for compliant Issuing and Treasury programs in the US.
*   **Issuing Regulated Customer Notices** (`/issuing/issuing-compliance-us/issuing-regulated-customer-notices`): Sending regulatory notifications to customers.
*   **Stripe Issuing Marketing Guidelines (Europe/UK)** (`/issuing/marketing-guidance-europe-uk`): Marketing guidelines for Issuing programs in the UK and Europe.
*   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines** (`/treasury/connect/compliance`): Guidelines for compliant Treasury for Platforms programs.

## API and Developer Resources

*   **Using Issuing Elements** (`/issuing/elements`): Displaying card details securely in your web application.
*   **Integrate Processor-Only Issuing** (`/issuing/processor-only-integration-guide`): Setting up a processor-only Issuing integration.
*   **Processor-Only Issuing** (`/issuing/processor-only-issuing`): Managing your Issuing program with Stripe as the processor.
*   **Customer Support** (`/issuing/customer-support`): Resources for support.
*   **Global Availability** (`/issuing/global`): Using Stripe Issuing in different countries.
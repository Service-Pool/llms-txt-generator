# Stripe Issuing and Treasury for Platforms

This documentation group provides comprehensive guidance on integrating and utilizing Stripe Issuing and Treasury for Platforms. These products enable businesses to programmatically create, manage, and distribute payment cards, and to embed financial services within their own platforms.

## Key Concepts and Features

*   **Stripe Issuing:** Allows businesses to create and manage virtual and physical payment cards for their customers, employees, or contractors. This includes features like:
    *   Cardholder management
    *   Virtual and physical card creation
    *   Customization of card programs
    *   Spending controls and real-time authorization
    *   Fraud management tools
    *   Integration with digital wallets
    *   Support for various use cases like B2B payments, fleet management, and consumer prepaid cards.
*   **Treasury for Platforms:** Provides the infrastructure for platforms to offer financial services to their connected accounts. This includes:
    *   Setting up financial accounts for connected accounts.
    *   Enabling money movement (inbound and outbound transfers, payouts).
    *   Integrating with Issuing to allow spending from financial accounts via cards.
    *   Compliance and regulatory guidelines.
    *   Support for various account structures and bank partnerships.
*   **Stripe Connect Integration:** Both Issuing and Treasury for Platforms heavily leverage Stripe Connect to manage relationships with connected accounts, enabling platforms to issue cards and provide financial services on behalf of their users.

## Core Integration Flows

*   **Onboarding:** Guides for onboarding users and connected accounts, including KYC/KYB processes and compliance requirements.
*   **Card Issuance:** Detailed instructions on creating and managing virtual and physical cards, including design customization and shipping.
*   **Funding:** Information on how to fund Issuing balances and financial accounts, including various funding types and post-funding options.
*   **Money Movement:** Comprehensive guides on moving money into and out of financial accounts, including ACH transfers, wires, and payouts.
*   **Fraud Management:** Strategies and tools for managing transaction fraud and ensuring program security.
*   **Customization and Control:** Options for customizing card programs, setting spending controls, and managing lifecycle controls.
*   **Testing:** Guidance on testing integrations in sandbox environments.

## Specific Use Cases and Guides

The documentation covers specific integration scenarios such as:

*   **Embedded Finance:** Building embedded financial services.
*   **B2B Payments:** Facilitating business-to-business payments with Issuing.
*   **Fleet Management:** Creating fleet card programs.
*   **Consumer Prepaid Cards:** Issuing prepaid debit cards to end-users.
*   **Credit Programs:** Setting up and managing credit programs for consumers.
*   **Processor-Only Issuing:** Integrating as a processor for Issuing programs.
*   **Stablecoin-Backed Cards:** Issuing cards backed by stablecoin balances.

## Compliance and Support

*   **Compliance Guidelines:** Detailed information on product marketing, design, and compliance for both Issuing and Treasury for Platforms, with specific guidance for the US, Europe, and the UK.
*   **Customer Support:** Resources for resolving common Issuing and Treasury for Platforms questions.
*   **Regulatory Notices:** Information on sending regulated customer communications.

This documentation suite is designed for developers and businesses looking to leverage Stripe's Issuing and Treasury for Platforms to build innovative financial products and services.
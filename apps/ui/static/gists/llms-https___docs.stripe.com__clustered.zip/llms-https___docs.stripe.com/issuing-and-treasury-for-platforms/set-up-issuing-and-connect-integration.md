## Integrating Stripe Issuing with Stripe Connect

This section provides comprehensive guidance on integrating Stripe Issuing with Stripe Connect, enabling platforms to issue cards to third-party users represented as connected accounts.

### Key Concepts and Use Cases

*   **Stripe Connect for Issuing:** This integration leverages Stripe Connect's infrastructure to manage fund flows and compliance requirements, allowing platform accounts to make API calls on behalf of connected accounts.
*   **When to Use Connect:** If you need to issue cards for users who are not directly employed by your business, Stripe Connect is the recommended solution. A prime example is a business building an expense management product for small businesses, where each small business is set up as a connected account.
*   **Platform Account's Role:** In a Connect integration, the platform account acts as the intermediary, making API calls on behalf of the connected accounts.

### Core Integration Steps

1.  **Set Up and Onboard Connected Accounts:** Before issuing cards, you must onboard your connected accounts. This involves collecting necessary Know Your Customer (KYC) and Know Your Business (KYB) information to ensure compliance with financial regulations.
2.  **Enable Issuing and Treasury Capabilities:** For connected accounts to utilize Issuing and Treasury for platforms, you need to request the `card_issuing` and `treasury` capabilities for them. This is typically done via API calls to update the connected account object.
3.  **Fund Issuing Balances:** Before issued cards can be used for transactions, funds must be allocated to the connected account's Issuing balance. This balance is separate from other Stripe funds and is reserved for Issuing. Funding can be managed through various methods, including pull funding, push funding, and Stripe balance transfers.
4.  **Create Cardholders and Cards:** Once funding is in place, you can create cardholders (representing individuals or companies associated with the connected account) and then issue virtual or physical cards to them.
5.  **Manage Card Programs and Controls:** Customize your card program by defining card designs, setting spending controls, and managing other program-specific configurations.
6.  **Handle Real-time Authorizations and Transactions:** Implement logic to handle authorization requests in real-time, either through direct webhook responses or by listening to `issuing_authorization.request` events. Understand how transactions are processed after authorization.
7.  **Fraud Management:** Implement robust fraud detection and prevention strategies using Stripe's advanced fraud tools and controls. This includes understanding transaction fraud, liability, and monitoring for suspicious activity.
8.  **Compliance and Legal Considerations:** Adhere to all relevant marketing, design, and compliance guidelines, especially when offering financial services. This includes presenting accurate business information, obtaining terms of service acceptance, and understanding regional variations.

### Specific Features and Guides

*   **Cardholder Management:** Learn how to create and manage cardholders and their associated cards within the Connect ecosystem.
*   **Physical and Virtual Cards:** Understand the options for issuing both physical and virtual cards, including their use cases and creation processes.
*   **Customization and Branding:** Customize your card program with unique designs, card bundles, and branding elements.
*   **Digital Wallets:** Integrate with digital wallets like Apple Pay and Google Pay for card provisioning.
*   **Credit Offerings:** Explore options for providing credit to connected accounts, managing credit terms, and tracking obligations.
*   **Testing and Sandbox Environments:** Utilize sandbox environments to thoroughly test your integration before going live.
*   **Customer Support:** Understand how to provide customer support for Issuing and Treasury for platforms users.
*   **Program Management Models:** Choose between Stripe program management and processor-only models based on your business needs and responsibilities.
*   **Global Availability:** Learn about regional considerations and options for issuing cards in different countries.
*   **Stablecoin-Backed Cards:** Explore the integration of stablecoin-backed cards for enhanced flexibility in fund management.

By following these guidelines and leveraging the provided documentation, platforms can successfully integrate Stripe Issuing with Stripe Connect to offer robust card programs to their users.
## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite covers Stripe's Issuing and Treasury for Platforms products, offering comprehensive guides for developers and businesses looking to integrate and manage card programs and financial services.

### Key Areas of Coverage:

*   **Getting Started & Onboarding:**
    *   **Onboarding Overview:** Understand the general process for launching an Issuing or Treasury for Platforms integration.
    *   **Integration Guides:** Detailed guides for specific use cases like B2B Payments, Embedded Finance, and Fleet management.
    *   **Sample App:** A practical sample application to demonstrate API usage for onboarding, card creation, and payments.
    *   **Testing:** Learn how to test your Issuing integration in a sandbox environment.
    *   **Beta Migration:** Information on migrating from the Issuing beta to the generally available product.

*   **Issuing Card Management:**
    *   **Card Types:** Guidance on choosing between physical and virtual cards.
    *   **Issuing Cards:** Comprehensive information on creating and managing physical and virtual cards.
    *   **Customization:** Details on customizing card programs, including artwork templates and bundle selections.
    *   **Digital Wallets:** How to integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **PIN Management:** Managing PINs for cardholders.
    *   **Replacement Cards:** Procedures for replacing expired, damaged, lost, or stolen cards.

*   **Funding and Balances:**
    *   **Issuing Balance:** Understanding and managing your Issuing balance.
    *   **Adding Funds:** Options for funding your card program, including pull-funded top-ups, push-funded top-ups, and balance transfers.
    *   **Post-funding:** Learn about post-funding your integration with Stripe and Dynamic Reserves.

*   **Controls and Fraud Management:**
    *   **Manage Fraud:** Strategies and tools for combating transaction fraud.
    *   **Spending Controls:** Setting rules and limits for card and cardholder spending.
    *   **Lifecycle Controls:** Implementing automatic card cancellation based on usage.
    *   **Real-time Authorizations:** Handling authorization requests in real-time via webhooks.
    *   **Authorization Rules:** Limiting authorization approvals with custom rules.
    *   **Fraud Challenges:** Implementing additional verification steps for high-risk transactions.
    *   **Advanced Fraud Tools:** Utilizing API signals and tooling to prevent fraud.
    *   **3D Secure:** Understanding cardholder authentication using 3D Secure.
    *   **Token Management:** Managing network tokens for secure payments.
    *   **Issuing Watchlist:** Understanding Stripe's screening process against sanctions lists.

*   **Stripe Connect Integrations:**
    *   **Issuing and Connect:** Setting up Issuing integrations with Stripe Connect.
    *   **Connected Accounts, Cardholders, and Cards:** Managing these entities within a Connect integration.
    *   **Funding Issuing Balances with Connect:** How to fund connected accounts for Issuing.
    *   **Cardholder Controls:** Handling cardholder information screening and updates.
    *   **Inactive Connected Accounts:** Managing offboarding for inactive accounts.
    *   **Embedded Components:** Embedding Issuing card management into your website.

*   **Treasury for Platforms:**
    *   **Overview:** Introduction to Treasury for Platforms and its capabilities.
    *   **Getting Started:** Steps to gain API access and set up your integration.
    *   **Account Management:** Understanding account structures, connected accounts, and financial accounts.
    *   **Financial Account Features:** Exploring the functionalities of financial accounts.
    *   **Working with Cards:** Integrating Stripe Issuing cards with Treasury for Platforms.
    *   **Money Movement:** Comprehensive guides on moving money into and out of financial accounts, including using InboundTransfers, OutboundPayments, OutboundTransfers, and handling ACH NOCs.
    *   **Payouts and Top-ups:** Managing money movement between payments balance and financial accounts.
    *   **Bank Partners:** Information on integrating with banking partners like Fifth Third Bank.
    *   **Compliance and Marketing:** Guidelines for marketing and ensuring compliance for Treasury for Platforms.
    *   **Handling Complaints:** Procedures for managing customer complaints.
    *   **Regulatory Receipts:** Understanding hosted transaction receipts.
    *   **Sample Integrations:** Examples and sample applications for Treasury for Platforms and Issuing.

*   **Credit Products:**
    *   **Issuing Credit Overview:** General information on credit products.
    *   **Credit Consumer Issuing:** Details on offering credit programs to consumers.
    *   **Manage Account Obligations:** Tracking credit spend, lifecycle, and balances for connected accounts.
    *   **Manage Credit Terms:** Configuring credit limits and terms for connected accounts.
    *   **Available Credit and Flow of Funds:** Understanding how available credit impacts transactions.
    *   **Reporting Credit Decisions:** Managing adverse action notices and reporting regulatory data.
    *   **Testing Credit Integrations:** Validating your credit integration in testing environments.

*   **Specific Use Cases & Features:**
    *   **B2B Payments:** Integration guide for business-to-business payments.
    *   **Embedded Finance:** Building embedded financial services.
    *   **Fleet:** Creating fleet card programs.
    *   **Consumer Prepaid Debit Cards:** Issuing prepaid debit cards to users.
    *   **Issuing for Agents:** Providing programmable cards for agents.
    *   **Merchant Categories:** Understanding MCCs for spending controls.
    *   **ATM Usage:** Using Issuing cards at ATMs.
    *   **Global Availability:** Information on using Stripe Issuing in different countries.
    *   **Stablecoin-backed Cards:** Issuing cards backed by stablecoin balances.
    *   **Customer Support:** Resources for resolving Issuing and Treasury for Platforms questions.
    *   **Compliance Guidelines:** Product marketing, design, and compliance guidelines for Issuing and Treasury for Platforms.
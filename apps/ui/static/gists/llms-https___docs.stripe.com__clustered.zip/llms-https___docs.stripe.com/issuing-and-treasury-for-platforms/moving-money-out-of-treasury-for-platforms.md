## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite covers Stripe's Issuing and Treasury for Platforms products, providing comprehensive guidance for developers and businesses looking to integrate and manage card programs and financial services for their users.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing, how it works, and its capabilities for creating and managing payment cards.
*   **Treasury for Platforms Overview:** Learn how to embed financial services into your platform, enabling connected accounts to hold funds, pay bills, and manage cash flow.
*   **Integration Guides:**
    *   **Embedded Finance:** Build integrated financial services.
    *   **B2B Payments:** Facilitate business-to-business payments with Issuing.
    *   **Fleet:** Create fleet card programs for business expenses.
*   **Onboarding Overview:** Navigate the process of getting your Issuing or Treasury for Platforms integration live, including use case approval and live mode access.
*   **Customer Support:** Find resources for resolving common Issuing and Treasury for Platforms questions.
*   **Sample App:** Explore a sample application to understand how to use Issuing and Treasury for Platforms APIs for onboarding, card issuance, and payments.
*   **Testing Your Integration:** Learn how to test your Issuing integration in a sandbox environment and simulate purchases.
*   **Beta Migration Guide:** Understand changes and migration steps from the Issuing beta to the generally available product.
*   **Global Availability:** Discover how to use Stripe Issuing in different countries, including local and cross-border issuing options.

### Issuing Product Details

*   **Issuing Cards:**
    *   **Choose Card Type:** Decide between physical and virtual cards for your cardholders.
    *   **Virtual Cards:** Learn about creating and managing virtual cards.
    *   **Physical Cards:** Understand the options for issuing and managing physical cards.
        *   **Choose Card Bundle:** Select standard or custom physical card bundles.
        *   **Customize Card Bundle:** Configure the components of your card bundle.
        *   **Artwork Templates:** Access design templates for card customization.
        *   **Create a Design:** Design your custom card.
        *   **Issue Cards:** Create physical cards for cardholders.
        *   **Ship Cards:** Understand shipping options for physical cards.
        *   **Address Validation:** Ensure successful delivery of physical cards.
    *   **Replacement Cards:** Learn how to replace expired, damaged, lost, or stolen cards.
    *   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **PIN Management:** Allow cardholders to manage their personal identification numbers.
*   **Funding Your Issuing Balance:**
    *   **Issuing Balance:** Understand how to make funds available for card spend.
    *   **Add Funds to Your Card Program:** Explore different funding options for your Issuing balance.
    *   **Post-fund Your Integration:** Learn about post-funding options with Stripe and Dynamic Reserves.
*   **Controls and Fraud Management:**
    *   **Manage Fraud:** Implement strategies to combat transaction fraud.
    *   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent fraud.
    *   **Issuing Authorization Rules:** Limit authorization approvals with custom rules.
    *   **Real-time Authorizations:** Approve or decline authorization requests in real-time.
    *   **Migrate to Direct Webhook Response:** Update your integration for real-time authorizations.
    *   **Fraud Challenges:** Implement additional verification steps for high-risk transactions.
    *   **Spending Controls:** Set rules and limits for card and cardholder spending.
    *   **Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards.
    *   **Token Management:** Manage network tokens for secure payments.
*   **Purchases and Transactions:**
    *   **Authorizations:** Understand how authorization requests are handled.
    *   **Transactions:** Learn about the lifecycle of a transaction after authorization.
    *   **Disputes:** Manage transaction disputes through the Dashboard or API.
    *   **Merchant Categories:** Understand how businesses are categorized and use this for controls.
    *   **ATM Usage:** Enable and manage ATM cash withdrawals for your cards.
    *   **Enriched Merchant Data:** Utilize detailed merchant data for fraud prevention and insights.
*   **Issuing Program Management:**
    *   **Program Management:** Choose between Stripe program management and processor-only models.
    *   **Customize Your Card Program:** Tailor your Issuing card program to your business needs.
    *   **Issuing Watchlist:** Understand automatic screening against sanctions lists.
    *   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.
*   **Consumer Issuing:**
    *   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for instant spending and disbursements.
    *   **Credit Consumer Issuing:** Create and manage credit programs for your customers (US only).
*   **Stablecoin-Backed Cards:**
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts:** Issue cards backed by stablecoin balances for connected accounts.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrate with Bridge to build stablecoin-backed card programs.
    *   **Stablecoin-backed card issuing:** Issue prepaid or debit cards backed by stablecoin balances.

### Stripe Connect and Issuing Integration

*   **Set up an Issuing and Connect Integration:** Integrate Stripe Issuing with Stripe Connect to issue cards on behalf of connected accounts.
*   **Connected Accounts, Cardholders, and Cards:** Understand how to create and manage cardholders and cards within a Connect integration.
*   **Cardholder Controls:** Ensure compliance with cardholder screening and validation requirements.
*   **Inactive Connected Accounts Offboarding:** Manage the disabling of Issuing capabilities for inactive connected accounts.
*   **Fund Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing.
*   **Embed Issuing Card Management:** Use Connect embedded components to integrate card management into your website.
*   **Update Terms of Service Acceptance:** Ensure accurate business information and acceptance of Issuing terms.

### Treasury for Platforms Product Details

*   **Treasury for Platforms Overview:** A comprehensive guide to providing financial services to connected accounts.
*   **Eligibility Requirements:** Understand the criteria for using Treasury for Platforms.
*   **Get Started with API Access:** Begin your Treasury for Platforms integration.
*   **Onboarding Users:** Implement a compliant onboarding process for connected accounts.
*   **Managing Fraud:** Learn best practices for fraud prevention and management.
*   **Marketing and Compliance Guidelines:** Ensure your marketing and user interfaces adhere to financial regulations.
    *   **Regulatory Receipts:** Understand hosted transaction receipts for regulated transactions.
    *   **Handling Complaints:** Properly manage customer complaints related to Treasury for Platforms or Issuing.
    *   **Marketing Treasury for Platforms:** Create compliant messaging for your users.
*   **Sample Integrations:**
    *   **Set up Financial Accounts and Cards:** Follow a sample integration to set up financial accounts and create cards.
    *   **Using Treasury for Platforms to Move Money:** Learn basic money movement using treasury endpoints.
    *   **Issuing and Treasury for Platforms Sample App:** Utilize a Next.js sample app for your integration.
    *   **Webhooks:** Understand webhook events for Issuing and Treasury for Platforms.
*   **Account Management:**
    *   **Accounts Structure:** Understand the interaction of account components in Treasury for Platforms.
    *   **Working with Connected Accounts:** Request capabilities and collect onboarding requirements.
    *   **Working with Financial Accounts:** Learn how to provision and manage financial accounts.
    *   **Financial Account Features:** Explore features available for financial accounts.
    *   **Platform Financial Accounts:** Understand the financial account provisioned for your platform.
    *   **Working with Balances and Transactions:** Learn about financial account balances and transaction effects.
*   **Moving Money:**
    *   **Moving Money into Financial Accounts:** Add money to financial accounts using InboundTransfer and ReceivedCredit objects.
    *   **Moving Money Out of Treasury for Platforms:** Transfer funds from financial accounts using various methods.
    *   **Moving money using OutboundTransfer objects:** Transfer funds to external accounts.
    *   **Moving money using OutboundPayment objects:** Send money to third-party accounts.
    *   **Moving money using ReceivedDebit objects:** Understand how funds are pulled from financial accounts.
    *   **Moving money using CreditReversal objects:** Reverse received credits.
    *   **Moving money using DebitReversal objects:** Retrieve funds from received debits.
    *   **Payouts and Top-ups from Payments Balance:** Move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated.
*   **Bank Partners:**
    *   **Integrate with Fifth Third Bank:** Add Fifth Third Bank to your Treasury for Platforms integration.
    *   **Build a New Treasury for Platforms Integration with Fifth Third Bank:** Get started with Treasury for Platforms using Fifth Third Bank.
*   **Issuing and Treasury for Platforms with Issuing:** Learn how to integrate Stripe Issuing with Treasury for Platforms.
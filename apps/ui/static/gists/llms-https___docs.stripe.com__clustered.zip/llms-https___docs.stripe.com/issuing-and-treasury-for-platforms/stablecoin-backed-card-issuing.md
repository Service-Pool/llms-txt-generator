```md
# Stripe Issuing and Treasury for Platforms Documentation

This documentation suite covers Stripe's Issuing and Treasury for Platforms products, providing comprehensive guidance for developers and businesses looking to integrate advanced financial services. It details how to create, manage, and distribute payment cards, handle money movement, and ensure compliance with financial regulations.

## Key Areas Covered:

*   **Issuing Cards:**
    *   Creating and managing virtual and physical cards.
    *   Customizing card programs, including design and branding.
    *   Handling cardholder management and controls.
    *   Managing fraud and security features like 3D Secure and real-time authorizations.
    *   Integrating with digital wallets.
    *   Specific use cases like B2B payments, fleet management, and consumer prepaid cards.
    *   Processor-only integration models.
    *   Global availability and regional considerations.

*   **Treasury for Platforms:**
    *   Setting up financial accounts for platforms and connected accounts.
    *   Managing money movement, including inbound and outbound transfers, payouts, and top-ups.
    *   Integrating with bank partners like Fifth Third Bank.
    *   Handling compliance, marketing, and fraud management for financial services.
    *   Using Treasury for Platforms with Issuing for comprehensive financial solutions.

*   **Stripe Connect Integration:**
    *   Establishing Issuing and Treasury for Platforms integrations with Stripe Connect.
    *   Managing connected accounts, cardholders, and their associated cards and financial accounts.
    *   Funding Issuing balances for connected accounts.
    *   Embedding card management features into your website.

*   **Credit Solutions:**
    *   Issuing Credit for consumers and managing credit programs.
    *   Setting up and managing credit terms, obligations, and payments for connected accounts.
    *   Reporting credit decisions and regulatory data.

*   **Testing and Support:**
    *   Testing Issuing and Treasury for Platforms integrations in sandbox environments.
    *   Customer support resources for Issuing and Treasury for Platforms.
    *   Guidance on migrating from beta versions.

## Core Product Pages:

*   **/issuing**: The main entry point for Stripe Issuing, covering card creation, management, and distribution.
*   **/treasury/connect**: The central hub for Treasury for Platforms, detailing how to embed financial services for connected accounts.
*   **/issuing/integration-guides**: A collection of guides for specific integration types like B2B payments, embedded finance, and fleet management.
*   **/treasury/connect/examples/sample-app**: Demonstrates a sample application integrating both Issuing and Treasury for Platforms.
*   **/issuing/how-issuing-works**: Explains the fundamental mechanics of how Stripe Issuing operates.
*   **/treasury/connect/how-financial-accounts-for-platforms-works**: Details the architecture and functionality of Treasury for Platforms.

## Key Sub-sections:

*   **Card Management**: Covers physical and virtual cards, digital wallets, replacements, PIN management, and artwork templates.
*   **Funding and Balances**: Details how to fund Issuing balances and manage them using various methods, including post-funding and dynamic reserves.
*   **Controls and Fraud**: Explains spending controls, lifecycle controls, advanced fraud tools, real-time authorizations, fraud challenges, and authorization rules.
*   **Connect Integrations**: Focuses on integrating Issuing and Treasury for Platforms with Stripe Connect, including onboarding, funding, and cardholder management for connected accounts.
*   **Credit Features**: Provides information on issuing credit, managing credit terms, and handling account obligations.
*   **Money Movement**: Deep dives into moving money within Treasury for Platforms, including inbound/outbound transfers, payments, and handling regulatory receipts.
*   **Compliance and Guidelines**: Offers essential information on product marketing, design, and compliance for both Issuing and Treasury for Platforms, with specific guidance for the US and Europe/UK.
*   **Specific Use Cases**: Includes guides for B2B payments, fleet management, embedded finance, consumer prepaid cards, and stablecoin-backed cards.
```
```md
# Stablecoin-Backed Cards for Bridge, Privy, or Third-Party Wallets

Integrate Stripe Issuing with Bridge to build a stablecoin-backed consumer or commercial card program.

## Private preview

Integrate Stripe Issuing with the Bridge stablecoin infrastructure to build a card program funded by a Bridge custodial wallet, Privy non-custodial wallet, or any other non-custodial wallet. This guide shows you how to connect your Stripe account to Bridge to issue debit cards that spend just-in-time from a stablecoin balance.

### Onboard

When launching a card program with Bridge and Stripe Issuing, Stripe outlines the end-to-end requirements and creates an individualized onboarding approach to the program design of your business. We’ll match you with a dedicated implementation specialist to guide you through the onboarding process.
```
## Stripe Issuing and Treasury for Platforms Documentation

This documentation group provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers a wide range of topics, from initial setup and integration to advanced features like fraud management, credit offerings, and global availability.

### Core Concepts and Integration

*   **Getting Started with Issuing:** The foundational pages explain how Stripe Issuing works, its core functionalities, and how to get started with issuing cards for your business or platform. This includes understanding the onboarding process and choosing the right card types (virtual vs. physical).
*   **Treasury for Platforms Overview:** This section details how Treasury for Platforms enables you to embed financial services into your product, allowing connected accounts to hold funds, pay bills, and manage cash flow. It covers account structures, financial accounts, and the overall workflow.
*   **Integration Guides:** Specific guides are provided for various use cases, including:
    *   **Embedded Finance:** Building embedded financial services integrations.
    *   **B2B Payments:** Creating B2B payment solutions with Issuing.
    *   **Fleet:** Developing fleet financial services integrations.
*   **Sample App and Testing:** A sample application is available to demonstrate how to use Issuing and Treasury for Platforms APIs. Comprehensive guides on testing your Issuing integration in a sandbox environment are also provided.

### Card Management and Features

*   **Issuing Cards:** This covers the creation and management of both virtual and physical cards, including details on choosing card bundles, creating designs, and shipping.
*   **Card Controls:** Advanced features for managing card usage are detailed, such as spending controls, lifecycle controls, real-time authorizations, and PIN management.
*   **Fraud Management:** Strategies and tools for managing fraud are explained, including advanced fraud tools, 3D Secure authentication, fraud challenges, and real-time authorization rules.
*   **Digital Wallets:** Guidance on integrating Issuing cards with digital wallets like Apple Pay and Google Pay is provided.
*   **Replacement Cards:** Information on how to handle expired, damaged, lost, or stolen cards.

### Connect Integrations

*   **Issuing with Connect:** This section focuses on integrating Stripe Issuing with Stripe Connect, enabling platforms to issue cards to third-party users. It covers setting up the integration, managing connected accounts, cardholders, and cards, and funding Issuing balances with Connect.
*   **Treasury for Platforms with Connect:** This explores how to use Treasury for Platforms with Connect, including account management, financial account features, working with balances and transactions, and moving money between accounts.

### Credit Offerings

*   **Issuing Credit:** This suite of pages details Stripe's credit solutions, including Credit Consumer Issuing, managing account obligations, credit terms, and reporting credit decisions. It also covers available credit and the flow of funds.

### Funding and Money Movement

*   **Issuing Balance:** Understanding and managing your Issuing balance is crucial for card spend. This section covers various funding methods, including pull-funded top-ups, push-funded top-ups, and Stripe balance transfers.
*   **Post-funding:** Learn how to post-fund your integration with Stripe, including using dynamic reserves.
*   **Treasury Money Movement:** This covers various aspects of moving money within Treasury for Platforms, including inbound and outbound transfers, payouts, and working with bank account objects.

### Compliance and Support

*   **Compliance Guidelines:** Detailed guidelines for product marketing, design, and compliance are provided for both Issuing and Treasury for Platforms, with specific sections for the US and Europe/UK.
*   **Customer Support:** Information on how to access customer support for Issuing and Treasury for Platforms.
*   **Watchlist Screening:** Understanding the Issuing watchlist process and how Stripe screens users against sanctions lists.

This documentation aims to provide developers and businesses with the necessary information to successfully implement and leverage Stripe's Issuing and Treasury for Platforms products.
## Stripe Issuing: Card Program Management and Financial Services Integration

This documentation suite provides comprehensive guidance on leveraging Stripe Issuing to create, manage, and distribute payment cards for businesses and their users. It covers everything from initial setup and integration with Stripe Connect to advanced features like fraud management, spending controls, and credit programs.

### Key Areas Covered:

*   **Getting Started with Issuing:**
    *   Overview of Stripe Issuing and its capabilities.
    *   How Issuing works, including regional considerations and partnerships.
    *   Onboarding processes and requirements for launching an Issuing program.
    *   Testing your Issuing integration in sandbox environments.
    *   Migrating from beta versions of the Issuing API.

*   **Card Program Management:**
    *   **Card Types:**
        *   Choosing between physical and virtual cards.
        *   Issuing virtual cards and displaying their details.
        *   Creating and managing physical cards, including custom designs and bundles.
    *   **Customization and Branding:**
        *   Customizing your card program with BIN setup and account ranges.
        *   Designing cards with artwork templates and bundle selections.
    *   **Funding and Balances:**
        *   Adding funds to your Issuing balance.
        *   Understanding Issuing balance and different funding methods.
        *   Post-funding your integration with Dynamic Reserves.
    *   **Cardholder Management:**
        *   Choosing cardholder types (individual vs. company).
        *   Creating and managing cardholders and their associated cards.
        *   Managing cardholder controls and compliance.
        *   Handling inactive connected accounts.
    *   **PIN Management:**
        *   Allowing cardholders to manage their PINs.

*   **Integration with Stripe Connect:**
    *   Setting up Issuing and Connect integrations for platforms.
    *   Managing connected accounts, cardholders, and cards.
    *   Funding Issuing balances with Connect.
    *   Embedding Issuing card management into your website using Connect components.
    *   Updating Issuing terms of service acceptance for connected accounts.

*   **Financial Services and Treasury Integration:**
    *   **Treasury for Platforms Overview:**
        *   Understanding how Treasury for platforms works and its eligibility requirements.
        *   Getting started with API access and sandbox environments.
        *   Account structures, including platform and connected accounts.
    *   **Financial Account Management:**
        *   Working with financial accounts and their features.
        *   Managing balances and transactions within financial accounts.
        *   Moving money into and out of financial accounts using various methods (ACH, wires, Stripe network).
    *   **Issuing Cards with Treasury:**
        *   Integrating Stripe Issuing with Treasury for platforms to set up financial accounts and cards.
        *   Enabling Issuing on connected accounts.
    *   **Credit Programs:**
        *   Issuing Credit overview and its private preview status.
        *   Setting up credit for connected accounts and managing credit terms.
        *   Managing account obligations, including amounts, transactions, and adjustments.
        *   Reporting credit decisions and managing adverse action notices.
        *   Reporting required regulatory data for credit decisions.
        *   Testing credit integrations.
    *   **Stablecoin-backed Cards:**
        *   Issuing prepaid or debit cards backed by stablecoin balances.
        *   Integrating with third-party wallets like Bridge.

*   **Fraud Management and Controls:**
    *   Managing fraud with Stripe Issuing controls and tools.
    *   Advanced fraud tools, including API signals and real-time authorizations.
    *   Setting up and managing real-time authorization rules.
    *   Migrating to direct webhook responses for real-time authorizations.
    *   Understanding and implementing fraud challenges for additional verification.
    *   Issuing lifecycle controls for automatic card cancellation.
    *   Issuing spending controls to set rules on card usage.
    *   Token management for secure payment processing.
    *   Issuing watchlist for sanctions screening.

*   **Purchases and Transactions:**
    *   Handling Issuing authorizations and understanding transaction lifecycles.
    *   Managing Issuing disputes.
    *   Utilizing enriched merchant data for insights and fraud prevention.
    *   Understanding how transactions are processed and recorded.
    *   Using cards at ATMs for cash withdrawals.

*   **Compliance and Guidelines:**
    *   Product marketing, design, and compliance guidelines for Issuing and Treasury.
    *   Issuing regulated customer notices and communication requirements.
    *   Marketing guidelines for Issuing programs in Europe and the UK.

*   **Customer Support:**
    *   Accessing customer support for Issuing and Treasury for platforms.

This documentation suite is designed for developers and businesses looking to integrate Stripe Issuing and Treasury for platforms into their applications and offer robust financial services to their users.
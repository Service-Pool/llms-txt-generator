## Stripe Issuing: Token Management

This section details how to manage network tokens for your Stripe Issuing cards, enhancing security and enabling seamless digital wallet integration.

### Understanding Network Tokens

Network tokens are virtual representations of your issued cards. They are created when a cardholder:

*   **Adds a card to a digital wallet:** This includes services like Apple Pay and Google Pay.
*   **Saves a payment method for their account:** This applies to online storefronts or intermediary payment methods.

These tokens act as substitutes for sensitive card details (card number, expiration date, verification code) during transactions. By not exposing the actual card information, network tokens significantly reduce the risk of stolen card data due to transactions or fraudulent actors. Consequently, tokens are generally considered a more secure payment method than physical cards or manual entry of card details.

### Key Benefits of Token Management

*   **Enhanced Security:** Reduces the risk of card data compromise by using tokenized representations for payments.
*   **Digital Wallet Integration:** Enables seamless addition of cards to popular digital wallets like Apple Pay and Google Pay.
*   **Streamlined Online Payments:** Simplifies online checkout by using saved, tokenized payment methods.
*   **Reduced PCI Compliance Burden:** By leveraging Stripe-hosted iframes for displaying sensitive data, you minimize your PCI-DSS compliance requirements.

### How Token Management Works with Stripe Issuing

Stripe Issuing integrates with tokenization services to create and manage these network tokens. When a cardholder adds a card to a digital wallet or saves it for online payments, Stripe facilitates the creation of a token. This token is then used for subsequent transactions, ensuring that your servers never handle sensitive cardholder data directly.

### Further Information

For detailed implementation guidance and API references, please refer to the following Stripe Issuing documentation:

*   **Use digital wallets with Issuing:** [Link to relevant page]
*   **Issuing Elements:** [Link to relevant page]
## Embedding Issuing Card Management

This section details how to integrate Stripe Issuing card management functionality directly into your website using Connect embedded components. This approach minimizes the need for extensive coding and configuration, allowing you to provide your connected accounts with seamless access to card management features.

### Key Components

Stripe offers two primary embedded components for Issuing card management:

*   **Issuing Card Component:** This component allows for the display and management of individual Issuing cards.
*   **Issuing Cards List Component:** This component provides a view of all Issuing cards associated with a connected account.

### Security Considerations

**Important Security Tip:** These components are designed for **admin users of connected accounts** who require access to sensitive card and cardholder data for the entire connected account. They **should not be used to render UI for individual cardholders** under any circumstances.

### Quickstart

To implement Issuing Connect embedded components, you will need access to both Stripe Issuing and Stripe Connect. For a deeper understanding of how embedded components function, refer to the [Connect embedded components documentation](link-to-connect-embedded-components-docs).
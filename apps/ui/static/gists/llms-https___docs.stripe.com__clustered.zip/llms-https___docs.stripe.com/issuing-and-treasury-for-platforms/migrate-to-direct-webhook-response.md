## Stripe Issuing and Treasury for Platforms Documentation

This documentation set provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and integration to advanced features like fraud management, credit programs, and international expansion.

### Key Areas of Focus:

*   **Getting Started with Issuing:**
    *   Onboarding overview and requirements.
    *   Choosing cardholder types and card types (virtual/physical).
    *   Funding your Issuing balance.
    *   Integrating Issuing into your platform.
    *   Using the Issuing sample app.

*   **Issuing Integration Guides:**
    *   Specific guides for B2B Payments, Embedded Finance, and Fleet management.
    *   Processor-only Issuing integration.

*   **Card Management and Customization:**
    *   Creating and managing virtual and physical cards.
    *   Customizing card programs, including BIN setup and artwork templates.
    *   Ordering and customizing physical card bundles.
    *   Managing PINs and replacement cards.
    *   Using digital wallets with Issuing.

*   **Fraud Prevention and Controls:**
    *   Managing fraud with Issuing controls and tools.
    *   Advanced fraud tools and real-time authorizations.
    *   Implementing authorization rules, fraud challenges, and lifecycle controls.
    *   Token management for secure payments.

*   **Issuing Credit Programs:**
    *   Overview of Issuing Credit and its features.
    *   Setting up credit for connected accounts and managing credit terms.
    *   Managing account obligations, including available credit, obligation payments, and transactions.
    *   Reporting credit decisions and adverse action notices.
    *   Testing credit integrations.

*   **Treasury for Platforms:**
    *   Overview of Treasury for Platforms and its capabilities.
    *   Getting started with API access and understanding eligibility requirements.
    *   Account management, including account structures and working with connected and financial accounts.
    *   Financial account features and platform financial accounts.
    *   Moving money, including inbound and outbound transfers, payouts, and top-ups.
    *   Integrating with bank partners like Fifth Third Bank.
    *   Handling ACH NOC and SEC.

*   **Connect Integrations:**
    *   Setting up Issuing and Connect integrations.
    *   Managing connected accounts, cardholders, and cards.
    *   Funding Issuing balances with Connect.
    *   Updating Issuing terms of service acceptance.
    *   Embedding Issuing card management into your website.
    *   Managing inactive connected accounts.

*   **Purchases and Transactions:**
    *   Handling Issuing authorizations and transactions.
    *   Managing Issuing disputes.
    *   Utilizing enriched merchant data.
    *   ATM usage with Issuing cards.

*   **Global Availability and Compliance:**
    *   Using Stripe Issuing in different countries.
    *   Product marketing, design, and compliance guidelines (US and Europe/UK).
    *   Issuing regulated customer notices.

*   **Testing and Migration:**
    *   Testing Issuing integrations in sandbox environments.
    *   Migrating from Issuing beta.
    *   Testing Treasury for Platforms integrations.

*   **Advanced Features:**
    *   Stablecoin-backed card issuing.
    *   Issuing for agents.
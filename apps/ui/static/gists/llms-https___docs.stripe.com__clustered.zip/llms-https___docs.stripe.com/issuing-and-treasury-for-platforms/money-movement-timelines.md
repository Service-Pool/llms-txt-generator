## Stripe Issuing and Treasury for Platforms: A Comprehensive Guide

This documentation suite provides a deep dive into Stripe's Issuing and Treasury for Platforms products, empowering developers to build sophisticated financial services for their businesses and customers. Whether you're looking to issue physical or virtual cards, manage funds, or offer embedded financial experiences, this resource covers the essential aspects of integration, management, and compliance.

### Key Areas Covered:

*   **Issuing Fundamentals:** Understand the core concepts of Stripe Issuing, from how it works to choosing the right card types (virtual or physical) and managing card programs.
*   **Integration Guides:** Explore detailed guides for specific use cases such as B2B Payments, Embedded Finance, and Fleet management, enabling tailored card solutions.
*   **Card Management:** Learn how to create, customize, and manage both physical and virtual cards, including aspects like artwork, bundles, and digital wallet integration.
*   **Funding and Balances:** Discover how to fund your Issuing balance, understand different funding types, and manage post-funding scenarios with Dynamic Reserves.
*   **Controls and Security:** Implement robust fraud management strategies, leverage advanced fraud tools, and configure spending and lifecycle controls to protect your program.
*   **Stripe Connect Integration:** Seamlessly integrate Issuing with Stripe Connect to manage cards for connected accounts, including funding, cardholder management, and embedded components.
*   **Treasury for Platforms:** Delve into Treasury for Platforms, understanding its account structure, financial account features, and how to move money efficiently.
*   **Credit Offerings:** Explore Stripe's credit solutions, including Consumer Credit Issuing and managing credit terms for connected accounts.
*   **Compliance and Guidelines:** Navigate the regulatory landscape with detailed information on product marketing, design, and compliance guidelines for both Issuing and Treasury for Platforms.
*   **Testing and Support:** Learn how to effectively test your integrations in sandbox environments and access customer support for Issuing and Treasury.

### Getting Started:

This documentation is structured to guide you through the entire process of implementing Stripe Issuing and Treasury for Platforms.

*   **For new users:** Begin with the "How Issuing works" and "Treasury for platforms" overview pages to grasp the fundamental concepts. Then, explore the "Integration guides" relevant to your specific use case.
*   **For developers:** Refer to the API documentation and integration guides for detailed instructions on implementing features. The "Sample app" can provide a practical starting point.
*   **For compliance and business teams:** Focus on the "Compliance guidelines" and "Marketing guidelines" sections to ensure your program adheres to all necessary regulations.

By leveraging the comprehensive resources within this documentation suite, you can confidently build and scale innovative financial products with Stripe Issuing and Treasury for Platforms.
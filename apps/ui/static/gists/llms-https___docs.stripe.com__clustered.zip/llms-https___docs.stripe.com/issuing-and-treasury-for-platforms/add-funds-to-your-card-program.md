## Funding Your Stripe Issuing Card Program

To enable card spending, Stripe Issuing users must fund an **Issuing balance**. This balance represents funds reserved for Issuing and is safely separated from your earnings, payouts, and funds from other Stripe products.

You have several options for funding your Issuing balance, depending on your integration and region:

*   **External Bank Account:** This is the default funding option. You can pull or push funds from an external bank account to your Issuing balance.
    *   **Pull-funded top-ups:** Funds are pulled from your external bank account. This is the default option in the US and is not available in the EU or UK. It may involve a delay of up to 5 business days for fund transfers.
    *   **Push-funded top-ups:** Funds are pushed from your external bank account. You can access the necessary bank account and routing information to do this via the Stripe Dashboard or API. Funds are immediately available as a top-up.
*   **Stripe Balance Transfers:** If you use Stripe to process payments, you can fund your Issuing balance directly from your Stripe acquiring balance.
*   **Connect Balance Transfers:** For Stripe Connect integrations, you can transfer funds from a connected account's balance to your Issuing balance.

This page provides information to help you decide which funding type works best for your integration.

### Funding Types Overview

| Funding Type               | Description

<!-- truncated by AI -->
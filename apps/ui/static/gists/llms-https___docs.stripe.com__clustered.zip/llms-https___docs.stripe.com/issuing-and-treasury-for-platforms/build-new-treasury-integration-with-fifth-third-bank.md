## Stripe Issuing and Treasury for Platforms

This documentation group provides comprehensive guidance on integrating Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and onboarding to advanced features like fraud management, credit programs, and international use cases.

### Key Areas:

*   **Getting Started:**
    *   **Onboarding:** Understand the onboarding process for Issuing and Treasury for Platforms, including use case approval and going live. (Page 6, Page 102)
    *   **Integration Guides:** Explore specific integration guides for various use cases like Embedded Finance, B2B Payments, and Fleet management. (Page 2, Page 3, Page 4, Page 5)
    *   **Sample App:** Utilize the Issuing and Treasury for Platforms sample app to understand API usage and onboard customers. (Page 7, Page 104)
    *   **Testing:** Learn how to test your Issuing integration in a sandbox environment. (Page 84)
    *   **API Access:** Get started with API access to Treasury for Platforms. (Page 85)

*   **Issuing Core Functionality:**
    *   **Card Types:** Decide between physical and virtual cards for your cardholders. (Page 12, Page 33)
    *   **Funding:** Learn how to fund your Issuing balance and card programs. (Page 11, Page 61)
    *   **Issuing Cards:** Create and manage both virtual and physical cards. (Page 8, Page 26, Page 34)
    *   **Card Customization:** Customize your card program, including designs and bundles. (Page 16, Page 22, Page 23, Page 24, Page 25)
    *   **PIN Management:** Understand how to manage PINs for cardholders. (Page 30)
    *   **Replacement Cards:** Learn how to handle expired, damaged, lost, or stolen cards. (Page 32)

*   **Treasury for Platforms:**
    *   **Account Structure:** Understand the account components of Treasury for Platforms. (Page 86)
    *   **Financial Accounts:** Learn about financial account features and how to work with them. (Page 87, Page 89, Page 93)
    *   **Money Movement:** Explore how to move money into and out of financial accounts, including timelines and specific transfer types. (Page 101, Page 107, Page 108, Page 111, Page 112, Page 114, Page 115, Page 116, Page 118)
    *   **Bank Partners:** Integrate with bank partners like Fifth Third Bank. (Page 94, Page 95)

*   **Advanced Features & Controls:**
    *   **Fraud Management:** Implement advanced fraud tools and controls to mitigate risk. (Page 20, Page 42, Page 43, Page 45, Page 103)
    *   **Real-time Authorizations:** Handle authorization requests in real-time. (Page 9, Page 44, Page 48)
    *   **Spending Controls:** Set rules and limits to control cardholder spending. (Page 49)
    *   **Lifecycle Controls:** Manage automatic card cancellation based on usage. (Page 47)
    *   **Token Management:** Understand how to manage network tokens for enhanced security. (Page 50)
    *   **3D Secure:** Implement cardholder authentication using 3D Secure. (Page 10)

*   **Stripe Connect Integration:**
    *   **Setting up Issuing and Connect:** Integrate Issuing with Stripe Connect for managing funds and compliance. (Page 41)
    *   **Cardholders and Cards:** Create and manage cardholders and cards within a Connect integration. (Page 39)
    *   **Funding:** Learn how to fund Issuing balances for connected accounts. (Page 40)
    *   **Embedded Components:** Embed Issuing card management into your website using Connect components. (Page 37)
    *   **Inactive Accounts:** Understand the offboarding process for inactive connected accounts. (Page 38)
    *   **Cardholder Controls:** Manage cardholder information and compliance. (Page 36)
    *   **Terms of Service:** Update Issuing terms of service acceptance for connected accounts. (Page 62)

*   **Credit Programs:**
    *   **Consumer Credit Issuing:** Launch credit programs for your customers. (Page 14, Page 15)
    *   **Credit Management:** Manage account obligations, credit terms, and available credit. (Page 51, Page 52, Page 54, Page 55, Page 56, Page 57)
    *   **Reporting:** Report credit decisions and manage adverse action notices. (Page 58, Page 59)

*   **Compliance and Guidelines:**
    *   **US Guidelines:** Adhere to product marketing, design, and compliance guidelines for Issuing and Treasury in the US. (Page 71)
    *   **EU/UK Guidelines:** Follow marketing guidelines for Issuing programs in the UK and Europe. (Page 75)
    *   **Regulated Customer Notices:** Understand how to send regulatory notifications to customers. (Page 72)
    *   **Treasury Compliance:** Navigate marketing, design, and compliance guidelines for Treasury for Platforms. (Page 96)

*   **Specific Use Cases & Features:**
    *   **B2B Payments:** Integrate for B2B payment solutions. (Page 2)
    *   **Embedded Finance:** Build embedded financial services. (Page 3)
    *   **Fleet Management:** Create fleet card programs. (Page 4)
    *   **Consumer Prepaid Cards:** Issue prepaid debit cards to users. (Page 13)
    *   **Digital Wallets:** Integrate Issuing cards with digital wallets. (Page 17)
    *   **Processor-Only Integration:** Set up a processor-only Issuing integration. (Page 18, Page 19)
    *   **Merchant Categories:** Understand Issuing merchant categories for spending controls. (Page 35)
    *   **ATM Usage:** Learn how to use cards at ATMs. (Page 76)
    *   **Transactions:** Understand how Issuing transactions are processed. (Page 80)
    *   **Disputes:** Manage transaction disputes. (Page 78)
    *   **Stablecoin-Backed Cards:** Issue cards backed by stablecoin balances. (Page 81, Page 82, Page 83)
    *   **Issuing for Agents:** Provide programmable cards for agents. (Page 69)
    *   **Global Availability:** Use Stripe Issuing in different countries. (Page 65)
    *   **Customer Support:** Find information on customer support for Issuing and Treasury. (Page 1)
    *   **Issuing Watchlist:** Understand the Issuing watchlist process. (Page 74)
    *   **Post-Funding:** Learn about post-funding integrations with Stripe and Dynamic Reserves. (Page 63, Page 64)
    *   **Authorization Rules:** Limit authorization approvals using Issuing authorization rules. (Page 43)
    *   **Issuing Elements:** Display card details in a PCI-compliant way. (Page 46)
    *   **Authorizations:** Handle authorization requests for Issuing. (Page 77)
    *   **Enriched Merchant Data:** Use comprehensive merchant data for fraud prevention. (Page 79)
    *   **Credit Consumer Issuing:** Create and manage credit programs for consumers. (Page 14, Page 15)
    *   **Beta Migration:** Migrate from the Issuing beta. (Page 68)
    *   **How Issuing Works:** Understand the core mechanics of Stripe Issuing. (Page 67)
    *   **How Treasury for Platforms Works:** Learn about connected accounts, financial accounts, and money movement. (Page 106)
    *   **Webhooks:** Understand webhook events for Issuing and Treasury for Platforms. (Page 105)
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated. (Page 113)
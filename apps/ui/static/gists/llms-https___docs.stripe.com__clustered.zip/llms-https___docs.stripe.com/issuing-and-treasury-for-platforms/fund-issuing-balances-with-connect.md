## Funding Issuing Balances with Connect

This document explains how to fund the Issuing balances of connected accounts within your Stripe Connect integration.

### Overview

Before an issued card can be used for transactions, you must allocate funds to the connected account's Issuing balance. This balance holds funds reserved for Issuing and is safely separated from earnings, payouts, and funds from other Stripe products.

### Funding Options

You have two primary options for funding an Issuing balance from an external account:

*   **Pull Funding:** This is the default funding option in the US and is not available in the EU or UK. It requires verifying external bank accounts, which can introduce a delay of up to 5 business days for fund transfers.
*   **Push Funding:** This method involves the connected account initiating the transfer of funds from their external account to their Issuing balance.

### Funding from a Bank Account

When using pull funding, you will need to verify the external bank accounts. Stripe provides the necessary bank account and routing information to facilitate these transfers. Once funds are received in the Issuing balance, they are immediately available as a top-up.
# Stripe Issuing and Treasury for Platforms

This documentation section covers Stripe's Issuing and Treasury for Platforms products, providing comprehensive guidance on how to integrate and manage card programs and financial services for your business and your customers.

## Key Features and Concepts

*   **Stripe Issuing:** Enables you to create, manage, and distribute physical or virtual payment cards for your business, employees, contractors, or AI agents. You can customize card designs, manage spending controls, and approve transactions in real-time.
*   **Treasury for Platforms:** A suite of APIs that allows you to embed financial services into your platform, enabling your connected accounts to hold funds, pay bills, earn cash back, and manage their cash flow. This is done in partnership with trusted banks.
*   **Stripe Connect:** Essential for Issuing and Treasury for Platforms integrations where you need to issue cards or provide financial services to users who are not directly employed by your business. Platforms make API calls on behalf of connected accounts.
*   **Financial Accounts:** Separate accounts within Treasury for Platforms that hold funds for your connected accounts, distinct from the platform's main balance. These accounts can be used to store funds, back card spend, and facilitate money movement.
*   **Cardholder Management:** Creating and managing cardholders, who represent individuals associated with business entities (connected accounts).
*   **Funding Issuing Balances:** Adding funds to your Issuing balance from external bank accounts or your Stripe acquiring balance to enable card spend. This includes options like pull-funded top-ups, push-funded top-ups, Stripe balance transfers, and Connect balance transfers.
*   **Card Types:** Issuing supports both virtual and physical cards, each with specific use cases and considerations.
*   **Customization:** Options to customize card programs, including BIN setup, account ranges, card designs, and physical card bundles.
*   **Fraud Management:** Tools and controls to identify and prevent transaction fraud, including advanced fraud tools, real-time authorizations, fraud challenges, and spending controls.
*   **Real-time Authorizations:** The ability to approve or decline authorization requests in real-time via webhooks.
*   **Credit Features:** Functionality to manage credit programs for your customers, including credit policies, funding obligations, and managing credit terms.
*   **Global Availability:** Stripe Issuing offers solutions for issuing cards in different countries, including local issuing and cross-border options.
*   **Compliance and Guidelines:** Adhering to product marketing, design, and compliance guidelines for Issuing and Treasury for Platforms, especially in specific regions like the US, UK, and Europe.
*   **Testing:** Utilizing sandbox environments to test integrations before going live, including simulating purchases and money movements.

## Integration Guides

This section provides specific guides for integrating Stripe Issuing and Treasury for Platforms for various use cases:

*   **Embedded Finance Integration Guide:** For building embedded financial services.
*   **B2B Payments Integration Guide:** For creating cards for business-related purchases.
*   **Fleet Integration Guide:** For building fleet management card programs.
*   **Processor-Only Issuing Integration Guide:** For scenarios where you manage your own issuing program.
*   **Issuing and Connect Integration:** Setting up Issuing with Stripe Connect for managing funds flows and compliance.
*   **Treasury for Platforms Integration:** General guides on getting started with API access, onboarding users, and managing fraud.
*   **Sample App:** A Next.js sample app demonstrating Issuing and Treasury for Platforms integration.

## Card Management

*   **Virtual Cards:** Creating and displaying virtual card details.
*   **Physical Cards:** Issuing, ordering custom bundles, creating designs, address validation, and shipping physical cards.
*   **Digital Wallets:** Adding Issuing cards to digital wallets like Apple Pay and Google Pay.
*   **Replacement Cards:** Procedures for replacing expired, damaged, lost, or stolen cards.
*   **PIN Management:** Allowing cardholders to manage their personal identification numbers.

## Money Movement with Treasury for Platforms

*   **Financial Accounts:** Understanding the structure and features of financial accounts for platforms and connected accounts.
*   **Moving Money:** Detailed guides on moving money into and out of financial accounts using various methods like InboundTransfers, OutboundPayments, OutboundTransfers, and ReceivedCredits.
*   **Balances and Transactions:** Working with financial account balances and understanding the impact of transactions.
*   **Payouts and Top-ups:** Moving money between payments balance and financial account balances.
*   **Bank Partners:** Information on integrating with bank partners like Fifth Third Bank.
*   **Regulatory Receipts:** Understanding and providing hosted transaction receipts.

## Controls and Security

*   **Spending Controls:** Setting rules on cards and cardholders to control spending by category, country, or amount.
*   **Lifecycle Controls:** Automatically canceling virtual cards after a specified number of payments.
*   **Advanced Fraud Tools:** Utilizing API signals and tooling to identify and prevent transaction fraud.
*   **Real-time Authorizations:** Responding to authorization requests in real-time.
*   **Fraud Challenges:** Implementing an additional layer of verification for authorizations.
*   **3D Secure:** Cardholder authentication for online transactions.
*   **Token Management:** Managing network tokens for secure payments.
*   **Issuing Watchlist:** Understanding the process for screening Issuing users against sanctions lists.
*   **Cardholder Controls:** Ensuring compliance with legal and regulatory guidelines for cardholder information.

## Customer Support

*   **Customer Support for Issuing and Treasury for Platforms:** Resources for resolving common questions and issues.
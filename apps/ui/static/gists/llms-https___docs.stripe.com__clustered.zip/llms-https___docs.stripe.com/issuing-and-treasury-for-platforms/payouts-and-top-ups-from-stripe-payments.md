## Stripe Issuing and Treasury for Platforms

This documentation suite provides comprehensive guidance on utilizing Stripe's Issuing and Treasury for Platforms products. These products empower platforms to embed financial services, such as card issuance and money management, directly into their offerings for their connected accounts.

### Core Functionality and Integration

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing, including how to create, manage, and distribute payment cards programmatically. This section covers the core concepts and benefits of building a commercial card program.
*   **How Issuing Works:** Delve into the mechanics of Stripe Issuing, detailing how to build and scale card programs, issue physical or virtual cards, manage spending, and control transactions in real-time.
*   **Integration Guides:** Access specific guides for integrating Issuing into various use cases:
    *   **Embedded Finance:** Build integrated financial services solutions.
    *   **B2B Payments:** Facilitate business-to-business payments with Issuing.
    *   **Fleet:** Develop fleet management card programs.
*   **Onboarding Overview:** Learn the essential steps and requirements for taking your Issuing or Treasury for Platforms integration live, including use case approval and live mode access.
*   **Sample App:** Explore the Issuing and Treasury for Platforms sample app to understand how to onboard customers, issue cards, and manage outbound payments.

### Card Management

*   **Card Types:** Choose between **Virtual Cards** and **Physical Cards**, understanding the use cases and trade-offs for each.
*   **Physical Card Customization:**
    *   **Choose Card Bundle:** Select standard or custom physical card bundles.
    *   **Order a Custom Bundle:** Guide through the process of ordering custom physical card bundles.
    *   **Customize Card Bundle:** Make specific selections for your card bundle.
    *   **Artwork Templates:** Utilize provided templates for designing your cards.
    *   **Create a Design:** Learn how to create and name your card designs.
    *   **Issue Cards:** Create physical cards for your cardholders.
    *   **Ship Cards:** Understand the options for shipping physical cards.
    *   **Address Validation:** Ensure successful delivery of physical cards with address validation features.
*   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers (PINs).
*   **Replacement Cards:** Learn how to replace expired, damaged, lost, or stolen cards.
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **Token Management:** Understand how to manage network tokens for secure payments.

### Funding and Balances

*   **Issuing Balance:** Learn how to make funds available for card spend by managing your Issuing balance.
*   **Add Funds to Your Card Program:** Explore different funding options, including pull-funded top-ups, push-funded top-ups, Stripe balance transfers, and Connect balance transfers.
*   **Post-funding:** Understand how to post-fund your integration with Stripe, including using Dynamic Reserves for real-time capital management.

### Controls and Fraud Prevention

*   **Manage Fraud:** Discover how to combat transaction fraud using Stripe Issuing's controls and tools.
*   **Spending Controls:** Set rules for cards and cardholders to manage spending by blocking categories, countries, or setting limits.
*   **Lifecycle Controls:** Implement automatic usage-based cancellation of virtual cards for single-use or limited-use scenarios.
*   **Advanced Fraud Tools:** Leverage API signals and tooling to identify and prevent transaction fraud.
*   **Real-time Authorizations:** Approve or decline authorization requests in real-time using synchronous webhooks.
    *   **Migrate to Direct Webhook Response:** Transition from deprecated API calls to direct webhook responses for real-time authorizations.
*   **Authorization Rules:** Limit authorization approvals by configuring custom rules based on various conditions.
*   **Fraud Challenges:** Implement additional verification steps for high-risk authorizations to minimize accidental blocks.
*   **3D Secure:** Understand how to implement cardholder authentication using 3D Secure for online transactions.
*   **Issuing Watchlist:** Learn about the process of screening Issuing users against sanctions lists.

### Stripe Connect Integration

*   **Set up an Issuing and Connect Integration:** Integrate Stripe Issuing with Stripe Connect to issue cards on behalf of connected accounts.
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and the cards issued to them.
*   **Cardholder Controls:** Ensure compliance by managing cardholder information according to legal and regulatory guidelines.
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity affects Issuing capabilities on connected accounts.
*   **Embed Issuing Card Management:** Use Connect embedded components to integrate card management functionality into your website.
*   **Fund Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing.
*   **Update Issuing Terms of Service Acceptance:** Ensure accurate business information is presented for connected accounts.

### Stripe Treasury for Platforms

*   **Treasury for Platforms Overview:** Understand how to provide financial services to connected accounts by embedding financial services into your product.
*   **Treasury for Platforms Requirements:** Familiarize yourself with the compliance requirements and restrictions for using Treasury for Platforms.
*   **Get Started with API Access:** Enable your Stripe account for Issuing and Treasury for Platforms capabilities in a sandbox environment.
*   **Accounts Structure:** Learn how platform and connected accounts interact within Treasury for Platforms.
*   **Financial Account Features:** Understand the features available for financial accounts, enabling money movement and card attachment.
*   **Working with Financial Accounts:** Learn how to provision and manage financial accounts for your platform and connected accounts.
*   **Platform Financial Accounts:** Understand the specific financial account provisioned for your platform.
*   **Working with Balances and Transactions:** Learn about financial account balances and how transactions affect them.
*   **Working with Connected Accounts:** Request the treasury capability and collect onboarding requirements for your connected accounts.
*   **Set up Financial Accounts and Cards:** Follow a sample integration to set up financial accounts and create payment cards.
*   **Using Treasury for Platforms to Move Money:** Explore API endpoints for storing, managing, and moving connected account funds.
*   **Treasury for Platforms Connected Account Onboarding Guide:** Implement a compliant onboarding process for your connected accounts.
*   **Treasury for Platforms Fraud Guide:** Learn best practices for managing fraud within your Treasury for Platforms integration.
*   **Sample App:** Utilize the provided Next.js sample app for Issuing and Treasury for Platforms integrations.
*   **Webhooks:** Understand webhook events for Stripe Issuing and Treasury for Platforms to handle asynchronous operations.
*   **Moving Money:**
    *   **Moving Money Into Financial Accounts:** Learn about InboundTransfer and ReceivedCredit objects.
    *   **Moving Money Out of Financial Accounts:** Explore OutboundTransfer, OutboundPayment, ReceivedDebit, and DebitReversal objects.
    *   **Payouts and Top-ups from Payments Balance:** Understand how to move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated via ACH Notifications of Change.
*   **Money Movement Timelines:** Understand the processing and cutoff times for various money movement methods.
*   **Integrate with Fifth Third Bank:** Learn how to integrate with Fifth Third Bank, a new partner for Treasury for Platforms.
*   **Handling Complaints:** Implement a proper process for handling customer complaints related to Treasury for Platforms or Issuing.
*   **Marketing Treasury for Platforms:** Create compliant messaging for your users, avoiding prohibited terms.
*   **Regulatory Receipts:** Understand hosted transaction receipts for regulated money movements.

### Credit Offerings

*   **Issuing Credit:** Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
*   **Credit Consumer Issuing:** Launch a credit program for your consumers with BIN sponsorship.
*   **Manage Credit Terms:** Update credit limits and terms for connected accounts.
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for your connected accounts.
    *   **Obligation Amounts, Transactions, and Adjustments:** View details about FundingObligations and make adjustments.
    *   **Obligation Payments:** Understand how to collect repayment from connected accounts.
    *   **Available Credit and Flow of Funds:** Learn how funds flow and impact available credit.
*   **Report Other Credit Decisions and Manage Adverse Action Notices:** Record application and decision details, including adverse actions.
*   **Report Required Regulatory Data for Credit Decisions:** Comply with regulatory reporting requirements for credit programs.
*   **Test Credit Integration:** Validate your automated platform funding in testing environments.

### Specific Use Cases and Features

*   **B2B Payments:** Build B2B payment integrations using Stripe Issuing.
*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for instant spending and disbursements.
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.
*   **Processor-Only Issuing:** Integrate with Stripe Issuing where you manage compliance and regulatory requirements.
*   **Global Availability:** Understand how Stripe Issuing supports card programs across different countries.
*   **Issuing Merchant Categories:** Learn about Merchant Category Codes (MCCs) and how to use them for spending controls.
*   **Stablecoin-Backed Cards:** Issue cards backed by stablecoin balances in partnership with Bridge.
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts:** Issue prepaid or debit cards backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrate Stripe Issuing with Bridge for stablecoin-backed card programs.
*   **Customer Support:** Find information on resolving common Issuing and Treasury for Platforms questions.
*   **Product Marketing, Design, and Compliance Guidelines:** Adhere to guidelines for launching compliant Issuing and Treasury programs.
    *   **Issuing Regulated Customer Notices:** Understand how to send regulatory notifications to your customers.
    *   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant.
*   **Use Cards at Automated Teller Machines (ATMs):** Enable ATM cash withdrawals for US-issued cards.
*   **Issuing Authorizations:** Handle authorization requests for card transactions.
*   **Issuing Transactions:** Understand how transaction objects are created after authorizations are captured.
*   **Issuing Disputes:** Learn how to dispute transactions and monitor them through to resolution.
*   **Enriched Merchant Data:** Utilize comprehensive merchant data for fraud prevention and spending controls.
*   **Testing:** Learn how to test your Issuing integration in a sandbox environment.
*   **Issuing Beta Migration Guide:** Migrate from the Issuing beta to the generally available version.
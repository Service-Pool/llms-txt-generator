## Issuing Balance

To spend money using cards, you need to add funds to the Issuing balance on your account. This balance represents funds reserved for Issuing and is safely separated from your earnings, payouts, and funds from other Stripe products.

**Note:** If you use stablecoin balances to fund your Issuing program, see [Spend directly from a non-custodial wallet](https://stripe.com/docs/issuing/stablecoin-cards/spend-from-wallet) to learn how our smart contract works. The methods on this page apply to fiat-funded Issuing programs.

### Push funding

Push funding allows you to transfer funds from an external bank account into your Issuing balance. You can find your bank account and routing information in the Stripe Dashboard to initiate these transfers.

### Pull funding (US-only)

Pull funding is the default funding option in the US and is not available in the EU or the UK. This method requires you to verify your external bank accounts, which may cause a delay in transferring funds (up to 5 business days).

### Using the Stripe Dashboard or API

You can access the bank account and routing information needed to push funds from your external bank account through either the Stripe Dashboard or the API. When your external bank account receives funds, they are immediately available as a top-up to your Stripe Issuing balance.
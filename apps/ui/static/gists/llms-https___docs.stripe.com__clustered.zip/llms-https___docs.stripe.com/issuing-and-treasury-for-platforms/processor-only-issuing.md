## Stripe Issuing & Treasury for Platforms Documentation

This documentation group provides comprehensive guidance on leveraging Stripe Issuing and Treasury for Platforms to build and manage sophisticated card programs and financial services. It caters to platforms looking to embed financial capabilities for their users, covering everything from initial setup and integration to advanced fraud management and money movement.

### Key Areas Covered:

*   **Getting Started with Issuing & Treasury for Platforms:**
    *   **Onboarding Overview:** Understand the steps required to launch your Issuing or Treasury for Platforms integration, including use case approval and going live.
    *   **Integration Guides:** Detailed guides for specific use cases like Embedded Finance, B2B Payments, and Fleet management.
    *   **Sample App:** A practical example to help you understand how to use the APIs for onboarding, card issuance, and payments.
    *   **Testing:** Learn how to test your Issuing integration in a sandbox environment.
    *   **Customer Support:** Information on how to resolve common Issuing and Treasury for Platforms questions.

*   **Issuing Card Management:**
    *   **Card Types:** Guidance on choosing between physical and virtual cards.
    *   **Card Creation & Customization:** Instructions on creating designs, ordering custom bundles, and issuing physical and virtual cards.
    *   **Digital Wallets:** How to integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **PIN Management:** Managing PINs for cardholders.
    *   **Replacement Cards:** Procedures for replacing expired, damaged, lost, or stolen cards.
    *   **Program Management:** Understanding the different operating models for managing your Issuing program (Stripe program management vs. processor-only).

*   **Funding and Money Movement:**
    *   **Issuing Balance:** How to fund your Issuing balance to enable card spend.
    *   **Adding Funds:** Various methods for adding funds to your card program.
    *   **Post-funding:** Options for post-funding your integration with Stripe and Dynamic Reserves.
    *   **Treasury for Platforms:** Comprehensive guides on setting up financial accounts, moving money (inbound and outbound transfers, payments, top-ups), and managing balances and transactions.
    *   **Stablecoin-backed Cards:** Information on issuing cards backed by stablecoin balances.

*   **Controls and Fraud Management:**
    *   **Spending Controls:** Setting rules and limits for card and cardholder spending.
    *   **Lifecycle Controls:** Automatically canceling virtual cards after a specified number of payments.
    *   **Real-time Authorizations:** Handling authorization requests in real-time via webhooks.
    *   **Advanced Fraud Tools:** Utilizing API signals and tooling to identify and prevent transaction fraud.
    *   **Fraud Challenges:** Implementing additional verification steps for high-risk authorizations.
    *   **3D Secure:** Understanding cardholder authentication using 3D Secure.
    *   **Token Management:** Managing network tokens for secure payments.
    *   **Issuing Watchlist:** Understanding Stripe's automatic screening against sanctions lists.
    *   **Fraud Guide (Treasury for Platforms):** Best practices for managing fraud within a Treasury for Platforms context.

*   **Stripe Connect Integration:**
    *   **Setting up Issuing and Connect:** Integrating Issuing with Stripe Connect for platforms.
    *   **Connected Accounts, Cardholders, and Cards:** Managing these entities within a Connect integration.
    *   **Funding Issuing Balances with Connect:** How to fund connected accounts for Issuing.
    *   **Cardholder Controls:** Ensuring compliance with cardholder screening regulations.
    *   **Embedded Components:** Using prebuilt UI components for card management.
    *   **Inactive Account Management:** Handling the disabling of Issuing capabilities for inactive accounts.
    *   **Treasury for Platforms with Connect:** Detailed documentation on account structures, financial accounts, money movement, onboarding, and compliance for Treasury for Platforms.

*   **Credit Features:**
    *   **Issuing Credit:** Overview of credit features for connected accounts.
    *   **Credit Consumer Issuing:** Solutions for launching credit programs for consumers.
    *   **Managing Account Obligations:** Tracking credit spend, lifecycle, and balances.
    *   **Managing Credit Terms:** Configuring credit limits and periods for connected accounts.
    *   **Reporting Credit Decisions:** Recording underwriting decisions and managing adverse action notices.

*   **Compliance and Guidelines:**
    *   **US Compliance:** Product marketing, design, and compliance guidelines for Issuing and Treasury for Platforms in the US.
    *   **EU/UK Marketing Guidance:** Specific marketing guidelines for Issuing programs in the UK and Europe.
    *   **Treasury for Platforms Compliance:** Guidelines for marketing and maintaining compliant Treasury for Platforms programs.
    *   **Regulated Customer Notices:** Understanding and sending regulatory notifications.

This collection of documentation empowers developers and businesses to build robust, compliant, and feature-rich card and financial service offerings using Stripe's Issuing and Treasury for Platforms products.
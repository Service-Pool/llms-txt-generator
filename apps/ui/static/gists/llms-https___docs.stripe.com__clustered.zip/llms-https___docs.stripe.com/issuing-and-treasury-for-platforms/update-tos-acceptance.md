## Issuing and Treasury for Platforms Documentation

This documentation suite provides comprehensive guidance on leveraging Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and integration to advanced features like fraud management, credit offerings, and international expansion.

### Getting Started

*   **Onboarding Overview**: Understand the essential steps to get your Issuing or Treasury for Platforms integration live.
*   **Integration Guides**:
    *   **Embedded Finance**: Build an embedded financial services integration.
    *   **B2B Payments**: Create B2B payment solutions using Issuing.
    *   **Fleet**: Develop fleet financial services integrations.
*   **Sample App**: Explore a sample application to see Issuing and Treasury for Platforms APIs in action.
*   **Customer Support**: Find solutions to common Issuing and Treasury for Platforms questions.

### Core Issuing Features

*   **How Issuing Works**: Get a foundational understanding of Stripe Issuing.
*   **Card Types**:
    *   **Virtual Cards**: Learn about creating and using virtual cards.
    *   **Physical Cards**: Discover options for issuing and managing physical cards, including:
        *   **Artwork Templates**: Design your custom cards.
        *   **Card Bundles**: Customize card, carrier, and envelope options.
        *   **Address Validation**: Ensure successful physical card delivery.
        *   **Issuing Cards**: General information on creating physical cards.
*   **Funding Your Issuing Balance**:
    *   **Issuing Balance**: Understand how to make funds available for card spend.
    *   **Add Funds to Your Card Program**: Explore various funding options.
    *   **Post-fund Your Integration**: Learn about post-funding with Stripe and Dynamic Reserves.
*   **Card Management**:
    *   **Replacement Cards**: Process for replacing expired, damaged, lost, or stolen cards.
    *   **PIN Management**: Allow cardholders to manage their PINs.
    *   **Digital Wallets**: Integrate Issuing cards with Apple Pay and Google Pay.
    *   **Token Management**: Understand how tokens are used for secure payments.

### Advanced Issuing Features & Controls

*   **Spending Controls**: Set rules to manage card and cardholder spending.
*   **Lifecycle Controls**: Implement automatic usage-based card cancellation.
*   **Real-time Authorizations**: Approve or decline authorization requests in real time.
    *   **Quickstart**: Set up and manage real-time authorizations.
    *   **Migrate to Direct Webhook Response**: Transition from deprecated API calls.
*   **Fraud Management**:
    *   **Manage Fraud**: Understand and combat transaction fraud with Stripe Issuing tools.
    *   **Advanced Fraud Tools**: Utilize API signals for fraud prevention.
    *   **Fraud Challenges**: Implement additional verification for authorizations.
    *   **3D Secure**: Learn about cardholder authentication for online transactions.
*   **Merchant Categories**: Understand how businesses are categorized and use this for controls.
*   **Issuing Watchlist**: Learn about Stripe's automatic screening against sanctions lists.
*   **Issuing for Agents**: Provide programmable cards with built-in controls for agents.

### Stripe Connect Integration

*   **Set up an Issuing and Connect Integration**: Integrate Issuing with Stripe Connect for issuing cards to third parties.
*   **Connected Accounts, Cardholders, and Cards**: Understand the relationships and management of these entities within Connect.
*   **Cardholder Controls**: Ensure compliance with cardholder screening requirements.
*   **Inactive Connected Accounts Offboarding**: Manage the process for inactive Issuing accounts.
*   **Connect Funding**: Learn how to fund Issuing balances for connected accounts.
*   **Embed Card Management**: Use prebuilt UI components to embed card management into your website.

### Issuing Credit

*   **Issuing Credit Overview**: Apply your platform's Issuing account balance or exposure limit to connected accounts.
*   **Credit Consumer Issuing**: Launch a credit program for your customers (US only).
    *   **How Credit Consumer Issuing Works**: Understand the features and APIs.
*   **Manage Credit Terms**: Configure credit limits and terms for connected accounts.
*   **Manage Account Obligations**: Track credit spend, lifecycle, and balances for connected accounts.
    *   **Available Credit and Flow of Funds**: Understand how funds flow and available credit.
    *   **Obligation Amounts, Transactions, and Adjustments**: View and adjust Funding Obligation details.
    *   **Obligation Payments**: Manage payments to your Funding Obligation.
*   **Report Other Credit Decisions and Manage Adverse Action Notices**: Record underwriting decisions and send AANs.
*   **Report Required Regulatory Data for Credit Decisions**: Fulfill regulatory reporting requirements.
*   **Test Credit Integration**: Validate your automated platform funding in testing environments.

### Treasury for Platforms

*   **Treasury for Platforms Overview**: Learn how to provide financial services to connected accounts.
*   **How Treasury for Platforms Works**: Understand connected accounts, financial accounts, and money movement.
*   **Eligibility Requirements**: Understand the requirements for using Treasury for Platforms.
*   **Getting Started**:
    *   **Get Started with API Access**: Access Treasury for Platforms via API.
    *   **Onboarding Users**: Implement a Treasury for Platforms onboarding process.
    *   **Sample Integrations**:
        *   **Set up Financial Accounts and Cards**: Follow a sample integration.
        *   **Using Treasury for Platforms to Move Money**: Learn about money movement APIs.
        *   **Issuing and Treasury for Platforms Sample App**: Explore a Next.js sample app.
*   **Account Management**:
    *   **Accounts Structure**: Understand the account components of Treasury for Platforms.
    *   **Working with Connected Accounts**: Request capabilities and collect onboarding requirements.
    *   **Working with Financial Accounts**: Store, send, and receive funds using financial accounts.
    *   **Financial Account Features**: Learn about available features for financial accounts.
    *   **Platform Financial Accounts**: Understand the financial account for your platform.
*   **Moving Money**:
    *   **Money Movement Timelines**: Understand processing and cutoff times.
    *   **Moving Money into Financial Accounts**: Add money using InboundTransfer and ReceivedCredit.
        *   **Moving Money Using InboundTransfer Objects**: Transfer from external US bank accounts.
        *   **Moving Money Using ReceivedCredit Objects**: Receive funds into a financial account.
        *   **Moving Money Using CreditReversal Objects**: Reverse received credits.
    *   **Moving Money Out of Treasury for Platforms**: Transfer funds from financial accounts.
        *   **Moving Money Using OutboundTransfer Objects**: Transfer to external accounts via ACH or wire.
        *   **Moving Money Using OutboundPayment Objects**: Push transfers to third-party accounts.
        *   **Moving Money Using ReceivedDebit Objects**: Observe funds pulled from a financial account.
        *   **Moving Money Using DebitReversal Objects**: Retrieve funds from a ReceivedDebit.
    *   **Payouts and Top-ups from Payments Balance**: Move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts**: Set up money movements.
    *   **ACH NOC and SEC Handling**: Learn how external account information is updated.
*   **Bank Partners**:
    *   **Integrate with Fifth Third Bank**: Add Fifth Third Bank to your integration.
    *   **Build a New Treasury for Platforms Integration with Fifth Third Bank**: Get started with Fifth Third Bank.
*   **Marketing and Compliance**:
    *   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines**: Ensure your program and marketing are compliant.
    *   **Handling Complaints**: Properly handle complaints about Treasury for Platforms or Issuing.
    *   **Marketing Treasury for Platforms**: Create compliant messaging for your users.
    *   **Regulatory Receipts**: Understand hosted transaction receipts.
*   **Managing Fraud**: Best practices for managing fraud as a platform.

### Regional and Compliance Guidelines

*   **Product and Marketing Compliance Guidelines (US)**: Navigate financial regulations for product branding and offering financial services.
*   **Issuing Regulated Customer Notices**: Learn about sending regulatory notifications.
*   **Marketing Guidance (Europe/UK)**: Adhere to guidelines for marketing Issuing programs in the UK and Europe.
*   **Use Stripe Issuing in Different Countries**: Explore global issuing options.

### Testing and Migration

*   **Test Your Issuing Integration**: Simulate purchases and test your integration in a sandbox.
*   **Issuing Beta Migration Guide**: Migrate from the Issuing beta to the generally available version.
*   **Get Started with API Access to Treasury for Platforms**: Test in a sandbox environment.
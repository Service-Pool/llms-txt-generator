## Stripe Issuing and Treasury for Platforms: A Comprehensive Guide

This documentation set provides a detailed overview of Stripe's Issuing and Treasury for Platforms products, enabling businesses to create and manage custom payment card programs and financial services for their users.

### Key Features and Functionality

*   **Issuing Cards:** Create and manage virtual and physical payment cards for your business, employees, or customers. This includes options for customization, card types (virtual/physical), and program management.
*   **Treasury for Platforms:** Embed financial services into your platform, allowing your connected accounts to hold funds, pay bills, earn cash back, and manage their cash flow. This integrates with Stripe Connect to manage funds and compliance.
*   **Connect Integration:** Seamlessly integrate Issuing and Treasury for Platforms with Stripe Connect to manage multiple connected accounts, cardholders, and their associated financial activities.
*   **Money Movement:** Facilitate various money movement operations, including inbound and outbound transfers, payouts, and top-ups, all managed through financial accounts.
*   **Fraud Management:** Leverage Stripe's advanced fraud tools and controls to identify, prevent, and manage transaction fraud, ensuring the security of your card programs.
*   **Customization and Control:** Tailor card programs with features like spending controls, lifecycle controls, real-time authorizations, and PIN management to meet specific business needs.
*   **Compliance and Guidelines:** Adhere to product marketing, design, and compliance guidelines to ensure your Issuing and Treasury for Platforms programs meet regulatory requirements.

### Getting Started

*   **Onboarding Overview:** Understand the essential steps and requirements for launching your Issuing or Treasury for Platforms integration.
*   **Integration Guides:** Explore specific guides for implementing solutions like B2B payments, embedded finance, and fleet management.
*   **Sample App:** Utilize the provided sample app to see Issuing and Treasury for Platforms APIs in action and accelerate your integration.
*   **Testing:** Test your Issuing integration in a sandbox environment to simulate purchases and validate your setup before going live.

### Specific Topics Covered

*   **Card Management:**
    *   Choosing card types (virtual/physical)
    *   Designing and customizing physical cards
    *   Managing card replacements and PINs
    *   Using digital wallets with Issuing
*   **Funding and Balances:**
    *   Adding funds to your Issuing balance
    *   Post-funding your integration with Stripe and Dynamic Reserves
    *   Managing Issuing balances and financial accounts
*   **Connect and Account Management:**
    *   Setting up Issuing and Connect integrations
    *   Managing connected accounts, cardholders, and cards
    *   Handling inactive connected accounts
    *   Understanding account structures and financial account features
*   **Money Movement:**
    *   Moving money into and out of financial accounts
    *   Working with InboundTransfers, OutboundPayments, and OutboundTransfers
    *   Understanding money movement timelines and ACH handling
*   **Credit Programs:**
    *   Issuing Credit solutions for consumer and connected accounts
    *   Managing credit terms, obligations, and available credit
    *   Reporting credit decisions and regulatory data
*   **Fraud and Security:**
    *   Managing fraud with Issuing controls and tools
    *   Implementing advanced fraud tools and real-time authorizations
    *   Utilizing fraud challenges and 3D Secure for authentication
*   **Compliance and Best Practices:**
    *   Adhering to product marketing, design, and compliance guidelines
    *   Managing regulated customer notices and marketing materials
    *   Handling customer complaints and regulatory receipts

This documentation set aims to provide a comprehensive resource for developers and businesses looking to leverage Stripe Issuing and Treasury for Platforms to build innovative financial products and services.
```md
---
title: Moving money using ReceivedCredit objects | Stripe Documentation
---

You can send funds to a financial account with the account’s routing and account numbers for ach and us_domestic_wire, or the financial account ID for transfers between financial accounts.

When funds move into a financial account, Stripe creates a corresponding ReceivedCredit object on the account. A ReceivedCredit contains information on how the funds were sent and from what account, where possible.

When the origin of the funds is another financial account, the ReceivedCredit contains a `linked_flows.source_flow` reference to the originating money movement. In this case, the source OutboundPayment has `stripe` as its network value.

Use `GET /v1/treasury/received_credits/{{RECEIVED_CREDIT_ID}}` to retrieve the ReceivedCredit with the specified ID.

The following request retrieves the ReceivedCredit with the specified ID. The response for this request includes expanded Transaction object details.

```json
{
  "data": [
    {
      "id": "rcd_123",
      "object": "received_credit",
      "amount": 1000,
      "balance_transaction": "bal_123",
      "currency": "usd",
      "description": "Received from Stripe",
      "financial_account": "fa_123",
      "linked_flows": {
        "source_flow": {
          "type": "stripe_outbound_payment",
          "stripe_outbound_payment": {
            "id": "op_123",
            "network": "stripe"
          }
        }
      },
      "status": "succeeded",
      "transaction": "txn_123",
      "type": "stripe_flow"
    }
  ],
  "has_more": false,
  "url": "/v1/treasury/received_credits"
}
```
```
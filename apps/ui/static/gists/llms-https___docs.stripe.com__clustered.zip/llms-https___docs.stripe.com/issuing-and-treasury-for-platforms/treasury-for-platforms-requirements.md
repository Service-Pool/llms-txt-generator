# Stripe Issuing and Treasury for Platforms Documentation

This documentation set covers Stripe Issuing and Treasury for Platforms, providing comprehensive guides for integrating and managing card programs and financial services for connected accounts.

## Key Areas:

*   **Getting Started:**
    *   **Onboarding Overview:** Understand the steps to get your Issuing or Treasury for Platforms integration live.
    *   **Integration Guides:** Explore specific guides for Embedded Finance, B2B Payments, and Fleet integrations.
    *   **Sample App:** Utilize a sample application to understand how to onboard customers, issue cards, and make payments.
    *   **API Access:** Learn how to get started with API access for Treasury for Platforms.
    *   **Sandbox Environments:** Test your integrations in a sandbox environment before going live.

*   **Issuing Cards:**
    *   **How Issuing Works:** Understand the fundamental concepts and architecture of Stripe Issuing.
    *   **Card Types:** Decide between physical and virtual cards for your cardholders.
    *   **Issuing Balance:** Learn how to fund your Issuing balance to enable card spend.
    *   **Card Programs:** Customize your card program to meet your business needs.
    *   **Physical Cards:** Detailed information on creating, designing, and shipping physical cards, including customization options and address validation.
    *   **Virtual Cards:** Learn how to create and display virtual card details.
    *   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers.
    *   **Replacement Cards:** Understand the process for replacing expired, damaged, lost, or stolen cards.

*   **Treasury for Platforms:**
    *   **How Treasury for Platforms Works:** Understand the core components and capabilities of Treasury for Platforms.
    *   **Account Structure:** Learn about the different account types within Treasury for Platforms.
    *   **Financial Accounts:** Understand how to set up and manage financial accounts for your platform and connected accounts.
    *   **Moving Money:** Comprehensive guides on moving money into and out of financial accounts using various methods like ACH, wires, and Stripe network transfers.
    *   **Payouts and Top-ups:** Learn how to manage money movement between payments balances and financial accounts.
    *   **Bank Partners:** Information on integrating with bank partners like Fifth Third Bank.

*   **Stripe Connect Integration:**
    *   **Issuing and Connect:** Set up and manage Issuing integrations with Stripe Connect.
    *   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and cards.
    *   **Funding Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing.
    *   **Cardholder Controls:** Manage cardholder information in compliance with regulations.
    *   **Inactive Connected Accounts:** Understand the offboarding process for inactive accounts.
    *   **Embedded Components:** Embed Issuing card management functionality into your website.
    *   **Treasury for Platforms with Connect:** Comprehensive guides on using Treasury for Platforms with Stripe Connect, including account management, money movement, and onboarding.

*   **Controls and Fraud Management:**
    *   **Manage Fraud:** Understand how to combat transaction fraud using Stripe Issuing controls and tools.
    *   **Spending Controls:** Set rules on cards and cardholders to control spending.
    *   **Lifecycle Controls:** Control automatic usage-based cancellation of cards.
    *   **Real-time Authorizations:** Approve or decline authorization requests in real time.
    *   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud.
    *   **Authorization Rules:** Limit authorization approvals using custom Issuing authorization rules.
    *   **Fraud Challenges:** Implement additional verification steps for high-risk authorizations.
    *   **3D Secure:** Learn about cardholder authentication using 3D Secure for online transactions.
    *   **Token Management:** Manage network tokens on your cards.

*   **Credit Products:**
    *   **Issuing Credit:** Understand how to apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
    *   **Credit Consumer Issuing:** Create, launch, and manage a credit program for your consumers.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Manage Credit Terms:** Configure credit terms for connected accounts.
    *   **Available Credit and Flow of Funds:** Understand how funds flow and how available credit impacts authorization declines.
    *   **Reporting Credit Decisions:** Report credit decisions and manage adverse action notices.
    *   **Regulatory Data Reporting:** Report required regulatory data for credit decisions.
    *   **Test Credit Integration:** Validate your automated platform funding in testing environments.

*   **Purchases and Transactions:**
    *   **Authorizations:** Handle authorization requests for card purchases.
    *   **Transactions:** Understand how authorizations become transactions.
    *   **Disputes:** Learn how to dispute transactions.
    *   **Enriched Merchant Data:** Use comprehensive merchant data to understand spending patterns and prevent fraud.
    *   **ATM Usage:** Understand how to use Issuing cards at ATMs.

*   **Compliance and Guidelines:**
    *   **Product Marketing, Design, and Compliance Guidelines:** Adhere to guidelines for launching and maintaining compliant Issuing and Treasury programs.
    *   **Marketing Guidance (Europe/UK):** Understand marketing guidelines for Issuing programs in the UK and Europe.
    *   **Customer Communications:** Learn about sending regulated customer notices.
    *   **Treasury for Platforms Requirements:** Understand the compliance requirements and restrictions for using Treasury for Platforms.

*   **Customer Support:**
    *   **Customer Support for Issuing and Treasury for Platforms:** Find solutions to common Issuing and Treasury for Platforms questions and issues.
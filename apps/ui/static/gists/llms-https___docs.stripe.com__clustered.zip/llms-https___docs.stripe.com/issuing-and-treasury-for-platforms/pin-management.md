## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite covers Stripe's Issuing and Treasury for Platforms products, designed to help businesses embed financial services into their own applications and platforms. It provides comprehensive guides on issuing cards, managing funds, handling transactions, and ensuring compliance.

### Core Concepts & Getting Started

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing and how it can be used to create and manage payment cards for your business or customers.
*   **Treasury for Platforms Overview:** Learn how to offer financial services to your connected accounts, enabling them to hold funds, pay bills, and manage cash flow.
*   **How Issuing Works:** Delve into the mechanics of Stripe Issuing, including card creation, spending controls, and transaction authorization.
*   **How Treasury for Platforms Works:** Understand the architecture of Treasury for Platforms, including connected accounts, financial accounts, and money movement.
*   **Integration Guides:**
    *   **Embedded Finance:** Build integrated financial services for your customers.
    *   **B2B Payments:** Create a B2B payments integration using Stripe Issuing.
    *   **Fleet:** Develop a fleet financial services integration.
*   **Onboarding Overview:** Navigate the process of getting your Issuing or Treasury for Platforms integration live.
*   **Customer Support:** Find resources and guidance for resolving common Issuing and Treasury for Platforms issues.
*   **Sample App:** Explore a sample application to see Issuing and Treasury for Platforms APIs in action.
*   **Testing Your Integration:** Learn how to test your Issuing and Treasury for Platforms integrations in a sandbox environment.
*   **Beta Migration Guide:** Understand how to migrate from the Issuing beta to the generally available product.

### Issuing Cards

*   **Choose Card Type:** Decide between physical and virtual cards for your cardholders.
    *   **Virtual Cards:** Learn about creating and managing virtual cards.
    *   **Physical Cards:** Explore options for issuing physical cards.
        *   **Choose Card Bundle:** Select standard or custom physical card bundles.
        *   **Customize Card Bundle:** Make selections for your card bundle.
        *   **Artwork Templates:** Design your custom card artwork.
        *   **Create a Design:** Guide to creating and naming your card design.
        *   **Issue Cards:** Create physical cards for cardholders.
        *   **Ship Cards:** Understand shipping options for physical cards.
        *   **Address Validation:** Ensure successful delivery of physical cards.
*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for users to receive and spend money.
*   **Credit Consumer Issuing:** Learn about the private preview for a credit program for your customers.
*   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers.
*   **Replacement Cards:** Understand the process for replacing expired, damaged, lost, or stolen cards.

### Funding and Balances

*   **Issuing Balance:** Make funds available for card spend.
*   **Add Funds to Your Card Program:** Explore options for funding your Issuing balance.
*   **Post-fund Your Integration with Stripe:** Accrue a negative Issuing balance and fund Stripe later.
*   **Post-fund Your Integration with Dynamic Reserves:** Use dynamic reserves to post-fund card spend.

### Integrations with Stripe Connect

*   **Set up an Issuing and Connect Integration:** Issue cards on connected accounts.
*   **Connected Accounts, Cardholders, and Cards:** Create and manage cardholders and cards with Stripe Connect.
*   **Cardholder Controls:** Understand how cardholder controls affect your integration and compliance.
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity affects connected accounts' Issuing capabilities.
*   **Fund Issuing Balances with Connect:** Allocate funds to connected accounts' Issuing balances.
*   **Embed Issuing Card Management:** Use prebuilt UI components to embed card management into your website.

### Controls and Fraud Management

*   **Manage Fraud:** Understand transaction fraud and how to combat it with Stripe Issuing controls.
*   **Advanced Fraud Tools:** Reduce fraud with Issuing's advanced tooling and API signals.
*   **Issuing Authorization Rules:** Limit authorization approvals using custom rules.
*   **Real-Time Authorizations:** Approve or decline authorization requests in real time using webhooks.
    *   **Migrate to Direct Webhook Response:** Transition from deprecated API calls to direct webhook responses.
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations.
*   **Spending Controls:** Set rules on cards and cardholders to control spending.
*   **Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards.
*   **Token Management:** Manage network tokens on your cards for secure payments.
*   **Issuing Watchlist:** Understand the process for screening Issuing users against sanctions lists.

### Purchases and Transactions

*   **Issuing Authorizations:** Handle authorization requests when a card is used for a purchase.
*   **Issuing Transactions:** Understand the Transaction object created after an authorization is captured.
*   **Issuing Disputes:** Learn how to dispute transactions.
*   **Enriched Merchant Data:** Use comprehensive merchant data to understand spending patterns and prevent fraud.
*   **Use Cards at Automated Teller Machines (ATMs):** Enable and use US-issued cards for ATM cash withdrawals.

### Credit Products

*   **Issuing Credit Overview:** Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Available Credit and Flow of Funds:** Understand how funds flow and available credit impacts declines.
    *   **Obligation Payments:** Manage payments to your Funding Obligation.
    *   **Obligation Amounts, Transactions, and Adjustments:** View Funding Obligation details and make adjustments.
*   **Manage Credit Terms:** Update credit limits and terms for connected accounts.
*   **Report Other Credit Decisions and Manage Adverse Action Notices:** Record application and decision details, and send adverse action notices.
*   **Report Required Regulatory Data for Credit Decisions:** Upload regulatory reporting data for credit decisions.
*   **Test Credit Integration:** Validate your automated platform funding in testing environments.

### Treasury for Platforms Specifics

*   **Get Started with API Access:** Test Treasury for Platforms functionality in a sandbox environment.
*   **Accounts Structure:** Understand the account components of Treasury for Platforms.
*   **Working with Connected Accounts:** Request the treasury capability and collect onboarding requirements.
*   **Working with Financial Accounts:** Use financial accounts to store, send, and receive funds.
*   **Financial Account Features:** Learn about features available for financial accounts.
*   **Platform Financial Accounts:** Understand the financial account provisioned for your platform.
*   **Working with Balances and Transactions:** Learn about financial account balances and transaction effects.
*   **Moving Money:**
    *   **Moving Money into Financial Accounts:** Add money using InboundTransfer and ReceivedCredit objects.
        *   **Moving money using InboundTransfer objects:** Transfer money from an external US bank account.
        *   **Moving money using ReceivedCredit objects:** Move money into a financial account from another account.
        *   **Moving money using CreditReversal objects:** Return funds from received credits.
    *   **Moving Money Out of Treasury for Platforms:** Move funds from a financial account to another account.
        *   **Moving money using OutboundTransfer objects:** Transfer funds to an external bank account you own.
        *   **Moving money using OutboundPayment objects:** Create outbound payments to third parties.
        *   **Moving money using ReceivedDebit objects:** Observe funds pulled from a financial account.
        *   **Moving money using DebitReversal objects:** Retrieve funds taken from a financial account.
    *   **Payouts and Top-ups from Payments Balance:** Move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated.
*   **Money Movement Timelines:** Understand processing and cutoff times for money movement.
*   **Integrate with Fifth Third Bank:** Add Fifth Third Bank to your Treasury for Platforms integration.
*   **Build a New Treasury for Platforms Integration with Fifth Third Bank:** Get started with Treasury for Platforms using Fifth Third Bank.
*   **Treasury for Platforms Requirements:** Understand compliance requirements and restrictions.
*   **Marketing and Compliance Guidelines:** Keep your Treasury for Platforms program and marketing compliant.
*   **Handling Complaints:** Properly handle complaints about Treasury for Platforms or Issuing.
*   **Marketing Treasury for Platforms:** Create compliant messaging for your users.
*   **Regulatory Receipts:** Learn about hosted transaction receipts.
*   **Sample Integrations:**
    *   **Use Treasury for Platforms and Issuing to set up financial accounts and cards:** Follow a sample integration.
    *   **Using Treasury for Platforms to Move Money:** Learn about basic money movement.
    *   **Treasury for Platforms Connected Account Onboarding Guide:** Implement an onboarding process for connected accounts.
    *   **Treasury for Platforms Fraud Guide:** Learn best practices for managing fraud.
    *   **Issuing and Treasury for Platforms Sample App:** Use a Next.js sample app for your integration.
    *   **Webhooks for Stripe Issuing and Treasury for Platforms:** Understand webhook events.

### Compliance and Guidelines

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US):** Launch and maintain compliant Issuing and Treasury programs.
*   **Issuing Regulated Customer Notices:** Understand sending regulatory notifications to your customers.
*   **Stripe Issuing Marketing Guidelines (UK & Europe):** Adhere to marketing guidelines for Issuing programs in the UK and Europe.

### Specific Use Cases

*   **Issuing for Your Business:** Programmatically create virtual cards for your business.
*   **B2B Payments Integration Guide:** Build a B2B payments integration with Issuing.
*   **Embedded Finance Integration Guide:** Build an embedded financial services integration.
*   **Fleet Integration Guide:** Build a fleet financial services integration.
*   **Issuing for Agents:** Issue programmable cards with built-in controls for agents.
*   **Stablecoin-backed Cards:**
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts:** Issue cards backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrate with Bridge for stablecoin-backed card programs.
    *   **Stablecoin-backed card issuing:** Issue prepaid or debit cards backed by stablecoin balances.
*   **Issuing and Treasury for platforms sample app:** Use the sample app to onboard customers, issue cards, and make outbound payments.
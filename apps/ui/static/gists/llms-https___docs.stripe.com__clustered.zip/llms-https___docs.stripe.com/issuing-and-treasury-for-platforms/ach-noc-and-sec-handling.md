## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite covers Stripe's Issuing and Treasury for Platforms products, providing comprehensive guides for developers and businesses looking to integrate and manage card programs and financial services.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing, how it works, and its capabilities for creating, managing, and distributing payment cards for your business or users.
*   **Treasury for Platforms Overview:** Learn how to embed financial services into your product using Stripe Treasury for Platforms, enabling connected accounts to hold funds, pay bills, and manage cash flow.
*   **Integration Guides:**
    *   **Embedded Finance:** Build an integrated financial services offering.
    *   **B2B Payments:** Create a B2B payments integration using Stripe Issuing.
    *   **Fleet:** Develop a fleet financial services integration.
*   **Onboarding Overview:** Prepare for and launch your Issuing or Treasury for Platforms integration, covering essential steps for going live.
*   **Customer Support:** Find resources and guidance for resolving common Issuing and Treasury for Platforms questions.
*   **Sample App:** Explore the Issuing and Treasury for Platforms sample app to understand API usage for onboarding, card issuance, and payments.
*   **Testing:** Learn how to test your Issuing integration in a sandbox environment.
*   **Beta Migration Guide:** Understand how to migrate from the Issuing beta to the generally available version.

### Issuing Card Management

*   **Choose Card Type:** Decide between physical and virtual cards for your cardholders.
*   **Virtual Cards:** Learn how to create and display virtual card details.
*   **Physical Cards:**
    *   **Choose Card Bundle:** Select standard or custom physical card bundles.
    *   **Order Custom Bundle:** Guide through the process of ordering a custom physical card bundle.
    *   **Create Design:** Design your physical cards using provided templates.
    *   **Artwork Templates:** Access design templates for cards, carriers, and envelopes.
    *   **Address Validation:** Ensure successful delivery of physical cards with address normalization and validation.
    *   **Issue Cards:** Create physical cards for your cardholders.
    *   **Ship Cards:** Understand shipping options for physical cards.
*   **Replacement Cards:** Learn how to replace expired, damaged, lost, or stolen cards.
*   **PIN Management:** Allow cardholders to manage their personal identification numbers.
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **Token Management:** Understand how to manage network tokens for enhanced security.

### Issuing Program Management and Customization

*   **Program Management:** Choose between Stripe program management and processor-only models.
*   **Processor-Only Issuing:** Integrate Issuing where you manage regulatory requirements, compliance, and licensing.
*   **Customize Your Card Program:** Tailor your Stripe Issuing card program to meet specific business needs.
*   **Add Funds to Your Card Program:** Explore options for funding your Issuing balance.
*   **Issuing Balance:** Learn how to make funds available for your cards.
*   **Post-fund Your Integration:**
    *   **Postfund with Stripe:** Accrue a negative Issuing balance and fund Stripe later.
    *   **Postfund with Dynamic Reserves:** Use dynamic reserves to post-fund card spend.
*   **Issuing Merchant Categories:** Understand Merchant Category Codes (MCCs) and their use in spending controls.
*   **Global Availability:** Learn about using Stripe Issuing in different countries and regions.

### Issuing Controls and Fraud Management

*   **Manage Fraud:** Understand transaction fraud risks and how to combat them using Stripe's tools.
*   **Advanced Fraud Tools:** Reduce fraud with Issuing's advanced tooling and API signals.
*   **Issuing Authorization Rules:** Limit authorization approvals using custom rules.
*   **Real-Time Authorizations:** Approve or decline authorization requests in real-time using webhooks.
    *   **Quickstart:** Get started with real-time authorizations.
    *   **Migrate to Direct Webhook Response:** Transition from deprecated API calls to direct webhook responses.
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations.
*   **3D Secure:** Learn about cardholder authentication using 3D Secure for online transactions.
*   **Spending Controls:** Set rules on cards and cardholders to control spending.
*   **Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards.

### Issuing with Stripe Connect

*   **Set Up Issuing and Connect Integration:** Integrate Stripe Issuing with Stripe Connect to manage funds flows and compliance.
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and cards in a Connect integration.
*   **Fund Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing.
*   **Cardholder Controls:** Ensure compliance with cardholder screening and validation requirements.
*   **Inactive Connected Accounts Offboarding:** Understand how inactivity affects Issuing capabilities on connected accounts.
*   **Embed Issuing Card Management:** Use prebuilt UI components to embed card management into your website.

### Issuing Credit Programs

*   **Credit Consumer Issuing:** Launch a credit program for your consumers.
*   **How Consumer Credit Issuing Works:** Understand the features and APIs for managing a consumer credit program.
*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for instant spending and rewards.
*   **Manage Credit Terms:** Configure credit limits and terms for connected accounts.
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Obligation Amounts, Transactions, and Adjustments:** View details of Funding Obligations and make adjustments.
    *   **Obligation Payments:** Learn how to make payments to your Funding Obligation.
    *   **Available Credit and Flow of Funds:** Understand how funds flow and impact available credit.
*   **Report Other Credit Decisions and Manage Adverse Action Notices:** Record credit decisions and send adverse action notices.
*   **Report Required Regulatory Data for Credit Decisions:** Comply with regulatory reporting requirements for credit programs.
*   **Test Credit Integration:** Validate your automated platform funding in testing environments.
*   **Issuing Credit:** Apply your platform's Issuing balance or exposure limit to cards issued to connected accounts.

### Treasury for Platforms - Core Functionality

*   **Treasury for Platforms Overview:** Understand the core features and benefits of Treasury for Platforms.
*   **Eligibility Requirements:** Review the criteria for using Treasury for Platforms.
*   **Get Started with API Access:** Gain API access to Treasury for Platforms and test in a sandbox.
*   **Onboarding Users:** Implement a compliant onboarding process for connected accounts.
*   **Managing Fraud:** Learn best practices for managing fraud with Treasury for Platforms.
*   **Marketing and Compliance Guidelines:** Ensure your program and marketing campaigns are compliant.
    *   **Regulatory Receipts:** Understand hosted transaction receipts for regulated money movements.
    *   **Handling Complaints:** Properly handle complaints related to Treasury for Platforms or Issuing.
    *   **Marketing Treasury for Platforms:** Create compliant messaging for your users.
*   **Sample Integrations:**
    *   **Set Up Financial Accounts and Cards:** Follow a sample integration to set up financial accounts and cards.
    *   **Using Treasury for Platforms to Move Money:** Learn basic money movement using Treasury endpoints.
    *   **Issuing and Treasury for Platforms Sample App:** Use the Next.js sample app for Issuing and Treasury for Platforms.
    *   **Webhooks:** Understand webhook events for Issuing and Treasury for Platforms.
*   **Account Management:**
    *   **Accounts Structure:** Understand the account components of Treasury for Platforms.
    *   **Working with Connected Accounts:** Request capabilities and collect onboarding requirements for connected accounts.
    *   **Working with Financial Accounts:** Use financial accounts to store, send, and receive funds.
    *   **Financial Account Features:** Learn about features available for financial accounts.
    *   **Platform Financial Accounts:** Understand the financial account provisioned for your platform.
    *   **Working with Balances and Transactions:** Learn about financial account balances and transaction effects.
*   **Moving Money:**
    *   **Payouts and Top-ups from Payments Balance:** Move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated.
    *   **Moving Money into Financial Accounts:** Add money to financial accounts using InboundTransfer and ReceivedCredit.
    *   **Moving Money Out of Treasury for Platforms:** Transfer funds from financial accounts using various methods.
*   **Bank Partners:**
    *   **Integrate with Fifth Third Bank:** Add Fifth Third Bank to your Treasury for Platforms integration.
    *   **Build a New Treasury for Platforms Integration with Fifth Third Bank:** Get started with Treasury for Platforms using Fifth Third Bank.

### Specific Use Cases and Features

*   **B2B Payments:** Build a B2B payments integration with Issuing.
*   **Fleet:** Build a Fleet financial services integration with Issuing.
*   **Issuing for your business:** Programmatically create virtual cards for your business expenses.
*   **Issuing watchlist:** Understand the Issuing watchlist process and best practices.
*   **Issuing for agents:** Issue programmable cards with built-in controls for agents.
*   **Stablecoin-backed cards:**
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts:** Issue cards backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrate Stripe Issuing with Bridge for stablecoin-backed card programs.
    *   **Stablecoin-backed card issuing:** Issue prepaid or debit cards backed by stablecoin balances.
*   **Credit Consumer Issuing:** Launch a credit program for your customers.
*   **Issuing and Treasury product marketing, design, and compliance guidelines (US):** Launch and maintain compliant Issuing and Treasury programs in the US.
*   **Issuing regulated customer notices:** Comply with regulations by sending customer communications.
*   **Stripe Issuing marketing guidelines (Europe/UK):** Adhere to marketing guidelines for Issuing programs in the UK and Europe.
*   **Use cards at automated teller machines (ATMs):** Enable and use US-issued cards for ATM cash withdrawals.
*   **Issuing authorizations:** Handle authorization requests for card transactions.
*   **Issuing disputes:** Dispute transactions through the Dashboard or API.
*   **Enriched merchant data:** Use comprehensive merchant data for fraud prevention and insights.
*   **Issuing transactions:** Understand how transactions are created after authorization.
*   **Issuing Connect:** Set up an Issuing and Connect integration.
*   **Update Issuing terms of service acceptance:** Present accurate business information and accept terms.
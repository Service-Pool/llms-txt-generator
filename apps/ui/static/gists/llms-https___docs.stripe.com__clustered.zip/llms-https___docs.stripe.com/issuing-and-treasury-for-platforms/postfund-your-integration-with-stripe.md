```markdown
## Post-funding Your Stripe Integration

This section covers how to post-fund your Stripe Issuing integration, allowing you to accrue a negative Issuing balance on card spend and settle with Stripe at a later time. This approach offers flexibility by enabling funding after card authorizations are captured rather than requiring pre-funding.

### Understanding Post-funding

Post-funding allows you to defer the settlement of card spend. Instead of pre-funding your Issuing balance before any card activity occurs, you can allow card spend to accrue a negative balance. Stripe will then notify you daily of the amount owed, and you can settle this amount via a same-day wire transfer before a specified deadline to avoid late fees and penalties.

### Key Concepts

*   **Accrue Negative Balance:** Card transactions will reduce your Issuing balance below zero.
*   **Daily Reconciliation:** Stripe will inform you of the total amount owed each day.
*   **Same-Day Wire Transfer:** You can settle the owed amount via a same-day wire transfer.
*   **Settlement Deadline:** A daily deadline (typically 20:00 UTC) must be met to avoid additional fees.

### Post-funding with Connect

If you are a Connect platform, the post-funding process applies to your connected accounts. You will receive notifications regarding the amounts owed by your connected accounts and will be responsible for facilitating the settlement.

### Dynamic Reserves

Stripe also offers Dynamic Reserves, a feature that allows platforms to adjust their own credit limits in real-time. This helps manage cash flow between Stripe and the funds available for authorization, controlling capital usage, minimizing funding costs, and managing unexpected volatility. Dynamic reserves enable your connected accounts to accrue a negative Issuing balance and post-fund Stripe later.
```
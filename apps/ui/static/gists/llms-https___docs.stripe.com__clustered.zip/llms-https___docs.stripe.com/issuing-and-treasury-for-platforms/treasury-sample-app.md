## Stripe Issuing and Treasury for Platforms

This documentation suite covers Stripe's Issuing and Treasury for Platforms products, offering comprehensive guides for businesses looking to embed financial services into their offerings.

### Core Functionality

*   **Stripe Issuing:** Enables businesses to programmatically create, manage, and distribute payment cards for their users or internal use. This includes options for physical and virtual cards, customizable designs, real-time transaction approvals, and robust fraud management tools.
*   **Stripe Treasury for Platforms:** Provides a suite of APIs for Stripe Connect platforms to embed financial services into their products. This allows connected accounts to hold funds, pay bills, earn cash back, and manage their cash flow through financial accounts.

### Key Areas Covered

This documentation is organized into several key areas:

#### Getting Started and Onboarding

*   **Onboarding Overview:** General steps and requirements for launching an Issuing or Treasury for Platforms integration.
*   **Integration Guides:** Specific guides for various use cases, including:
    *   Embedded Finance
    *   B2B Payments
    *   Fleet Management
*   **Sample Applications:** Practical examples and code to help you start integrating, including a sample app for Issuing and Treasury for Platforms.
*   **Testing:** Guidance on how to test your Issuing integration in a sandbox environment.

#### Card Management and Issuance

*   **Card Types:** Information on choosing between physical and virtual cards.
*   **Physical Cards:** Detailed guides on ordering custom bundles, creating designs, issuing cards, and shipping.
*   **Virtual Cards:** How to create and manage virtual cards.
*   **Digital Wallets:** Integrating Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **Replacement Cards:** Procedures for replacing expired, damaged, lost, or stolen cards.
*   **PIN Management:** How cardholders can manage their Personal Identification Numbers.

#### Funding and Money Movement

*   **Issuing Balance:** Understanding and funding your Issuing balance for card spend.
*   **Adding Funds:** Options for funding your Issuing balance, including pull-funded, push-funded, and balance transfers.
*   **Post-funding:** How to post-fund your integration with Stripe, including using Dynamic Reserves.
*   **Treasury for Platforms Money Movement:** Comprehensive guides on moving money into and out of financial accounts, including:
    *   Inbound Transfers
    *   Outbound Payments and Transfers
    *   Received Credits and Debits
    *   Credit Reversals and Debit Reversals
    *   Payouts and top-ups from Stripe Payments

#### Connect Integrations

*   **Issuing with Connect:** Setting up Issuing integrations with Stripe Connect to issue cards to third parties.
*   **Treasury for Platforms with Connect:** Detailed information on using Treasury for Platforms with Stripe Connect, including:
    *   Account structures
    *   Financial account features
    *   Working with connected accounts and financial accounts
    *   Enabling Issuing cards for connected accounts
    *   Platform financial accounts
    *   Onboarding users
    *   Managing fraud
    *   Marketing and compliance guidelines
    *   Handling complaints
    *   Regulatory receipts

#### Controls and Fraud Management

*   **Manage Fraud:** Strategies and tools for combating transaction fraud with Stripe Issuing.
*   **Advanced Fraud Tools:** Utilizing API signals and tooling to identify and prevent fraud.
*   **Issuing Authorization Rules:** Limiting authorization approvals with custom rules.
*   **Real-time Authorizations:** Handling authorization requests in real-time using webhooks.
*   **Fraud Challenges:** Implementing additional verification steps for high-risk transactions.
*   **Spending Controls:** Setting rules and limits to control cardholder spending.
*   **Lifecycle Controls:** Automating card cancellation based on usage.
*   **Token Management:** Managing network tokens for secure payments.
*   **Issuing Watchlist:** Understanding Stripe's screening process against sanctions lists.

#### Credit and Financial Services

*   **Issuing Credit:** Applying platform balances or exposure limits to cards issued to connected accounts.
*   **Credit Consumer Issuing:** Solutions for launching credit programs for consumers.
*   **Manage Credit Terms:** Configuring credit limits and periods for connected accounts.
*   **Manage Account Obligations:** Tracking credit spend, lifecycle, and balances for connected accounts.
*   **Available Credit and Flow of Funds:** Understanding how credit availability changes and impacts authorizations.

#### Customization and Program Management

*   **Customize Your Card Program:** Tailoring your Stripe Issuing card program to business needs.
*   **Program Management:** Choosing between Stripe program management and processor-only models.
*   **Processor-only Issuing:** Integrating as a processor for Issuing programs.

#### Compliance and Guidelines

*   **Product Marketing, Design, and Compliance Guidelines:** Adhering to regulations for Issuing and Treasury for Platforms.
*   **Marketing Guidance (Europe/UK):** Specific marketing guidelines for Issuing programs in the UK and Europe.
*   **Issuing Regulated Customer Notices:** Sending required regulatory notifications to customers.

#### Specific Use Cases and Features

*   **B2B Payments:** Building B2B payment integrations with Issuing.
*   **Fleet Integration:** Creating fleet financial services integrations with Issuing.
*   **Consumer Prepaid Debit Cards:** Issuing prepaid debit cards for various use cases.
*   **Stablecoin-backed Cards:** Issuing cards backed by stablecoin balances.
*   **Issuing for Agents:** Providing programmable cards with built-in controls for agents.
*   **Merchant Categories:** Understanding MCCs for spending controls.
*   **ATM Usage:** Using Issuing cards for ATM cash withdrawals.
*   **3D Secure:** Cardholder authentication for online transactions.
*   **Issuing Elements:** Displaying card details in a PCI-compliant way.

This comprehensive documentation suite aims to equip developers and businesses with the knowledge and tools necessary to successfully implement and manage Stripe Issuing and Treasury for Platforms solutions.
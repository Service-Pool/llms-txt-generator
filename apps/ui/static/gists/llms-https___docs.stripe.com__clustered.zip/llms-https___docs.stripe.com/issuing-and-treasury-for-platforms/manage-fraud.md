## Stripe Issuing and Treasury for Platforms: Comprehensive Guide

This documentation suite provides in-depth guidance on utilizing Stripe Issuing and Treasury for Platforms to build and manage sophisticated financial services for your business and customers. It covers everything from initial setup and integration to advanced features like fraud management, credit offerings, and global expansion.

---

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing for creating, managing, and distributing payment cards.
*   **How Issuing Works:** Delve into the mechanics of building and scaling a card program, including partnerships with banks and card networks.
*   **Onboarding Overview:** Learn the essential steps and requirements to get your Issuing or Treasury for Platforms integration live.
*   **Treasury for Platforms Overview:** Discover how to embed financial services into your platform, enabling connected accounts to hold funds, pay bills, and manage cash flow.
*   **Get Started with API Access to Treasury for Platforms:** Begin your integration journey by setting up sandbox environments and requesting capabilities.
*   **Treasury for Platforms Requirements:** Understand the compliance requirements and restrictions for both platforms and connected accounts using Treasury for Platforms.
*   **Integration Guides:** Explore specific guides for integrating Issuing for various use cases:
    *   **Embedded Finance Integration Guide:** Build an embedded financial services offering.
    *   **B2B Payments Integration Guide:** Create cards for business, employee, or contractor purchases.
    *   **Fleet Integration Guide:** Develop a fleet financial services integration.
*   **Issuing for your business:** Programmatically create virtual cards for your business, employees, contractors, or AI agents.
*   **Customer Support for Issuing and Treasury for Platforms:** Find resources to resolve common issues and questions.

---

### Card Management and Issuance

*   **Choose which type of card to issue:** Decide between physical and virtual cards, understanding the trade-offs and use cases.
*   **Virtual cards with Issuing:** Learn how to create and display virtual card details.
    *   **Create virtual cards:** Step-by-step guide to issuing virtual cards.
*   **Physical cards:** Explore options for issuing physical cards, from standard to fully custom designs.
    *   **Choose your physical bundle:** Set up standard or custom physical card bundles.
    *   **Customize card bundle:** Make your physical card bundle selections.
    *   **Artwork templates:** Utilize provided design templates for cards, carriers, and envelopes.
    *   **Create a design:** Design and name your card bundle.
    *   **Issue cards:** Create physical cards for cardholders.
    *   **Ship cards:** Select shipping speeds for your cards.
    *   **Address validation:** Enable and manage address validation for physical card delivery.
*   **Replacement cards:** Learn how to replace expired, damaged, lost, or stolen cards.
*   **PIN management:** Allow cardholders to manage their personal identification numbers.
*   **Use digital wallets with Issuing:** Integrate cards with digital wallets like Apple Pay and Google Pay.
*   **Token management:** Understand how to manage network tokens on your cards.

---

### Funding and Balances

*   **Fund your Issuing balance:** Make funds available for card spend.
    *   **Issuing balance:** Learn how to make funds available to your cards.
    *   **Add funds to your card program:** Explore options for funding your Issuing balance.
    *   **Postfund your integration with Stripe:** Accrue a negative Issuing balance on card spend and postfund Stripe later.
    *   **Post-fund your integration with Dynamic Reserves:** Use dynamic reserves to post-fund card spend.
*   **Fund Issuing balances with Connect:** Learn how to fund connected accounts for Issuing.

---

### Controls and Fraud Management

*   **Manage fraud with Stripe Issuing controls and tools:** Understand and combat transaction fraud.
*   **Advanced fraud tools:** Reduce fraud with Issuing’s advanced tooling and API signals.
*   **Issuing authorization rules:** Limit authorization approvals using custom rules.
*   **Issuing lifecycle controls:** Control automatic usage-based cancellation of cards.
*   **Issuing spending controls:** Set rules on cards and cardholders to control spending by category, country, or amount.
*   **Fraud challenges:** Turn on additional verification layers for authorizations.
*   **Cardholder authentication using 3D Secure:** Implement 3D Secure for enhanced online transaction security.
*   **Issuing real-time authorizations:** Approve or decline authorization requests in real time using synchronous webhooks.
    *   **Migrate to direct webhook response:** Transition real-time authorizations to direct webhook responses.
*   **Issuing watchlist:** Understand the process for screening Issuing users against sanctions lists.

---

### Stripe Connect Integration

*   **Set up an Issuing and Connect integration:** Issue cards on connected accounts for third parties.
*   **Connected accounts, cardholders, and cards:** Create and manage cardholders and cards with Stripe Connect.
*   **Cardholder controls:** Ensure compliance with legal and regulatory guidelines for cardholder information.
*   **Inactive connected accounts offboarding:** Understand how inactivity affects connected account Issuing capabilities.
*   **Embed Issuing card management into your website:** Use prebuilt UI components for card management within your website.
*   **Fund Issuing balances with Connect:** Learn how to fund connected accounts for Issuing.
*   **Update the Issuing terms of service acceptance:** Present accurate business information and accept Issuing terms of service for connected accounts.

---

### Credit Offerings

*   **Issuing Credit:** Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
*   **Credit Consumer Issuing:** Launch a credit program for your customers.
    *   **How Credit Consumer Issuing works:** Understand the features and APIs for managing a credit program.
*   **Manage credit terms:** Update credit limits and terms for connected accounts.
*   **Manage account obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Obligation amounts, transactions, and adjustments:** View FundingObligation details and make adjustments.
    *   **Obligation payments:** Make payments to your FundingObligation.
    *   **Available credit and flow of funds:** Understand how funds flow and use the available credit field.
*   **Report other credit decisions and manage adverse action notices:** Record application and decision details, and send adverse action notice emails.
*   **Report required regulatory data for credit decisions:** Fulfill regulatory reporting requirements for credit programs.
*   **Test credit integration:** Validate your automated platform funding in testing environments.
*   **Set up credit for connected accounts:** Configure credit terms for your connected accounts.

---

### Treasury for Platforms Specifics

*   **Accounts structure:** Understand the interaction of account components in Treasury for Platforms.
*   **Financial account features:** Learn about the features available for financial accounts.
*   **Working with Stripe Issuing cards:** Integrate Stripe Issuing with Treasury for Platforms.
*   **Platform financial accounts:** Understand the financial account provisioned for your platform.
*   **Treasury for platforms supportability for connected accounts:** Learn how Stripe evaluates connected accounts for Treasury for Platforms support.
*   **Working with balances and transactions:** Understand financial account balances and transaction effects.
*   **Working with connected accounts:** Request the treasury capability and collect onboarding requirements.
*   **Working with financial accounts:** Use financial accounts to store, send, and receive funds.
*   **Integrate with Fifth Third Bank:** Add Fifth Third Bank to your Treasury for Platforms integration.
*   **Build a new Treasury for Platforms integration with Fifth Third Bank:** Get started with Treasury for Platforms using Fifth Third Bank.
*   **Treasury for platforms product marketing, design, and compliance guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant.
*   **Handling complaints:** Properly handle complaints related to Treasury for Platforms or Stripe Issuing.
*   **Marketing Treasury for platforms:** Create precise, compliant messaging for your users.
*   **Regulatory receipts:** Learn about hosted transaction receipts for regulated money movements.
*   **Use Treasury for platforms and Issuing to set up financial accounts and cards:** Follow a sample integration for setting up financial accounts and cards.
*   **Using Treasury for platforms to move money:** Learn how to use SetupIntents and PaymentMethods for money movement.
*   **Treasury for platforms connected account onboarding guide:** Implement a Treasury for Platforms onboarding process for your connected accounts.
*   **Treasury for platforms fraud guide:** Learn best practices for managing fraud as a platform.
*   **Issuing and Treasury for platforms sample app:** Use the Next.js sample app to start your integration.
*   **Webhooks for Stripe Issuing and Treasury for platforms:** Understand webhook events for Issuing and Treasury for Platforms.
*   **How Treasury for platforms works:** Learn about connected accounts, financial accounts, and money movement.
*   **Moving money using CreditReversal objects:** Return funds from received credits.
*   **Moving money with using InboundTransfer objects:** Transfer money from an external US bank account into a financial account.
*   **Moving money using ReceivedCredit objects:** Move money into a financial account from another financial account or bank account.
*   **Money movement timelines:** Understand the timelines for various money movement types.
*   **Moving money into financial accounts:** Learn the requests available to move money into financial accounts.
*   **Moving money out of Treasury for platforms:** Learn the requests available to move money out of financial accounts.
*   **Moving money using DebitReversal objects:** Retrieve funds taken from a financial account.
*   **Moving money using OutboundPayment objects:** Create outbound payments to move money from financial accounts to third parties.
*   **Moving money using OutboundTransfer objects:** Transfer money out of financial accounts to external accounts.
*   **Moving money using ReceivedDebit objects:** Observe ReceivedDebit object creation when funds are pulled from a financial account.
*   **Payouts and top-ups from payments balance:** Move money between payments account balances and financial account balances.
*   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.

---

### Advanced Features and Use Cases

*   **Customize your card program:** Tailor your Stripe Issuing card program to your business needs.
*   **Processor-only Issuing:** Integrate a processor-only Issuing model, managing regulatory requirements and compliance.
    *   **Integrate processor-only Issuing:** Set up a processor-only Issuing integration.
*   **Issuing merchant categories:** Understand the Merchant Category Codes (MCC) used to group businesses.
*   **Consumer prepaid debit cards:** Issue prepaid debit cards for users to receive and spend money.
*   **Stablecoin-backed cards:** Issue prepaid or debit cards backed by stablecoin balances.
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts:** Issue cards backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrate Stripe Issuing with Bridge for stablecoin-backed card programs.
*   **Issuing for agents:** Provide programmable cards with built-in controls for agents.
*   **Use Stripe Issuing in different countries:** Explore global issuing options, including local and cross-border issuing.
*   **Issuing beta migration guide:** Migrate from the Issuing beta to the generally available version.
*   **Product and marketing compliance guidelines (US):** Adhere to guidelines for compliant Issuing and Treasury programs.
*   **Issuing regulated customer notices:** Send regulatory notifications to your customers.
*   **Stripe Issuing marketing guidelines:** Understand marketing guidelines for Issuing programs in the UK and Europe.
*   **Use cards at automated teller machines (ATMs):** Enable and use US-issued cards for ATM cash withdrawals.
*   **Issuing authorizations:** Handle authorization requests when a card is used for a purchase.
*   **Issuing disputes:** Submit and monitor disputes through to resolution.
*   **Enriched merchant data:** Use comprehensive merchant data to understand spending patterns and prevent fraud.
*   **Issuing transactions:** Handle transactions after authorization is approved and captured.
*   **Sample app:** Try the Issuing and Treasury for platforms sample app to onboard customers, issue cards, and make outbound payments.
*   **Testing:** Test your Issuing integration and simulate purchases in a sandbox environment.
*   **Using Issuing Elements:** Display card details in your web application in a PCI-compliant way.

---

### Support and Additional Information

*   **Issuing watchlist:** Learn about the Issuing watchlist process and best practices.
*   **Issuing for agents:** Understand how to issue cards for agents.
*   **Customer support:** Access resources for resolving common Issuing and Treasury for Platforms questions.
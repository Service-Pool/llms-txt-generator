## Integrating Stripe Issuing and Treasury for Platforms

This documentation section provides a comprehensive guide to integrating Stripe Issuing and Treasury for Platforms, enabling businesses to offer sophisticated financial services to their customers. It covers everything from initial setup and integration guides for specific use cases to managing cards, funds, fraud, and advanced credit functionalities.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing, including how to create, manage, and distribute payment cards. (Page 66)
*   **How Issuing Works:** Delve into the mechanics of building a card program with Stripe Issuing, including partnerships with banks and card networks. (Page 67)
*   **Onboarding Overview:** Learn the essential steps to take your Issuing or Treasury for Platforms integration live, including use case approval and going live procedures. (Page 6)
*   **Treasury for Platforms Overview:** Understand how to provide financial services to connected accounts using Stripe's Treasury for Platforms APIs. (Page 120)
*   **Treasury for Platforms Requirements:** Familiarize yourself with the compliance requirements and restrictions for using Treasury for Platforms. (Page 121)
*   **Customer Support for Issuing and Treasury:** Find information on resolving common issues and questions related to Issuing and Treasury for Platforms. (Page 1)

### Integration Guides for Specific Use Cases

Stripe provides tailored integration guides for various business needs:

*   **Embedded Finance Integration Guide:** Build an embedded financial services offering using Issuing and Treasury for Platforms. (Page 3)
*   **B2B Payments Integration Guide:** Create virtual cards for business expenses using Stripe Issuing. (Page 2)
*   **Fleet Integration Guide:** Build a fleet financial services integration with Issuing for managing customer business expenses. (Page 4)
*   **Integration Guides Landing Page:** An overview of all available integration guides. (Page 5)

### Card Management and Issuance

*   **Choose Your Card Type:** Decide between physical or virtual cards for your cardholders. (Page 12)
*   **Virtual Cards:** Learn about creating and displaying virtual card details. (Page 33)
    *   **Create Virtual Cards:** Step-by-step guide to issuing virtual cards. (Page 34)
*   **Physical Cards:** Understand the options for issuing physical cards. (Page 28)
    *   **Choose Card Bundle:** Select standard or custom physical card bundles. (Page 24)
    *   **Order a Custom Bundle:** Guide to ordering custom physical card bundles. (Page 27)
    *   **Customize Card Bundle:** Make your card bundle selections. (Page 23)
    *   **Artwork Templates:** Utilize provided design templates for card customization. (Page 22)
    *   **Create a Design:** Steps to create and name your card design. (Page 25)
    *   **Issue Cards:** Instructions for creating physical cards. (Page 26)
    *   **Ship Cards:** Options for shipping physical cards. (Page 29)
    *   **Address Validation:** Enable and manage address validation for physical card delivery. (Page 21)
*   **Replacement Cards:** Learn how to replace expired, damaged, lost, or stolen cards. (Page 32)
*   **PIN Management:** Allow cardholders to manage their personal identification numbers. (Page 30)
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay. (Page 17)
*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for instant spending and other use cases. (Page 13)
*   **Credit Consumer Issuing:** Understand and launch a credit program for your consumers. (Page 15, Page 14)
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents. (Page 69)

### Funding and Balances

*   **Fund Your Issuing Balance:** Make funds available for card spend. (Page 61)
*   **Add Funds to Your Card Program:** Explore options for funding your Issuing balance. (Page 11)
*   **Postfund your integration with Stripe:** Learn how to accrue a negative Issuing balance and post-fund later. (Page 64)
*   **Post-fund your integration with Dynamic Reserves:** Use dynamic reserves to manage cash flow and minimize funding costs. (Page 63)

### Controls and Fraud Management

*   **Manage Fraud:** Understand and combat transaction fraud with Stripe Issuing controls and tools. (Page 20)
*   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud. (Page 42)
*   **Issuing Authorization Rules:** Limit authorization approvals using custom rules. (Page 43)
*   **Real-time Authorizations:** Approve or decline authorization requests in real time using synchronous webhooks. (Page 48)
    *   **Migrate to Direct Webhook Response:** Transition from deprecated API calls to direct webhook responses for real-time authorizations. (Page 44)
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations. (Page 45)
*   **3D Secure:** Learn about cardholder authentication using 3D Secure for online transactions. (Page 10)
*   **Spending Controls:** Set rules on cards and cardholders to control spending by category, country, or limits. (Page 49)
*   **Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards. (Page 47)
*   **Token Management:** Manage network tokens for cards, which are virtual representations used in digital wallets and online storefronts. (Page 50)
*   **Issuing Watchlist:** Understand the automatic screening process against sanctions lists and manual review procedures. (Page 74)

### Stripe Connect and Treasury for Platforms

*   **Set up an Issuing and Connect Integration:** Integrate Stripe Connect with Issuing to manage funds flows and compliance for connected accounts. (Page 41)
*   **Connected Accounts, Cardholders, and Cards:** Learn how to create and manage cardholders and cards within a Connect integration. (Page 39)
*   **Cardholder Controls:** Understand how cardholder screening and validation affect your integration. (Page 36)
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity impacts Issuing capabilities for connected accounts. (Page 38)
*   **Fund Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing. (Page 40)
*   **Update Issuing Terms of Service Acceptance:** Ensure accurate business information is presented for connected accounts. (Page 62)
*   **Embed Issuing Card Management:** Use prebuilt UI components to embed card management functionality into your website. (Page 37)
*   **Treasury for Platforms:** Understand how to provide financial services to connected accounts. (Page 120)
*   **Treasury for Platforms Account Structure:** Learn how platform and connected accounts interact within Treasury for Platforms. (Page 86)
*   **Financial Account Features:** Explore the features available for financial accounts, enabling money movement and card attachment. (Page 87)
*   **Working with Financial Accounts:** Understand how to use financial accounts to store, send, and receive funds. (Page 93)
*   **Platform Financial Accounts:** Learn about the dedicated financial account for your platform. (Page 89)
*   **Working with Balances and Transactions:** Understand financial account balances and how transactions affect them. (Page 91)
*   **Moving Money:** Comprehensive guides on moving money within Treasury for Platforms.
    *   **Moving Money into Financial Accounts:** Methods for adding money to financial accounts. (Page 111)
        *   **Using InboundTransfer Objects:** Transfer money from external US bank accounts. (Page 108)
        *   **Using ReceivedCredit Objects:** Move money into a financial account from other accounts. (Page 109)
        *   **Using CreditReversal Objects:** Return funds from received credits. (Page 107)
    *   **Moving Money Out of Treasury for Platforms:** Methods for moving funds from financial accounts. (Page 112)
        *   **Using OutboundTransfer Objects:** Transfer money to external accounts. (Page 116)
        *   **Using OutboundPayment Objects:** Create outbound payments to third parties. (Page 115)
        *   **Using ReceivedDebit Objects:** Observe funds pulled from a financial account. (Page 117)
    *   **Payouts and Top-ups from Payments Balance:** Move money between payments and financial account balances. (Page 118)
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms. (Page 119)
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated. (Page 113)
*   **Money Movement Timelines:** Understand the processing and cutoff times for various money movement types. (Page 110)
*   **Integrate with Fifth Third Bank:** Integrate with Fifth Third Bank for Treasury for Platforms. (Page 94, Page 95)
*   **Treasury for Platforms Fraud Guide:** Best practices for managing fraud as a platform. (Page 103)
*   **Treasury for Platforms Connected Account Onboarding Guide:** Implement an onboarding process for connected accounts. (Page 102)
*   **Marketing and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant. (Page 96)
*   **Handling Complaints:** Properly handle complaints related to Treasury for Platforms or Issuing. (Page 97)
*   **Marketing Treasury for Platforms:** Create compliant messaging for your users. (Page 98)
*   **Regulatory Receipts:** Learn about hosted transaction receipts. (Page 99)

### Sample Apps and Testing

*   **Issuing and Treasury for Platforms Sample App:** Explore a sample application to see how Issuing and Treasury for Platforms APIs can be used. (Page 7, Page 104)
*   **Test Your Issuing Integration:** Learn how to test your integration and simulate purchases in a sandbox environment. (Page 84)
*   **Test Credit Integration:** Validate your automated platform funding in testing environments. (Page 60)
*   **Get Started with API Access to Treasury for Platforms:** Test Treasury for Platforms and Issuing in a sandbox environment. (Page 85)

### Other Topics

*   **Issuing Merchant Categories:** Understand the Merchant Category Codes (MCCs) used to group businesses. (Page 35)
*   **Customize Your Card Program:** Tailor your Stripe Issuing card program to meet your business needs. (Page 16)
*   **Use Stripe Issuing in Different Countries:** Learn about global integration options for Issuing. (Page 65)
*   **Issuing Beta Migration Guide:** Migrate from the Issuing beta to the generally available version. (Page 68)
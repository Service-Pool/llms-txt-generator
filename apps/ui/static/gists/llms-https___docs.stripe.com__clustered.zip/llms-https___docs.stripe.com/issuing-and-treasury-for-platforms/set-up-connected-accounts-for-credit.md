## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite provides comprehensive guidance on leveraging Stripe Issuing and Treasury for Platforms to build and manage sophisticated financial services for your business and customers. It covers everything from initial setup and integration to advanced features like fraud management, credit programs, and international expansion.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing, including how it works, its capabilities, and how to get started.
*   **Treasury for Platforms Overview:** Learn how Treasury for Platforms enables you to embed financial services into your product, allowing your connected accounts to hold funds, pay bills, and manage cash flow.
*   **Integration Guides:**
    *   **Embedded Finance:** Build embedded financial services with Issuing and Treasury for Platforms.
    *   **B2B Payments:** Create B2B payment solutions using Stripe Issuing.
    *   **Fleet:** Develop fleet financial services integrations with Issuing.
*   **Onboarding Overview:** Navigate the process of getting your Issuing or Treasury for Platforms integration live, including use case approval and live mode access.
*   **Customer Support:** Access resources for resolving common Issuing and Treasury for Platforms questions and issues.
*   **Sample App:** Explore the Issuing and Treasury for Platforms sample app to understand API usage for onboarding, card creation, and payments.
*   **Testing Your Integration:** Learn how to test your Issuing integration in a sandbox environment and simulate purchases.
*   **Beta Migration Guide:** Understand how to migrate from the Issuing beta to the generally available version.

### Issuing Card Management

*   **Choose Card Type:** Decide between physical and virtual cards for your cardholders.
*   **Virtual Cards:** Learn about creating and managing virtual cards with Issuing.
*   **Physical Cards:** Explore options for issuing physical cards, including standard and custom designs.
    *   **Choose Card Bundle:** Select standard or custom physical card bundles.
    *   **Order a Custom Bundle:** Understand the process for ordering custom physical card bundles.
    *   **Create a Design:** Design your custom cards using provided templates.
    *   **Issue Cards:** Create physical cards for your cardholders.
    *   **Ship Cards:** Learn about the shipping options for physical cards.
    *   **Address Validation:** Ensure successful delivery of physical cards with address validation.
*   **Artwork Templates:** Utilize provided templates for card, carrier, and envelope designs.
*   **Replacement Cards:** Manage the process of replacing expired, damaged, lost, or stolen cards.
*   **PIN Management:** Allow cardholders to manage their personal identification numbers.
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **Token Management:** Understand how to manage network tokens for enhanced security.

### Funding and Balances

*   **Issuing Balance:** Learn how to make funds available for your cards.
*   **Add Funds to Your Card Program:** Explore options for funding your Issuing balance, including pull-funded top-ups, push-funded top-ups, Stripe balance transfers, and Connect balance transfers.
*   **Postfund Your Integration with Stripe:** Understand how to accrue a negative Issuing balance and postfund Stripe later.
*   **Post-fund Your Integration with Dynamic Reserves:** Utilize dynamic reserves to manage cash between Stripe and authorization availability.

### Program Management and Customization

*   **Program Management:** Choose between Stripe program management and processor-only models for your Issuing program.
*   **Customize Your Card Program:** Tailor your Stripe Issuing card program to meet your specific business needs.
*   **Processor-Only Issuing:** Integrate with Stripe Issuing as a processor, managing your own program.
*   **Issuing Merchant Categories:** Understand how businesses are categorized and how to use these categories for spending controls.

### Connect Integrations

*   **Set up an Issuing and Connect Integration:** Learn how to issue cards on connected accounts using Stripe Connect.
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and cards in a Connect integration.
*   **Cardholder Controls:** Manage cardholder information in compliance with legal and regulatory guidelines.
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity affects connected accounts and how Stripe disables Issuing capabilities.
*   **Fund Issuing Balances with Connect:** Discover how to fund connected accounts for Issuing.
*   **Update Issuing Terms of Service Acceptance:** Ensure accurate business information is presented for connected accounts.
*   **Embed Issuing Card Management:** Use prebuilt UI components to embed card management functionality into your website.

### Advanced Controls and Fraud Management

*   **Manage Fraud:** Understand transaction fraud risks and how to combat them using Stripe Issuing controls and tools.
*   **Advanced Fraud Tools:** Leverage API signals and tooling to identify and prevent transaction fraud.
*   **Issuing Authorization Rules:** Limit authorization approvals using custom rules to prevent unauthorized activity.
*   **Real-time Authorizations:** Approve or decline authorization requests in real time using synchronous webhooks.
*   **Migrate to Direct Webhook Response:** Update your integration to respond directly to authorization webhooks.
*   **Fraud Challenges:** Implement additional verification steps for high-risk authorizations.
*   **Issuing Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards.
*   **Issuing Spending Controls:** Set rules on cards and cardholders to manage spending limits and restrictions.

### Credit Programs

*   **Issuing Credit Overview:** Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
*   **Credit Consumer Issuing:** Learn about the Stripe consumer credit solution to launch a credit program for your customers.
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for your connected accounts.
*   **Manage Credit Terms:** Configure credit terms for your connected accounts.
*   **Available Credit and Flow of Funds:** Understand how funds flow and how available credit impacts authorization declines.
*   **Obligation Payments:** Learn how to make payments to your FundingObligation.
*   **Obligation Amounts, Transactions, and Adjustments:** View details about FundingObligations and make adjustments.
*   **Report Other Credit Decisions and Manage Adverse Action Notices:** Record credit decision details and send adverse action notice emails.
*   **Report Required Regulatory Data for Credit Decisions:** Comply with regulatory reporting requirements for credit programs.
*   **Test Credit Integration:** Validate your automated platform funding in testing environments.

### Treasury for Platforms Specifics

*   **Treasury for Platforms Overview:** Learn how to provide financial services to connected accounts.
*   **Get Started with API Access:** Enable your Stripe account for Issuing and Treasury for Platforms capabilities on connected accounts.
*   **Accounts Structure:** Understand the interaction of account components within Treasury for Platforms.
*   **Working with Connected Accounts:** Request the treasury capability and collect onboarding requirements for your connected accounts.
*   **Financial Account Features:** Explore the features available for financial accounts.
*   **Platform Financial Accounts:** Learn about the financial account provisioned for your platform.
*   **Working with Financial Accounts:** Understand how to use financial accounts to store, send, and receive funds.
*   **Working with Balances and Transactions:** Learn about financial account balances and the impact of transactions.
*   **Moving Money:** Explore various methods for moving money within Treasury for Platforms.
    *   **Payouts and Top-ups from Payments Balance:** Move money between payments account balances and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.
    *   **ACH NOC and SEC Handling:** Understand how external account information is updated.
    *   **Moving Money into Financial Accounts:** Learn the requests available to move money into financial accounts.
    *   **Moving Money Out of Financial Accounts:** Discover methods to move funds from financial accounts.
*   **Money Movement Timelines:** Understand the processing and cutoff times for various money movement types.
*   **Integrate with Fifth Third Bank:** Add Fifth Third Bank to your existing Treasury for Platforms integration.
*   **Build a New Treasury for Platforms Integration with Fifth Third Bank:** Get started with Treasury for Platforms using Fifth Third Bank.
*   **Treasury for Platforms Requirements:** Understand the compliance requirements and restrictions for using Treasury for Platforms.
*   **Treasury for Platforms Fraud Guide:** Learn best practices for managing fraud as a platform.
*   **Treasury for Platforms Connected Account Onboarding Guide:** Implement a Treasury for Platforms onboarding process for your connected accounts.
*   **Marketing Treasury for Platforms:** Create compliant messaging for your users.
*   **Handling Complaints:** Learn how to properly handle complaints related to Treasury for Platforms or Issuing.
*   **Regulatory Receipts:** Understand hosted transaction receipts for regulated money movements.
*   **Sample Application with Issuing and Treasury for Platforms:** Use the Next.js sample app to start your integration.
*   **Webhooks for Stripe Issuing and Treasury for Platforms:** Learn about webhook events for Issuing and Treasury for Platforms.

### Compliance and Guidelines

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines:** Adhere to guidelines for launching and maintaining compliant Issuing and Treasury programs.
*   **Issuing Regulated Customer Notices:** Understand how Stripe helps you stay compliant by sending regulated customer notices.
*   **Stripe Issuing Marketing Guidelines:** Learn about marketing guidelines for Issuing programs in the UK and Europe.
## Stripe Issuing and Treasury for Platforms Documentation

This documentation group provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and integration to advanced features like fraud management, credit offerings, and international use.

### Core Concepts and Getting Started

*   **Issuing Overview** (`/issuing`): An introduction to Stripe Issuing, enabling platforms to create, manage, and distribute payment cards for their users.
*   **How Issuing Works** (`/issuing/how-issuing-works`): Explains the fundamental mechanics of building a card program with Stripe Issuing, including partnerships with banks and card networks.
*   **Treasury for Platforms Overview** (`/treasury/connect`): Introduces Treasury for Platforms, a suite of APIs for Stripe Connect platforms to embed financial services for connected accounts.
*   **Get started with API access to Treasury for Platforms** (`/treasury/connect/access`): Guides users on how to gain API access and test Treasury for Platforms functionality in a sandbox environment.
*   **Onboarding Overview** (`/issuing/onboarding-overview`): Details the steps required to take an Issuing or Treasury for Platforms integration live, including use case approval and live mode access.
*   **Integration Guides** (`/issuing/integration-guides`): A central hub for guides on integrating specific use cases like Embedded Finance, B2B Payments, and Fleet.
*   **Sample App** (`/issuing/sample-app`, `/treasury/connect/examples/sample-app`): Provides a sample application to demonstrate how to use Issuing and Treasury for Platforms APIs, including onboarding, card creation, and outbound payments.
*   **Test your Issuing integration** (`/issuing/testing`): Instructions on how to test Issuing integrations in a sandbox environment by issuing cards and simulating purchases.
*   **Test your integration** (`/treasury/connect/moving-money/into/credit-reversals`): Guidance on testing credit integrations in a sandbox environment.

### Issuing Card Management

*   **Choose your card type** (`/issuing/choose-cards`): Helps users decide between physical and virtual cards, outlining their use cases and trade-offs.
*   **Virtual cards with Issuing** (`/issuing/cards/virtual`): Details on creating and displaying virtual card details in a PCI-compliant manner.
*   **Create virtual cards** (`/issuing/cards/virtual/issue-cards`): Step-by-step instructions for creating virtual cards using the Dashboard or API.
*   **Physical cards** (`/issuing/cards/physical`): An overview of options for issuing physical cards, from standard to fully custom designs.
*   **Create physical cards** (`/issuing/cards/physical/issue-cards`): Instructions on creating physical cards using the Dashboard or the Create a card endpoint.
*   **Choose card bundle** (`/issuing/cards/physical/choose-bundle`): Explains how to set up standard or custom physical card bundles.
*   **Order a custom bundle** (`/issuing/cards/physical/order-custom-bundle`): Guides users through the process of ordering custom physical card bundles.
*   **Customize card bundle** (`/issuing/cards/physical/card-bundle-selections`): Details on making selections for card body materials and core color options.
*   **Artwork templates** (`/issuing/cards/artwork-templates`): Provides design templates and best practices for uploading card artwork.
*   **Address validation** (`/issuing/cards/physical/address-validation`): Information on enabling and managing address validation for physical card delivery.
*   **Ship cards** (`/issuing/cards/physical/ship-cards`): Explains the options for shipping cards, including individual and bulk shipments.
*   **Replacement cards** (`/issuing/cards/replacements`): How to replace expired, damaged, lost, or stolen cards.
*   **PIN management** (`/issuing/cards/pin-management`): Guidance on how cardholders can manage their personal identification numbers.
*   **Use digital wallets with Issuing** (`/issuing/cards/digital-wallets`): How to add Issuing cards to digital wallets like Apple Pay and Google Pay.
*   **Token management** (`/issuing/controls/token-management`): Information on managing network tokens for cards, which are virtual representations used in digital wallets and online.

### Funding and Balances

*   **Fund your Issuing balance** (`/issuing/funding/balance`): Explains how to make funds available for card spend by adding funds to the Issuing balance.
*   **Add funds to your card program** (`/issuing/adding-funds-to-your-card-program`): Details on various funding options for Issuing balances, including pull-funded, push-funded, and balance transfers.
*   **Postfund your integration with Stripe** (`/issuing/funding/post-fund`): Learn how to accrue a negative Issuing balance on card spend and post-fund Stripe later.
*   **Post-fund your integration with Dynamic Reserves** (`/issuing/funding/post-fund-with-dynamic-reserves`): How to use dynamic reserves to manage cash flow and fund card spend after authorizations.

### Integrations with Stripe Connect

*   **Set up an Issuing and Connect integration** (`/issuing/connect`): Guides on issuing cards on connected accounts using Stripe Connect.
*   **Connected accounts, cardholders, and cards** (`/issuing/connect/cardholders-and-cards`): How to create and manage cardholders and cards within a Stripe Connect integration.
*   **Fund Issuing balances with Connect** (`/issuing/connect/funding`): Instructions on how to fund connected accounts for Issuing.
*   **Update the Issuing terms of service acceptance** (`/issuing/connect/tos_acceptance`): How to present business information and accept Issuing terms of service for connected accounts.
*   **Cardholder controls** (`/issuing/connect/cardholder-controls`): Information on how cardholder screening and controls affect Issuing and Connect integrations.
*   **Inactive connected accounts offboarding** (`/issuing/connect/inactive-accounts-management`): How inactivity affects connected accounts' Issuing capabilities.
*   **Embed Issuing card management into your website** (`/issuing/connect/embedded-components`): Using Connect embedded components to integrate Issuing card management into a website.

### Specific Use Cases and Integrations

*   **B2B payments integration guide** (`/issuing/integration-guides/b2b-payments`): How to build a B2B payments integration using Stripe Issuing.
*   **Embedded Finance integration guide** (`/issuing/integration-guides/embedded-finance`): Guide to building an embedded financial services integration with Issuing and Treasury for Platforms.
*   **Fleet integration guide** (`/issuing/integration-guides/fleet`): How to build a fleet financial services integration with Stripe Issuing.
*   **Consumer prepaid debit cards** (`/issuing/consumer-prepaid-debit-cards`): Information on issuing prepaid debit cards for rewards, disbursements, or branded card programs.
*   **How Consumer Credit Issuing works** (`/issuing/consumer-issuing/how-it-works`): Details on the features and APIs for creating and managing credit programs for consumers.
*   **Credit Consumer Issuing** (`/issuing/consumer-issuing`): Information on Stripe's consumer credit solution for launching credit programs.
*   **Processor-only Issuing** (`/issuing/processor-only-issuing`, `/issuing/processor-only-integration-guide`): How to integrate Issuing where Stripe acts as the processor, and you manage compliance and licensing.
*   **Issuing for agents** (`/issuing/agents`): How to issue programmable cards with built-in controls for agents to use for purchases.
*   **Use Stripe Issuing in different countries** (`/issuing/global`): Explains global issuing options, including local and cross-border issuing.
*   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts** (`/issuing/stablecoin-cards-for-financial-accounts`): How to issue cards backed by Stablecoin Financial Accounts.
*   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets** (`/issuing/bridge-stablecoin-cards`): Integrating Stripe Issuing with Bridge for stablecoin-backed card programs.
*   **Stablecoin-backed card issuing** (`/issuing/stablecoin-cards`): Details on issuing prepaid or debit cards backed by stablecoin balances.

### Controls and Fraud Management

*   **Manage fraud with Stripe Issuing controls and tools** (`/issuing/manage-fraud`): Understand transaction fraud risks and how to combat them using Stripe's resources.
*   **Advanced fraud tools** (`/issuing/controls/advanced-fraud-tools`): Using API signals and tooling to identify and prevent transaction fraud.
*   **Issuing authorization rules** (`/issuing/controls/authorization-rules`): How to limit authorization approvals using custom rules.
*   **Real-time authorizations** (`/issuing/controls/real-time-authorizations`): Handling authorization requests in real time using synchronous webhooks.
*   **Migrate to direct webhook response** (`/issuing/controls/real-time-authorizations/direct-webhook-migration`): Migrating real-time authorizations from deprecated API calls to direct webhook responses.
*   **Fraud challenges** (`/issuing/controls/fraud-challenges`): Using additional verification steps to minimize accidental transaction blocks.
*   **Issuing spending controls** (`/issuing/controls/spending-controls`): Setting rules on cards and cardholders to control spending by category, country, or limits.
*   **Issuing lifecycle controls** (`/issuing/controls/lifecycle-controls`): Controlling automatic usage-based cancellation of virtual cards.
*   **3D Secure** (`/issuing/3d-secure`): Cardholder authentication using 3D Secure for online transactions.

### Credit Offerings

*   **Issuing Credit** (`/issuing/credit`): An overview of applying platform Issuing account balances or exposure limits to cards issued to connected accounts.
*   **Set up credit for connected accounts** (`/issuing/credit/connect-credit-setup`): How to configure credit terms for connected accounts and fund their spend from your platform.
*   **Manage credit terms** (`/issuing/credit/manage-credit-terms`): Updating credit limits and terms for connected accounts.
*   **Manage account obligations** (`/issuing/credit/manage-account-obligations`): Tracking credit spend, lifecycle, and balances for connected accounts.
*   **Obligation amounts, transactions, and adjustments** (`/issuing/credit/manage-account-obligations/obligations-transactions-adjustments`): Viewing details of FundingObligations and making adjustments.
*   **Obligation payments** (`/issuing/credit/manage-account-obligations/obligation-payments`): How to make payments to your FundingObligation.
*   **Available credit and flow of funds** (`/issuing/credit/manage-account-obligations/available-credit`): Understanding how funds flow and how available credit affects authorization declines.
*   **Report other credit decisions and manage adverse action notices** (`/issuing/credit/report-credit-decisions-and-manage-aans`): Recording credit underwriting decisions and sending adverse action notices.
*   **Report required regulatory data for credit decisions** (`/issuing/credit/report-required-regulatory-data-for-credit-decisions`): Reporting regulatory data for credit decisions when required.
*   **Test credit integration** (`/issuing/credit/test-credit`): Validating credit integrations in testing environments.

### Treasury for Platforms - Core Functionality

*   **Treasury for Platforms Requirements** (`/treasury/connect/requirements`): Understanding the compliance requirements and restrictions for using Treasury for Platforms.
*   **Accounts structure** (`/treasury/connect/account-management/accounts-structure`): Explaining the interaction of account components in Treasury for Platforms.
*   **Working with connected accounts** (`/treasury/connect/account-management/connected-accounts`): Requesting the treasury capability and collecting onboarding requirements for connected accounts.
*   **Working with financial accounts** (`/treasury/connect/account-management/financial-accounts`): Using financial accounts to store, send, and receive funds.
*   **Financial account features** (`/treasury/connect/account-management/financial-account-features`): Details on features available for financial accounts, such as moving money and attaching cards.
*   **Platform financial accounts** (`/treasury/connect/account-management/platform-financial-account`): Information about the financial account automatically provisioned for your platform.
*   **Working with balances and transactions** (`/treasury/connect/account-management/working-with-balances-and-transactions`): Understanding financial account balances and the impact of transactions.
*   **Moving money** (`/treasury/connect/moving-money/moving-money-into-financial-accounts`, `/treasury/connect/moving-money/moving-money-out`): Guides on moving money into and out of financial accounts.
*   **Money movement timelines** (`/treasury/connect/money-movement/timelines`): Timelines for various money movement types with Treasury for Platforms.
*   **Payouts and top-ups from payments balance** (`/treasury/connect/moving-money/payouts`): How to move money between payments account balances and financial account balances.
*   **Working with SetupIntents, PaymentMethods, and BankAccounts** (`/treasury/connect/moving-money/working-with-bankaccount-objects`): Setting up money movements with Treasury for Platforms.
*   **ACH NOC and SEC handling** (`/treasury/connect/moving-money/noc-sec-handling`): How external account information is updated via ACH NOCs.
*   **Integrate with Fifth Third Bank** (`/treasury/connect/fifth-third`): Integrating Fifth Third Bank into an existing Treasury for Platforms integration.
*   **Build a new Treasury for Platforms integration with Fifth Third Bank** (`/treasury/connect/fifth-third-get-started`): Getting started with Treasury for Platforms using Fifth Third Bank.
*   **Treasury for platforms fraud guide** (`/treasury/connect/examples/fraud-guide`): Best practices for managing fraud as a platform.
*   **Treasury for platforms connected account onboarding guide** (`/treasury/connect/examples/onboarding-guide`): Implementing an onboarding process for connected accounts using Treasury for Platforms.
*   **Marketing Treasury for platforms** (`/treasury/connect/marketing-financial-accounts`): Creating compliant messaging for Treasury for Platforms.
*   **Handling complaints** (`/treasury/connect/handling-complaints`): Properly handling complaints related to Treasury for Platforms or Issuing.
*   **Regulatory receipts** (`/treasury/connect/moving-money/regulatory-receipts`): Information on hosted transaction receipts for regulated money movements.

### Compliance and Support

*   **Issuing and Treasury product marketing, design, and compliance guidelines** (`/issuing/compliance-us`, `/treasury/connect/compliance`): Guidelines for launching and maintaining compliant Issuing and Treasury programs.
*   **Issuing regulated customer notices** (`/issuing/compliance-us/issuing-regulated-customer-notices`): How to send regulatory notifications to customers.
*   **Marketing guidance (Europe/UK)** (`/issuing/marketing-guidance-europe-uk`): Marketing guidelines for Issuing programs in the UK and Europe.
*   **Customer support for Issuing and Treasury for platforms** (`/issuing/customer-support`): Resolving common Issuing and Treasury for Platforms questions and issues.
*   **Issuing watchlist** (`/issuing/issuing-watchlist`): Information on Stripe's automatic screening of Issuing users against sanctions lists.
*   **Treasury for platforms supportability for connected accounts** (`/treasury/connect/supportability`): How Stripe evaluates connected accounts for Treasury for Platforms supportability.

### Other Topics

*   **Customize your card program** (`/issuing/customize-your-program`): How to customize your Stripe Issuing card program to meet business needs.
*   **Program management** (`/issuing/program-management`): Choosing between Stripe program management and processor-only models.
*   **Issuing merchant categories** (`/issuing/categories`): Understanding merchant categories (MCCs) and their use in spending controls.
*   **Use cards at automated teller machines (ATMs)** (`/issuing/purchases/atm-usage`): How to use US-issued cards for ATM cash withdrawals.
*   **Issuing authorizations** (`/issuing/purchases/authorizations`): Handling authorization requests for card purchases.
*   **Issuing disputes** (`/issuing/purchases/disputes`): How to dispute transactions with Issuing.
*   **Issuing transactions** (`/issuing/purchases/transactions`): Understanding how transactions are created after an authorization is captured.
*   **Enriched merchant data** (`/issuing/purchases/enriched-merchant-data`): Using comprehensive merchant data for fraud prevention and spending controls.
*   **Issuing beta migration guide** (`/issuing/migration-from-beta`): How to migrate from the Issuing beta program to general availability.
*   **Choose a cardholder type** (`/issuing/other/choose-cardholder`): Selecting the appropriate cardholder type (individual or company) for your use case.
*   **Issuing for your business** (`/issuing/direct`): How to programmatically create virtual cards for your business, employees, or contractors.
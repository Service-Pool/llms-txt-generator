## Stripe Issuing and Treasury for Platforms: Core Concepts and Integration Guides

This documentation set provides comprehensive guidance on integrating and utilizing Stripe Issuing and Treasury for Platforms. It covers everything from the fundamental concepts of card issuance and money movement to advanced fraud management and regulatory compliance.

### Key Areas Covered:

*   **Getting Started with Issuing and Treasury:**
    *   **Onboarding Overview:** Understand the process for launching your Issuing or Treasury for Platforms integration.
    *   **How Issuing Works:** Gain a foundational understanding of Stripe Issuing's capabilities and architecture.
    *   **Integration Guides:** Explore specific guides for various use cases like Embedded Finance, B2B Payments, and Fleet management.
    *   **Sample App:** Utilize a provided sample application to see Issuing and Treasury for Platforms APIs in action.
    *   **Testing:** Learn how to test your Issuing integration in a sandbox environment.
    *   **Customer Support:** Find information on resolving common Issuing and Treasury for Platforms issues.

*   **Card Issuance and Management:**
    *   **Card Types:** Decide between physical and virtual cards, understanding their use cases and trade-offs.
    *   **Physical Cards:** Detailed information on ordering, customizing, designing, and shipping physical cards, including address validation and artwork templates.
    *   **Virtual Cards:** Learn how to create and display virtual card details.
    *   **Card Programs:** Understand program management, customization options, and how to add funds to your card program.
    *   **PIN Management:** Allow cardholders to manage their PINs.
    *   **Replacement Cards:** Procedures for replacing expired, damaged, lost, or stolen cards.
    *   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.

*   **Money Movement and Treasury for Platforms:**
    *   **Treasury for Platforms Overview:** Understand how to provide financial services to connected accounts.
    *   **Account Structure:** Learn about platform and connected accounts, financial accounts, and their interactions.
    *   **Financial Account Features:** Explore the capabilities of financial accounts, including moving money and attaching payment cards.
    *   **Moving Money:** Detailed guides on moving money into and out of financial accounts via ACH, wire transfers, and the Stripe network.
    *   **Payouts and Top-ups:** Manage money movement between payments balances and financial accounts.
    *   **Bank Partners:** Information on integrating with banking partners like Fifth Third Bank.

*   **Connect Integrations:**
    *   **Setting up Issuing and Connect:** Learn how to issue cards on connected accounts using Stripe Connect.
    *   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between these entities in a Connect integration.
    *   **Funding Issuing Balances with Connect:** Strategies for funding connected accounts for Issuing.
    *   **Inactive Connected Accounts:** Management of inactive accounts to mitigate risk.
    *   **Embed Card Management:** Utilize Connect embedded components to integrate card management into your website.
    *   **Terms of Service Acceptance:** Ensure accurate business information and acceptance of Issuing terms.

*   **Controls and Fraud Management:**
    *   **Manage Fraud:** Understand transaction fraud risks and how to combat them using Stripe's tools.
    *   **Spending Controls:** Set rules for cards and cardholders to control spending by category, country, or amount.
    *   **Lifecycle Controls:** Implement automatic card cancellation based on usage.
    *   **Real-time Authorizations:** Approve or decline authorization requests in real time via webhooks.
    *   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud.
    *   **Fraud Challenges:** Implement additional verification steps for high-risk authorizations.
    *   **3D Secure:** Understand cardholder authentication for online transactions.
    *   **Authorization Rules:** Limit authorization approvals based on custom conditions.
    *   **Issuing Watchlist:** Information on Stripe's automatic screening against sanctions lists.

*   **Credit and Advanced Features:**
    *   **Issuing Credit:** Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
    *   **Credit Consumer Issuing:** Create, launch, and manage a credit program for your consumers.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Stablecoin-backed Cards:** Issue cards backed by stablecoin balances, integrating with Bridge or other wallets.
    *   **Processor-only Issuing:** Understand the model where you manage your Issuing program's compliance and licensing.

*   **Compliance and Guidelines:**
    *   **Product Marketing, Design, and Compliance Guidelines:** Adhere to regulations for marketing and user interfaces.
    *   **Marketing Guidance (Europe/UK):** Specific marketing guidelines for Issuing programs in the UK and Europe.
    *   **Regulated Customer Notices:** Understand how to send regulatory notifications to customers.
    *   **Treasury for Platforms Compliance:** Guidelines for maintaining compliant Treasury for Platforms programs.

This documentation set is designed to empower developers and businesses to effectively leverage Stripe's Issuing and Treasury for Platforms products, enabling them to build sophisticated financial services and manage card programs with robust controls and security.
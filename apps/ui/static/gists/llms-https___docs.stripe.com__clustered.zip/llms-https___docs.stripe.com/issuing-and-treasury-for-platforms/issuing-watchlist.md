## Issuing Watchlist

Stripe automatically screens Issuing users against US and international sanctions lists. For Issuing, we screen all relevant data. Screening can occur based on events such as:

*   Onboarding
*   Updates to sanction lists
*   Creation or update of cardholders

If automated screening flags a user, Stripe opens a manual review for them. Our team reviews any flagged cardholders, and updates information about these cardholders within 24 hours. During the review, this process might impact your business, and all cards decline authorizations with the `cardholder_verification_required` reason.

### Integrating with watchlist events

Make sure your integration listens to the `issuing_cardholder.updated` webhook events. This is how we notify you when an interesting event occurs.

When a user creates or updates a cardholder, Stripe updates the `requirements.disabled_reason` to `under_review`.
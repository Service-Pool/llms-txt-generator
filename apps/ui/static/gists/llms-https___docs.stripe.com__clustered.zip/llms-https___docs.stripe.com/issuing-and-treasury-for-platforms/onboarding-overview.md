## Onboarding Overview

This guide provides an overview of the onboarding process for launching an integration using Stripe Issuing or Treasury for platforms. To successfully go live, your offering must be a business that Stripe supports, and you must integrate systems and establish business processes.

### Before You Go Live

Before you can launch your integration, you must complete the following steps:

*   **Get your use case approved:** Submit information about your intended use case, familiarize yourself with the compliance requirements, and explore the available testing environments.
*   **Obtain live mode access:** Build and manage your integration in the production environment, ensuring you handle all necessary operational responsibilities and complete all required compliance tasks.
*   **Get ready to launch your offering:** Thoroughly test your program with your employees using real funds to ensure everything functions as expected.

### Supported Use Cases

Stripe Issuing and Treasury for platforms support various use cases, including:

*   **Embedded Finance:** Create cards and financial accounts for your customers (US only). This is suitable for platforms like SaaS and e-commerce businesses.
*   **B2B Payments:** Facilitate business-to-business payments.
*   **Expense Management:** Manage expenses for your business or employees.
## Issuing Merchant Categories

Every business that processes card payments is categorized using Merchant Category Codes (MCCs). The category name is provided as a value for `merchant_data.category` on Authorization objects. If a business doesn’t fit into a specific category, it’s categorized as miscellaneous.

You can use these categories when creating spending controls to restrict issued cards from being used with certain business types.

You can also use enriched merchant data to set more granular controls.

| Category                                 | MCC    |
| :--------------------------------------- | :----- |
| A/C, Refrigeration Repair                | 7623   |
| Accounting/Bookkeeping Services          | 8931   |
| Advertising Services                     | 7311   |
| Agricultural Cooperative                 | 0763   |
| Airlines, Air Carriers                   | 4511   |
| Airports, Flying Fields                  | 4582   |
| Ambulance Services                       | 4119   |
| Amusement Parks/Carnivals                | 7996   |
| Antique Reproductions                    | 5937   |
| Antique Shops                            | 5932   |
| Aquariums                                | 7998   |
| Architectural/Surveying Services         | 8911   |
| Art Dealers and Galleries                | 5971   |
| Artists Supply and Craft Shops           | 5970   |
| Auto Body Repair Shops                   | 7531   |
| Auto Paint Shops                         | 7535   |
| Auto Service Shops                       | 7538   |
| Auto and Home Supply Stores              | 5531   |
| Automated Cash Disburse                  | 6011   |
| Automated Fuel Dispensers                | 5542   |
| Automobile Associations                  | 8675   |
| Automotive Parts and Accessories Stores  | 5533   |
| Automotive Tire Stores                   | 5532   |
| Bail and                                 |        |
## Stripe Issuing and Treasury for Platforms: Documentation

This documentation suite provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and integration to advanced features, fraud management, and specific use cases.

### Core Concepts & Getting Started

*   **Issuing Overview** (Page 66): An introduction to Stripe Issuing, enabling you to create, manage, and distribute payment cards for your business.
*   **How Issuing Works** (Page 67): Understand the fundamental mechanics of building a card program with Stripe Issuing, including partnerships with banks and card networks.
*   **Onboarding Overview** (Page 6): A guide to the essential steps required to take your Issuing or Treasury for Platforms integration live.
*   **Integration Guides** (Page 5): A central hub for various integration guides, including Embedded Finance, B2B Payments, and Fleet.
*   **Issuing and Treasury for Platforms Sample App** (Page 7, Page 104): Explore a sample application to understand how to onboard customers, issue cards, and make outbound payments.
*   **Get Started with API Access to Treasury for Platforms** (Page 85): Learn how to test Treasury for Platforms functionality in a sandbox environment before going live.
*   **Treasury for Platforms Overview** (Page 120): An introduction to Treasury for Platforms, a suite of APIs for Stripe Connect platforms to embed financial services.

### Issuing Card Management

*   **Choose Card Type** (Page 12): Decide between physical or virtual cards for your cardholders, understanding the trade-offs and use cases.
*   **Virtual Cards** (Page 33, Page 34): Learn how to create and manage virtual cards with Issuing.
*   **Physical Cards** (Page 28): Understand the options for issuing physical cards, from standard to fully custom designs.
    *   **Choose Card Bundle** (Page 24): Set up a standard or custom physical card bundle.
    *   **Order a Custom Bundle** (Page 27): Guide to ordering custom physical card bundles.
    *   **Customize Card Bundle** (Page 23): Make your card bundle selections.
    *   **Artwork Templates** (Page 22): Access design templates for cards, carriers, and envelopes.
    *   **Create a Design** (Page 25): Learn how to create and name your card bundle design.
    *   **Issue Cards** (Page 26): How to create physical cards for cardholders.
    *   **Ship Cards** (Page 29): Select shipping speeds for your cards.
    *   **Address Validation** (Page 21): Enable and manage address validation for physical card delivery.
*   **Replacement Cards** (Page 32): Learn how to replace cards that are expired, damaged, lost, or stolen.
*   **PIN Management** (Page 30): Allow cardholders to manage their personal identification numbers.
*   **Use Digital Wallets with Issuing** (Page 17): Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **Token Management** (Page 50): Understand how to manage network tokens on your cards.

### Funding and Balances

*   **Issuing Balance** (Page 61): Learn how to make funds available for your cards.
*   **Add Funds to Your Card Program** (Page 11): Explore options for funding your Issuing balance.
*   **Post-fund Your Integration with Stripe** (Page 64): Understand how to accrue a negative Issuing balance and post-fund Stripe later.
*   **Post-fund Your Integration with Dynamic Reserves** (Page 63): Learn how to use dynamic reserves to post-fund card spend.

### Integration and Connect

*   **Set Up an Issuing and Connect Integration** (Page 41): Learn how to issue cards on connected accounts using Stripe Connect.
*   **Connected Accounts, Cardholders, and Cards** (Page 39): Understand how to create and manage cardholders and cards with Stripe Connect.
*   **Cardholder Controls** (Page 36): Learn how cardholder controls affect your integration and ensure compliance.
*   **Inactive Connected Accounts Offboarding** (Page 38): Understand how inactivity affects connected accounts' Issuing capabilities.
*   **Fund Issuing Balances with Connect** (Page 40): Learn how to fund connected accounts for Issuing.
*   **B2B Payments Integration Guide** (Page 2): Build a B2B payments integration using Stripe Issuing.
*   **Embedded Finance Integration Guide** (Page 3): Build an embedded financial services integration with Issuing and Treasury for platforms.
*   **Fleet Integration Guide** (Page 4): Build a fleet financial services integration with Issuing.
*   **Integrate Processor-Only Issuing** (Page 18): Set up a processor-only Issuing integration.
*   **Processor-Only Issuing** (Page 19): Manage your Issuing program with a processor-only model.
*   **Embed Issuing Card Management into Your Website** (Page 37): Use prebuilt UI components to embed Issuing card management.

### Controls and Fraud Management

*   **Manage Fraud** (Page 20): Understand transaction fraud and how to combat it with Stripe Issuing controls.
*   **Advanced Fraud Tools** (Page 42): Reduce fraud with Issuing's advanced tooling and API signals.
*   **Issuing Authorization Rules** (Page 43): Limit authorization approvals using Issuing authorization rules.
*   **Real-Time Authorizations** (Page 48): Approve or decline authorization requests in real time using synchronous webhooks.
    *   **Migrate to Direct Webhook Response** (Page 44): Migrate Issuing real-time authorizations to direct webhook responses.
    *   **Quickstart: Set up and Manage Real-Time Authorizations** (Page 9): A quickstart guide for real-time authorizations.
*   **Fraud Challenges** (Page 45): Enable an additional layer of verification for authorizations.
*   **Issuing Lifecycle Controls** (Page 47): Control automatic usage-based cancellation of cards.
*   **Issuing Spending Controls** (Page 49): Set rules on cards and cardholders to control spending.

### Credit and Treasury for Platforms

*   **Treasury for Platforms** (Page 120): Learn how to provide financial services to connected accounts.
*   **Treasury for Platforms Requirements** (Page 121): Understand the compliance requirements and restrictions for using Treasury for Platforms.
*   **How Treasury for Platforms Works** (Page 106): Learn about connected accounts, financial accounts for platforms, and moving money.
*   **Accounts Structure** (Page 86): Understand the account components of Treasury for Platforms.
*   **Working with Connected Accounts** (Page 92): Request the treasury capability and collect onboarding requirements for connected accounts.
*   **Working with Financial Accounts** (Page 93): Use financial accounts to store, send, and receive funds.
*   **Financial Account Features** (Page 87): Learn about the features available for financial accounts.
*   **Platform Financial Accounts** (Page 89): Understand the financial account for your platform.
*   **Working with Balances and Transactions** (Page 91): Learn about financial account balances and transaction effects.
*   **Moving Money** (Page 112): Learn the requests available to move money out of financial accounts.
    *   **Moving Money Using InboundTransfer Objects** (Page 108): Transfer money from an external US bank account into a financial account.
    *   **Moving Money Using ReceivedCredit Objects** (Page 109): Move money into a financial account from another financial account or bank account.
    *   **Moving Money Using CreditReversal Objects** (Page 107): Return funds from received credits.
    *   **Moving Money Using OutboundTransfer Objects** (Page 116): Transfer money out of financial accounts to external accounts.
    *   **Moving Money Using OutboundPayment Objects** (Page 115): Create outbound payments to move money to third parties.
    *   **Moving Money Using ReceivedDebit Objects** (Page 117): Understand how external account holders can pull funds from a financial account.
    *   **ACH NOC and SEC Handling** (Page 113): Learn how external account information is updated.
*   **Payouts and Top-ups from Payments Balance** (Page 118): Learn how to move money between payments account balances and financial account balances.
*   **Working with SetupIntents, PaymentMethods, and BankAccounts** (Page 119): Set up money movements with Treasury for Platforms.
*   **Money Movement Timelines** (Page 110): Learn about the timelines for various types of money movement.
*   **Integrate with Fifth Third Bank** (Page 94): Add Fifth Third Bank to your existing Treasury for Platforms integration.
*   **Build a New Treasury for Platforms Integration with Fifth Third Bank** (Page 95): Get started with Treasury for Platforms using Fifth Third Bank.
*   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines** (Page 96): Keep your Treasury for Platforms program and marketing campaigns compliant.
*   **Handling Complaints** (Page 97): Learn how to properly handle complaints about Treasury for Platforms or Stripe Issuing.
*   **Marketing Treasury for Platforms** (Page 98): Create precise messaging for your users that complies with regulations.
*   **Regulatory Receipts** (Page 99): Learn about hosted transaction receipts.
*   **Use Treasury for Platforms and Issuing to Set Up Financial Accounts and Cards** (Page 100): Follow a sample integration that sets up a financial account and creates cards.
*   **Using Treasury for Platforms to Move Money** (Page 101): Learn how to use SetupIntents and PaymentMethods to move money.
*   **Treasury for Platforms Connected Account Onboarding Guide** (Page 102): Implement a Treasury for Platforms onboarding process for your connected accounts.
*   **Treasury for Platforms Fraud Guide** (Page 103): Learn best practices for managing fraud as a platform.
*   **Webhooks for Stripe Issuing and Treasury for Platforms** (Page 105): Understand webhook events for Issuing and Treasury for Platforms.
*   **Issuing Credit** (Page 53): Apply your platform Issuing account balance or platform exposure limit to cards issued to connected accounts.
*   **Credit Consumer Issuing** (Page 15): Learn about the Stripe consumer credit solution.
    *   **How Credit Consumer Issuing Works** (Page 14): Learn about the features and APIs for a credit program for your customers.
*   **Manage Account Obligations** (Page 54): Track the credit spend, lifecycle, and balances for your connected accounts.
    *   **Obligation Amounts, Transactions, and Adjustments** (Page 57): View details about a FundingObligation and make adjustments.
    *   **Obligation Payments** (Page 56): Make payments to your FundingObligation.
    *   **Available Credit and Flow of Funds** (Page 51): Learn how funds flow and how to use the available credit amount field.
*   **Manage Credit Terms** (Page 55): Update credit terms for connected accounts.
*   **Set Up Credit for Connected Accounts** (Page 52): Configure credit terms for your connected accounts and fund their spend.
*   **Report Other Credit Decisions and Manage Adverse Action Notices** (Page 58): Record application and decision details and send adverse action notice emails.
*   **Report Required Regulatory Data for Credit Decisions** (Page 59): Report required regulatory data for credit decisions.
*   **Test Credit Integration** (Page 60): Validate your automated platform funding in testing environments.

### Specific Use Cases and Features

*   **Consumer Prepaid Debit Cards** (Page 13): Issue prepaid debit cards for users to receive and spend money.
*   **Issuing for Agents** (Page 69): Give your agents programmable cards with built-in controls.
*   **Stablecoin-Backed Cards** (Page 81, Page 83): Issue prepaid or debit cards backed by stablecoin balances.
    *   **Stablecoin-Backed Cards for Stripe Stablecoin Financial Accounts** (Page 81): Issue cards backed by Stablecoin Financial Accounts.
    *   **Stablecoin-Backed Cards for Bridge, Privy, or Third-Party Wallets** (Page 82): Integrate Stripe Issuing with Bridge for stablecoin-backed card programs.
*   **Issuing Merchant Categories** (Page 35): Learn about the available categories businesses are grouped into.
*   **Use Cards at Automated Teller Machines (ATMs)** (Page 76): Learn how to use your Stripe Issuing cards at ATMs.

### Compliance and Support

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US)** (Page 71): Learn how to launch and maintain compliant Issuing and Treasury programs.
*   **Issuing Regulated Customer Notices** (Page 72): Understand how to send regulatory notifications to your customers.
*   **Stripe Issuing Marketing Guidelines (UK/Europe)** (Page 75): Learn about marketing guidelines for Issuing programs in the UK and Europe.
*   **Customer Support for Issuing and Treasury for Platforms** (Page 1): Resolve common Issuing and Treasury for Platforms questions and issues.
*   **Issuing Watchlist** (Page 74): Learn about the Issuing watchlist process and best practices.

### Testing and Migration

*   **Test Your Issuing Integration** (Page 84): Issue cards and simulate purchases in a sandbox environment.
*   **Issuing Beta Migration Guide** (Page 68): Learn how to migrate from the Issuing beta.

### Other

*   **Customize Your Card Program** (Page 16): Learn how to customize your Stripe Issuing card program.
*   **Issuing Elements** (Page 46): Display card details in your web application in a PCI-compliant way.
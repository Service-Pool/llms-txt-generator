## Stripe Issuing and Treasury for Platforms

This documentation suite provides comprehensive guidance on leveraging Stripe Issuing and Treasury for Platforms to build and manage card programs and financial services for your business and customers. Whether you're looking to issue physical or virtual cards, manage funds, implement advanced fraud controls, or integrate with Stripe Connect, these resources cover the necessary steps and considerations.

---

### Core Concepts & Getting Started

*   **Issuing Overview** (Page 66): Get a high-level understanding of Stripe Issuing, its capabilities for creating, managing, and distributing payment cards, and how to get started.
*   **How Issuing Works** (Page 67): Delve into the mechanics of Stripe Issuing, including card program control, physical/virtual card issuance, spending management, and transaction approval/declining. Learn about regional considerations and partnerships with banks and card networks.
*   **Onboarding Overview** (Page 6): Understand the essential steps and requirements for taking your Issuing or Treasury for Platforms integration live, including use case approval and live mode access.
*   **Issuing and Treasury for Platforms Sample App** (Page 7, Page 104): Explore a sample application that demonstrates how to use Issuing and Treasury for Platforms APIs for onboarding customers, issuing cards, and making outbound payments.
*   **Test Your Issuing Integration** (Page 84): Learn how to test your Issuing integration in a sandbox environment by issuing cards and simulating purchases without real transactions.
*   **Test Your Integration** (Page 60): A guide to testing your credit integration in a sandbox environment using the Credit API.

### Issuing Card Management

*   **Choose Your Card Type** (Page 12): Decide between physical or virtual cards for your cardholders, understanding the trade-offs and use cases for each.
*   **Virtual Cards with Issuing** (Page 33): Learn about creating and displaying virtual card details in a PCI-compliant manner using the Dashboard, API, or Issuing Elements.
*   **Issue Virtual Cards** (Page 34): Step-by-step guide on creating virtual cards for cardholders using the Dashboard or the Cardholders API.
*   **Physical Cards** (Page 28): Understand the options for issuing physical cards, from standard cards with basic branding to fully custom designs, prioritizing speed-to-market or customization.
*   **Create Physical Cards** (Page 26): Instructions on creating physical cards for cardholders using the Dashboard or the Create a card endpoint.
*   **Choose Card Bundle** (Page 24): Learn how to set up standard or custom physical card bundles, including the card, carrier, and envelope.
*   **Order a Custom Bundle** (Page 27): Details on the process for ordering custom physical card bundles, including timelines and requirements.
*   **Customize Card Bundle** (Page 23): Make your card bundle selections, choosing from standard options or exploring innovative physical card materials.
*   **Artwork Templates** (Page 22): Access design templates for cards, carriers, and envelopes, with best practices for optimizing artwork for printing.
*   **Address Validation** (Page 21): Enable and manage address validation features for physical cards to ensure successful delivery.
*   **Ship Cards** (Page 29): Select shipping speeds and options for your cards, including individual and bulk shipping.
*   **Replacement Cards** (Page 32): Learn how to replace cards that are expired, damaged, lost, or stolen, understanding the process for each scenario.
*   **PIN Management** (Page 30): Allow cardholders to manage their personal identification numbers (PINs) for physical and virtual cards.
*   **Use Digital Wallets with Issuing** (Page 17): Integrate Issuing cards with digital wallets like Apple Pay and Google Pay using manual or push provisioning.
*   **Token Management** (Page 50): Understand how to manage network tokens for your cards, which are virtual representations used for payments and enhanced security.

### Funding and Balances

*   **Fund Your Issuing Balance** (Page 11, Page 61): Learn how to make funds available in your Issuing balance for future card spend, with options like pull funding, push funding, and Stripe balance transfers.
*   **Add Funds to Your Card Program** (Page 11): Explore your options for funding card spend, including pull-funded top-ups, push-funded top-ups, Stripe balance transfers, and Connect balance transfers.
*   **Postfund Your Integration with Stripe** (Page 64): Learn how to accrue a negative Issuing balance on card spend and post-fund Stripe at a later time, instead of pre-funding.
*   **Post-fund Your Integration with Dynamic Reserves** (Page 63): Utilize dynamic reserves to adjust your own credit limits in real-time to manage cash between Stripe and authorization availability.

### Integration Guides

*   **Integration Guides** (Page 5): A central hub for various integration guides to launch Stripe Issuing or Treasury for Platforms integrations.
*   **Embedded Finance Integration Guide** (Page 3): Build an embedded financial services integration using Issuing and Treasury for Platforms.
*   **B2B Payments Integration Guide** (Page 2): Create cards for your business, employees, or contractors to make purchases on your behalf using Stripe Issuing.
*   **Fleet Integration Guide** (Page 4): Build a fleet financial services integration with Issuing to create and manage customized fleet card programs.
*   **Integrate Processor-Only Issuing** (Page 18): Set up a processor-only Issuing integration where you manage your program's regulatory requirements, compliance, and licensing.
*   **Processor-Only Issuing** (Page 19): Understand the processor-only management model for Issuing, where Stripe integrates with networks and BIN sponsors through you.

### Stripe Connect Integrations

*   **Set Up an Issuing and Connect Integration** (Page 41): Learn how to issue cards on connected accounts using Stripe Connect for managing fund flows and compliance.
*   **Connected Accounts, Cardholders, and Cards** (Page 39): Understand how connected accounts, cardholders, and cards interact within a Stripe Connect integration.
*   **Cardholder Controls** (Page 36): Ensure your Issuing and Connect integration complies with legal and regulatory guidelines for screening cardholder information.
*   **Embed Issuing Card Management into Your Website** (Page 37): Use prebuilt UI components to embed Issuing card management functionality into your website for connected accounts.
*   **Inactive Connected Accounts Offboarding** (Page 38): Learn how inactivity affects connected accounts and how Stripe disables Issuing capabilities on inactive accounts.
*   **Fund Issuing Balances with Connect** (Page 40): Allocate funds to a connected account's Issuing balance before the issued card can be used for transactions.
*   **Update the Issuing Terms of Service Acceptance** (Page 62): Present accurate business information for connected accounts and ensure acceptance of Issuing terms of service.

### Credit Programs

*   **Issuing Credit** (Page 53): Apply your platform's Issuing account balance or exposure limit to cards issued to your connected accounts.
*   **Credit Consumer Issuing** (Page 15): Learn about the Stripe consumer credit solution to launch a credit program for your customers.
*   **How Credit Consumer Issuing Works** (Page 14): Understand the features and APIs needed to create, launch, and manage a credit program for your customers.
*   **Consumer Prepaid Debit Cards** (Page 13): Issue prepaid debit cards for users to instantly receive and spend money, offering rewards, disbursements, or branded card programs.
*   **Manage Credit Terms** (Page 55): Update credit terms for connected accounts, including credit limit amounts and intervals, or deactivate spending capabilities.
*   **Manage Account Obligations** (Page 54): Track credit spend, lifecycle, and balances for your connected accounts.
*   **Available Credit and Flow of Funds** (Page 51): Understand how funds flow and how the available credit amount field impacts authorization declines.
*   **Obligation Payments** (Page 56): Learn how to collect repayment from connected accounts for their Funding Obligations.
*   **Obligation Amounts, Transactions, and Adjustments** (Page 57): View details about Funding Obligations and make adjustments.
*   **Report Other Credit Decisions and Manage Adverse Action Notices** (Page 58): Record application and decision details, including adverse actions and sending adverse action notice emails (AANs).
*   **Report Required Regulatory Data for Credit Decisions** (Page 59): Report required regulatory data for credit decisions if your platform is subject to additional reporting.
*   **Set Up Credit for Connected Accounts** (Page 52): Configure credit terms for your connected accounts and fund their spend from your platform.
*   **Test Credit Integration** (Page 60): Validate your automated platform funding in testing environments.

### Fraud Management and Controls

*   **Manage Fraud** (Page 20): Understand transaction fraud, liability, and how to monitor and prevent fraud using Stripe's tools and controls.
*   **Advanced Fraud Tools** (Page 42): Reduce fraud with Issuing's advanced tooling, leveraging API signals and features for authorization decisions and compromise notifications.
*   **Issuing Authorization Rules** (Page 43): Limit authorization approvals by blocking transactions that match custom conditions, such as geography, amount, or fraud signals.
*   **Real-Time Authorizations** (Page 48): Approve or decline authorization requests in real time using synchronous webhooks.
*   **Migrate to Direct Webhook Response** (Page 44): Migrate your Issuing real-time authorizations from deprecated API calls to direct webhook responses.
*   **Fraud Challenges** (Page 45): Turn on fraud challenges for additional verification on high-risk authorizations, minimizing accidental blocks and allowing cardholders to retry legitimate transactions.
*   **Issuing Lifecycle Controls** (Page 47): Automatically cancel virtual cards after a specified number of payments for single-use or n-use card scenarios.
*   **Issuing Spending Controls** (Page 49): Set rules on cards and cardholders to control spending by blocking merchant categories, countries, merchant IDs, or setting spending limits.

### Transactions and Purchases

*   **Issuing Authorizations** (Page 77): Learn how authorization requests are handled, including balance checks, spending control validation, and real-time webhook responses.
*   **Issuing Transactions** (Page 80): Understand how authorization captures create Transaction objects and how the purchase amount is deducted from your balance.
*   **Issuing Disputes** (Page 78): Learn how to dispute transactions through the Dashboard or API for issues like fraud, product not received, or processing errors.
*   **Use Cards at Automated Teller Machines (ATMs)** (Page 76): Enable ATM cash withdrawals for US-issued cards and understand how ATM transactions are treated.
*   **Issuing Merchant Categories** (Page 35): Learn about Merchant Category Codes (MCCs) and how they're used for spending controls.
*   **Enriched Merchant Data** (Page 79): Utilize comprehensive merchant data to understand spending patterns, improve fraud prevention, and apply precise geospatial controls.

### Treasury for Platforms

*   **Treasury for Platforms** (Page 120): An overview of the Treasury for Platforms API suite for Stripe Connect platforms, enabling embedded financial services.
*   **How Treasury for Platforms Works** (Page 106): Learn about connected accounts, financial accounts for platforms, and moving money within the Treasury for Platforms ecosystem.
*   **Treasury for Platforms Requirements** (Page 121): Understand the compliance requirements and restrictions for using Treasury for Platforms.
*   **Get Started with API Access to Treasury for Platforms** (Page 85): Test Treasury for Platforms and Issuing in a sandbox environment before going live.
*   **Accounts Structure** (Page 86): Understand the different account types within the Treasury for Platforms ecosystem.
*   **Working with Connected Accounts** (Page 92): Request the treasury capability and collect onboarding requirements for your connected accounts.
*   **Working with Financial Accounts** (Page 93): Learn how to use financial accounts to store, send, and receive funds.
*   **Financial Account Features** (Page 87): Explore the features available for financial accounts, enabling money movement and card attachment.
*   **Platform Financial Accounts** (Page 89): Understand the financial account provisioned for your platform to store working capital.
*   **Working with Balances and Transactions** (Page 91): Learn about financial account balances and how transactions affect them.
*   **Moving Money** (Page 112): Explore methods to move funds out of financial accounts to other accounts.
*   **Moving Money into Financial Accounts** (Page 111): Learn the requests available to move money into financial accounts using InboundTransfer and ReceivedCredit objects.
*   **Moving Money Using InboundTransfer Objects** (Page 108): Transfer money from an external US bank account into a financial account using the ACH network.
*   **Moving Money Using ReceivedCredit Objects** (Page 109): Understand how funds move into a financial account and the corresponding ReceivedCredit object.
*   **Moving Money Using CreditReversal Objects** (Page 107): Learn how to return funds from received credits that add money to your financial account.
*   **Moving Money Using OutboundTransfer Objects** (Page 116): Transfer money out of financial accounts to external accounts via ACH or wire transfer.
*   **Moving Money Using OutboundPayment Objects** (Page 115): Create outbound payments to move money from financial accounts to third parties.
*   **Moving Money Using ReceivedDebit Objects** (Page 117): Understand how external account holders can pull funds from a financial account.
*   **Moving Money Using DebitReversal Objects** (Page 114): Retrieve funds taken out of a financial account from an external account holder.
*   **Payouts and Top-ups from Payments Balance** (Page 118): Learn how to move money between payments account balances and financial account balances.
*   **Working with SetupIntents, PaymentMethods, and BankAccounts** (Page 119): Set up money movements with Treasury for Platforms using PaymentMethod objects to save account credentials.
*   **ACH NOC and SEC Handling** (Page 113): Learn how external account information is updated via ACH Notification of Change (NOC).
*   **Money Movement Timelines** (Page 110): Understand the timelines for various types of money movement with Treasury for Platforms.
*   **Treasury for Platforms Fraud Guide** (Page 103): Learn best practices for managing fraud as a platform using Treasury for Platforms.
*   **Treasury for Platforms Connected Account Onboarding Guide** (Page 102): Implement a Treasury for Platforms onboarding process for your connected accounts, considering fraud prevention and regulatory compliance.
*   **Integrate with Fifth Third Bank** (Page 94): Add Fifth Third Bank to your existing Treasury for Platforms integration.
*   **Build a New Treasury for Platforms Integration with Fifth Third Bank** (Page 95): Get started with Stripe Treasury for Platforms using Fifth Third Bank.
*   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines** (Page 96): Ensure your Treasury for Platforms program and marketing campaigns are compliant.
*   **Handling Complaints** (Page 97): Learn how to properly handle complaints related to Treasury for Platforms or Stripe Issuing.
*   **Marketing Treasury for Platforms** (Page 98): Create precise messaging for your users that complies with regulations when using Treasury for Platforms.
*   **Regulatory Receipts** (Page 99): Learn about hosted transaction receipts for regulated money movements.

### Compliance and Support

*   **Customer Support for Issuing and Treasury for Platforms** (Page 1): Resolve common Issuing and Treasury for Platforms questions and issues.
*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines** (Page 71): Learn how to launch and maintain compliant Issuing and Treasury programs.
*   **Issuing Regulated Customer Notices** (Page 72): Understand how Stripe helps you stay compliant by sending properly formatted regulatory notifications to your customers.
*   **Stripe Issuing Marketing Guidelines** (Page 75): Learn about marketing guidelines for Issuing programs in the United Kingdom and Europe.
*   **Issuing Watchlist** (Page 74): Understand the Issuing watchlist process and best practices for automatic screening against sanctions lists.
*   **Issuing Beta Migration Guide** (Page 68): Learn how to migrate from the Issuing beta to the generally available version.
*   **Issuing for Agents** (Page 69): Provide agents with programmable cards with built-in controls for autonomous discovery, evaluation, and sourcing of products and services.
*   **Use Stripe Issuing in Different Countries** (Page 65): Learn about different integration options for issuing cards globally, including local and cross-border issuing.

### Stablecoin-Backed Cards

*   **Stablecoin-Backed Cards for Stripe Stablecoin Financial Accounts** (Page 81): Issue virtual or physical prepaid or debit cards for connected accounts, backed by Stablecoin Financial Accounts.
*   **Stablecoin-Backed Cards for Bridge, Privy, or Third-Party Wallets** (Page 82): Integrate Stripe Issuing with Bridge to build a stablecoin-backed consumer or commercial card program.
*   **Stablecoin-Backed Card Issuing** (Page 83): Issue prepaid or debit cards backed by stablecoin balances in partnership with Bridge.
## Stripe Issuing and Treasury for Platforms: Customer Communications and Compliance

This section of the Stripe documentation focuses on the crucial aspects of customer communication and regulatory compliance when using Stripe Issuing and Treasury for Platforms. It provides guidance on how platforms can effectively communicate with their customers and connected accounts regarding financial services, ensuring adherence to legal and regulatory requirements.

### Key Areas Covered:

*   **Issuing Regulated Customer Notices:** This guide details the mandatory customer communications that Issuing platforms must send upon specific trigger events. It highlights how Stripe assists in maintaining compliance by automatically sending properly formatted notices when required, offering a no-code solution for sending regulated emails.
*   **Product Marketing, Design, and Compliance Guidelines:** This comprehensive section covers the essential guidelines for marketing and user interfaces when offering Treasury for Platforms and Issuing products. It helps platforms navigate financial regulations and ensures that their branding and user experiences are compliant.
*   **Marketing Treasury for Platforms:** This resource focuses on crafting precise and compliant messaging for users of Treasury for Platforms. It provides recommended terms to use and terms to avoid to ensure regulatory adherence when describing financial services.
*   **Handling Complaints:** This guide outlines the mandatory procedures for handling customer complaints related to Treasury for Platforms or Stripe Issuing. It details how to provide accessible complaint submission channels, acknowledge and resolve complaints within specified timeframes, and maintain necessary records.
*   **Regulatory Receipts:** This section explains the availability of hosted transaction receipts for all money movement resources within Treasury for Platforms. It details how to provide customers with access to these receipts, which include transaction summaries and relevant disclosures.

By adhering to the guidelines and utilizing the resources provided in this section, platforms can ensure transparent, compliant, and effective communication with their customers when offering financial services through Stripe Issuing and Treasury for Platforms.
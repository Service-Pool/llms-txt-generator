## Stripe Issuing and Treasury for Platforms: Comprehensive Guide

This documentation suite provides a deep dive into Stripe's Issuing and Treasury for Platforms products, empowering developers to build sophisticated financial services for their users. Whether you're looking to issue cards, manage funds, or create embedded financial experiences, this resource covers the essential aspects of integration, management, and compliance.

---

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing, allowing you to create, manage, and distribute payment cards for your business or users.
*   **How Issuing Works:** Delve into the mechanics of Stripe Issuing, covering card program creation, spending management, transaction approvals, and network partnerships.
*   **Treasury for Platforms Overview:** Explore the suite of APIs that enable platforms to embed financial services, allowing connected accounts to hold funds, pay bills, and manage cash flow.
*   **Onboarding Overview:** Learn the essential steps and requirements for launching a Stripe Issuing or Treasury for Platforms integration.
*   **Integration Guides:** Access specific guides for integrating Issuing with various use cases:
    *   **Embedded Finance:** Build embedded financial services with Issuing and Treasury for Platforms.
    *   **B2B Payments:** Create a B2B payments integration using Stripe Issuing.
    *   **Fleet:** Develop a fleet financial services integration with Issuing.
*   **Sample App:** Utilize the Issuing and Treasury for Platforms sample app to understand API usage for onboarding, card creation, authorization testing, and outbound payments.
*   **Customer Support for Issuing and Treasury:** Find solutions for common questions and issues related to Issuing and Treasury for Platforms.

---

### Card Issuance and Management

*   **Choose Your Card Type:** Decide between physical and virtual cards, understanding the use cases and trade-offs for each.
*   **Virtual Cards:** Learn how to create and manage virtual cards for immediate use.
*   **Physical Cards:** Discover the process of issuing physical cards, including design, ordering, and shipping.
    *   **Choose Card Bundle:** Select standard or custom physical card bundles.
    *   **Order a Custom Bundle:** Understand the process and timeline for ordering custom card bundles.
    *   **Customize Card Bundle:** Make selections for card body materials and core color options.
    *   **Artwork Templates:** Utilize provided templates for card, carrier, and envelope design.
    *   **Create a Design:** Learn how to create and name your card bundle designs.
    *   **Issue Cards:** Create physical cards for cardholders via the Dashboard or API.
    *   **Ship Cards:** Choose between individual and bulk shipping options for your cards.
    *   **Address Validation:** Ensure successful delivery of physical cards with built-in address normalization and validation.
*   **Replacement Cards:** Understand the process for replacing expired, damaged, lost, or stolen cards.
*   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers (PINs) for transactions.
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay through manual or push provisioning.
*   **Token Management:** Learn how to manage network tokens for enhanced security in digital payments.

---

### Funding and Balances

*   **Fund Your Issuing Balance:** Make funds available for card spend by adding funds to your Issuing balance.
*   **Add Funds to Your Card Program:** Explore various funding options, including pull-funded top-ups, push-funded top-ups, Stripe balance transfers, and Connect balance transfers.
*   **Issuing Balance:** Understand how the Issuing balance functions as a segregated fund for card transactions.
*   **Post-fund Your Integration with Stripe:** Learn how to accrue a negative Issuing balance on card spend and post-fund Stripe later.
*   **Post-fund Your Integration with Dynamic Reserves:** Utilize dynamic reserves to adjust credit limits in real-time for managing cash flow.

---

### Integration with Stripe Connect

*   **Set up an Issuing and Connect Integration:** Integrate Stripe Issuing with Stripe Connect to manage funds flows and compliance for connected accounts.
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and the cards issued to them.
*   **Connect Funding:** Learn how to fund Issuing balances for connected accounts.
*   **Cardholder Controls:** Ensure compliance with legal and regulatory guidelines by managing cardholder information.
*   **Inactive Connected Accounts Offboarding:** Understand how inactivity affects Issuing capabilities on connected accounts.
*   **Embed Issuing Card Management:** Use Connect embedded components to integrate card management functionality into your website.

---

### Credit and Advanced Features

*   **Issuing Credit:** Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
*   **Credit Consumer Issuing:** Create, launch, and manage a credit program for your consumers.
*   **Manage Credit Terms:** Configure credit limits and terms for connected accounts.
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for your connected accounts.
    *   **Available Credit and Flow of Funds:** Understand how transactions affect available credit and how funds flow.
    *   **Obligation Payments:** Learn how to collect repayment from connected accounts.
    *   **Obligation Amounts, Transactions, and Adjustments:** View details about Funding Obligations and make adjustments.
*   **Report Other Credit Decisions and Manage Adverse Action Notices:** Record credit underwriting details and manage adverse action notices (AANs).
*   **Report Required Regulatory Data for Credit Decisions:** Comply with regulatory reporting requirements for credit programs.
*   **Test Credit Integration:** Validate your automated platform funding in testing environments.
*   **Stablecoin-backed Cards:** Issue prepaid or debit cards backed by stablecoin balances, integrating with Bridge, Privy, or third-party wallets.

---

### Controls and Fraud Management

*   **Manage Fraud:** Understand transaction fraud risks and how to combat them using Stripe Issuing controls and tools.
*   **Advanced Fraud Tools:** Leverage API signals and tooling to identify and prevent transaction fraud.
*   **Issuing Authorization Rules:** Limit authorization approvals by configuring custom rules based on various conditions.
*   **Real-time Authorizations:** Approve or decline authorization requests in real-time using synchronous webhooks.
    *   **Migrate to Direct Webhook Response:** Transition from deprecated API calls to direct webhook responses for real-time authorizations.
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations to minimize accidental blocks and verify high-risk transactions.
*   **Spending Controls:** Set rules on cards and cardholders to control spending by blocking merchant categories, countries, or setting spending limits.
*   **Lifecycle Controls:** Automatically cancel virtual cards after a specified number of payments for single-use or n-use scenarios.

---

### Transactions and Purchases

*   **Issuing Authorizations:** Understand how authorization requests are handled, approved, or declined.
*   **Issuing Transactions:** Learn how to handle transactions after an authorization is approved and captured.
*   **Issuing Disputes:** Submit and monitor disputes for transactions through the Dashboard or API.
*   **Enriched Merchant Data:** Utilize comprehensive merchant data to understand spending patterns and improve fraud prevention.
*   **Use Cards at Automated Teller Machines (ATMs):** Enable and manage ATM cash withdrawals for US-issued cards.
*   **Issuing Merchant Categories:** Understand the Merchant Category Codes (MCCs) used to group businesses and how to use them for spending controls.

---

### Compliance and Guidelines

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US):** Adhere to guidelines for launching and maintaining compliant Issuing and Treasury programs.
*   **Issuing Regulated Customer Notices:** Understand how to send regulatory notifications to your customers.
*   **Stripe Issuing Marketing Guidelines (Europe/UK):** Follow marketing guidelines for Issuing programs in the UK and Europe.
*   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant.

---

### Program Management and Customization

*   **Program Management:** Choose between Stripe program management and processor-only models for your Issuing program.
*   **Integrate Processor-Only Issuing:** Set up and manage your Issuing program with Stripe as the processor.
*   **Customize Your Card Program:** Tailor your Stripe Issuing card program to meet your specific business needs.
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents to autonomously discover and source products.
*   **Choose a Cardholder Type:** Select the appropriate cardholder type (individual or company) for your use case.
*   **Issuing Watchlist:** Understand the automated screening process for Issuing users against sanctions lists.

---

### Treasury for Platforms Specifics

*   **Get Started with API Access to Treasury for Platforms:** Test Treasury for Platforms functionality in a sandbox environment before going live.
*   **Accounts Structure:** Understand the interaction between platform and connected accounts within the Treasury for Platforms framework.
*   **Financial Account Features:** Explore the features available for financial accounts, enabling money movement and card attachment.
*   **Working with Stripe Issuing Cards:** Integrate Stripe Issuing with Treasury for Platforms to create physical and virtual cards.
*   **Platform Financial Accounts:** Learn about the automatically provisioned financial account for your platform.
*   **Treasury for Platforms Supportability for Connected Accounts:** Understand how Stripe evaluates connected accounts for Treasury for Platforms supportability.
*   **Working with Balances and Transactions:** Learn about financial account balances and how transactions affect them.
*   **Working with Connected Accounts:** Request the treasury capability and collect onboarding requirements for your connected accounts.
*   **Working with Financial Accounts:** Use financial accounts to store, send, and receive funds.
*   **Integrate with Fifth Third Bank:** Add Fifth Third Bank as a partner to your existing Treasury for Platforms integration.
*   **Build a New Treasury for Platforms Integration with Fifth Third Bank:** Get started with a new Treasury for Platforms integration using Fifth Third Bank.
*   **Webhooks for Stripe Issuing and Treasury for Platforms:** Understand webhook events for Issuing and Treasury for Platforms and how they occur.
*   **How Treasury for Platforms Works:** Learn about connected accounts, financial accounts for platforms, and moving money.
*   **Moving Money Using CreditReversal Objects:** Reverse received credits to return funds to your financial account.
*   **Moving Money Using InboundTransfer Objects:** Transfer money from an external US bank account into a financial account.
*   **Moving Money Using ReceivedCredit Objects:** Understand how funds move into a financial account and the corresponding ReceivedCredit object.
*   **Money Movement Timelines:** Learn about the processing and cutoff times for various money movement types.
*   **Moving Money into Financial Accounts:** Explore the requests available to move money into financial accounts.
*   **Moving Money Out of Treasury for Platforms:** Learn the methods to move funds from a financial account to another account.
*   **Moving Money Using DebitReversal Objects:** Retrieve funds taken out of a financial account from an external account holder.
*   **Moving Money Using OutboundPayment Objects:** Create outbound payments to move money from financial accounts to third parties.
*   **Moving Money Using OutboundTransfer Objects:** Transfer money out of financial accounts to external accounts.
*   **Moving Money Using ReceivedDebit Objects:** Observe ReceivedDebit object creation when funds are pulled from a financial account.
*   **Payouts and Top-ups from Payments Balance:** Move money between payments account balances and financial account balances.
*   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.
*   **Treasury for Platforms Requirements:** Understand the compliance requirements and restrictions for using Treasury for Platforms.
*   **Treasury for Platforms Fraud Guide:** Learn best practices for managing fraud as a platform.
*   **Issuing and Treasury for Platforms Sample App:** Utilize the Next.js sample app to start your own Issuing and Treasury for Platforms integration.
## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and card creation to advanced fraud management and international expansion.

### Core Concepts and Getting Started

*   **Issuing Overview**: Understand the fundamental capabilities of Stripe Issuing for creating, managing, and distributing payment cards.
*   **How Issuing Works**: Delve into the mechanics of building a card program with Stripe Issuing, including partnerships with banks and card networks.
*   **Onboarding Overview**: Learn the essential steps and requirements to get your Issuing or Treasury for Platforms integration live.
*   **Integration Guides**: Access specific guides for various use cases:
    *   **Embedded Finance**: Build embedded financial services with Issuing and Treasury for Platforms.
    *   **B2B Payments**: Create cards for business, employee, or contractor purchases.
    *   **Fleet**: Develop fleet management card programs.
*   **Sample App**: Explore a sample application to see Issuing and Treasury for Platforms APIs in action, allowing you to onboard customers, create cards, and test authorizations.
*   **Customer Support**: Find resources for resolving common Issuing and Treasury for Platforms questions.

### Card Management and Issuance

*   **Choose Card Type**: Decide between physical and virtual cards, understanding the use cases and trade-offs for each.
*   **Virtual Cards**: Learn how to create and display virtual card details in a PCI-compliant manner.
*   **Physical Cards**: Understand the process of issuing physical cards, including design, ordering, and shipping.
    *   **Artwork Templates**: Utilize provided templates for card, carrier, and envelope design.
    *   **Customize Card Bundle**: Select standard or custom options for your physical card bundles.
    *   **Order a Custom Bundle**: Follow the process for ordering bespoke physical card bundles.
    *   **Create a Design**: Design and name your card bundle for issuance.
    *   **Issue Cards**: Create physical cards for cardholders using the Dashboard or API.
    *   **Ship Cards**: Choose between individual and bulk shipping options for your cards.
    *   **Address Validation**: Ensure successful delivery of physical cards with built-in address normalization and validation.
*   **Replacement Cards**: Learn how to replace expired, damaged, lost, or stolen cards.
*   **PIN Management**: Enable cardholders to manage their personal identification numbers.
*   **Digital Wallets**: Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.

### Funding and Balances

*   **Issuing Balance**: Understand how to make funds available for card spend, separated from other Stripe balances.
*   **Add Funds to Your Card Program**: Explore various funding options, including pull-funded top-ups, push-funded top-ups, and balance transfers.
*   **Postfund Your Integration with Stripe**: Learn about accruing a negative Issuing balance on card spend and funding Stripe later.
*   **Post-fund Your Integration with Dynamic Reserves**: Utilize dynamic reserves to manage capital and minimize funding costs.

### Program Management and Customization

*   **Program Management**: Choose between Stripe program management and processor-only models for your Issuing program.
*   **Processor-Only Issuing**: Integrate as a processor, managing regulatory requirements, compliance, and licensing.
*   **Customize Your Card Program**: Tailor your Stripe Issuing card program to meet specific business needs, including BIN setup.

### Controls and Fraud Management

*   **Manage Fraud**: Understand transaction fraud risks and how to combat them using Stripe Issuing controls and tools.
*   **Advanced Fraud Tools**: Leverage API signals and tooling to identify and prevent transaction fraud.
*   **Issuing Authorization Rules**: Limit authorization approvals by configuring custom rules based on various conditions.
*   **Real-Time Authorizations**: Approve or decline authorization requests in real time using synchronous webhooks.
    *   **Migrate to Direct Webhook Response**: Transition from deprecated API calls to direct webhook responses for real-time authorizations.
*   **Fraud Challenges**: Implement an additional layer of verification for authorizations to minimize accidental blocks.
*   **Spending Controls**: Set rules on cards and cardholders to control spending by blocking merchant categories, countries, or setting spending limits.
*   **Lifecycle Controls**: Automatically cancel virtual cards after a specified number of payments for single-use or n-use scenarios.
*   **Token Management**: Manage network tokens for cards, which are virtual representations used for secure payments.
*   **Issuing Watchlist**: Understand the automatic screening process against sanctions lists and manual review procedures.

### Stripe Connect Integrations

*   **Set Up an Issuing and Connect Integration**: Integrate Stripe Connect with Issuing to manage funds flows and compliance for third-party users.
*   **Connected Accounts, Cardholders, and Cards**: Learn how to create and manage cardholders and cards within a Connect integration.
*   **Cardholder Controls**: Ensure compliance with legal and regulatory guidelines for screening cardholder information.
*   **Inactive Connected Accounts Offboarding**: Understand how inactivity affects Issuing capabilities on connected accounts.
*   **Fund Issuing Balances with Connect**: Learn how to allocate funds to connected accounts' Issuing balances.
*   **Embed Issuing Card Management into Your Website**: Utilize Connect embedded components for seamless card management integration.
*   **Update the Issuing Terms of Service Acceptance**: Ensure accurate business information is presented for connected accounts.

### Stripe Treasury for Platforms

*   **Treasury for Platforms Overview**: Learn how to provide financial services to connected accounts by embedding financial services into your product.
*   **Get Started with API Access**: Test Treasury for Platforms functionality in a sandbox environment before going live.
*   **Eligibility Requirements**: Understand the compliance requirements and restrictions for using Treasury for Platforms.
*   **Accounts Structure**: Comprehend the interaction between platform and connected accounts within the Treasury for Platforms framework.
*   **Working with Connected Accounts**: Request the treasury capability and collect onboarding requirements for connected accounts.
*   **Working with Financial Accounts**: Utilize financial accounts to store, send, and receive funds for connected accounts.
*   **Financial Account Features**: Discover features available for financial accounts, such as moving money and attaching payment cards.
*   **Platform Financial Accounts**: Understand the dedicated financial account provisioned for your platform.
*   **Working with Balances and Transactions**: Learn about financial account balances and how transactions affect them.
*   **Moving Money**: Explore various methods for moving money into and out of financial accounts.
    *   **Moving Money into Financial Accounts**: Use InboundTransfer and ReceivedCredit objects.
    *   **Moving Money Out of Financial Accounts**: Utilize OutboundTransfer, OutboundPayment, ReceivedDebit, and card transactions.
    *   **Payouts and Top-ups from Payments Balance**: Move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts**: Set up money movements with Treasury for Platforms.
    *   **ACH NOC and SEC Handling**: Understand how external account information is updated via ACH Notifications of Change.
*   **Money Movement Timelines**: Learn about the processing and cutoff times for various money movement methods.
*   **Integrate with Fifth Third Bank**: Integrate Fifth Third Bank into your existing or new Treasury for Platforms integration.
*   **Sample Integrations**:
    *   **Use Treasury for Platforms and Issuing to Set Up Financial Accounts and Cards**: Follow a sample integration for setting up financial accounts and creating cards.
    *   **Using Treasury for Platforms to Move Money**: Learn basic money movement using Treasury endpoints.
    *   **Issuing and Treasury for Platforms Sample App**: Utilize a Next.js sample app for Issuing and Treasury for Platforms integration.
*   **Webhooks**: Understand webhook events for Stripe Issuing and Treasury for Platforms to handle asynchronous events.
*   **Marketing and Compliance Guidelines**: Adhere to guidelines for compliant marketing and user interfaces for Treasury for Platforms and Issuing.
*   **Handling Complaints**: Learn how to properly handle complaints related to Treasury for Platforms or Stripe Issuing.
*   **Regulatory Receipts**: Understand hosted transaction receipts for regulated money movement.

### Credit Issuing

*   **Issuing Credit Overview**: Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
*   **Credit Consumer Issuing**: Create, launch, and manage a credit program for your consumers.
*   **Set Up Credit for Connected Accounts**: Configure credit terms for connected accounts and fund their spend from your platform.
*   **Manage Credit Terms**: Update credit limits and deactivate credit spending abilities for connected accounts.
*   **Manage Account Obligations**: Track credit spend, lifecycle, and balances for your connected accounts.
    *   **Obligation amounts, transactions, and adjustments**: View details about Funding Obligations and make adjustments.
    *   **Obligation payments**: Make payments to your Funding Obligation.
    *   **Available credit and flow of funds**: Understand how funds flow and use the available credit amount field.
*   **Report other credit decisions and manage adverse action notices**: Record application and decision details, including adverse actions.
*   **Report required regulatory data for credit decisions**: Upload regulatory reporting data for credit decisions if your platform is subject to additional reporting.
*   **Test Credit Integration**: Validate your automated platform funding in testing environments.

### Regional and Compliance Information

*   **Use Stripe Issuing in Different Countries**: Explore options for local and cross-border issuing across various geographies.
*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US)**: Navigate financial regulations for marketing and user interfaces in the US.
*   **Issuing Regulated Customer Notices**: Understand how Stripe helps you stay compliant by sending regulated customer communications.
*   **Stripe Issuing Marketing Guidelines (Europe/UK)**: Adhere to guidelines for marketing Issuing programs in the UK and Europe.

### Transactions and Purchases

*   **Issuing Authorizations**: Learn how to handle authorization requests when a card is used for a purchase.
*   **Issuing Transactions**: Understand how authorization captures result in Transaction objects.
*   **Issuing Disputes**: Learn how to dispute transactions through the Dashboard or API.
*   **Use Cards at Automated Teller Machines (ATMs)**: Enable and use US-issued cards for ATM cash withdrawals.
*   **Enriched Merchant Data**: Utilize comprehensive merchant data for improved fraud prevention and spending analysis.
*   **Issuing Merchant Categories**: Understand Merchant Category Codes (MCCs) and how they are used for spending controls.
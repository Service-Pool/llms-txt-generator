## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite provides comprehensive guidance on leveraging Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and integration to advanced features like fraud management, credit programs, and international expansion.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing and how it can be used to create and manage payment cards for your business or customers.
*   **How Issuing Works:** Delve into the mechanics of Stripe Issuing, including partnerships with banks and card networks, and regional considerations.
*   **Treasury for Platforms Overview:** Learn how Treasury for Platforms enables you to embed financial services into your product, allowing connected accounts to hold funds, pay bills, and manage cash flow.
*   **Get Started with API Access to Treasury for Platforms:** Understand the initial steps to gain API access and begin testing Treasury for Platforms.
*   **Onboarding Overview:** A crucial guide for understanding the process of getting your Issuing or Treasury for Platforms integration live.
*   **Test Your Issuing Integration:** Learn how to simulate purchases and test your Issuing integration in a sandbox environment.
*   **Test Your Integration (Treasury for Platforms):** Validate your automated platform funding in testing environments for Treasury for Platforms.

### Issuing Card Management

*   **Choose Your Card Type:** Decide between physical or virtual cards for your cardholders, understanding the trade-offs and use cases for each.
*   **Virtual Cards with Issuing:** Learn how to create and display virtual card details to your cardholders in a PCI-compliant manner.
*   **Physical Cards:** Explore the options for issuing physical cards, from standard cards with basic branding to fully custom designs.
    *   **Choose your physical bundle:** Understand the components of a physical card bundle (card, carrier, envelope) and available standard and custom options.
    *   **Order a custom bundle:** Learn the process for ordering custom physical card bundles, including timelines and requirements.
    *   **Customize card bundle:** Make your card bundle selections during the design phase.
    *   **Artwork templates:** Utilize provided design templates for cards, carriers, and envelopes.
    *   **Create a design:** Learn how to create and name your card bundle design in the Issuing Dashboard or API.
    *   **Issue cards:** Understand how to issue physical cards to cardholders using the Dashboard or API.
    *   **Ship cards:** Select the shipping speed and method (individual or bulk) for your cards.
    *   **Address validation:** Enable and manage address validation features for physical cards to ensure successful delivery.
*   **Replacement cards:** Learn how to replace cards that are expired, damaged, lost, or stolen.
*   **Use digital wallets with Issuing:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **PIN management:** Allow your cardholders to manage their personal identification numbers for physical and virtual cards.

### Integration Guides and Use Cases

*   **Integration guides:** A central hub for accessing various integration guides for Issuing.
*   **Embedded Finance integration guide:** Build an embedded financial services integration with Issuing and Treasury for Platforms.
*   **B2B payments integration guide:** Create cards for your business, employees, or contractors to make purchases on your behalf.
*   **Fleet integration guide:** Build a fleet financial services integration using Stripe Issuing.
*   **Issuing and Treasury for Platforms sample app:** Explore a sample application to understand how to use Issuing and Treasury for Platforms APIs.
*   **Processor-only Issuing:** Integrate with Stripe Issuing where you manage your program, including regulatory requirements, compliance, and licensing.
    *   **Integrate processor-only Issuing:** Set up a processor-only Issuing integration.

### Funding and Balances

*   **Issuing balance:** Learn how to make funds available to your cards by funding your Issuing balance.
*   **Add funds to your card program:** Explore options for funding your Issuing balance, including pull-funded top-ups, push-funded top-ups, Stripe balance transfers, and Connect balance transfers.
*   **Postfund your integration with Stripe:** Accrue a negative Issuing balance on card spend and post-fund Stripe at a later time.
*   **Post-fund your integration with Dynamic Reserves:** Use dynamic reserves to adjust your own credit limits in real-time to manage cash between Stripe and funds available for authorization.

### Stripe Connect Integration

*   **Set up an Issuing and Connect integration:** Learn how to issue cards on connected accounts using Stripe Connect.
*   **Connected accounts, cardholders, and cards:** Understand how to create and manage cardholders and cards with Stripe Connect.
*   **Cardholder controls:** Ensure your Issuing and Connect integration complies with legal and regulatory guidelines for screening cardholder information.
*   **Inactive connected accounts offboarding:** Learn how inactivity can affect connected accounts' Issuing capabilities.
*   **Fund Issuing balances with Connect:** Understand how to fund connected accounts for Issuing.
*   **Update the Issuing terms of service acceptance:** Learn how to present accurate business information for your connected accounts and accept the Issuing terms of service.
*   **Embed Issuing card management into your website:** Use prebuilt UI components to embed Issuing card management functionality into your website.

### Treasury for Platforms Account Management

*   **Accounts structure:** Understand the technical components of Stripe Treasury for Platforms and how different account types interact.
*   **Working with connected accounts:** Request the treasury capability and collect onboarding requirements for your connected accounts.
*   **Working with financial accounts:** Learn how to use financial accounts to store, send, and receive funds.
*   **Financial account features:** Discover the features available for financial accounts, enabling money movement and card attachment.
*   **Platform financial accounts:** Understand the financial account provisioned for your platform to store working capital.
*   **Working with balances and transactions:** Learn about financial account balances and the impact of transactions.

### Treasury for Platforms Money Movement

*   **Use Treasury for platforms to move money:** Learn how to use SetupIntents and PaymentMethods, and how to verify bank accounts.
*   **Moving money into financial accounts:** Understand the requests available to move money into financial accounts using InboundTransfer and ReceivedCredit objects.
    *   **Moving money using InboundTransfer objects:** Learn how to transfer money from another account you own into a financial account.
    *   **Moving money using ReceivedCredit objects:** Learn how to move money into a financial account from another financial account or bank account.
    *   **Moving money using CreditReversal objects:** Learn how to return funds from received credits that add money to your financial account.
*   **Moving money out of Treasury for Platforms:** Learn the requests available to move money out of financial accounts to other accounts.
    *   **Moving money using OutboundTransfer objects:** Learn how to transfer money out of financial accounts to external accounts.
    *   **Moving money using OutboundPayment objects:** Learn how to create outbound payments to move money out of financial accounts to third parties.
    *   **Moving money using ReceivedDebit objects:** Learn how external account holders can pull funds from a financial account.
    *   **Moving money using DebitReversal objects:** Learn how you can retrieve funds taken out of a financial account from an external account holder.
*   **Payouts and top-ups from payments balance:** Learn how to move money between payments account balances and financial account balances.
*   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.
*   **ACH NOC and SEC handling:** Learn how external account information is updated.
*   **Money movement timelines:** Understand the timelines for various types of money movement with Treasury for Platforms.

### Credit Programs

*   **Issuing Credit:** Apply your platform Issuing account balance or platform exposure limit to cards issued to your connected accounts.
*   **Credit Consumer Issuing:** Learn about the Stripe consumer credit solution to launch a credit program for your customers.
    *   **How Credit Consumer Issuing works:** Learn about the features and APIs needed to create, launch, and manage a credit program for your customers.
*   **Manage account obligations:** Track the credit spend, lifecycle, and balances for your connected accounts.
    *   **Available credit and flow of funds:** Learn how funds flow and how to use the available credit amount field to prevent authorization declines.
    *   **Obligation payments:** Make payments to your FundingObligation.
    *   **Obligation amounts, transactions, and adjustments:** View details about a FundingObligation and make adjustments.
*   **Manage credit terms:** Learn how to manage the credit terms for connected accounts.
*   **Set up credit for connected accounts:** Learn how to configure credit terms for your connected accounts and fund their spend from your platform.
*   **Report other credit decisions and manage adverse action notices:** Learn how to report various credit decisions and send adverse action notice emails.
*   **Report required regulatory data for credit decisions:** Learn how to report required regulatory data for credit decisions if your platform is subject to additional reporting for credit programs.
*   **Test credit integration:** Validate your automated platform funding in testing environments.

### Fraud Management and Controls

*   **Manage fraud with Stripe Issuing controls and tools:** Understand transaction fraud and how to combat it using Stripe's resources.
*   **Advanced fraud tools:** Reduce fraud with Issuing’s advanced tooling, including API signals and real-time authorization decisions.
*   **Issuing authorization rules:** Limit authorization approvals using Issuing authorization rules to prevent unauthorized activity.
*   **Issuing real-time authorizations:** Approve or decline authorization requests in real time using synchronous webhooks.
    *   **Migrate to direct webhook response:** Learn how to migrate Issuing real-time authorizations from deprecated API calls to direct webhook responses.
*   **Fraud challenges:** Turn on fraud challenges for an additional layer of verification for authorizations.
*   **Spending controls:** Set rules on cards and cardholders to control spending by blocking merchant categories, countries, or setting spending limits.
*   **Lifecycle controls:** Control automatic usage-based cancellation of cards for single-use or n-use scenarios.
*   **3D Secure:** Learn about 3D Secure, an additional layer of authentication used to combat fraud for online transactions.
*   **Issuing watchlist:** Understand the Issuing watchlist process and best practices for screening users against sanctions lists.

### Compliance and Marketing

*   **Issuing and Treasury product marketing, design, and compliance guidelines:** Learn how to launch and maintain compliant Issuing and Treasury programs.
*   **Issuing regulated customer notices:** Understand how to send regulatory notifications to your customers.
*   **Treasury for platforms product marketing, design, and compliance guidelines:** Learn how to keep your Treasury for Platforms program and marketing campaigns compliant.
*   **Marketing Treasury for platforms:** Create precise messaging for your users that complies with regulations.
*   **Handling complaints:** Learn how to properly handle complaints about Treasury for Platforms or Stripe Issuing.
*   **Regulatory receipts:** Learn about hosted transaction receipts for regulated money movements.
*   **Marketing guidance (Europe/UK):** Understand marketing guidelines for Issuing programs in the United Kingdom and Europe.

### Other Features and Information

*   **Customer support for Issuing and Treasury for platforms:** Resolve common Issuing and Treasury for Platforms questions and issues.
*   **Issuing merchant categories:** Learn about the available categories that businesses are grouped into using Merchant Category Codes (MCCs).
*   **Use cards at automated teller machines (ATMs):** Learn how to enable and use your Stripe Issuing cards for ATM cash withdrawals.
*   **Issuing transactions:** Understand how to handle transactions after an authorization is approved and captured.
*   **Issuing disputes:** Learn how to dispute transactions when an issue occurs.
*   **Enriched merchant data:** Use comprehensive merchant data to understand customer spending patterns and improve fraud prevention.
*   **Stablecoin-backed card issuing:** Issue prepaid or debit cards backed by stablecoin balances in partnership with Bridge.
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts:** Learn how to issue virtual or physical prepaid or debit cards for connected accounts, backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrate Stripe Issuing with Bridge to build a stablecoin-backed consumer or commercial card program.
*   **Issuing for agents:** Give your agents programmable cards with built-in controls for agentic commerce workflows.
*   **Choose a cardholder type:** Learn how to select the best cardholder type (individual or company) for your use case.
*   **Use Stripe Issuing in different countries:** Explore integration options for issuing cards globally, including local and cross-border issuing.
*   **Issuing beta migration guide:** Learn how to migrate from the Issuing beta to the generally available version.
*   **Using Issuing Elements:** Display card details in your web application in a PCI-compliant way using Stripe.js.
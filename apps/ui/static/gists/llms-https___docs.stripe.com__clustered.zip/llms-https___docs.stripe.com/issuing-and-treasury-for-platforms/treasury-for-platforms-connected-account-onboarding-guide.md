## Stripe Issuing and Treasury for Platforms

This documentation group provides comprehensive guidance on integrating Stripe Issuing and Treasury for Platforms. It covers everything from initial setup and integration to advanced features like fraud management, credit programs, and international usage.

### Core Concepts and Integration

*   **Getting Started:** The foundational pages explain how to get started with Stripe Issuing and Treasury for Platforms, including sandbox environments and API access.
    *   [Issuing | Stripe Documentation](/issuing)
    *   [Treasury for platforms | Stripe Documentation](/treasury/connect)
    *   [Get started with API access to Treasury for platforms | Stripe Documentation](/treasury/connect/access)
    *   [How Treasury for platforms works | Stripe Documentation](/treasury/connect/how-financial-accounts-for-platforms-works)
    *   [Issuing and Treasury product marketing, design, and compliance guidelines | Stripe Documentation](/issuing/compliance-us)
    *   [Treasury for platforms product marketing, design, and compliance guidelines | Stripe Documentation](/treasury/connect/compliance)
    *   [Onboarding overview | Stripe Documentation](/issuing/onboarding-overview)
    *   [Treasury for platforms connected account onboarding guide | Stripe Documentation](/treasury/connect/examples/onboarding-guide)

*   **Integration Guides:** Specific guides are available for various use cases, helping you tailor your integration.
    *   [Integration guides | Stripe Documentation](/issuing/integration-guides)
    *   [Embedded Finance integration guide | Stripe Documentation](/issuing/integration-guides/embedded-finance)
    *   [B2B payments integration guide | Stripe Documentation](/issuing/integration-guides/b2b-payments)
    *   [Fleet integration guide | Stripe Documentation](/issuing/integration-guides/fleet)
    *   [Set up an Issuing and Connect integration | Stripe Documentation](/issuing/connect)
    *   [Use Treasury for platforms and Issuing to set up financial accounts and cards | Stripe Documentation](/treasury/connect/examples/financial-accounts)

### Issuing Cards

*   **Card Types and Customization:** Learn about the different card options and how to customize them.
    *   [Choose which type of card to issue | Stripe Documentation](/issuing/choose-cards)
    *   [Virtual cards with Issuing | Stripe Documentation](/issuing/cards/virtual)
    *   [Create virtual cards | Stripe Documentation](/issuing/cards/virtual/issue-cards)
    *   [Physical cards | Stripe Documentation](/issuing/cards/physical)
    *   [Create physical cards | Stripe Documentation](/issuing/cards/physical/issue-cards)
    *   [Customize your card program | Stripe Documentation](/issuing/customize-your-program)
    *   [Artwork templates | Stripe Documentation](/issuing/cards/artwork-templates)
    *   [Customize card bundle | Stripe Documentation](/issuing/cards/physical/card-bundle-selections)
    *   [Choose your physical bundle | Stripe Documentation](/issuing/cards/physical/choose-bundle)
    *   [Order a custom bundle | Stripe Documentation](/issuing/cards/physical/order-custom-bundle)
    *   [Ship cards | Stripe Documentation](/issuing/cards/physical/ship-cards)
    *   [Physical cards address validation | Stripe Documentation](/issuing/cards/physical/address-validation)

*   **Cardholder Management:** Understand how to manage cardholders and their associated controls.
    *   [Choose a cardholder type | Stripe Documentation](/issuing/other/choose-cardholder)
    *   [Connected accounts, cardholders, and cards | Stripe Documentation](/issuing/connect/cardholders-and-cards)
    *   [Cardholder controls | Stripe Documentation](/issuing/connect/cardholders-controls)
    *   [Inactive connected accounts offboarding | Stripe Documentation](/issuing/connect/inactive-accounts-management)

*   **PIN Management:** Learn how to manage PINs for cardholders.
    *   [PIN management | Stripe Documentation](/issuing/cards/pin-management)

*   **Replacement Cards:** Process for replacing expired, damaged, lost, or stolen cards.
    *   [Replacement cards | Stripe Documentation](/issuing/cards/replacements)

### Funding and Money Movement

*   **Issuing Balance:** How to fund your Issuing balance for card spend.
    *   [Fund your Issuing balance | Stripe Documentation](/issuing/funding/balance)
    *   [Add funds to your card program | Stripe Documentation](/issuing/adding-funds-to-your-card-program)

*   **Treasury for Platforms Money Movement:** Detailed guides on moving money within Treasury for Platforms.
    *   [Using Treasury for platforms to move money | Stripe Documentation](/treasury/connect/examples/moving-money)
    *   [Moving money into financial accounts | Stripe Documentation](/treasury/connect/moving-money/moving-money-into-financial-accounts)
    *   [Moving money using InboundTransfer objects | Stripe Documentation](/treasury/connect/moving-money/into/inbound-transfers)
    *   [Moving money using ReceivedCredit objects | Stripe Documentation](/treasury/connect/moving-money/into/received-credits)
    *   [Moving money using CreditReversal objects | Stripe Documentation](/treasury/connect/moving-money/into/credit-reversals)
    *   [Moving money out of Treasury for platforms | Stripe Documentation](/treasury/connect/moving-money/moving-money-out)
    *   [Moving money using OutboundTransfer objects | Stripe Documentation](/treasury/connect/moving-money/out-of/outbound-transfers)
    *   [Moving money using OutboundPayment objects | Stripe Documentation](/treasury/connect/moving-money/out-of/outbound-payments)
    *   [Moving money using ReceivedDebit objects | Stripe Documentation](/treasury/connect/moving-money/out-of/received-debits)
    *   [Moving money using DebitReversal objects | Stripe Documentation](/treasury/connect/moving-money/out-of/debit-reversals)
    *   [Payouts and top-ups from payments balance | Stripe Documentation](/treasury/connect/moving-money/payouts)
    *   [Money movement timelines | Stripe Documentation](/treasury/connect/money-movement/timelines)
    *   [Working with SetupIntents, PaymentMethods, and BankAccounts | Stripe Documentation](/treasury/connect/moving-money/working-with-bankaccount-objects)
    *   [ACH NOC and SEC handling | Stripe Documentation](/treasury/connect/moving-money/noc-sec-handling)

*   **Connect Funding:** Specific guidance on funding Issuing balances with Connect.
    *   [Fund Issuing balances with Connect | Stripe Documentation](/issuing/connect/funding)

*   **Post-funding:** Options for post-funding your integration.
    *   [Postfund your integration with Stripe | Stripe Documentation](/issuing/funding/post-fund)
    *   [Post-fund your integration with Dynamic Reserves | Stripe Documentation](/issuing/funding/post-fund-with-dynamic-reserves)

### Credit Programs

*   **Issuing Credit Overview:** Understand the capabilities and features of Issuing Credit.
    *   [Issuing Credit | Stripe Documentation](/issuing/credit)
    *   [Credit Consumer Issuing | Stripe Documentation](/issuing/credit/consumer-issuing)
    *   [How Credit Consumer Issuing works | Stripe Documentation](/issuing/consumer-issuing/how-it-works)

*   **Managing Credit:** Guides on setting up and managing credit terms and obligations.
    *   [Set up credit for connected accounts | Stripe Documentation](/issuing/credit/connect-credit-setup)
    *   [Manage credit terms | Stripe Documentation](/issuing/credit/manage-credit-terms)
    *   [Manage account obligations | Stripe Documentation](/issuing/credit/manage-account-obligations)
    *   [Obligation amounts, transactions, and adjustments | Stripe Documentation](/issuing/credit/manage-account-obligations/obligations-transactions-adjustments)
    *   [Obligation payments | Stripe Documentation](/issuing/credit/manage-account-obligations/obligation-payments)
    *   [Available credit and flow of funds | Stripe Documentation](/issuing/credit/manage-account-obligations/available-credit)
    *   [Report other credit decisions and manage adverse action notices | Stripe Documentation](/issuing/credit/report-credit-decisions-and-manage-aans)
    *   [Report required regulatory data for credit decisions | Stripe Documentation](/issuing/credit/report-required-regulatory-data-for-credit-decisions)
    *   [Test your integration | Stripe Documentation](/issuing/credit/test-credit)

### Fraud Management and Controls

*   **Fraud Prevention:** Tools and strategies to manage and prevent fraud.
    *   [Manage fraud with Stripe Issuing controls and tools | Stripe Documentation](/issuing/manage-fraud)
    *   [Advanced fraud tools | Stripe Documentation](/issuing/controls/advanced-fraud-tools)
    *   [Issuing authorization rules | Stripe Documentation](/issuing/controls/authorization-rules)
    *   [Fraud challenges | Stripe Documentation](/issuing/controls/fraud-challenges)
    *   [Cardholder authentication using 3D Secure | Stripe Documentation](/issuing/3d-secure)

*   **Real-time Authorizations:** Handling authorization requests in real-time.
    *   [Issuing real-time authorizations | Stripe Documentation](/issuing/controls/real-time-authorizations)
    *   [Set up and manage real-time authorizations | Stripe Documentation](/issuing/controls/real-time-authorizations/quickstart)
    *   [Migrate to direct webhook response | Stripe Documentation](/issuing/controls/real-time-authorizations/direct-webhook-migration)

*   **Spending Controls:** Setting rules to control cardholder spending.
    *   [Issuing spending controls | Stripe Documentation](/issuing/controls/spending-controls)

*   **Lifecycle Controls:** Automating card cancellation based on usage.
    *   [Issuing lifecycle controls | Stripe Documentation](/issuing/controls/lifecycle-controls)

*   **Token Management:** Managing network tokens for secure payments.
    *   [Token management | Stripe Documentation](/issuing/controls/token-management)

### Specific Use Cases and Features

*   **Consumer Issuing:** Issuing prepaid and stablecoin-backed cards for consumers.
    *   [Consumer prepaid debit cards | Stripe Documentation](/issuing/consumer-prepaid-debit-cards)
    *   [Stablecoin-backed cards for Stripe Stablecoin Financial Accounts | Stripe Documentation](/issuing/stablecoin-cards-for-financial-accounts)
    *   [Stablecoin-backed cards for Bridge, Privy, or third-party wallets | Stripe Documentation](/issuing/bridge-stablecoin-cards)
    *   [Stablecoin-backed card issuing | Stripe Documentation](/issuing/stablecoin-cards)

*   **B2B Payments, Fleet, and Embedded Finance:** Specialized integration guides.
    *   [B2B payments integration guide | Stripe Documentation](/issuing/integration-guides/b2b-payments)
    *   [Fleet integration guide | Stripe Documentation](/issuing/integration-guides/fleet)
    *   [Embedded Finance integration guide | Stripe Documentation](/issuing/integration-guides/embedded-finance)

*   **Processor-Only Integration:** For partners who manage their own BIN sponsorship and network integration.
    *   [Processor-only Issuing | Stripe Documentation](/issuing/processor-only-issuing)
    *   [Integrate processor-only Issuing | Stripe Documentation](/issuing/processor-only-integration-guide)

*   **Digital Wallets:** Integrating Issuing cards with digital wallets.
    *   [Use digital wallets with Issuing | Stripe Documentation](/issuing/cards/digital-wallets)

*   **ATM Usage:** Enabling ATM withdrawals for cards.
    *   [Use cards at automated teller machines (ATMs) | Stripe Documentation](/issuing/purchases/atm-usage)

*   **Issuing for Agents:** Providing programmable cards for agents.
    *   [Issuing for agents | Stripe Documentation](/issuing/agents)

*   **Global Availability:** Using Stripe Issuing in different countries.
    *   [Use Stripe Issuing in different countries | Stripe Documentation](/issuing/global)

### Treasury for Platforms Specifics

*   **Account Management:** Understanding the structure and management of accounts.
    *   [Accounts structure | Stripe Documentation](/treasury/connect/account-management/accounts-structure)
    *   [Working with connected accounts | Stripe Documentation](/treasury/connect/account-management/connected-accounts)
    *   [Working with financial accounts | Stripe Documentation](/treasury/connect/account-management/financial-accounts)
    *   [Financial account features | Stripe Documentation](/treasury/connect/account-management/financial-account-features)
    *   [Platform financial accounts | Stripe Documentation](/treasury/connect/account-management/platform-financial-account)
    *   [Working with balances and transactions | Stripe Documentation](/treasury/connect/account-management/working-with-balances-and-transactions)
    *   [Treasury for platforms supportability for connected accounts | Stripe Documentation](/treasury/connect/account-management/supportability)

*   **Bank Partners:** Information on integrating with specific bank partners.
    *   [Integrate with Fifth Third Bank | Stripe Documentation](/treasury/connect/fifth-third)
    *   [Build a new Treasury for platforms integration with Fifth Third Bank | Stripe Documentation](/treasury/connect/fifth-third-get-started)

*   **Compliance and Marketing:** Guidelines for compliant marketing and operations.
    *   [Treasury for platforms fraud guide | Stripe Documentation](/treasury/connect/examples/fraud-guide)
    *   [Treasury for platforms product marketing, design, and compliance guidelines | Stripe Documentation](/treasury/connect/compliance)
    *   [Handling complaints | Stripe Documentation](/treasury/connect/handling-complaints)
    *   [Marketing Treasury for platforms | Stripe Documentation](/treasury/connect/marketing-financial-accounts)
    *   [Regulatory receipts | Stripe Documentation](/treasury/connect/moving-money/regulatory-receipts)

### Testing and Support

*   **Testing Integrations:** How to test your Issuing and Treasury for Platforms integrations.
    *   [Test your Issuing integration | Stripe Documentation](/issuing/testing)
    *   [Test your integration | Stripe Documentation](/issuing/credit/test-credit)
    *   [Issuing and Treasury for platforms sample app | Stripe Documentation](/issuing/sample-app)
    *   [Issuing and Treasury for platforms sample app | Stripe Documentation](/treasury/connect/examples/sample-app)

*   **Customer Support:** Information on customer support for Issuing and Treasury.
    *   [Customer support for Issuing and Treasury for platforms | Stripe Documentation](/issuing/customer-support)

### Advanced Topics

*   **Issuing Watchlist:** Understanding the watchlist process for screening users.
    *   [Issuing watchlist | Stripe Documentation](/issuing/issuing-watchlist)

*   **Merchant Categories:** Information on merchant categories for spending controls.
    *   [Issuing merchant categories | Stripe Documentation](/issuing/categories)

*   **Transactions and Authorizations:** Details on how transactions and authorizations are handled.
    *   [Issuing authorizations | Stripe Documentation](/issuing/purchases/authorizations)
    *   [Issuing transactions | Stripe Documentation](/issuing/purchases/transactions)
    *   [Issuing disputes | Stripe Documentation](/issuing/purchases/disputes)
    *   [Enriched merchant data | Stripe Documentation](/issuing/purchases/enriched-merchant-data)

*   **Beta Migration:** Guidance for migrating from beta versions.
    *   [Issuing beta migration guide | Stripe Documentation](/issuing/migration-from-beta)

*   **Issuing Elements:** Using browser-side components for PCI-compliant display of card details.
    *   [Using Issuing Elements | Stripe Documentation](/issuing/elements)
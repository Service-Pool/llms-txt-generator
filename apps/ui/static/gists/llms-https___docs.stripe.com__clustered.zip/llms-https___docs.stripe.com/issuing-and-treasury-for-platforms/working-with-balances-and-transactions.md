## Stripe Issuing and Treasury for Platforms Documentation

This documentation set provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and integration to advanced features like fraud management, credit programs, and global availability.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing and how it enables you to create, manage, and distribute payment cards for your business or users.
*   **How Issuing Works:** Delve into the mechanics of Stripe Issuing, including partnerships with banks and card networks, and regional considerations.
*   **Treasury for Platforms Overview:** Learn how to embed financial services into your product, enabling connected accounts to hold funds, pay bills, and manage cash flow.
*   **Get Started with API Access:** Understand the initial steps for gaining API access to Treasury for Platforms and Issuing, including sandbox testing.
*   **Onboarding Overview:** Comprehensive guide to preparing for and launching your Issuing or Treasury for Platforms integration, including use case approval and live mode access.
*   **Integration Guides:** Access specific guides for integrating Issuing for various use cases:
    *   **Embedded Finance:** Build embedded financial services with Issuing and Treasury for Platforms.
    *   **B2B Payments:** Create cards for business, employee, or contractor purchases.
    *   **Fleet:** Build fleet financial services integrations.
*   **Sample App:** Explore the Issuing and Treasury for Platforms sample app to understand API usage for onboarding, card creation, and payments.
*   **Customer Support:** Find information on how to get customer support for Issuing and Treasury for Platforms.

### Issuing Card Management

*   **Choose Card Type:** Decide between physical and virtual cards for your cardholders.
    *   **Virtual Cards:** Learn about creating and managing virtual cards.
    *   **Physical Cards:** Understand the process of issuing and managing physical cards.
*   **Card Programs:** Manage and customize your card programs.
    *   **Program Management:** Overview of program management for Issuing.
    *   **Customize Your Card Program:** Tailor your Issuing card program to meet specific business needs.
*   **Physical Card Customization:**
    *   **Choose Card Bundle:** Select standard or custom physical card bundles.
    *   **Order a Custom Bundle:** Guide to ordering custom physical card bundles.
    *   **Customize Card Bundle:** Make selections for your card bundle.
    *   **Artwork Templates:** Utilize provided templates for card design.
    *   **Create a Design:** Steps to create and name your card design.
    *   **Issue Cards:** Learn how to create physical cards.
    *   **Ship Cards:** Understand shipping options for physical cards.
    *   **Address Validation:** Ensure successful delivery of physical cards with address validation.
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **Replacement Cards:** Manage the process of replacing expired, damaged, lost, or stolen cards.
*   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers.

### Funding and Balances

*   **Fund Your Issuing Balance:** Learn how to make funds available for card spend.
*   **Add Funds to Your Card Program:** Explore options for funding your Issuing balance.
*   **Issuing Balance:** Understand how the Issuing balance works and how to fund it.
*   **Post-fund Your Integration:**
    *   **Postfund with Stripe:** Learn how to accrue a negative Issuing balance and post-fund later.
    *   **Post-fund with Dynamic Reserves:** Utilize dynamic reserves to manage cash flow.

### Integrations and Connect

*   **Set up an Issuing and Connect Integration:** Integrate Stripe Issuing with Stripe Connect to manage funds flow and compliance for third-party users.
*   **Connect Funding:** Learn how to fund Issuing balances for connected accounts.
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and cards in a Connect integration.
*   **Cardholder Controls:** Manage cardholder information in accordance with legal and regulatory guidelines.
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity affects connected accounts' Issuing capabilities.
*   **Embed Card Management:** Use prebuilt UI components to embed Issuing card management into your website.
*   **Processor-only Issuing:** Integrate Issuing where you manage regulatory requirements, compliance, and licensing.
    *   **Integrate Processor-only Issuing:** Set up a processor-only Issuing integration.

### Credit Programs

*   **Issuing Credit Overview:** Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
*   **Credit Consumer Issuing:** Learn about the solution for launching a credit program for your consumers.
    *   **How Credit Consumer Issuing Works:** Understand the features and APIs for managing a consumer credit program.
    *   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for users to receive and spend money.
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Obligation amounts, transactions, and adjustments:** View details about Funding Obligations and make adjustments.
    *   **Obligation payments:** Learn how to make payments to your Funding Obligation.
    *   **Available credit and flow of funds:** Understand how funds flow and use available credit to prevent declines.
*   **Manage Credit Terms:** Configure credit terms for connected accounts.
*   **Report other credit decisions and manage adverse action notices:** Record application and decision details and send adverse action notices.
*   **Report required regulatory data for credit decisions:** Comply with reporting requirements for credit programs.
*   **Test Credit Integration:** Validate your automated platform funding in testing environments.
*   **Set up credit for connected accounts:** Configure credit terms and fund spend from your platform.

### Controls and Fraud Management

*   **Manage Fraud:** Understand transaction fraud and how to combat it using Stripe Issuing controls and tools.
*   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud.
*   **Issuing Authorization Rules:** Limit authorization approvals using custom rules.
*   **Real-time Authorizations:** Approve or decline authorization requests in real time using synchronous webhooks.
    *   **Quickstart:** Get started with real-time authorizations.
    *   **Migrate to direct webhook response:** Update your integration for real-time authorizations.
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations.
*   **3D Secure:** Learn about 3D Secure for cardholder authentication in online transactions.
*   **Spending Controls:** Set rules on cards and cardholders to control spending by category, country, or amount.
*   **Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards.
*   **Token Management:** Manage network tokens on your cards for secure payments.
*   **Issuing Watchlist:** Understand the process for screening Issuing users against sanctions lists.

### Specific Use Cases and Features

*   **B2B Payments:** Build B2B payment integrations using Stripe Issuing.
*   **Fleet:** Create fleet financial services integrations.
*   **Embedded Finance:** Build embedded financial services integrations.
*   **Issuing for your business:** Programmatically create virtual cards for your business needs.
*   **Issuing for agents:** Provide programmable cards with built-in controls for agents.
*   **Consumer prepaid debit cards:** Issue prepaid debit cards for users to receive and spend money.
*   **Stablecoin-backed cards:** Issue prepaid or debit cards backed by stablecoin balances.
    *   **Stablecoin-backed cards for financial accounts:** Issue cards backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrate Stripe Issuing with Bridge for stablecoin-backed card programs.
*   **Merchant Categories:** Understand the Merchant Category Codes (MCCs) used to group businesses.
*   **ATM Usage:** Learn how to use Stripe Issuing cards at ATMs.
*   **Issuing Authorizations:** Handle authorization requests for card transactions.
*   **Issuing Transactions:** Understand how transactions are created after authorization.
*   **Issuing Disputes:** Learn how to dispute transactions.
*   **Enriched Merchant Data:** Utilize comprehensive merchant data for fraud prevention and insights.

### Treasury for Platforms Specifics

*   **Treasury for Platforms Overview:** Understand the core functionality and use cases.
*   **Eligibility Requirements:** Review the criteria for using Treasury for Platforms.
*   **Onboarding Users:** Implement a Treasury for Platforms onboarding process for connected accounts.
*   **Managing Fraud:** Learn best practices for managing fraud as a platform.
*   **Marketing and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant.
    *   **Regulatory Receipts:** Understand hosted transaction receipts.
    *   **Handling Complaints:** Learn how to properly handle complaints.
    *   **Marketing Treasury for Platforms:** Create compliant messaging for your users.
*   **Sample Integrations:**
    *   **Set up financial accounts and cards:** Follow a sample integration for setting up financial accounts and cards.
    *   **Use Treasury for platforms to move money:** Learn about moving money using API endpoints.
    *   **Issuing and Treasury for platforms sample app:** Use the Next.js sample app to start your integration.
    *   **Webhooks:** Understand webhook events for Issuing and Treasury for Platforms.
*   **Account Management:**
    *   **Accounts Structure:** Understand the account components of Treasury for Platforms.
    *   **Working with Connected Accounts:** Request capabilities and collect onboarding requirements.
    *   **Working with Financial Accounts:** Learn how to use financial accounts to store, send, and receive funds.
    *   **Financial Account Features:** Explore features available for financial accounts.
    *   **Platform Financial Accounts:** Understand the financial account for your platform.
*   **Moving Money:**
    *   **Moving money into financial accounts:** Learn about requests to move money into financial accounts.
    *   **Moving money using InboundTransfer objects:** Transfer money from external accounts.
    *   **Moving money using ReceivedCredit objects:** Move money into a financial account from another source.
    *   **Moving money using CreditReversal objects:** Return funds from received credits.
    *   **Moving money out of financial accounts:** Learn about methods to move funds out of financial accounts.
    *   **Moving money using OutboundTransfer objects:** Transfer money to external accounts.
    *   **Moving money using OutboundPayment objects:** Create outbound payments to third parties.
    *   **Moving money using ReceivedDebit objects:** Observe funds pulled from a financial account.
    *   **Moving money using DebitReversal objects:** Retrieve funds taken from a financial account.
    *   **Payouts and top-ups from payments balance:** Move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms.
    *   **ACH NOC and SEC handling:** Learn how external account information is updated.
*   **Money Movement Timelines:** Understand the processing and cutoff times for various money movement types.
*   **Bank Partners:**
    *   **Fifth Third Bank overview:** Learn about Fifth Third Bank as a partner.
    *   **Integrate with Fifth Third Bank:** Add Fifth Third Bank to your integration.
    *   **Build a new Treasury for platforms integration with Fifth Third Bank:** Get started with Treasury for Platforms using Fifth Third Bank.
*   **Treasury for Platforms Requirements:** Understand the compliance requirements and restrictions.

### Compliance and Guidelines

*   **Issuing and Treasury product marketing, design, and compliance guidelines (US):** Adhere to guidelines for launching and maintaining compliant Issuing and Treasury programs.
*   **Issuing regulated customer notices:** Learn about sending regulatory notifications to your customers.
*   **Marketing guidance (Europe/UK):** Understand marketing guidelines for Issuing programs in the UK and Europe.

### Testing and Migration

*   **Test your Issuing integration:** Simulate purchases and test your integration in a sandbox environment.
*   **Test your integration (Credit):** Validate automated platform funding in testing environments.
*   **Issuing beta migration guide:** Learn how to migrate from the Issuing beta.
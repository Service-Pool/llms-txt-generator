```markdown
# Cardholder Authentication using 3D Secure

3D Secure (3DS) is an additional layer of security used for online transactions where the card is not physically present. It helps combat fraud by requiring cardholders to complete an extra verification step.

## How 3D Secure Works

1.  **Customer Enters Card Details:** The cardholder enters their card information during an online checkout.
2.  **3DS Verification Request:** The acquirer requests 3DS verification. If the Stripe Issuing card is enrolled in 3DS, the cardholder is prompted to complete an additional verification step.
3.  **Cardholder Authentication:** The cardholder is typically shown an authentication page from their Issuer, where they must complete a multi-factor authentication process (usually a one-time passcode sent via SMS or email).

This process adds an extra layer of security to online transactions, reducing the risk of fraud for both businesses and cardholders.
```
## Inactive Connected Accounts Offboarding

This section details how Stripe handles inactive connected accounts within the Issuing program and the implications for platforms.

### Inactivity Criteria

Stripe disables Issuing capabilities on connected accounts that have not authorized any card transactions in the past 13 months (395 days). This measure is in place to mitigate risks associated with inactive accounts, such as the increased chance of lost or compromised cards leading to transaction fraud.

### Disabling Issuing Capability

When a connected account meets the inactivity criteria, Stripe automatically disables its Issuing capability globally.

### Notifications

Stripe sends notices to connected accounts that have lost access to Issuing due to inactivity. These notices inform the connected account about the change and provide details about the email template and customization options available.

### Impact on Platforms

Platforms that integrate with Stripe Issuing and Stripe Connect need to be aware of this policy. While Stripe manages the disabling of the Issuing capability, platforms may need to adjust their own internal processes or communications to account for connected accounts that lose access to Issuing features.

### Reviewing the Guide

For detailed information on the inactivity criteria, the notification process, and any additional changes related to this update, it is recommended to review the full guide.
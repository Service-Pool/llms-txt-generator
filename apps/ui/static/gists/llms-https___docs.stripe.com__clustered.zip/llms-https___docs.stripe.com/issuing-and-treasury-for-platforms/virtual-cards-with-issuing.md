## Stripe Issuing and Treasury for Platforms

This documentation suite provides comprehensive guidance on leveraging Stripe Issuing and Treasury for Platforms to build and manage card programs and financial services for your business and your customers. It covers everything from initial setup and integration to advanced features like fraud management, credit offerings, and international expansion.

### Key Areas Covered:

*   **Getting Started with Issuing:**
    *   Understanding how Stripe Issuing works and its core functionalities.
    *   Guides for various integration types, including B2B Payments, Embedded Finance, and Fleet.
    *   Onboarding processes and compliance requirements.
*   **Card Management:**
    *   Choosing between physical and virtual cards.
    *   Creating, customizing, and issuing cards.
    *   Managing card programs, including card bundles, artwork, and PINs.
    *   Handling card replacements and digital wallet integration.
*   **Funding and Balances:**
    *   Managing your Issuing balance and adding funds.
    *   Post-funding options and dynamic reserves.
*   **Transaction Controls and Fraud Prevention:**
    *   Implementing spending controls and lifecycle controls.
    *   Utilizing advanced fraud tools, real-time authorizations, and fraud challenges.
    *   Managing merchant categories and enriched merchant data.
    *   Understanding authorization rules and PIN management.
*   **Stripe Connect Integrations:**
    *   Setting up Issuing and Connect integrations for managing cards on behalf of connected accounts.
    *   Managing cardholders, cards, and their controls within Connect.
    *   Funding Issuing balances for connected accounts.
    *   Embedding card management into your website using Connect components.
    *   Handling inactive connected accounts.
*   **Issuing Credit:**
    *   Offering credit programs to your customers, including consumer credit and managing credit terms.
    *   Understanding available credit, obligation management, and reporting.
    *   Testing credit integrations.
*   **Treasury for Platforms:**
    *   An overview of Treasury for Platforms and its capabilities for embedding financial services.
    *   Setting up financial accounts and cards for connected accounts.
    *   Managing account structures, balances, and transactions.
    *   Moving money in and out of financial accounts using various methods.
    *   Integrating with bank partners like Fifth Third Bank.
    *   Compliance guidelines and fraud management best practices for Treasury for Platforms.
*   **Global Availability and Compliance:**
    *   Using Stripe Issuing in different countries and understanding regional considerations.
    *   Adhering to product marketing, design, and compliance guidelines for both Issuing and Treasury for Platforms.
    *   Issuing regulated customer notices and marketing guidelines for Europe and the UK.
*   **Testing and Support:**
    *   Testing your Issuing and Treasury for Platforms integrations in sandbox environments.
    *   Accessing customer support for Issuing and Treasury for Platforms.

This documentation suite aims to empower developers and businesses to effectively utilize Stripe's Issuing and Treasury for Platforms products to create innovative financial solutions.
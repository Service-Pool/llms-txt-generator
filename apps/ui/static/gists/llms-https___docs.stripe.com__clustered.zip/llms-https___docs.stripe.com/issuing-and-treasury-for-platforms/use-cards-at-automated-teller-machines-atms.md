## Stripe Issuing and Treasury for Platforms: Card Issuance and Money Management

This documentation set provides comprehensive guidance on utilizing Stripe Issuing and Treasury for Platforms to create and manage payment card programs, facilitate money movement, and ensure compliance. It caters to developers and businesses looking to embed financial services into their platforms.

### Core Concepts and Functionality

*   **Stripe Issuing:** Enables businesses to programmatically create, manage, and distribute payment cards (physical and virtual) for their users or internal use. This includes features like:
    *   **Card Types:** Virtual and physical cards, with options for customization and design.
    *   **Funding:** Adding funds to an Issuing balance from external bank accounts or Stripe balances.
    *   **Controls:** Implementing spending controls, lifecycle controls, and advanced fraud tools to manage card usage and mitigate risk.
    *   **Authorizations & Transactions:** Handling real-time authorization requests and managing captured transactions.
    *   **Fraud Management:** Utilizing Stripe's tools and controls to combat transaction fraud.
    *   **Program Management:** Choosing between Stripe program management and processor-only models.
    *   **Specific Use Cases:** Guides for B2B payments, fleet management, embedded finance, and consumer prepaid/credit cards.

*   **Treasury for Platforms:** A suite of APIs that allows platforms to embed financial services for their connected accounts. This includes:
    *   **Financial Accounts:** Enabling connected accounts to hold funds, pay bills, and manage cash flow.
    *   **Money Movement:** Facilitating inbound and outbound transfers via ACH, wire, and the Stripe network.
    *   **Card Integration:** Working with Stripe Issuing cards to access financial accounts.
    *   **Account Management:** Understanding the structure of platform and connected accounts.
    *   **Compliance:** Adhering to regulatory requirements for offering financial services.

### Key Integration Areas

*   **Stripe Connect:** Essential for integrating Issuing and Treasury for Platforms, allowing platforms to manage funds flows and compliance for their connected accounts.
*   **API Access and Sandbox Environments:** Guidance on obtaining API access, setting up sandbox environments for testing, and migrating from beta versions.
*   **Onboarding and Compliance:** Detailed information on onboarding users, collecting KYC/KYB data, and adhering to marketing, design, and compliance guidelines for both Issuing and Treasury for Platforms.
*   **Sample Applications and Guides:** Practical examples and guides to help developers build and launch their integrations.

### Specific Features and Guides

*   **Card Management:**
    *   Creating and managing virtual and physical cards.
    *   Customizing card bundles, designs, and artwork.
    *   Handling replacement cards and PIN management.
    *   Integrating with digital wallets (Apple Pay, Google Pay).
*   **Fraud Prevention and Controls:**
    *   Real-time authorizations and direct webhook responses.
    *   Fraud challenges and advanced fraud tools.
    *   Issuing authorization rules and spending controls.
    *   Token management for secure payments.
*   **Money Movement and Funding:**
    *   Adding funds to Issuing balances and financial accounts.
    *   Understanding money movement timelines and using various transfer objects (InboundTransfer, OutboundPayment, etc.).
    *   Payouts and top-ups from Stripe Payments.
*   **Credit and Financial Services:**
    *   Issuing Credit solutions for consumer and connected accounts.
    *   Managing credit terms, obligations, and available credit.
    *   Reporting credit decisions and regulatory data.
*   **Global Issuing:**
    *   Options for local and cross-border issuing across different countries.
    *   Stablecoin-backed card programs.
*   **Customer Support and Troubleshooting:**
    *   Information on customer support for Issuing and Treasury for Platforms.
    *   Handling disputes and managing watchlist processes.

This documentation set provides a comprehensive resource for developers and businesses looking to leverage Stripe's Issuing and Treasury for Platforms to build sophisticated financial products and services.
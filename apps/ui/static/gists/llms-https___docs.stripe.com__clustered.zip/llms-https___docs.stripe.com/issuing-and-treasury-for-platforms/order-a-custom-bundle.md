## Stripe Issuing and Treasury for Platforms

This documentation suite focuses on Stripe's **Issuing** and **Treasury for platforms** products, offering comprehensive guidance for businesses looking to embed financial services into their platforms. It covers everything from initial setup and integration to advanced features like fraud management, credit offerings, and international expansion.

### Key Areas Covered:

*   **Getting Started with Issuing:**
    *   **Onboarding Overview:** Understand the steps required to launch an Issuing or Treasury for platforms integration.
    *   **How Issuing Works:** Learn the fundamental concepts and architecture of Stripe Issuing.
    *   **Integration Guides:** Detailed guides for specific use cases like B2B Payments, Embedded Finance, and Fleet management.
    *   **Sample App:** A practical example to help you understand how to use Issuing and Treasury for platforms APIs.
    *   **Testing:** Strategies and tools for testing your Issuing integration.

*   **Issuing Card Management:**
    *   **Card Types:** Choose between physical and virtual cards, understanding their use cases and tradeoffs.
    *   **Card Creation and Customization:**
        *   Designing your cards, including artwork templates and customization options.
        *   Ordering and customizing physical card bundles.
        *   Issuing physical and virtual cards to cardholders.
    *   **PIN Management:** How cardholders can manage their Personal Identification Numbers.
    *   **Digital Wallets:** Integrating Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **Replacement Cards:** Procedures for replacing expired, damaged, lost, or stolen cards.

*   **Funding and Balances:**
    *   **Issuing Balance:** Understanding and managing your Issuing balance for card spend.
    *   **Adding Funds:** Options for funding your Issuing balance, including pull-funded top-ups, push-funded top-ups, and balance transfers.
    *   **Post-funding:** Learn about post-funding your integration with Stripe and Dynamic Reserves, allowing for negative Issuing balances.

*   **Treasury for Platforms:**
    *   **Overview:** Understand how Treasury for platforms enables you to embed financial services for your connected accounts.
    *   **Account Management:**
        *   **Accounts Structure:** How platform and connected accounts interact within Treasury for platforms.
        *   **Connected Accounts:** Managing and onboarding connected accounts for Treasury for platforms.
        *   **Financial Accounts:** Setting up and managing financial accounts for your platform and connected accounts.
    *   **Money Movement:**
        *   **Moving Money:** Comprehensive guides on transferring funds into and out of financial accounts using various methods like ACH, wires, and Stripe's network.
        *   **Payouts and Top-ups:** Managing money movement between payments balances and financial accounts.
        *   **Timelines:** Understanding the processing times for different money movement methods.
    *   **Bank Partners:** Information on integrating with banking partners like Fifth Third Bank.
    *   **Sample Integrations:** Examples and guides for common Treasury for platforms use cases.

*   **Issuing and Treasury for Platforms Integration:**
    *   **Connect Integration:** Setting up and managing Issuing and Treasury for platforms integrations with Stripe Connect.
    *   **Embedded Components:** Embedding Issuing card management directly into your website.
    *   **Sample Application:** A Next.js sample app demonstrating Issuing and Treasury for platforms integration.
    *   **Webhooks:** Handling asynchronous events for Issuing and Treasury for platforms.

*   **Controls and Fraud Management:**
    *   **Manage Fraud:** Strategies and tools for combating transaction fraud.
    *   **Spending Controls:** Setting rules and limits to control cardholder spending.
    *   **Lifecycle Controls:** Automatically canceling virtual cards after a specified number of payments.
    *   **Real-time Authorizations:** Approving or declining authorization requests in real-time.
    *   **Authorization Rules:** Limiting authorization approvals with custom rules.
    *   **Fraud Challenges:** Implementing additional verification steps for high-risk transactions.
    *   **3D Secure:** Understanding cardholder authentication using 3D Secure.
    *   **Advanced Fraud Tools:** Utilizing API signals and tooling to prevent transaction fraud.
    *   **Token Management:** Managing network tokens for secure payments.
    *   **Issuing Watchlist:** Understanding the process for screening Issuing users against sanctions lists.

*   **Credit Offerings:**
    *   **Issuing Credit:** Overview of Stripe's credit solutions for Issuing.
    *   **Credit Consumer Issuing:** Creating and managing credit programs for your consumers.
    *   **Manage Credit Terms:** Configuring credit limits and terms for connected accounts.
    *   **Manage Account Obligations:** Tracking credit spend, lifecycle, and balances for connected accounts.
    *   **Available Credit and Flow of Funds:** Understanding how available credit changes and impacts authorizations.
    *   **Reporting Credit Decisions:** Recording credit underwriting decisions and managing adverse action notices.
    *   **Regulatory Reporting:** Reporting required regulatory data for credit decisions.
    *   **Testing Credit Integration:** Validating your automated platform funding in testing environments.

*   **Program Management and Compliance:**
    *   **Program Management:** Choosing between Stripe program management and processor-only models.
    *   **Processor-Only Issuing:** Integrating as a processor-only provider.
    *   **Compliance Guidelines:** Adhering to product marketing, design, and compliance guidelines for Issuing and Treasury for platforms in the US and Europe/UK.
    *   **Customer Communications:** Sending regulated customer notices.
    *   **Marketing Guidelines:** Specific marketing guidelines for Issuing programs in the UK and Europe.

*   **Specific Use Cases and Features:**
    *   **B2B Payments:** Building B2B payment integrations with Issuing.
    *   **Embedded Finance:** Creating embedded financial services integrations.
    *   **Fleet:** Building fleet financial services integrations.
    *   **Consumer Prepaid Debit Cards:** Issuing prepaid debit cards to users.
    *   **Issuing for Agents:** Providing programmable cards with built-in controls for agents.
    *   **Merchant Categories:** Understanding Issuing merchant categories for spending controls.
    *   **ATM Usage:** Using Issuing cards at ATMs for cash withdrawals.
    *   **Stablecoin-backed Cards:** Issuing cards backed by stablecoin balances.
    *   **Customer Support:** Resolving common Issuing and Treasury for platforms questions.
## Issuing and Treasury for Platforms Customer Support

This section provides guidance and resources for handling customer support inquiries related to Stripe Issuing and Treasury for Platforms. It aims to equip your support team with the necessary information and tools to effectively assist customers and cardholders.

### Key Areas of Support:

*   **Issuing Program Management:** Addressing questions about setting up, customizing, and managing Issuing card programs. This includes topics like cardholder types, card types (virtual/physical), funding balances, and program compliance.
*   **Treasury for Platforms Integration:** Supporting users who are integrating Stripe Treasury for Platforms to offer financial services to their connected accounts. This covers aspects like account setup, financial account management, and money movement.
*   **Connect Integrations:** Providing assistance with Issuing and Treasury for Platforms when used in conjunction with Stripe Connect, including managing connected accounts, cardholders, and their associated cards and financial accounts.
*   **Fraud Management:** Guiding users on how to leverage Stripe's fraud tools and controls to mitigate risks within their Issuing programs.
*   **Cardholder Experience:** Helping with common cardholder issues, such as card activation, PIN management, digital wallet integration, and replacement card requests.
*   **Troubleshooting and Issue Resolution:** Offering solutions for common problems encountered during integration and day-to-day operations.

### Support Resources:

*   **Stripe Documentation:** Comprehensive guides, API references, and best practices for both Issuing and Treasury for Platforms.
*   **Stripe Dashboard:** Tools for managing Issuing programs, viewing transactions, and configuring settings.
*   **Stripe APIs and SDKs:** Enabling programmatic management of Issuing and Treasury for Platforms features.
*   **Sample Apps:** Practical examples to help developers understand and implement integrations.
*   **Customer Support Team:** Direct access to Stripe's support for complex or unresolved issues.

### Best Practices for Support Teams:

*   **Familiarize yourself with the Issuing and Treasury for Platforms documentation.**
*   **Understand common use cases and potential customer pain points.**
*   **Utilize the Stripe Dashboard to investigate and troubleshoot customer issues.**
*   **Escalate complex technical issues to the appropriate Stripe support channels.**
*   **Maintain clear and concise communication with customers.**
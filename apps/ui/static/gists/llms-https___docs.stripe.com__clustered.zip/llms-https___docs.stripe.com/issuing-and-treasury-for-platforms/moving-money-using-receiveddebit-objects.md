## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. These products empower platforms to offer financial services, such as card issuance and money management, to their connected accounts.

### Core Concepts

*   **Stripe Issuing:** A product that enables platforms to create and manage payment cards (physical and virtual) for their users. This includes functionalities like card customization, transaction authorization, spending controls, and fraud management.
*   **Treasury for Platforms:** A suite of APIs that allows platforms to embed financial services into their products. This includes features for managing financial accounts, moving money (inbound and outbound transfers, payouts), and integrating with banking partners.
*   **Stripe Connect:** The underlying infrastructure that enables platforms to manage multiple connected accounts (users or businesses) and facilitate financial services for them.

### Key Areas of Documentation

This documentation is organized into several key areas to guide you through the integration process:

#### 1. Getting Started and Onboarding

*   **Onboarding Overview:** Understand the general process for launching an Issuing or Treasury for Platforms integration.
*   **Integration Guides:** Explore specific guides for different use cases:
    *   Embedded Finance
    *   B2B Payments
    *   Fleet Management
*   **Sample App:** Utilize a sample application to understand how to onboard customers, issue cards, and make payments.
*   **Sandbox Testing:** Learn how to test your integration in a sandbox environment before going live.

#### 2. Issuing Cards

*   **Issuing Overview:** Get a high-level understanding of how Stripe Issuing works.
*   **Card Types:**
    *   **Virtual Cards:** Learn about creating and managing virtual cards.
    *   **Physical Cards:** Understand the process of ordering, designing, and issuing physical cards, including customization options and shipping.
*   **Funding Issuing Balance:** Learn how to add funds to your Issuing balance to enable card spending.
*   **Card Programs:** Customize and manage your card programs, including BIN setup.
*   **Digital Wallets:** Integrate with digital wallets like Apple Pay and Google Pay.
*   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers.
*   **Replacement Cards:** Understand the process for replacing expired, damaged, lost, or stolen cards.

#### 3. Treasury for Platforms

*   **Treasury for Platforms Overview:** Understand the core functionalities and benefits of Treasury for Platforms.
*   **Account Management:**
    *   **Accounts Structure:** Learn about the different account types (platform and connected accounts) within Treasury for Platforms.
    *   **Connected Accounts:** Understand how to onboard and manage connected accounts.
    *   **Financial Accounts:** Learn about creating and managing financial accounts for your connected accounts.
*   **Money Movement:**
    *   **Moving Money In:** Explore methods for moving money into financial accounts (Inbound Transfers, Received Credits).
    *   **Moving Money Out:** Understand how to move money out of financial accounts (Outbound Payments, Outbound Transfers, Received Debits).
    *   **Payouts and Top-ups:** Learn how to manage money movement between payments balances and financial accounts.
    *   **Money Movement Timelines:** Understand the processing times for various money movement methods.
*   **Bank Partners:** Information on integrating with banking partners like Fifth Third Bank.

#### 4. Integrations with Stripe Connect

*   **Set up an Issuing and Connect Integration:** Learn how to integrate Issuing with Stripe Connect to issue cards for third parties.
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and the cards issued to them.
*   **Fund Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing.
*   **Connect Funding:** Explore options for funding Issuing balances with Connect.
*   **Cardholder Controls:** Understand how to manage cardholder information and ensure compliance.
*   **Inactive Connected Accounts Offboarding:** Learn how Stripe handles inactive Issuing accounts.
*   **Embed Issuing Card Management:** Use Connect embedded components to integrate card management into your website.

#### 5. Credit Products

*   **Issuing Credit Overview:** An introduction to Stripe's credit offerings for Issuing.
*   **Credit Consumer Issuing:** Learn about creating and managing credit programs for your consumers.
*   **Manage Credit Terms:** Understand how to set and update credit limits and terms for connected accounts.
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
*   **Available Credit and Flow of Funds:** Learn how available credit impacts transactions.

#### 6. Fraud Management and Controls

*   **Manage Fraud:** Understand potential fraud risks and how to combat them using Stripe Issuing tools.
*   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud.
*   **Issuing Authorization Rules:** Implement custom rules to limit authorization approvals.
*   **Real-time Authorizations:** Handle authorization requests in real-time using webhooks.
*   **Fraud Challenges:** Implement additional verification steps for high-risk transactions.
*   **Spending Controls:** Set rules on cards and cardholders to control spending by category, country, or amount.
*   **Lifecycle Controls:** Control automatic usage-based cancellation of cards.
*   **Token Management:** Manage network tokens for secure payments.
*   **Issuing Watchlist:** Understand how Stripe screens users against sanctions lists.

#### 7. Compliance and Guidelines

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines:** Adhere to regulations for offering financial services.
*   **Marketing Guidance (Europe/UK):** Specific marketing guidelines for the UK and Europe.
*   **Issuing Regulated Customer Notices:** Understand how to send regulatory notifications to your customers.
*   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant.
*   **Handling Complaints:** Learn how to properly handle complaints related to Treasury for Platforms or Issuing.

#### 8. Transactions and Purchases

*   **Issuing Authorizations:** Learn how authorization requests are handled.
*   **Issuing Transactions:** Understand the lifecycle of a transaction after authorization.
*   **Issuing Disputes:** Learn how to dispute transactions.
*   **Use Cards at ATMs:** Enable and manage ATM withdrawals for your cards.
*   **Enriched Merchant Data:** Utilize detailed merchant data for fraud prevention and insights.

#### 9. Advanced Features

*   **Processor-only Issuing:** Integrate with Stripe Issuing as a processor.
*   **Stablecoin-backed Cards:** Issue cards backed by stablecoin balances.
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.
*   **Migrate from Issuing Beta:** Guide for migrating from the Issuing beta to the general availability API.

This documentation suite aims to provide a comprehensive resource for developers and businesses looking to leverage Stripe's Issuing and Treasury for Platforms products.
```markdown
# Creating Physical Cards

This section guides you through the process of creating physical cards using Stripe Issuing, whether you're issuing standard or custom bundles.

## Issuing Cards with the Dashboard or API

You can issue both standard and custom card bundles to your cardholders using either the Stripe Dashboard or the `Create a card` endpoint.

*   **Standard Bundles:** If your design has been approved, any card you create will be sent to the card printer for fulfillment.
*   **Custom Bundles:** If your custom design is still under review, cards will be sent for fulfillment only after the design is approved. This applies when you add an additional logo to the card or text to the standard carriers. Otherwise, cards are fulfilled without additional review.

## Creating a Cardholder

Before you can issue a card, you need to create a cardholder. You can do this through the Dashboard or the Cardholders API.

**Note:** For stablecoin-backed consumer card programs, Bridge manages cardholder creation and identity verification. Refer to the Bridge documentation for specific details.

### Using the Dashboard

1.  Navigate to the **Cardholders** tab in the Issuing Dashboard.
2.  Click **Create cardholder** in the upper right.
3.  Select the cardholder type: **individual** or **company**.
4.  Add a billing address.
5.  If you're creating a company card, add the tax identification number.

### Using the API

You can use the Cardholders API to create a cardholder. For example, using `curl`:

```bash
curl https://api.stripe.com/v1/issuing/cardholders \
  -u "sk_test_RXHltS2OKzISvxWQ7NmRN57i001oa6x7o4:" \
  -d "name=Jenny Rosen" \
  --data-urlencode "email=jenny.rosen@example.com" \
  --data-urlencode "phone_number=+18008675309" \
  -d status=active \
  -d type=individual \
  -d "billing[address][line1]=123 Main Street" \
  -d "billing[address][city]=San Francisco" \
  -d "billing[address][state]=CA" \
  -d "billing[address][postal_code]=94111" \
  -d "billing[address][country]=US"
```

The response will include a unique `id` for the cardholder.

## Issuing a Card to a Cardholder

Once a cardholder is created, you can issue a card to them by passing the cardholder's ID to the `Create a card` endpoint.

```bash
curl https://api.stripe.com/v1/issuing/cards \
  -u "sk_test_RXHltS2OKzISvxWQ7NmRN57i001oa6x7o4:" \
  -d "cardholder={{CARDHOLDER_ID}}" \
  -d "currency=usd" \
  -d " pemasangan_type=physical" \
  -d " pemasangan_bundle=standard"
```

This command creates a physical card for the specified cardholder with a standard bundle. You can adjust the `currency`, `pemasangan_type` (physical or virtual), and `pemasangan_bundle` (standard or custom) parameters as needed.
```
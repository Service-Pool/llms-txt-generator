```md
# Stripe Issuing and Treasury for Platforms Documentation

This documentation suite covers Stripe's Issuing and Treasury for Platforms products, providing comprehensive guides for developers and businesses looking to integrate and manage card programs and financial services.

## Table of Contents

*   [Getting Started](#getting-started)
    *   [Onboarding Overview](#onboarding-overview)
    *   [Issuing Beta Migration Guide](#issuing-beta-migration-guide)
    *   [Customer Support for Issuing and Treasury](#customer-support-for-issuing-and-treasury)
    *   [Issuing Watchlist](#issuing-watchlist)
*   [Core Issuing Concepts](#core-issuing-concepts)
    *   [How Issuing Works](#how-issuing-works)
    *   [Issuing for Your Business](#issuing-for-your-business)
    *   [Issuing for Agents](#issuing-for-agents)
    *   [Choose Cardholder Type](#choose-cardholder-type)
    *   [Choose Card Type](#choose-card-type)
    *   [Add Funds to Your Issuing Balance](#add-funds-to-your-issuing-balance)
    *   [Issuing Balance](#issuing-balance)
    *   [Program Management](#program-management)
    *   [Customize Your Card Program](#customize-your-card-program)
    *   [Global Availability](#global-availability)
    *   [Issuing Merchant Categories](#issuing-merchant-categories)
*   [Integration Guides](#integration-guides)
    *   [Integration Guides Overview](#integration-guides-overview)
    *   [Embedded Finance Integration Guide](#embedded-finance-integration-guide)
    *   [B2B Payments Integration Guide](#b2b-payments-integration-guide)
    *   [Fleet Integration Guide](#fleet-integration-guide)
    *   [Processor-Only Issuing Integration Guide](#processor-only-issuing-integration-guide)
    *   [Sample App](#sample-app)
*   [Cards](#cards)
    *   [Virtual Cards](#virtual-cards)
        *   [Create Virtual Cards](#create-virtual-cards)
    *   [Physical Cards](#physical-cards)
        *   [Choose Card Bundle](#choose-card-bundle)
        *   [Order a Custom Bundle](#order-a-custom-bundle)
        *   [Customize Card Bundle](#customize-card-bundle)
        *   [Artwork Templates](#artwork-templates)
        *   [Create a Design](#create-a-design)
        *   [Issue Cards](#issue-cards)
        *   [Ship Cards](#ship-cards)
        *   [Address Validation](#address-validation)
    *   [Replacement Cards](#replacement-cards)
    *   [Digital Wallets](#digital-wallets)
    *   [PIN Management](#pin-management)
*   [Treasury for Platforms](#treasury-for-platforms)
    *   [Overview](#treasury-overview)
    *   [How Treasury for Platforms Works](#how-treasury-for-platforms-works)
    *   [Eligibility Requirements](#eligibility-requirements)
    *   [Getting Started with API Access](#getting-started-with-api-access)
    *   [Onboarding Users](#onboarding-users)
    *   [Account Management](#account-management)
        *   [Accounts Structure](#accounts-structure)
        *   [Working with Connected Accounts](#working-with-connected-accounts)
        *   [Working with Financial Accounts](#working-with-financial-accounts)
        *   [Financial Account Features](#financial-account-features)
        *   [Platform Financial Accounts](#platform-financial-accounts)
    *   [Moving Money](#moving-money)
        *   [Working with Balances and Transactions](#working-with-balances-and-transactions)
        *   [Payouts and Top-ups from Payments Balance](#payouts-and-top-ups-from-payments-balance)
        *   [Working with SetupIntents, PaymentMethods, and BankAccounts](#working-with-setupintents-paymentmethods-and-bankaccounts)
        *   [Moving Money into Financial Accounts](#moving-money-into-financial-accounts)
            *   [Moving money using InboundTransfer objects](#moving-money-using-inboundtransfer-objects)
            *   [Moving money using ReceivedCredit objects](#moving-money-using-receivedcredit-objects)
            *   [Moving money using CreditReversal objects](#moving-money-using-creditreversal-objects)
        *   [Moving Money Out of Financial Accounts](#moving-money-out-of-financial-accounts)
            *   [Moving money using OutboundTransfer objects](#moving-money-using-outboundtransfer-objects)
            *   [Moving money using OutboundPayment objects](#moving-money-using-outboundpayment-objects)
            *   [Moving money using ReceivedDebit objects](#moving-money-using-receiveddebit-objects)
            *   [Moving money using DebitReversal objects](#moving-money-using-debitreversal-objects)
        *   [Money Movement Timelines](#money-movement-timelines)
        *   [ACH NOC and SEC Handling](#ach-noc-and-sec-handling)
    *   [Bank Partners](#bank-partners)
        *   [Fifth Third Bank Overview](#fifth-third-bank-overview)
        *   [Integrate with Fifth Third Bank](#integrate-with-fifth-third-bank)
        *   [Build a new Treasury for Platforms integration with Fifth Third Bank](#build-a-new-treasury-for-platforms-integration-with-fifth-third-bank)
    *   [Sample Integrations](#sample-integrations)
        *   [Set up financial accounts and cards](#set-up-financial-accounts-and-cards)
        *   [Use Treasury for Platforms to move money](#use-treasury-for-platforms-to-move-money)
        *   [Issuing and Treasury for Platforms Sample App](#issuing-and-treasury-for-platforms-sample-app)
        *   [Webhooks for Stripe Issuing and Treasury for Platforms](#webhooks-for-stripe-issuing-and-treasury-for-platforms)
    *   [Marketing and Compliance Guidelines](#marketing-and-compliance-guidelines)
        *   [Treasury for Platforms Product Marketing, Design, and Compliance Guidelines](#treasury-for-platforms-product-marketing-design-and-compliance-guidelines)
        *   [Handling Complaints](#handling-complaints)
        *   [Marketing Treasury for Platforms](#marketing-treasury-for-platforms)
        *   [Regulatory Receipts](#regulatory-receipts)
*   [Issuing and Treasury for Platforms with Connect](#issuing-and-treasury-for-platforms-with-connect)
    *   [Set up an Issuing and Connect Integration](#set-up-an-issuing-and-connect-integration)
    *   [Update Terms of Service Acceptance](#update-terms-of-service-acceptance)
    *   [Connect Funding](#connect-funding)
    *   [Connected Accounts, Cardholders, and Cards](#connected-accounts-cardholders-and-cards)
    *   [Cardholder Controls](#cardholder-controls)
    *   [Inactive Connected Accounts Offboarding](#inactive-connected-accounts-offboarding)
    *   [Embed Issuing Card Management into Your Website](#embed-issuing-card-management-into-your-website)
*   [Issuing Controls](#issuing-controls)
    *   [Spending Controls](#spending-controls)
    *   [Lifecycle Controls](#lifecycle-controls)
    *   [Advanced Fraud Tools](#advanced-fraud-tools)
    *   [3D Secure](#3d-secure)
    *   [Fraud Challenges](#fraud-challenges)
    *   [Real-time Authorizations](#real-time-authorizations)
        *   [Quickstart](#real-time-authorizations-quickstart)
        *   [Migrate to Direct Webhook Response](#migrate-to-direct-webhook-response)
    *   [Issuing Authorization Rules](#issuing-authorization-rules)
    *   [PIN Management](#pin-management)
    *   [Token Management](#token-management)
*   [Issuing Purchases](#issuing-purchases)
    *   [Authorizations](#authorizations)
    *   [Transactions](#transactions)
    *   [Disputes](#disputes)
    *   [Merchant Categories](#merchant-categories)
    *   [ATM Usage](#atm-usage)
    *   [Enriched Merchant Data](#enriched-merchant-data)
*   [Issuing Credit](#issuing-credit)
    *   [Overview](#issuing-credit-overview)
    *   [Credit Consumer Issuing](#credit-consumer-issuing)
        *   [How Credit Consumer Issuing Works](#how-credit-consumer-issuing-works)
    *   [Manage Account Obligations](#manage-account-obligations)
        *   [Obligation Amounts, Transactions, and Adjustments](#obligation-amounts-transactions-and-adjustments)
        *   [Obligation Payments](#obligation-payments)
        *   [Available Credit and Flow of Funds](#available-credit-and-flow-of-funds)
    *   [Manage Credit Terms](#manage-credit-terms)
    *   [Report Other Credit Decisions and Manage Adverse Action Notices](#report-other-credit-decisions-and-manage-adverse-action-notices)
    *   [Report Required Regulatory Data for Credit Decisions](#report-required-regulatory-data-for-credit-decisions)
    *   [Test Credit Integration](#test-credit-integration)
*   [Stablecoin-Backed Cards](#stablecoin-backed-cards)
    *   [Stablecoin-Backed Cards for Stripe Stablecoin Financial Accounts](#stablecoin-backed-cards-for-stripe-stablecoin-financial-accounts)
    *   [Stablecoin-Backed Cards for Bridge, Privy, or Third-Party Wallets](#stablecoin-backed-cards-for-bridge-privy-or-third-party-wallets)
    *   [Stablecoin-Backed Card Issuing](#stablecoin-backed-card-issuing)
*   [Compliance and Guidelines](#compliance-and-guidelines)
    *   [Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US)](#issuing-and-treasury-product-marketing-design-and-compliance-guidelines-us)
    *   [Issuing Regulated Customer Notices](#issuing-regulated-customer-notices)
    *   [Stripe Issuing Marketing Guidelines (Europe/UK)](#stripe-issuing-marketing-guidelines-europe-uk)
*   [Testing](#testing)
    *   [Test Your Issuing Integration](#test-your-issuing-integration)
*   [Customer Support](#customer-support)
    *   [Customer support for Issuing and Treasury for platforms](#customer-support-for-issuing-and-treasury-for-platforms)

---

## Getting Started

### Onboarding Overview

This guide provides an overview of the steps required to develop and launch an integration using Stripe Issuing or Treasury for Platforms. It covers use case approval, obtaining live mode access, and preparing for launch.

### Issuing Beta Migration Guide

This guide helps users migrate from the Stripe Issuing beta to the generally available version, detailing API changes, attribute renames, and parameter updates.

### Customer Support for Issuing and Treasury

This document provides example issues and resolutions for customer support teams assisting with Issuing and Treasury for Platforms. It emphasizes equipping support teams with the necessary information and tools.

### Issuing Watchlist

This page explains how Stripe automatically screens Issuing users against US and international sanctions lists, the manual review process, and how to integrate with watchlist events via webhooks.

---

## Core Issuing Concepts

### How Issuing Works

This guide explains how to start building a card program with Stripe Issuing, covering programmatic control over card program details, partnerships with banks and card networks, and regional considerations.

### Issuing for Your Business

This guide explains how to programmatically create virtual cards for your business, employees, or contractors to make purchases on your behalf. It also covers activating sandbox environments and funding your financial account.

### Issuing for Agents

This page details how to issue programmable cards with built-in controls for agents, enabling them to autonomously discover, evaluate, and source products and services. It covers single-use cards, real-time spending controls, and transaction visibility.

### Choose a Cardholder Type

This guide explains how to select the best cardholder type (individual or company) for your use case when creating a Cardholder object. It outlines the additional information required for each type.

### Choose Card Type

This page describes the options for physical or virtual cards that can be issued to cardholders, including their respective use cases and trade-offs.

### Add Funds to Your Issuing Balance

This document explains how to fund your Issuing balance to enable card spend. It covers different funding types like pull-funded top-ups, push-funded top-ups, Stripe balance transfers, and Connect balance transfers.

### Issuing Balance

This page explains how to make funds available to your cards by adding funds to your Issuing balance. It details methods for funding, including push funding, pull funding, and Stripe balance transfers.

### Program Management

This guide outlines the two operating models for Stripe Issuing: Stripe program management and processor-only. It details the advantages and requirements of each model to help businesses choose the best option.

### Customize Your Card Program

This page explains how to customize your Stripe Issuing card program to fit your business needs, including details on BIN setup and account ranges.

### Global Availability

This guide explains the different integration options for issuing cards globally, including local issuing and cross-border issuing through programs for multinational companies and stablecoin-backed cards.

### Issuing Merchant Categories

This page explains Merchant Category Codes (MCCs) and how businesses are categorized. It details how these categories can be used for spending controls and with enriched merchant data.

---

## Integration Guides

### Integration Guides Overview

This page provides an overview of the integration guides available for launching Stripe Issuing or Treasury for Platforms integrations in the US.

### Embedded Finance Integration Guide

This guide explains how to build an embedded financial services integration using Stripe Issuing and Treasury for Platforms, covering the creation of verified connected accounts and financial accounts.

### B2B Payments Integration Guide

This guide details how to build a US B2B payments integration using Stripe Issuing to create cards for businesses, employees, or contractors to make purchases on their behalf.

### Fleet Integration Guide

This guide explains how to build a fleet financial services integration using Stripe Issuing to create cards and process transactions for customers' businesses.

### Processor-Only Issuing Integration Guide

This guide explains how to set up a processor-only Issuing integration, including the requirement to conduct Know Your Customer (KYC) on cardholders.

---

## Cards

### Virtual Cards

This page provides information on virtual cards created with Stripe Issuing, covering how to display card details in a PCI-compliant way using Issuing Elements.

#### Create Virtual Cards

This guide explains how to create virtual cards using the Dashboard or the Cardholders API, noting that they are available for immediate use after creation.

### Physical Cards

This page details how to issue physical cards with Stripe Issuing, offering options for standard cards and fully custom designs to suit different customization and speed-to-market needs.

#### Choose Card Bundle

This guide explains how to set up a standard or custom physical bundle, which includes a card, carrier, and envelope.

#### Order a Custom Bundle

This page outlines the process for ordering a custom physical bundle, including the required input forms and design templates, with an average turnaround time of 12-14 weeks.

#### Customize Card Bundle

This page explains how to make card bundle selections during the design phase, including choosing card body materials and core color options.

#### Artwork Templates

This page provides design templates (Adobe Illustrator) for cards, carriers, and envelopes, along with best practices for optimizing artwork for the printing process.

#### Create a Design

This guide explains how to create and name a design in the Issuing Dashboard or API, offering standard and custom bundle types.

#### Issue Cards

This guide explains how to issue physical cards using the Dashboard or the Create a card endpoint, covering both standard and custom bundles.

#### Ship Cards

This page details the two shipping options for physical cards: individual and bulk. It also covers the various shipping services offered with different cost points, speeds, and tracking capabilities.

#### Address Validation

This page explains how Stripe Issuing uses built-in address normalization and validation to ensure successful delivery of physical cards, comparing provided addresses to a third-party database.

### Replacement Cards

This guide explains how to replace cards that are expired, damaged, lost, or stolen, detailing how the process and the new card details might differ depending on the scenario.

### Digital Wallets

This page explains how to use Issuing to add cards to digital wallets like Apple Pay and Google Pay, covering manual and push provisioning methods.

### PIN Management

This guide explains how cardholders can manage their personal identification numbers (PINs) for Point-of-Sale and ATM transactions. It covers initial PIN setup and management through the Stripe API and Elements.

---

## Treasury for Platforms

### Overview

This page provides an overview of Stripe Treasury for Platforms, a suite of APIs for Stripe Connect platforms that enables embedding financial services into your product.

### How Treasury for Platforms Works

This guide explains connected accounts, financial accounts for platforms, and the process of moving money, detailing the modular components for building financial services.

### Eligibility Requirements

This page outlines the compliance requirements and restrictions for using Treasury for Platforms, applicable to both the platform and its connected accounts.

### Getting Started with API Access

This page guides users on how to get started with API access to Treasury for Platforms, including testing in a sandbox environment.

### Onboarding Users

This guide explains how to onboard connected accounts for Treasury for Platforms, emphasizing fraud prevention and regulatory compliance, including Know Your Customer (KYC) and Know Your Business (KYB) procedures.

### Account Management

#### Accounts Structure

This guide explains the technical components of Stripe Treasury for Platforms, specifically the different account types within a Connect integration.

#### Working with Connected Accounts

This page explains how to request the treasury capability and collect onboarding requirements for connected accounts.

#### Working with Financial Accounts

This guide explains how to use financial accounts to store, send, and receive funds, detailing how each financial account has its own distinct balance.

#### Financial Account Features

This page explains the features available for financial accounts, including moving money, attaching payment cards, and the capabilities required for each feature.

#### Platform Financial Accounts

This page describes the automatically provisioned financial account for your platform, used for storing working capital and testing integrations.

### Moving Money

#### Working with Balances and Transactions

This guide explains financial account balances and how transactions affect them, detailing properties like `cash`, `inbound_pending`, and `outbound_pending`.

#### Payouts and Top-ups from Payments Balance

This page explains how to move money between payments account balances and financial account balances using payouts and top-ups.

#### Working with SetupIntents, PaymentMethods, and BankAccounts

This guide explains how to set up money movements with Treasury for Platforms using PaymentMethod objects to save account credentials.

#### Moving Money into Financial Accounts

This page details the requests available to move money into financial accounts using InboundTransfer and ReceivedCredit objects.

##### Moving money using InboundTransfer objects

This guide explains how to transfer money from an external US bank account into a financial account using the ACH network via InboundTransfer objects.

##### Moving money using ReceivedCredit objects

This guide explains how to move money into a financial account from another financial account or bank account, detailing the ReceivedCredit object.

##### Moving money using CreditReversal objects

This guide explains how to return funds from received credits that add money to a financial account.

#### Moving Money Out of Financial Accounts

This page details the methods available to move funds from a financial account to another account.

##### Moving money using OutboundTransfer objects

This guide explains how to transfer money out of financial accounts to external accounts using OutboundTransfer objects.

##### Moving money using OutboundPayment objects

This guide explains how to create outbound payments to move money out of financial accounts to third parties using OutboundPayment objects.

##### Moving money using ReceivedDebit objects

This guide explains how external account holders can pull funds from a financial account, resulting in ReceivedDebit objects.

##### Moving money using DebitReversal objects

This guide explains how to retrieve funds taken out of a financial account from an external account holder using DebitReversal objects.

#### Money Movement Timelines

This page explains the timelines for various types of money movement with Treasury for Platforms, considering processing and cutoff times of banking partners and payment networks.

#### ACH NOC and SEC Handling

This guide explains how external account information is updated when a Notification of Change (NOC) is received for an ACH transaction.

### Bank Partners

#### Fifth Third Bank Overview

This page provides an overview of Fifth Third Bank as a new bank partner for Stripe's Treasury for Platforms product.

#### Integrate with Fifth Third Bank

This guide describes how to integrate Fifth Third Bank into an existing Treasury for Platforms integration.

#### Build a new Treasury for Platforms integration with Fifth Third Bank

This guide details how to get started with Stripe Treasury for Platforms using Fifth Third Bank, including sandbox environments and compliance reviews.

### Sample Integrations

#### Set up financial accounts and cards

This guide follows a sample integration that sets up a financial account and creates payment cards using Treasury for Platforms and Issuing.

#### Use Treasury for Platforms to move money

This guide describes basic money movement using Treasury for Platforms endpoints, covering funding financial accounts and moving money between them and external bank accounts.

#### Issuing and Treasury for Platforms Sample App

This page introduces the Stripe Next.js sample app as a starting point for Issuing and Treasury for Platforms integrations, highlighting its features and providing access to the code.

#### Webhooks for Stripe Issuing and Treasury for Platforms

This guide explains webhook events for Stripe Issuing and Treasury for Platforms, detailing why they occur and how to handle asynchronous events.

### Marketing and Compliance Guidelines

#### Treasury for Platforms Product Marketing, Design, and Compliance Guidelines

This document outlines guidelines for marketing and user interfaces to ensure compliance with financial regulations when offering Treasury for Platforms and Issuing products.

#### Handling Complaints

This page explains how to properly handle complaints related to Treasury for Platforms or Stripe Issuing, emphasizing the mandatory nature of complaint handling and Stripe's expectations for acknowledgment and resolution.

#### Marketing Treasury for Platforms

This guide provides recommended terms for marketing Treasury for Platforms to ensure compliance with regulations regarding financial services terminology.

#### Regulatory Receipts

This page explains hosted transaction receipts for regulated transactions within Treasury for Platforms, detailing how to provide customers with access to these receipts.

---

## Issuing and Treasury for Platforms with Connect

### Set up an Issuing and Connect Integration

This guide explains how to issue cards on connected accounts using Stripe Connect, detailing when to use Connect for Issuing integrations.

### Update Terms of Service Acceptance

This guide explains how to present accurate business information for connected accounts and accept the Issuing terms of service, including required disclosures.

### Connect Funding

This page explains how to fund connected accounts for Issuing, covering options like pull funding and push funding from external accounts.

### Connected Accounts, Cardholders, and Cards

This guide explains how connected accounts, cardholders, and cards interact within a Stripe Connect integration for Issuing.

### Cardholder Controls

This page details how Stripe screens cardholder information according to legal and regulatory guidelines and how updated cardholder controls affect integrations.

### Inactive Connected Accounts Offboarding

This guide explains how inactive Issuing accounts are disabled globally to mitigate risk, and how Stripe notifies connected accounts that have lost access due to inactivity.

### Embed Issuing Card Management into Your Website

This page explains how to use Connect embedded components to embed Issuing card management functionality into your website, offering prebuilt UI components for administrative users.

---

## Issuing Controls

### Spending Controls

This page explains how to use spending controls to set rules on cards and cardholders, including blocking merchant categories, countries, or setting spending limits.

### Lifecycle Controls

This guide explains how to use Issuing lifecycle controls to automatically cancel a virtual card after a specified number of payments, supporting single-use or n-use cards.

### Advanced Fraud Tools

This page explains how Stripe Issuing's advanced fraud tools help identify and prevent transaction fraud through API signals and tooling, enabling more informed authorization decisions.

### 3D Secure

This page explains 3D Secure (3DS), an additional layer of authentication used by businesses to combat fraud for online transactions where a card isn't physically present.

### Fraud Challenges

This page explains how fraud challenges provide an additional layer of verification for authorizations, minimizing accidental blocks and conducting additional verification on high-risk transactions.

### Real-time Authorizations

This section covers real-time authorizations in Stripe Issuing, allowing for synchronous approval or decline of authorization requests.

#### Quickstart

This page provides a quickstart guide for setting up and managing real-time authorizations.

#### Migrate to Direct Webhook Response

This guide explains how to migrate Issuing real-time authorizations from deprecated API calls to direct webhook responses, simplifying the process and improving authorization rates.

### Issuing Authorization Rules

This page explains how Issuing rules help prevent unauthorized activity by blocking authorizations that match custom conditions, such as transactions outside a specific geography or above a certain amount.

### PIN Management

This guide explains how to manage and view PINs on issued cards, covering initial PIN setup at creation and cardholder self-management options.

### Token Management

This page explains how to use Issuing to manage network tokens on cards, which are virtual representations created when a cardholder adds a card to a digital wallet or saves payment details.

---

## Issuing Purchases

### Authorizations

This page explains how Stripe Issuing handles authorization requests when a card is used for a purchase, detailing the steps involved in approval or decline.

### Transactions

This page explains how Stripe Issuing handles transactions after an authorization is approved and captured, detailing the creation of Transaction objects and the status updates.

### Disputes

This page explains how to use Issuing to dispute transactions, covering the process for submitting disputes through the Dashboard or API and the typical resolution timeframe.

### Merchant Categories

This page explains Merchant Category Codes (MCCs) and how businesses are categorized, detailing how these categories can be used for spending controls.

### ATM Usage

This page explains how US-issued cards can be used for ATM cash withdrawals, including enabling the feature, setting up PINs, and how ATM transactions are treated.

### Enriched Merchant Data

This page explains how enriched merchant data can be used to understand customer spending patterns and improve fraud prevention, providing detailed merchant information and transaction activity.

---

## Issuing Credit

### Overview

This page provides an overview of Issuing Credit, a private preview feature that allows platforms to apply their Issuing account balance or exposure limit to cards issued to connected accounts.

### Credit Consumer Issuing

This section covers Credit Consumer Issuing, a private preview feature that allows platforms to create, launch, and manage a credit program for their consumers.

#### How Credit Consumer Issuing Works

This guide explains the features and APIs needed to create, launch, and manage a credit program for consumers, including BIN sponsorship and collaboration with sponsor banks.

### Manage Account Obligations

This section details how to track credit spend, lifecycle, and balances for connected accounts using Funding Obligations.

#### Obligation Amounts, Transactions, and Adjustments

This page explains how to view details about a Funding Obligation and make adjustments, including fetching current pending Funding Obligations.

#### Obligation Payments

This page explains how to make payments to a Funding Obligation, detailing the responsibility of collecting repayment from the connected account and using Stripe's Payment Intents API.

#### Available Credit and Flow of Funds

This page explains how available credit changes with card-based transactions and adjustments, and how to use the available credit amount field to prevent authorization declines.

### Manage Credit Terms

This page explains how to manage credit terms for connected accounts by updating credit limit amounts or intervals, and how to deactivate a connected account's ability to spend funds supported by the platform's Issuing account.

### Report Other Credit Decisions and Manage Adverse Action Notices

This page explains how to record application and decision details using the CreditUnderwritingRecord API, including adverse actions and sending adverse action notice emails (AANs).

### Report Required Regulatory Data for Credit Decisions

This page explains how platforms subject to additional reporting for credit programs can upload regulatory data to Stripe's Files API and include the file ID in requests to report credit decisions.

### Test Credit Integration

This page explains how to test credit integrations in a sandbox environment using the Credit API, covering steps like creating connected accounts, requesting capabilities, and updating Credit Policies.

---

## Stablecoin-Backed Cards

### Stablecoin-Backed Cards for Stripe Stablecoin Financial Accounts

This page explains how to issue virtual or physical prepaid or debit cards for connected accounts, backed by Stablecoin Financial Accounts.

### Stablecoin-Backed Cards for Bridge, Privy, or Third-Party Wallets

This guide explains how to integrate Stripe Issuing with Bridge to build a stablecoin-backed consumer or commercial card program, spending from a stablecoin balance.

### Stablecoin-Backed Card Issuing

This page explains how to issue prepaid or debit cards backed by stablecoin balances in partnership with Bridge, allowing platforms to enter new markets with a single integration.

---

## Compliance and Guidelines

### Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US)

This guide outlines marketing and user interface guidelines for launching and maintaining compliant Issuing and Treasury programs in the US.

### Issuing Regulated Customer Notices

This page explains how Issuing platforms must send customer communications upon certain trigger events to comply with applicable laws, detailing Stripe's no-code solution for sending regulated emails.

### Stripe Issuing Marketing Guidelines (Europe/UK)

This document outlines marketing guidelines for Issuing programs in the United Kingdom and Europe, ensuring user interfaces and advertising adhere to financial regulations.

---

## Testing

### Test Your Issuing Integration

This guide explains how to test Issuing integrations in a sandbox environment by issuing cards and simulating purchases without making real transactions.

---

## Customer Support

### Customer Support for Issuing and Treasury for Platforms

This document provides example issues and resolutions for customer support teams assisting with Issuing and Treasury for Platforms. It emphasizes equipping support teams with the necessary information and tools.
```
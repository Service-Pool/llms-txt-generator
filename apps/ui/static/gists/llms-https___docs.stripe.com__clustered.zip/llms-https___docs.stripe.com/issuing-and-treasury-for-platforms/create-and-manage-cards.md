## Stripe Issuing and Treasury for Platforms

This documentation group provides comprehensive guidance on utilizing Stripe Issuing and Treasury for Platforms. It covers everything from initial setup and integration to advanced features like fraud management, credit programs, and international expansion.

### Core Concepts

*   **Stripe Issuing:** Enables businesses to create and manage their own payment card programs, allowing them to issue physical or virtual cards to their customers, employees, or contractors. This includes features for card customization, transaction controls, and fraud prevention.
*   **Treasury for Platforms:** A suite of APIs that allows Stripe Connect platforms to embed financial services into their products. This enables connected accounts to hold funds, pay bills, earn cash back, and manage their cash flow through financial accounts and cards.

### Key Areas of Documentation

The documentation is organized into several key areas:

#### Getting Started and Integration

*   **Onboarding Overview:** Guides users through the process of preparing for and launching an Issuing or Treasury for Platforms integration.
*   **Integration Guides:** Provides specific guides for integrating with Issuing for various use cases, including:
    *   Embedded Finance
    *   B2B Payments
    *   Fleet Management
*   **Sample App:** Offers a practical example of how to use Issuing and Treasury for Platforms APIs.
*   **API Access:** Details how to get started with API access to Treasury for Platforms.
*   **Setting up Financial Accounts and Cards:** Demonstrates how to set up financial accounts and create cards using Treasury for Platforms and Issuing.

#### Card Management and Issuance

*   **Choosing Card Types:** Explains the options for issuing virtual and physical cards.
*   **Physical Cards:** Comprehensive information on issuing, customizing, and shipping physical cards, including:
    *   Artwork templates and design creation.
    *   Custom bundle ordering and customization.
    *   Address validation for shipping.
    *   Shipping options.
*   **Virtual Cards:** Details on creating and displaying virtual card details.
*   **Replacement Cards:** Guidance on replacing expired, damaged, lost, or stolen cards.
*   **PIN Management:** How to manage PINs for cardholders.
*   **Digital Wallets:** Instructions on integrating Issuing cards with digital wallets like Apple Pay and Google Pay.

#### Funding and Money Movement

*   **Issuing Balance:** Explains how to fund your Issuing balance to enable card spend.
*   **Adding Funds to Card Programs:** Covers various funding options, including pull-funded top-ups, push-funded top-ups, and balance transfers.
*   **Post-funding:** Information on post-funding your integration with Stripe, including Dynamic Reserves.
*   **Treasury for Platforms Money Movement:** Extensive documentation on moving money into and out of financial accounts, including:
    *   Inbound and Outbound Transfers.
    *   Received Credits and Debits.
    *   Credit Reversals and Debit Reversals.
    *   Payouts and top-ups from the payments balance.
    *   Working with BankAccount objects.
    *   ACH NOC and SEC handling.
*   **Connect Funding:** Specific guidance on funding Issuing balances with Stripe Connect.

#### Controls and Fraud Management

*   **Manage Fraud:** Strategies and tools for managing transaction fraud with Stripe Issuing.
*   **Advanced Fraud Tools:** Details on using API signals and tooling to prevent fraud.
*   **Issuing Authorization Rules:** How to limit authorization approvals using custom rules.
*   **Real-time Authorizations:** Information on approving or declining authorization requests in real time via webhooks.
*   **Fraud Challenges:** Explains how to implement additional verification steps for high-risk transactions.
*   **Spending Controls:** Setting rules and limits for card and cardholder spending.
*   **Lifecycle Controls:** Managing automatic usage-based cancellation of virtual cards.
*   **Token Management:** How to manage network tokens for secure payments.

#### Stripe Connect Integration

*   **Setting up Issuing and Connect:** Guidance on integrating Issuing with Stripe Connect for issuing cards to third parties.
*   **Connected Accounts, Cardholders, and Cards:** Understanding the relationship between connected accounts, cardholders, and cards.
*   **Cardholder Controls:** Information on screening cardholder information and handling errors.
*   **Inactive Connected Accounts Offboarding:** How inactivity affects connected accounts' Issuing capabilities.
*   **Embedded Components:** Using prebuilt UI components to embed Issuing card management into your website.

#### Credit Programs

*   **Issuing Credit:** An overview of Stripe's credit solutions for Issuing.
*   **Credit Consumer Issuing:** Details on creating and managing credit programs for consumers.
*   **Manage Account Obligations:** Tracking credit spend, lifecycle, and balances for connected accounts.
*   **Available Credit and Flow of Funds:** Understanding how available credit changes and impacts authorizations.
*   **Manage Credit Terms:** Configuring credit limits and periods for connected accounts.
*   **Obligation Payments:** How to collect repayment for Funding Obligations.
*   **Obligation Amounts, Transactions, and Adjustments:** Viewing and adjusting Funding Obligation details.
*   **Report Other Credit Decisions and Manage AANs:** Recording credit decisions and sending adverse action notices.
*   **Report Required Regulatory Data for Credit Decisions:** Guidelines for platforms subject to additional reporting for credit programs.
*   **Test Credit Integration:** How to validate your credit integration in testing environments.

#### Program Management and Compliance

*   **Program Management:** Choosing between Stripe program management and processor-only models.
*   **Processor-Only Issuing:** Details on integrating as a processor-only for Issuing.
*   **Issuing Merchant Categories:** Understanding Merchant Category Codes (MCCs) for spending controls.
*   **Issuing Watchlist:** Information on how Stripe screens users against sanctions lists.
*   **Compliance Guidelines (US & Europe/UK):** Marketing, design, and compliance guidelines for Issuing and Treasury for Platforms.
*   **Issuing Regulated Customer Notices:** Sending regulatory notifications to customers.
*   **Customer Support:** Information on customer support for Issuing and Treasury for Platforms.

#### Advanced Features and Use Cases

*   **B2B Payments:** Integration guide for building B2B payment solutions with Issuing.
*   **Embedded Finance:** Guide for building embedded financial services integrations.
*   **Fleet:** Integration guide for building fleet financial services.
*   **Issuing for Agents:** Issuing programmable cards with built-in controls for agents.
*   **Stablecoin-Backed Cards:** Information on issuing cards backed by stablecoin balances, including integrations with Bridge, Privy, and third-party wallets.
*   **Global Availability:** How to use Stripe Issuing in different countries, including local and cross-border issuing.
*   **ATM Usage:** How to enable and use cards for ATM cash withdrawals.

#### Treasury for Platforms Specifics

*   **Treasury for Platforms Overview:** A general introduction to the product.
*   **Eligibility Requirements:** Understanding the criteria for using Treasury for Platforms.
*   **Account Management:** Details on account structures, working with connected accounts, financial accounts, and platform financial accounts.
*   **Financial Account Features:** Exploring features available for financial accounts.
*   **Working with Balances and Transactions:** Understanding financial account balances and transaction impacts.
*   **Bank Partners:** Information on integrating with Fifth Third Bank.
*   **Compliance Guidelines:** Marketing, design, and compliance guidelines for Treasury for Platforms.
*   **Handling Complaints:** Procedures for addressing customer complaints.
*   **Marketing Treasury for Platforms:** Creating compliant messaging for financial services.
*   **Regulatory Receipts:** Information on hosted transaction receipts.
*   **Onboarding Users:** Guides for onboarding connected accounts for Treasury for Platforms.
*   **Fraud Guide:** Best practices for managing fraud with Treasury for Platforms.
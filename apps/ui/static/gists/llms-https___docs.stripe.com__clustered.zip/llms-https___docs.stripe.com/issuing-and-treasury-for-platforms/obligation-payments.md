## Stripe Issuing and Treasury for Platforms Documentation

This documentation set provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. These products empower platforms to offer financial services, such as card issuance and money management, to their connected accounts.

### Key Areas Covered:

*   **Issuing:** This section details how to create, manage, and distribute payment cards for your business or your users. It covers various card types (virtual and physical), customization options, funding mechanisms, and fraud management tools.
    *   **Card Management:** Learn about choosing card types (virtual/physical), creating designs, ordering custom bundles, issuing cards, and shipping.
    *   **Funding and Balances:** Understand how to add funds to your Issuing balance and manage different funding types.
    *   **Controls and Security:** Explore spending controls, lifecycle controls, advanced fraud tools, 3D Secure authentication, real-time authorizations, and PIN management.
    *   **Program Management:** Discover different program management models, including Stripe's management and processor-only options.
    *   **Specialized Use Cases:** Find information on B2B payments, fleet management, embedded finance, consumer prepaid cards, credit programs, and agent-specific card issuance.
    *   **Global Availability:** Understand how to use Stripe Issuing in different countries.
    *   **Compliance:** Access product marketing, design, and compliance guidelines for various regions.

*   **Treasury for Platforms:** This section focuses on enabling platforms to offer financial services to their connected accounts. It covers setting up financial accounts, managing money movement, and integrating with Issuing.
    *   **Core Concepts:** Understand the account structure, financial account features, and how to work with balances and transactions.
    *   **Money Movement:** Learn about moving money into and out of financial accounts using various methods like InboundTransfers, OutboundPayments, and OutboundTransfers.
    *   **Integration with Issuing:** Discover how to integrate Stripe Issuing with Treasury for Platforms to issue cards linked to financial accounts.
    *   **Onboarding and Compliance:** Access guides on onboarding connected accounts, managing fraud, and adhering to marketing and compliance guidelines.
    *   **Bank Partnerships:** Information on integrating with banking partners like Fifth Third Bank.

*   **Integration Guides and Samples:** This section provides practical resources to help you get started.
    *   **Integration Guides:** Step-by-step guides for specific use cases like B2B payments, embedded finance, and fleet management.
    *   **Sample App:** A sample application to help you understand how to use Issuing and Treasury for Platforms APIs.
    *   **Testing:** Resources for testing your Issuing and Treasury for Platforms integrations in sandbox environments.

*   **Customer Support:** Information on how to get assistance with Issuing and Treasury for Platforms.

This documentation suite is designed for developers and product managers looking to leverage Stripe's robust Issuing and Treasury for Platforms solutions to build innovative financial products.
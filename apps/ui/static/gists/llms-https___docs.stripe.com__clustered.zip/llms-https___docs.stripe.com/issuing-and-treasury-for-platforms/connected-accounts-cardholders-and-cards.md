## Stripe Issuing and Treasury for Platforms Documentation

This section of the Stripe documentation provides comprehensive guidance on integrating and utilizing Stripe Issuing and Treasury for Platforms. It covers everything from initial setup and onboarding to advanced features like fraud management, credit programs, and international expansion.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing for creating and managing payment cards for your business.
*   **How Issuing Works:** Delve into the mechanics of how Stripe Issuing operates, including partnerships with banks and card networks.
*   **Treasury for Platforms Overview:** Learn how to embed financial services into your platform, enabling connected accounts to manage funds and transactions.
*   **Get Started with API Access:** Initial steps for gaining API access to Treasury for Platforms.
*   **Onboarding Overview:** A guide to the essential steps for launching your Issuing or Treasury for Platforms integration.
*   **Integration Guides:** Explore specific guides for integrating Issuing for various use cases:
    *   **Embedded Finance:** Build embedded financial services.
    *   **B2B Payments:** Facilitate business-to-business payments.
    *   **Fleet:** Create fleet card programs.
*   **Sample App:** Utilize the Issuing and Treasury for Platforms sample app to understand API usage and onboard customers.
*   **Testing Your Integration:** Learn how to test your Issuing integration in a sandbox environment.

### Card Management and Issuance

*   **Choose Card Type:** Decide between physical and virtual cards for your cardholders.
*   **Virtual Cards:** Understand how to create and manage virtual cards.
*   **Physical Cards:** Comprehensive details on issuing and managing physical cards.
    *   **Choose Card Bundle:** Select standard or custom physical card bundles.
    *   **Order a Custom Bundle:** Process for ordering custom physical card bundles.
    *   **Customize Card Bundle:** Options for customizing card bundles.
    *   **Artwork Templates:** Guidelines for designing your card artwork.
    *   **Create a Design:** Steps to create and name your card design.
    *   **Issue Cards:** How to create physical cards for cardholders.
    *   **Ship Cards:** Options for shipping physical cards.
    *   **Address Validation:** Ensuring accurate addresses for physical card delivery.
*   **Replacement Cards:** Procedures for replacing expired, damaged, lost, or stolen cards.
*   **PIN Management:** How cardholders can manage their Personal Identification Numbers.
*   **Digital Wallets:** Integrating Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **Issuing Elements:** Using browser-side components for PCI-compliant display of card details.

### Funding and Balances

*   **Issuing Balance:** Understanding and managing the Issuing balance for card spend.
*   **Add Funds to Your Card Program:** Options for funding your Issuing balance.
*   **Post-fund Your Integration with Stripe:** Learn about accruing a negative Issuing balance and funding later.
*   **Post-fund Your Integration with Dynamic Reserves:** Utilizing dynamic reserves for post-funding.

### Connect Integrations

*   **Set Up an Issuing and Connect Integration:** Integrating Issuing with Stripe Connect for managing funds and compliance for third-party users.
*   **Connected Accounts, Cardholders, and Cards:** Understanding the relationship between connected accounts, cardholders, and cards in a Connect integration.
*   **Cardholder Controls:** Managing cardholder information and compliance requirements.
*   **Inactive Connected Accounts Offboarding:** Handling the disabling of Issuing capabilities for inactive connected accounts.
*   **Fund Issuing Balances with Connect:** Methods for funding Issuing balances for connected accounts.
*   **Update the Issuing Terms of Service Acceptance:** Ensuring connected accounts accept the necessary terms.
*   **Embed Issuing Card Management into Your Website:** Using Connect embedded components for card management UI.

### Treasury for Platforms Integrations

*   **Treasury for Platforms Overview:** A high-level introduction to Treasury for Platforms.
*   **How Treasury for Platforms Works:** Detailed explanation of connected accounts, financial accounts, and money movement.
*   **Eligibility Requirements:** Understanding the criteria for using Treasury for Platforms.
*   **Get Started with API Access:** Initial steps for API access to Treasury for Platforms.
*   **Onboarding Users:** Guide to onboarding connected accounts for financial services.
*   **Accounts Structure:** Understanding the different account types within Treasury for Platforms.
*   **Working with Connected Accounts:** Managing connected accounts for Treasury for Platforms.
*   **Working with Financial Accounts:** Details on financial accounts for storing and moving funds.
*   **Financial Account Features:** Exploring the capabilities of financial accounts.
*   **Platform Financial Accounts:** Understanding the financial account for your platform.
*   **Working with Balances and Transactions:** Managing financial account balances and transaction history.
*   **Moving Money:** Comprehensive guides on money movement within Treasury for Platforms:
    *   **Moving money into financial accounts:** Using `InboundTransfer` and `ReceivedCredit` objects.
    *   **Moving money out of financial accounts:** Using `OutboundTransfer`, `OutboundPayment`, `ReceivedDebit`, and `DebitReversal` objects.
    *   **Payouts and top-ups from payments balance:** Moving funds between payments and financial accounts.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Setting up money movements.
    *   **ACH NOC and SEC handling:** Managing external account information updates.
*   **Money Movement Timelines:** Understanding the processing times for various money movement operations.
*   **Sample Integrations:**
    *   **Set up financial accounts and cards:** A sample integration for setting up financial accounts and creating cards.
    *   **Using Treasury for Platforms to move money:** An example of basic money movement.
    *   **Issuing and Treasury for Platforms Sample App:** A Next.js sample app for Issuing and Treasury for Platforms.
*   **Webhooks:** Understanding webhook events for Issuing and Treasury for Platforms.
*   **Marketing and Compliance Guidelines:**
    *   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines:** Ensuring compliant marketing and user interfaces.
    *   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US):** Specific guidelines for the US market.
    *   **Stripe Issuing Marketing Guidelines (UK and Europe):** Marketing guidelines for the UK and Europe.
    *   **Issuing Regulated Customer Notices:** Sending regulatory notifications to customers.
    *   **Handling Complaints:** Procedures for managing customer complaints.
    *   **Regulatory Receipts:** Information on hosted transaction receipts.
    *   **Marketing Treasury for Platforms:** Creating compliant messaging for users.
*   **Bank Partners:**
    *   **Integrate with Fifth Third Bank:** Integrating with Fifth Third Bank for Treasury for Platforms.
    *   **Build a new Treasury for Platforms integration with Fifth Third Bank:** Getting started with Fifth Third Bank.

### Credit Programs

*   **Issuing Credit Overview:** Introduction to credit programs with Issuing.
*   **Credit Consumer Issuing:** Details on launching credit programs for consumers.
*   **Manage Credit Terms:** Configuring credit limits and terms for connected accounts.
*   **Manage Account Obligations:** Tracking credit spend, lifecycle, and balances for connected accounts.
    *   **Available Credit and Flow of Funds:** Understanding available credit and fund flow.
    *   **Obligation Amounts, Transactions, and Adjustments:** Viewing obligation details and making adjustments.
    *   **Obligation Payments:** Making payments to your FundingObligation.
*   **Report Other Credit Decisions and Manage Adverse Action Notices:** Recording credit decisions and sending adverse action notices.
*   **Report Required Regulatory Data for Credit Decisions:** Complying with regulatory reporting requirements.
*   **Test Credit Integration:** Validating your credit integration in testing environments.

### Fraud Management and Controls

*   **Manage Fraud:** Understanding fraud risks and how to combat them with Stripe Issuing.
*   **Advanced Fraud Tools:** Utilizing API signals and tooling to prevent transaction fraud.
*   **Issuing Authorization Rules:** Limiting authorization approvals with custom rules.
*   **Issuing Real-Time Authorizations:** Approving or declining authorization requests in real time.
    *   **Migrate to Direct Webhook Response:** Migrating from deprecated API calls to direct webhook responses.
*   **Fraud Challenges:** Implementing additional verification steps for authorizations.
*   **Spending Controls:** Setting rules for cards and cardholders to control spending.
*   **Lifecycle Controls:** Controlling automatic usage-based cancellation of cards.
*   **3D Secure:** Cardholder authentication for online transactions.
*   **Issuing Watchlist:** Understanding the process for screening users against sanctions lists.

### Other Features and Considerations

*   **Customer Support:** Information on customer support for Issuing and Treasury for Platforms.
*   **Issuing Merchant Categories:** Understanding Merchant Category Codes (MCCs) for spending controls.
*   **Use Stripe Issuing in Different Countries:** Global availability and integration options for Issuing.
*   **Issuing Beta Migration Guide:** Guidance for migrating from the Issuing beta program.
*   **Issuing for Agents:** Issuing programmable cards with built-in controls for agents.
*   **Choose a Cardholder Type:** Selecting the appropriate cardholder type for your use case.
*   **Stablecoin-Backed Cards:** Issuing cards backed by stablecoin balances.
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts:** Issuing cards for connected accounts backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets:** Integrating Stripe Issuing with Bridge for stablecoin-backed card programs.
    *   **Stablecoin-backed card issuing:** Overview of issuing cards backed by stablecoin balances.
*   **Use Cards at Automated Teller Machines (ATMs):** Enabling and using cards for ATM cash withdrawals.
*   **Issuing Authorizations:** Handling authorization requests for card transactions.
*   **Issuing Transactions:** Understanding the lifecycle of a transaction after authorization.
*   **Issuing Disputes:** Procedures for disputing transactions.
*   **Enriched Merchant Data:** Utilizing comprehensive merchant data for fraud prevention and insights.
*   **Processor-Only Issuing:** Integrating with Stripe Issuing as a processor.
*   **Customize Your Card Program:** Tailoring your Stripe Issuing card program to business needs.
*   **Program Management:** Choosing between Stripe program management and processor-only models.
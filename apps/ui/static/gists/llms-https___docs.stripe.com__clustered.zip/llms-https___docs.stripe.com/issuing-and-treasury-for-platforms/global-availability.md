## Stripe Issuing and Treasury for Platforms

This documentation suite provides comprehensive guidance on integrating and utilizing Stripe Issuing and Treasury for Platforms. These products enable businesses to create and manage payment card programs for their users, facilitate money movement, and offer embedded financial services.

### Key Areas Covered:

*   **Getting Started with Issuing:**
    *   Understanding how Issuing works and its core features.
    *   Onboarding processes and requirements for launching an Issuing program.
    *   Choosing between physical and virtual cards, including design customization and ordering.
    *   Funding your Issuing balance and managing card programs.
    *   Testing your Issuing integration in a sandbox environment.

*   **Issuing Integrations and Features:**
    *   **B2B Payments:** Guides for building B2B payment solutions with Issuing.
    *   **Embedded Finance:** Integrating Issuing for embedded financial services.
    *   **Fleet Management:** Creating fleet card programs with Issuing.
    *   **Consumer Issuing:** Options for consumer prepaid debit cards and credit programs.
    *   **Processor-Only Integration:** Setting up and managing an Issuing program where you handle more of the processing.
    *   **Customization:** Tailoring card programs, including BIN setup and card design.
    *   **Digital Wallets:** Integrating Issuing cards with Apple Pay and Google Pay.
    *   **PIN Management:** Allowing cardholders to manage their PINs.
    *   **Replacement Cards:** Processes for handling expired, damaged, lost, or stolen cards.
    *   **Merchant Categories:** Understanding MCC codes for spending controls.
    *   **Global Availability:** Options for issuing cards in different countries.

*   **Controls and Fraud Management:**
    *   **Spending Controls:** Setting rules and limits for card usage.
    *   **Lifecycle Controls:** Managing automatic card cancellation based on usage.
    *   **Advanced Fraud Tools:** Utilizing API signals and tooling to prevent transaction fraud.
    *   **Real-time Authorizations:** Approving or declining authorization requests in real-time.
    *   **Fraud Challenges:** Implementing additional verification steps for high-risk transactions.
    *   **3D Secure:** Cardholder authentication for online transactions.
    *   **Token Management:** Managing network tokens for secure payments.
    *   **Issuing Watchlist:** Understanding automatic screening against sanctions lists.
    *   **Customer Support:** Resources for resolving Issuing and Treasury-related issues.

*   **Stripe Connect Integration:**
    *   **Setting up Issuing and Connect:** Integrating Issuing with Stripe Connect for platforms.
    *   **Connected Accounts, Cardholders, and Cards:** Managing these entities within a Connect integration.
    *   **Funding Issuing Balances with Connect:** Allocating funds to connected accounts for Issuing.
    *   **Cardholder Controls:** Ensuring compliance with cardholder screening requirements.
    *   **Embedding Card Management:** Using Connect embedded components for UI.
    *   **Inactive Account Management:** Handling the disabling of Issuing capabilities for inactive accounts.
    *   **Terms of Service Acceptance:** Updating and managing Issuing terms for connected accounts.

*   **Treasury for Platforms:**
    *   **Getting Started:** API access, sandbox environments, and onboarding users.
    *   **Account Management:** Understanding account structures, connected accounts, and financial accounts.
    *   **Financial Account Features:** Capabilities for moving money, attaching cards, and managing balances.
    *   **Working with Cards:** Integrating Stripe Issuing with Treasury for Platforms.
    *   **Money Movement:**
        *   Moving money into and out of financial accounts (ACH, wires, Stripe network).
        *   Using InboundTransfer, OutboundPayment, OutboundTransfer, ReceivedCredit, DebitReversal, and CreditReversal objects.
        *   Payouts and top-ups from Stripe Payments balance.
        *   Working with SetupIntents, PaymentMethods, and BankAccounts.
        *   Understanding ACH NOC and SEC handling.
        *   Money movement timelines.
    *   **Compliance and Marketing:** Guidelines for regulatory compliance, marketing, and handling complaints.
    *   **Bank Partners:** Information on integrating with Fifth Third Bank.
    *   **Sample Integrations:** Guides and sample applications for common use cases.

*   **Credit Issuing:**
    *   **Issuing Credit Overview:** Understanding the credit APIs and their private preview status.
    *   **Credit Consumer Issuing:** Launching credit programs for consumers.
    *   **Manage Account Obligations:** Tracking credit spend, lifecycle, and balances for connected accounts.
    *   **Credit Policies and Funding Obligations:** How these work together.
    *   **Manage Credit Terms:** Updating credit limits and intervals.
    *   **Obligation Payments:** Collecting repayment from connected accounts.
    *   **Obligation Amounts, Transactions, and Adjustments:** Viewing and adjusting funding obligations.
    *   **Reporting Credit Decisions:** Recording application details and managing adverse action notices.
    *   **Regulatory Data Reporting:** Providing required data for credit decisions.
    *   **Testing Credit Integrations:** Validating automated platform funding in sandbox environments.

*   **Stablecoin-Backed Cards:**
    *   Issuing prepaid or debit cards backed by stablecoin balances.
    *   Integrating with Bridge, Privy, or third-party wallets.
    *   Using Stablecoin Financial Accounts.
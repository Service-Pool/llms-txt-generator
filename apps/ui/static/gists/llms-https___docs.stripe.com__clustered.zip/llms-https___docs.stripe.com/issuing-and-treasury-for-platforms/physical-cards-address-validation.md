## Stripe Issuing and Treasury for Platforms: Card Issuance and Financial Account Management

This documentation set provides comprehensive guidance on leveraging Stripe's Issuing and Treasury for Platforms products. It covers the entire lifecycle of card issuance, from choosing card types and customization to managing transactions, fraud, and advanced controls. Additionally, it details how to integrate financial account management for your connected accounts, enabling them to store, send, and receive funds.

### Key Areas Covered:

*   **Getting Started with Issuing:**
    *   **Onboarding Overview:** Understand the steps required to launch your Issuing integration.
    *   **How Issuing Works:** Gain a foundational understanding of Stripe Issuing's capabilities.
    *   **Integration Guides:** Explore specific guides for B2B payments, Embedded Finance, and Fleet management.
    *   **Sample App:** Utilize a sample application to see Issuing and Treasury for Platforms APIs in action.
    *   **Customer Support:** Find resources for resolving common Issuing and Treasury for Platforms issues.

*   **Card Management:**
    *   **Card Types:** Decide between physical and virtual cards, understanding their use cases and trade-offs.
    *   **Issuing Cards:** Learn how to create and issue both virtual and physical cards.
    *   **Physical Card Customization:** Customize your physical card program with options for bundles, artwork, and design.
    *   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **PIN Management:** Understand how to manage and set PINs for cardholders.
    *   **Replacement Cards:** Learn the process for replacing expired, damaged, lost, or stolen cards.

*   **Funding and Balances:**
    *   **Issuing Balance:** Understand how to fund your Issuing balance to enable card spend.
    *   **Adding Funds:** Explore various funding options, including pull-funded top-ups, push-funded top-ups, and balance transfers.
    *   **Post-Funding:** Learn about post-funding your integration with Stripe and Dynamic Reserves.

*   **Controls and Fraud Management:**
    *   **Manage Fraud:** Discover Stripe Issuing's tools and controls for combating transaction fraud.
    *   **Spending Controls:** Set rules and limits to control cardholder spending by category, country, or amount.
    *   **Lifecycle Controls:** Implement automatic card cancellation based on usage.
    *   **Real-time Authorizations:** Handle authorization requests synchronously for immediate approval or decline decisions.
    *   **Authorization Rules:** Define custom conditions to limit authorization approvals.
    *   **Fraud Challenges:** Implement additional verification steps for high-risk transactions.
    *   **Advanced Fraud Tools:** Leverage API signals and tooling for enhanced fraud detection.
    *   **3D Secure:** Understand cardholder authentication using 3D Secure for online transactions.
    *   **Issuing Watchlist:** Learn about automatic screening against sanctions lists.

*   **Stripe Connect Integration:**
    *   **Set up Issuing and Connect:** Integrate Stripe Issuing with Stripe Connect to issue cards for third parties.
    *   **Connected Accounts, Cardholders, and Cards:** Manage the relationship between connected accounts, cardholders, and issued cards.
    *   **Fund Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing.
    *   **Cardholder Controls:** Understand how cardholder information is screened and managed.
    *   **Inactive Connected Accounts:** Manage the offboarding process for inactive accounts.
    *   **Embed Card Management:** Utilize prebuilt UI components to embed Issuing card management into your website.

*   **Treasury for Platforms:**
    *   **Overview:** Understand how Treasury for Platforms enables embedding financial services for connected accounts.
    *   **Getting Started:** Learn how to gain API access and set up sandbox environments.
    *   **Account Management:** Explore the accounts structure, working with connected accounts, and financial accounts.
    *   **Financial Account Features:** Discover the features available for financial accounts, including moving money.
    *   **Working with Balances and Transactions:** Understand financial account balances and how transactions affect them.
    *   **Money Movement:** Learn how to move money into and out of financial accounts using various methods like ACH, wires, and Stripe network transfers.
    *   **Compliance and Marketing:** Navigate regulatory requirements, marketing guidelines, and complaint handling.
    *   **Bank Partners:** Understand integration with banking partners like Fifth Third Bank.
    *   **Sample Integrations:** Utilize sample applications and guides for setting up financial accounts and moving money.

*   **Credit Issuing:**
    *   **Issuing Credit Overview:** Understand how to apply your platform's Issuing balance or exposure limit to cards issued to connected accounts.
    *   **Credit Consumer Issuing:** Learn about issuing credit programs for your customers.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Manage Credit Terms:** Configure credit limits and terms for connected accounts.
    *   **Reporting:** Report credit decisions and manage adverse action notices.

*   **Specific Use Cases:**
    *   **B2B Payments:** Build B2B payment integrations using Stripe Issuing.
    *   **Embedded Finance:** Create embedded financial services integrations.
    *   **Fleet:** Develop fleet financial services integrations.
    *   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for rewards, disbursements, or branded programs.
    *   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.
    *   **Stablecoin-Backed Cards:** Issue cards backed by stablecoin balances.

*   **Compliance and Guidelines:**
    *   **Product Marketing, Design, and Compliance:** Adhere to guidelines for launching and maintaining compliant Issuing and Treasury programs.
    *   **Marketing Guidance (Europe/UK):** Understand marketing guidelines for Issuing programs in the UK and Europe.
    *   **Regulated Customer Notices:** Learn about sending regulatory notifications to customers.
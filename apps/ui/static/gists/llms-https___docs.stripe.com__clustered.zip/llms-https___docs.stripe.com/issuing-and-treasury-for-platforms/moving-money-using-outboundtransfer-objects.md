## Stripe Issuing and Treasury for Platforms Documentation

This collection of documentation pages provides comprehensive guidance on utilizing Stripe's Issuing and Treasury for Platforms products. These products empower platforms to embed financial services, such as card issuance and money management, directly into their offerings for connected accounts.

### Core Concepts and Getting Started

*   **Issuing Overview (`/issuing`)**: An introduction to Stripe Issuing, enabling platforms to create, manage, and distribute payment cards for their users without setup fees.
*   **How Issuing Works (`/issuing/how-issuing-works`)**: Explains the fundamental mechanics of building a card program with Stripe Issuing, including partnerships with banks and card networks.
*   **Treasury for Platforms Overview (`/treasury/connect`)**: Introduces Treasury for Platforms as a suite of APIs for Stripe Connect platforms to embed financial services, allowing connected accounts to hold funds, pay bills, and manage cash flow.
*   **Getting Started with API Access to Treasury for Platforms (`/treasury/connect/access`)**: Guides users on how to obtain API access and test Treasury for Platforms functionality in a sandbox environment.
*   **Onboarding Overview (`/issuing/onboarding-overview`)**: Details the steps required to take an Issuing or Treasury for Platforms integration live, including use case approval and live mode access.
*   **Issuing Beta Migration Guide (`/issuing/migration-from-beta`)**: Provides instructions for migrating from the Issuing beta to the generally available version, including API changes.

### Integration Guides and Use Cases

*   **Integration Guides (`/issuing/integration-guides`)**: A central hub for various integration guides, including:
    *   **Embedded Finance Integration Guide (`/issuing/integration-guides/embedded-finance`)**: For building embedded financial services with Issuing and Treasury for Platforms.
    *   **B2B Payments Integration Guide (`/issuing/integration-guides/b2b-payments`)**: For creating cards for business, employee, or contractor purchases.
    *   **Fleet Integration Guide (`/issuing/integration-guides/fleet`)**: For building fleet financial services with Issuing.
*   **Sample App (`/issuing/sample-app`, `/treasury/connect/examples/sample-app`)**: Demonstrates how to use Issuing and Treasury for Platforms APIs, allowing users to onboard customers, create cards, test authorizations, and make outbound payments.
*   **Issuing for Your Business (`/issuing/direct`)**: Guides on programmatically creating virtual cards for internal business use.
*   **Issuing for Agents (`/issuing/agents`)**: Details on issuing programmable cards with built-in controls for agents to use for purchases.

### Card Management and Customization

*   **Choose Your Card Type (`/issuing/choose-cards`)**: Helps decide between physical and virtual cards, outlining tradeoffs and use cases.
*   **Virtual Cards (`/issuing/cards/virtual`, `/issuing/cards/virtual/issue-cards`)**: Information on creating and displaying virtual cards, including PCI-compliant methods.
*   **Physical Cards (`/issuing/cards/physical`, `/issuing/cards/physical/issue-cards`)**: Covers the process of issuing physical cards, including customization and printing.
    *   **Artwork Templates (`/issuing/cards/artwork-templates`)**: Guidelines for preparing artwork for card printing.
    *   **Customize Card Bundle (`/issuing/cards/physical/card-bundle-selections`)**: Options for customizing the card, carrier, and envelope.
    *   **Choose Your Physical Bundle (`/issuing/cards/physical/choose-bundle`)**: Details on standard and custom physical bundle options.
    *   **Order a Custom Bundle (`/issuing/cards/physical/order-custom-bundle`)**: Steps for ordering custom physical card bundles.
    *   **Ship Cards (`/issuing/cards/physical/ship-cards`)**: Information on shipping options for physical cards.
    *   **Address Validation (`/issuing/cards/physical/address-validation`)**: How to ensure accurate shipping addresses for physical cards.
*   **Replacement Cards (`/issuing/cards/replacements`)**: Procedures for replacing expired, damaged, lost, or stolen cards.
*   **PIN Management (`/issuing/cards/pin-management`)**: How cardholders can manage their PINs.
*   **Use Digital Wallets with Issuing (`/issuing/cards/digital-wallets`)**: Instructions for adding Issuing cards to digital wallets like Apple Pay and Google Pay.
*   **Customize Your Card Program (`/issuing/customize-your-program`)**: Details on customizing card programs, including BIN setup.

### Funding and Balances

*   **Fund Your Issuing Balance (`/issuing/funding/balance`)**: Explains how to make funds available for card spend by adding funds to the Issuing balance.
*   **Add Funds to Your Card Program (`/issuing/adding-funds-to-your-card-program`)**: Discusses various funding options for card programs.
*   **Postfund your integration with Stripe (`/issuing/funding/post-fund`)**: Learn how to accrue a negative Issuing balance and postfund Stripe later.
*   **Post-fund your integration with Dynamic Reserves (`/issuing/funding/post-fund-with-dynamic-reserves`)**: Utilizing dynamic reserves to manage cash flow between Stripe and authorization availability.

### Connect Integrations

*   **Set Up an Issuing and Connect Integration (`/issuing/connect`)**: Guidance on integrating Stripe Connect with Issuing to manage funds flows and compliance for connected accounts.
*   **Connected Accounts, Cardholders, and Cards (`/issuing/connect/cardholders-and-cards`)**: How to create and manage cardholders and cards within a Stripe Connect integration.
*   **Fund Issuing Balances with Connect (`/issuing/connect/funding`)**: Instructions on allocating funds to connected accounts' Issuing balances.
*   **Update the Issuing Terms of Service Acceptance (`/issuing/connect/tos_acceptance`)**: How to present business information and obtain acceptance of Issuing terms of service for connected accounts.
*   **Cardholder Controls (`/issuing/connect/cardholders-controls`)**: Information on how cardholder screening affects integrations and compliance.
*   **Inactive Connected Accounts Offboarding (`/issuing/connect/inactive-accounts-management`)**: Details on how inactivity affects Issuing capabilities for connected accounts.
*   **Embed Issuing Card Management into Your Website (`/issuing/connect/embedded-components`)**: Using Connect embedded components to integrate card management functionality.

### Treasury for Platforms Account Management

*   **Accounts Structure (`/treasury/connect/account-management/accounts-structure`)**: Explains the interaction between platform and connected accounts within Treasury for Platforms.
*   **Working with Connected Accounts (`/treasury/connect/account-management/connected-accounts`)**: How to request treasury capabilities and collect onboarding requirements for connected accounts.
*   **Working with Financial Accounts (`/treasury/connect/account-management/financial-accounts`)**: Details on using financial accounts to store, send, and receive funds.
*   **Financial Account Features (`/treasury/connect/account-management/financial-account-features`)**: Information on features available for financial accounts, such as moving money and attaching cards.
*   **Platform Financial Accounts (`/treasury/connect/account-management/platform-financial-account`)**: Understanding the financial account provisioned for your platform.
*   **Working with Stripe Issuing Cards (`/treasury/connect/account-management/issuing-cards`)**: How to integrate Stripe Issuing with Treasury for Platforms to create cards using financial accounts.
*   **Treasury for Platforms Supportability for Connected Accounts (`/treasury/connect/supportability`)**: How Stripe evaluates connected accounts for Treasury for Platforms supportability.
*   **Working with Balances and Transactions (`/treasury/connect/working-with-balances-and-transactions`)**: Explains financial account balances and how transactions affect them.

### Money Movement with Treasury for Platforms

*   **Using Treasury for Platforms to Move Money (`/treasury/connect/moving-money/moving-money-into-financial-accounts`)**: Guides on moving money into financial accounts using InboundTransfer and ReceivedCredit objects.
    *   **Moving Money Using InboundTransfer Objects (`/treasury/connect/moving-money/into/inbound-transfers`)**: How to transfer money from an external US bank account into a financial account.
    *   **Moving Money Using ReceivedCredit Objects (`/treasury/connect/moving-money/into/received-credits`)**: How funds move into a financial account and the corresponding ReceivedCredit object.
    *   **Moving Money Using CreditReversal Objects (`/treasury/connect/moving-money/into/credit-reversals`)**: Reversing ReceivedCredits to return funds.
*   **Moving Money Out of Treasury for Platforms (`/treasury/connect/moving-money/moving-money-out`)**: Methods for moving funds from a financial account to another account.
    *   **Moving Money Using OutboundTransfer Objects (`/treasury/connect/moving-money/out-of/outbound-transfers`)**: Transferring funds from a financial account to an external bank account.
    *   **Moving Money Using OutboundPayment Objects (`/treasury/connect/moving-money/out-of/outbound-payments`)**: Creating outbound payments to third parties.
    *   **Moving Money Using ReceivedDebit Objects (`/treasury/connect/moving-money/out-of/received-debits`)**: Understanding when money is pulled from a financial account.
    *   **Moving Money Using DebitReversal Objects (`/treasury/connect/moving-money/out-of/debit-reversals`)**: Retrieving funds taken from a financial account via a ReceivedDebit.
*   **Payouts and Top-ups from Payments Balance (`/treasury/connect/moving-money/payouts`)**: How to move money between payments balance and financial account balances.
*   **Working with SetupIntents, PaymentMethods, and BankAccounts (`/treasury/connect/moving-money/working-with-bankaccount-objects`)**: Setting up money movements with Treasury for Platforms using PaymentMethod objects.
*   **ACH NOC and SEC Handling (`/treasury/connect/moving-money/noc-sec-handling`)**: How external account information is updated via ACH transactions.
*   **Money Movement Timelines (`/treasury/connect/money-movement/timelines`)**: Timelines for various money movement types with Treasury for Platforms.

### Fraud Management and Controls

*   **Manage Fraud (`/issuing/manage-fraud`)**: Understanding transaction fraud risks and how to combat them using Stripe Issuing controls.
*   **Advanced Fraud Tools (`/issuing/controls/advanced-fraud-tools`)**: Utilizing API signals and tooling to identify and prevent transaction fraud.
*   **Issuing Authorization Rules (`/issuing/controls/authorization-rules`)**: Limiting authorization approvals using custom rules.
*   **Issuing Real-Time Authorizations (`/issuing/controls/real-time-authorizations`)**: Approving or declining authorization requests in real time using synchronous webhooks.
    *   **Migrate to Direct Webhook Response (`/issuing/controls/real-time-authorizations/direct-webhook-migration`)**: Migrating real-time authorizations from deprecated API calls to direct webhook responses.
*   **Fraud Challenges (`/issuing/controls/fraud-challenges`)**: Implementing additional verification layers for authorizations.
*   **Issuing Lifecycle Controls (`/issuing/controls/lifecycle-controls`)**: Automatically canceling virtual cards after a specified number of payments.
*   **Issuing Spending Controls (`/issuing/controls/spending-controls`)**: Setting rules on cards and cardholders to control spending by category, country, or amount.
*   **Issuing Merchant Categories (`/issuing/categories`)**: Understanding Merchant Category Codes (MCCs) for spending controls.
*   **Token Management (`/issuing/controls/token-management`)**: Managing network tokens for cards, which are virtual representations used for payments.
*   **Issuing Watchlist (`/issuing/issuing-watchlist`)**: How Stripe automatically screens Issuing users against sanctions lists.
*   **Treasury for Platforms Fraud Guide (`/treasury/connect/examples/fraud-guide`)**: Best practices for managing fraud as a platform using Treasury for Platforms.

### Credit and Consumer Issuing

*   **Credit Consumer Issuing (`/issuing/credit`, `/issuing/credit/manage-account-obligations`, `/issuing/credit/manage-credit-terms`, `/issuing/credit/manage-account-obligations/obligation-payments`, `/issuing/credit/manage-account-obligations/obligations-transactions-adjustments`, `/issuing/credit/report-credit-decisions-and-manage-aans`, `/issuing/credit/report-required-regulatory-data-for-credit-decisions`, `/issuing/credit/test-credit`)**: Comprehensive documentation on offering credit programs to consumers, including managing credit terms, obligations, and regulatory reporting.
*   **Consumer Prepaid Debit Cards (`/issuing/consumer-prepaid-debit-cards`)**: How to issue prepaid debit cards for rewards, disbursements, or branded card programs.
*   **How Consumer Credit Issuing Works (`/issuing/consumer-issuing/how-it-works`)**: An overview of the features and APIs for creating and managing a credit program for customers.
*   **Available Credit and Flow of Funds (`/issuing/credit/manage-account-obligations/available-credit`)**: Understanding how available credit changes and using it to prevent declines.
*   **Set Up Credit for Connected Accounts (`/issuing/credit/connect-credit-setup`)**: Configuring credit terms for connected accounts and funding their spend.

### Stablecoin-Backed Cards

*   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts (`/issuing/stablecoin-cards-for-financial-accounts`)**: Issuing cards backed by Stablecoin Financial Accounts.
*   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets (`/issuing/bridge-stablecoin-cards`)**: Integrating Stripe Issuing with Bridge for stablecoin-backed card programs.
*   **Stablecoin-backed card issuing (`/issuing/stablecoin-cards`)**: Issuing prepaid or debit cards backed by stablecoin balances.

### Compliance and Support

*   **Customer Support for Issuing and Treasury for Platforms (`/issuing/customer-support`)**: Guidance on resolving common Issuing and Treasury for Platforms questions.
*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US) (`/issuing/compliance-us`)**: Guidelines for launching and maintaining compliant Issuing and Treasury programs in the US.
*   **Issuing Regulated Customer Notices (`/issuing/issuing-compliance-us/issuing-regulated-customer-notices`)**: Information on sending regulatory notifications to customers.
*   **Stripe Issuing Marketing Guidelines (UK and Europe) (`/issuing/marketing-guidance-europe-uk`)**: Marketing guidelines for Issuing programs in the UK and Europe.
*   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines (`/treasury/connect/compliance`)**: Guidelines for ensuring Treasury for Platforms programs and marketing campaigns are compliant.
*   **Handling Complaints (`/treasury/connect/handling-complaints`)**: Procedures for properly handling complaints related to Treasury for Platforms or Issuing.
*   **Marketing Treasury for Platforms (`/treasury/connect/marketing-financial-accounts`)**: Creating compliant messaging for Treasury for Platforms.
*   **Regulatory Receipts (`/treasury/connect/moving-money/regulatory-receipts`)**: Information on hosted transaction receipts for regulated money movements.

### Testing and Development

*   **Test Your Issuing Integration (`/issuing/testing`)**: How to test Issuing integrations and simulate purchases in a sandbox environment.
*   **Test Your Integration (Credit) (`/issuing/credit/test-credit`)**: Validating credit integrations in testing environments.
*   **Treasury for Platforms Connected Account Onboarding Guide (`/treasury/connect/examples/onboarding-guide`)**: Implementing an onboarding process for connected accounts using Treasury for Platforms.
*   **Webhooks for Stripe Issuing and Treasury for Platforms (`/treasury/connect/examples/webhooks`)**: Understanding webhook events for Issuing and Treasury for Platforms.

### Other Resources

*   **Customer Support for Issuing and Treasury for Platforms (`/issuing/customer-support`)**: Directs users to customer support resources.
*   **Use Cards at Automated Teller Machines (ATMs) (`/issuing/purchases/atm-usage`)**: How to enable and use Issuing cards for ATM cash withdrawals.
*   **Issuing Authorizations (`/issuing/purchases/authorizations`)**: Handling authorization requests for card transactions.
*   **Issuing Disputes (`/issuing/purchases/disputes`)**: How to dispute transactions processed through Issuing.
*   **Enriched Merchant Data (`/issuing/purchases/enriched-merchant-data`)**: Using detailed merchant data for fraud prevention and spending controls.
*   **Issuing Transactions (`/issuing/purchases/transactions`)**: Understanding transaction objects after an authorization is captured.
*   **Choose a Cardholder Type (`/issuing/other/choose-cardholder`)**: Selecting the appropriate cardholder type (individual or company) for your use case.
*   **Use Stripe Issuing in Different Countries (`/issuing/global`)**: Information on global issuing options, including local and cross-border issuing.
*   **Processor-only Issuing (`/issuing/processor-only-issuing`, `/issuing/processor-only-integration-guide`)**: Details on integrating with a processor-only Issuing model.
*   **Program Management (`/issuing/program-management`)**: Comparing Stripe program management and processor-only models.
*   **Integrate with Fifth Third Bank (`/treasury/connect/fifth-third`)**: Adding Fifth Third Bank to an existing Treasury for Platforms integration.
*   **Build a New Treasury for Platforms Integration with Fifth Third Bank (`/treasury/connect/fifth-third-get-started`)**: Getting started with Treasury for Platforms using Fifth Third Bank.
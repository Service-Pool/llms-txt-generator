## Issuing Lifecycle Controls

You can use lifecycle controls to automatically cancel a virtual card after a specified number of payments. This provides support for single-use or n-use cards. To enable this functionality, set the `lifecycle_controls` parameter when creating a virtual card.

### How it works

Set `lifecycle_controls.cancel_after.payment_count` to specify the number of payments after which you want the virtual card automatically canceled. After the card reaches this payment count, its status automatically updates to `canceled`, and all future authorizations are declined.

### What counts as a payment

The following events count towards the `payment_count`:

*   **Approved authorizations** >1 USD: Standard card transactions that are approved
*   **Captured authorizations** ≤1 USD: Small transactions (≤1 USD) that are actually captured and result in a transaction
*   **Force posts**:
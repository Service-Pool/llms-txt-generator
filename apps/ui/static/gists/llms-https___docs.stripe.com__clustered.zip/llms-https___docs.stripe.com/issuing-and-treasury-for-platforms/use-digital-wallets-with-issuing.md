## Stripe Issuing and Treasury for Platforms: A Comprehensive Guide

This documentation suite provides a deep dive into Stripe's Issuing and Treasury for Platforms products, empowering developers and businesses to build sophisticated financial services. Whether you're looking to issue physical or virtual cards, manage funds, or create embedded financial experiences, these resources cover the essential aspects of integration, management, and best practices.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing, allowing you to create, manage, and distribute payment cards for your business or users. (Page 66)
*   **How Issuing Works:** Delve into the mechanics of Stripe Issuing, from card creation and spending controls to transaction approvals and network partnerships. (Page 67)
*   **Treasury for Platforms Overview:** Explore the suite of APIs that enable platforms to embed financial services for their connected accounts, facilitating fund holding, bill payments, and more. (Page 120)
*   **Getting Started with API Access:** Learn how to gain API access to Treasury for Platforms and begin testing in a sandbox environment. (Page 85)
*   **Onboarding Overview:** Understand the process of preparing your integration for launch, including use case approval and live mode access. (Page 6)
*   **Integration Guides:** Access specific guides for building integrations for Embedded Finance, B2B Payments, and Fleet management. (Page 5)
*   **Sample App:** Utilize the provided sample app to understand how to onboard customers, issue cards, and make outbound payments. (Page 7)
*   **Testing Your Integration:** Learn how to effectively test your Issuing integration in a sandbox environment without real financial transactions. (Page 84)
*   **Customer Support:** Find resources for resolving common Issuing and Treasury for Platforms questions. (Page 1)

### Card Management and Issuance

*   **Choose Card Type:** Decide between physical and virtual cards, understanding the use cases and trade-offs for each. (Page 12)
*   **Virtual Cards:** Learn how to create and manage virtual cards for immediate use. (Page 33)
*   **Issue Virtual Cards:** Step-by-step guide on creating virtual cards using the Dashboard or API. (Page 34)
*   **Physical Cards:** Explore the options for issuing physical cards, from standard designs to fully custom solutions. (Page 28)
*   **Create Physical Cards:** Detailed instructions on issuing physical cards to cardholders. (Page 26)
*   **Card Bundles:** Understand how to choose and customize physical card bundles, including carriers and envelopes. (Page 24)
*   **Customize Card Bundle:** Make selections for your card bundle during the design phase. (Page 23)
*   **Artwork Templates:** Access design templates for creating custom card artwork. (Page 22)
*   **Address Validation:** Ensure successful delivery of physical cards through address normalization and validation. (Page 21)
*   **Replacement Cards:** Learn the process for replacing expired, damaged, lost, or stolen cards. (Page 32)
*   **PIN Management:** Enable cardholders to manage their personal identification numbers for transactions. (Page 30)
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay. (Page 17)

### Funding and Financial Accounts

*   **Issuing Balance:** Understand how to make funds available for card spend by adding funds to your Issuing balance. (Page 61)
*   **Add Funds to Your Card Program:** Explore various funding options, including pull-funded top-ups, push-funded top-ups, and balance transfers. (Page 11)
*   **Post-fund Your Integration with Stripe:** Learn how to accrue a negative Issuing balance on card spend and post-fund Stripe later. (Page 64)
*   **Post-fund with Dynamic Reserves:** Utilize dynamic reserves to adjust credit limits in real-time for managing cash flow. (Page 63)
*   **Treasury for Platforms Accounts Structure:** Understand the interaction between platform and connected accounts within Treasury for Platforms. (Page 86)
*   **Financial Account Features:** Discover the features available for financial accounts, enabling money movement and card attachment. (Page 87)
*   **Platform Financial Accounts:** Learn about the dedicated financial account provisioned for your platform. (Page 89)
*   **Working with Balances and Transactions:** Understand financial account balances and how transactions affect them. (Page 91)
*   **Moving Money into Financial Accounts:** Explore methods for adding money to financial accounts using InboundTransfer and ReceivedCredit objects. (Page 111)
*   **Moving Money Out of Treasury for Platforms:** Learn how to move funds from financial accounts using various methods like OutboundTransfers and OutboundPayments. (Page 112)
*   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms using these key objects. (Page 119)
*   **Payouts and Top-ups from Payments Balance:** Understand how to move money between payments account balances and financial account balances. (Page 118)

### Stripe Connect Integrations

*   **Set up an Issuing and Connect Integration:** Learn how to issue cards on connected accounts, leveraging Stripe Connect for fund flows and compliance. (Page 41)
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and the cards issued to them. (Page 39)
*   **Fund Issuing Balances with Connect:** Discover how to fund connected accounts for Issuing, including pull and push funding options. (Page 40)
*   **Update Issuing Terms of Service Acceptance:** Ensure accurate business information is presented for connected accounts to accept Issuing terms. (Page 62)
*   **Cardholder Controls:** Manage cardholder information in compliance with legal and regulatory guidelines. (Page 36)
*   **Embed Issuing Card Management:** Utilize prebuilt UI components to embed Issuing card management into your website. (Page 37)
*   **Inactive Connected Accounts Offboarding:** Understand how inactivity affects connected accounts and the disabling of Issuing capabilities. (Page 38)
*   **Treasury for Platforms Connected Account Onboarding:** Implement a compliant onboarding process for connected accounts using Treasury for Platforms. (Page 102)
*   **Working with Connected Accounts:** Request the treasury capability and collect onboarding requirements for your connected accounts. (Page 92)

### Advanced Features and Controls

*   **Manage Fraud:** Understand transaction fraud risks and how to combat them using Stripe Issuing's controls and tools. (Page 20)
*   **Advanced Fraud Tools:** Leverage API signals and tooling to identify and prevent transaction fraud. (Page 42)
*   **Issuing Authorization Rules:** Limit authorization approvals by configuring custom rules to block unauthorized activity. (Page 43)
*   **Real-time Authorizations:** Approve or decline authorization requests in real time using synchronous webhooks. (Page 48)
*   **Migrate to Direct Webhook Response:** Transition from deprecated API calls to direct webhook responses for real-time authorizations. (Page 44)
*   **Fraud Challenges:** Enable an additional layer of verification for authorizations to minimize accidental blocks. (Page 45)
*   **Issuing Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards. (Page 47)
*   **Issuing Spending Controls:** Set rules on cards and cardholders to control spending by blocking categories, countries, or setting limits. (Page 49)
*   **Token Management:** Manage network tokens on your cards, which are virtual representations used for secure payments. (Page 50)
*   **3D Secure:** Implement an additional layer of authentication for online transactions to combat fraud. (Page 10)
*   **Issuing Merchant Categories:** Understand Merchant Category Codes (MCCs) and how to use them for spending controls. (Page 35)
*   **Enriched Merchant Data:** Utilize comprehensive merchant data to understand spending patterns and improve fraud prevention. (Page 79)
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents to complete purchases on your behalf. (Page 69)

### Credit and Financial Services

*   **Issuing Credit:** Apply your platform's Issuing account balance to authorize and fund transactions for connected accounts. (Page 53)
*   **Credit Consumer Issuing:** Create, launch, and manage a credit program for your consumers using Stripe's BIN sponsorship. (Page 15)
*   **How Credit Consumer Issuing Works:** Learn about the features and APIs for building a consumer credit program. (Page 14)
*   **Set up Credit for Connected Accounts:** Configure credit terms for connected accounts and fund their spend from your platform. (Page 52)
*   **Manage Credit Terms:** Update credit limits and intervals for connected accounts. (Page 55)
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for your connected accounts. (Page 54)
*   **Obligation Amounts, Transactions, and Adjustments:** View details about Funding Obligations and make adjustments. (Page 57)
*   **Obligation Payments:** Understand how to collect repayment from connected accounts for their Funding Obligations. (Page 56)
*   **Available Credit and Flow of Funds:** Learn how funds flow and how available credit impacts authorization declines. (Page 51)
*   **Report Other Credit Decisions and Manage Adverse Action Notices:** Record credit underwriting scenarios and send adverse action notice emails. (Page 58)
*   **Report Required Regulatory Data for Credit Decisions:** Comply with regulatory reporting requirements for credit programs. (Page 59)
*   **Test Credit Integration:** Validate your automated platform funding in testing environments using the Credit API. (Page 60)

### Compliance and Guidelines

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US):** Adhere to guidelines for launching and maintaining compliant Issuing and Treasury programs in the US. (Page 71)
*   **Issuing Regulated Customer Notices:** Understand how to send regulatory notifications to your customers to maintain compliance. (Page 72)
*   **Marketing Guidance (Europe/UK):** Follow marketing guidelines for Issuing programs in the United Kingdom and Europe. (Page 75)
*   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant. (Page 96)
*   **Issuing Watchlist:** Understand the process for automatic screening against sanctions lists and manual review procedures. (Page 74)
*   **Treasury for Platforms Fraud Guide:** Learn best practices for managing fraud as a platform. (Page 103)
*   **Treasury for Platforms Supportability for Connected Accounts:** Understand how Stripe evaluates connected accounts for Treasury for Platforms supportability. (Page 90)

### Specific Use Cases

*   **B2B Payments Integration Guide:** Build a B2B payments integration using Stripe Issuing. (Page 2)
*   **Embedded Finance Integration Guide:** Create an embedded financial services integration with Issuing and Treasury for Platforms. (Page 3)
*   **Fleet Integration Guide:** Build a fleet financial services integration with Issuing. (Page 4)
*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for users to instantly receive and spend money. (Page 13)
*   **Stablecoin-backed Cards:** Explore issuing cards backed by stablecoin balances, integrating with Bridge, Privy, or third-party wallets. (Page 81, Page 82, Page 83)
*   **Issuing for Your Business:** Programmatically create virtual cards for your business, employees, or contractors. (Page 73)

### Transactions and Disputes

*   **Issuing Authorizations:** Learn how to handle authorization requests when a card is used for a purchase. (Page 77)
*   **Issuing Transactions:** Understand how transaction objects are created after an authorization is approved and captured. (Page 80)
*   **Issuing Disputes:** Learn how to dispute transactions through the Dashboard or API. (Page 78)
*   **Use Cards at Automated Teller Machines (ATMs):** Enable and use US-issued cards for ATM cash withdrawals. (Page 76)
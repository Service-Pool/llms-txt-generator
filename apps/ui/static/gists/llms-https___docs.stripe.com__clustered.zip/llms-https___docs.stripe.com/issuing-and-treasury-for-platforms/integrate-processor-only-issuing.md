## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite covers Stripe Issuing and Treasury for Platforms, providing comprehensive resources for developers and businesses looking to integrate card issuance and financial services into their platforms.

### Key Areas Covered:

*   **Getting Started with Issuing:**
    *   **Onboarding Overview:** Understand the steps to get your Issuing integration live, including use case approval and live mode access.
    *   **How Issuing Works:** Learn the fundamental concepts and architecture behind Stripe Issuing.
    *   **Integration Guides:** Explore specific guides for various use cases like B2B Payments, Embedded Finance, and Fleet management.
    *   **Sample App:** Utilize a sample application to understand how to onboard customers, issue cards, and make outbound payments.
    *   **Customer Support:** Find information on resolving common Issuing and Treasury for Platforms questions.

*   **Card Management:**
    *   **Choosing Card Types:** Decide between virtual and physical cards based on your use case.
    *   **Virtual Cards:** Learn how to create and manage virtual cards.
    *   **Physical Cards:** Understand the process of issuing, customizing, and shipping physical cards.
        *   **Card Bundles:** Customize your physical card bundles, including design and artwork.
        *   **Address Validation:** Ensure successful delivery of physical cards with address validation.
    *   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **Replacement Cards:** Manage the process of replacing expired, damaged, lost, or stolen cards.
    *   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers.

*   **Funding and Balances:**
    *   **Issuing Balance:** Learn how to make funds available for card spend.
    *   **Adding Funds:** Explore different funding options for your Issuing balance.
    *   **Post-funding:** Understand how to post-fund your integration with Stripe and Dynamic Reserves.

*   **Controls and Fraud Management:**
    *   **Manage Fraud:** Discover tools and strategies to combat transaction fraud.
    *   **Spending Controls:** Set rules to control spending by blocking categories, countries, or setting limits.
    *   **Lifecycle Controls:** Implement automatic card cancellation based on usage.
    *   **Real-time Authorizations:** Approve or decline authorization requests in real time via webhooks.
    *   **Authorization Rules:** Limit authorization approvals based on custom conditions.
    *   **Fraud Challenges:** Implement additional verification steps for high-risk transactions.
    *   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud.
    *   **3D Secure:** Implement cardholder authentication for online transactions.
    *   **Token Management:** Manage network tokens for secure payments.
    *   **Issuing Watchlist:** Understand Stripe's automatic screening against sanctions lists.

*   **Stripe Connect Integration:**
    *   **Set up Issuing and Connect:** Learn how to issue cards on connected accounts.
    *   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between these entities in a Connect integration.
    *   **Cardholder Controls:** Ensure compliance with legal and regulatory guidelines for cardholder information.
    *   **Inactive Connected Accounts Offboarding:** Manage the disabling of Issuing capabilities for inactive accounts.
    *   **Connect Funding:** Fund Issuing balances for connected accounts.
    *   **Embedded Components:** Embed Issuing card management functionality into your website using prebuilt UI components.

*   **Issuing Program Management:**
    *   **Program Management:** Choose between Stripe program management and processor-only models.
    *   **Processor-only Issuing:** Integrate as a processor, managing regulatory requirements and compliance.
    *   **Customize Your Program:** Tailor your Issuing card program to your business needs.
    *   **Merchant Categories:** Understand Merchant Category Codes (MCCs) and their use in spending controls.
    *   **Global Availability:** Learn about Issuing options in different countries.
    *   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.
    *   **Compliance Guidelines:** Adhere to marketing, design, and compliance guidelines for Issuing and Treasury for Platforms.
    *   **Regulated Customer Notices:** Understand how to send regulatory notifications to customers.

*   **Stripe Treasury for Platforms:**
    *   **Getting Started with API Access:** Enable your Stripe account for Treasury for Platforms and Issuing capabilities.
    *   **Accounts Structure:** Understand the different account types within Treasury for Platforms.
    *   **Financial Account Features:** Learn about features available for financial accounts.
    *   **Working with Issuing Cards:** Integrate Stripe Issuing with Treasury for Platforms.
    *   **Platform Financial Accounts:** Understand the financial account provisioned for your platform.
    *   **Treasury for Platforms Supportability:** Learn how Stripe evaluates connected accounts for Treasury for Platforms.
    *   **Working with Balances and Transactions:** Understand financial account balances and transaction effects.
    *   **Working with Connected Accounts:** Request Treasury capabilities and collect onboarding requirements.
    *   **Working with Financial Accounts:** Use financial accounts to store, send, and receive funds.
    *   **Money Movement:** Explore various methods for moving money into and out of financial accounts, including:
        *   Inbound Transfers
        *   Received Credits
        *   Credit Reversals
        *   Outbound Payments
        *   Outbound Transfers
        *   Received Debits
        *   Debit Reversals
        *   Payouts and Top-ups from Payments Balance
    *   **Money Movement Timelines:** Understand the processing times for different money movement methods.
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated.
    *   **Working with Bank Accounts:** Set up money movements using SetupIntents, PaymentMethods, and BankAccounts.
    *   **Fifth Third Bank Integration:** Integrate with Fifth Third Bank for Treasury for Platforms.
    *   **Marketing and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant.
    *   **Handling Complaints:** Learn how to properly handle complaints related to Treasury for Platforms or Issuing.
    *   **Regulatory Receipts:** Understand hosted transaction receipts for regulated transactions.
    *   **Sample Integrations:** Explore sample applications and guides for Treasury for Platforms and Issuing.
    *   **Treasury for Platforms Fraud Guide:** Best practices for managing fraud as a platform.
    *   **Treasury for Platforms Requirements:** Understand the compliance requirements for using Treasury for Platforms.

*   **Credit Features:**
    *   **Issuing Credit:** Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
    *   **Credit Consumer Issuing:** Create, launch, and manage a credit program for your consumers.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Manage Credit Terms:** Configure credit terms for connected accounts.
    *   **Available Credit and Flow of Funds:** Understand how funds flow and how available credit affects authorization declines.
    *   **Obligation Payments:** Make payments to your FundingObligation.
    *   **Obligation Amounts, Transactions, and Adjustments:** View details about FundingObligations and make adjustments.
    *   **Report Other Credit Decisions and Manage Adverse Action Notices:** Record application and decision details, and send adverse action notices.
    *   **Report Required Regulatory Data for Credit Decisions:** Report regulatory data for credit programs.
    *   **Test Credit Integration:** Validate your automated platform funding in testing environments.

*   **Stablecoin-backed Cards:**
    *   **Stablecoin-backed Cards for Financial Accounts:** Issue prepaid or debit cards backed by Stablecoin Financial Accounts.
    *   **Stablecoin-backed Cards for Bridge, Privy, or Third-party Wallets:** Integrate Stripe Issuing with Bridge for stablecoin-backed card programs.
    *   **Stablecoin-backed Card Issuing:** Issue prepaid or debit cards backed by stablecoin balances.

*   **Testing:**
    *   **Test Your Issuing Integration:** Issue cards and simulate purchases in a sandbox environment.
    *   **Test Credit Integration:** Validate your credit integration in testing environments.
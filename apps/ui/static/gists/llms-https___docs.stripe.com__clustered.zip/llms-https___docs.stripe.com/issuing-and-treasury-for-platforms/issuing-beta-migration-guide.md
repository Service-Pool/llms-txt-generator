```markdown
# Issuing Beta Migration Guide

This guide explains how to migrate from the Stripe Issuing beta.

## Overview

Stripe Issuing became generally available for all US businesses. Upon exiting beta, we released pricing and API changes to support its long-term evolution. Depending on your integration, some of these API changes may be breaking, so pay close attention to each item in this guide.

We will be discontinuing the beta API on March 1, 2021. Below, we've outlined all the changes to the API to help with your migration. Contact support with any questions.

## Compatibility

**Caution:** As noted in each section, we recommend supporting both the old and new API until you've officially switched over. We also recommend creating a new Issuing account to test out the new API before switching over on your main account.

### Attributes

For beta users, both legacy and new attributes are currently available on all Issuing objects. Renamed attributes point to the same backend value as their legacy counterpart. When the beta is discontinued, only the new attributes will be available.

To prepare, we recommend switching reads to support both the old and new attribute until you've successfully switched over to the new API.

### Parameters

For renamed parameters, either the legacy or new name can be used, but not both. When the beta is discontinued, only the new parameters will be accepted.

To prepare, we recommend switching writes to support both the old and new param until you've successfully switched over to the new API.

### Enums

Transitioning to new enum values will be slightly more complicated. New values can be written and read back, but old, existing values will continue to be returned until the beta is discontinued.

To prepare, we recommend switching reads to support both the old and new enum values until you've successfully switched over to the new API. For writes, we recommend switching to the new enum values.

## API Changes

### Issuing API

#### Cardholders

| Legacy Attribute | New Attribute | Description |
|---|---|---|
| `currency` | `balance` | The balance of the cardholder. |
| `type` | `card_type` | The type of card (e.g., `physical`, `virtual`). |

#### Cards

| Legacy Attribute | New Attribute | Description |
|---|---|---|
| `status` | `card_status` | The status of the card (e.g., `active`, `inactive`). |
| `spending_rules` | `spending_controls` | Rules that govern card spending. |

#### Authorizations

| Legacy Attribute | New Attribute | Description |
|---|---|---|
| `merchant_data.name` | `merchant_data.display_name` | The display name of the merchant. |
| `merchant_data.category_code` | `merchant_data.category` | The merchant category code. |

### Other Changes

*   **Pricing:** Issuing is no longer free. Refer to the [Issuing pricing page](https://stripe.com/pricing/issuing) for details.
*   **Support:** Beta users can contact support for migration assistance.
```
## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and integration to advanced features like fraud management, credit programs, and international expansion.

### Key Areas of Focus:

*   **Getting Started with Issuing:**
    *   Understand the core concepts of Stripe Issuing and how it works.
    *   Navigate the onboarding process and requirements for launching an Issuing program.
    *   Explore different integration models, including Stripe program management and processor-only integrations.
    *   Learn about regional considerations and global availability.

*   **Issuing Card Management:**
    *   **Card Types:** Choose between physical and virtual cards, understanding the use cases and trade-offs for each.
    *   **Customization:** Customize your card program with options for card design, bundles, and artwork templates.
    *   **Issuing Cards:** Learn how to create and issue both physical and virtual cards to your cardholders.
    *   **PIN Management:** Understand how to manage PINs for cardholders.
    *   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **Replacement Cards:** Manage the process of replacing expired, damaged, lost, or stolen cards.

*   **Funding and Transactions:**
    *   **Issuing Balance:** Learn how to fund your Issuing balance to enable card spend.
    *   **Funding Options:** Explore various funding types, including pull-funded top-ups, push-funded top-ups, Stripe balance transfers, and Connect balance transfers.
    *   **Post-funding:** Understand how to post-fund your integration with Stripe, including dynamic reserves.
    *   **Authorizations:** Learn how to handle authorization requests in real-time.
    *   **Transactions:** Understand how authorizations are captured and become transactions.
    *   **ATM Usage:** Configure and understand ATM withdrawals for your issued cards.

*   **Fraud Management and Controls:**
    *   **Manage Fraud:** Implement strategies and utilize Stripe's tools to combat transaction fraud.
    *   **Advanced Fraud Tools:** Leverage API signals and tooling for enhanced fraud detection.
    *   **Authorization Rules:** Configure rules to limit authorization approvals based on custom conditions.
    *   **Real-time Authorizations:** Implement real-time decision-making for authorization requests.
    *   **Fraud Challenges:** Utilize additional verification steps to minimize accidental blocks and verify high-risk transactions.
    *   **Spending Controls:** Set rules and limits on card and cardholder spending.
    *   **Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards.
    *   **Token Management:** Understand how to manage network tokens for secure payments.
    *   **Issuing Watchlist:** Learn about Stripe's automated screening against sanctions lists.

*   **Stripe Connect Integration for Issuing:**
    *   **Set up Issuing and Connect:** Integrate Stripe Issuing with Stripe Connect to issue cards on behalf of connected accounts.
    *   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and the cards issued to them.
    *   **Cardholder Controls:** Manage cardholder information in compliance with legal and regulatory guidelines.
    *   **Inactive Connected Accounts:** Learn how inactivity affects connected accounts' Issuing capabilities.
    *   **Connect Funding:** Fund Issuing balances for connected accounts.
    *   **Embed Card Management:** Utilize Connect embedded components to integrate card management functionality into your website.

*   **Credit Programs with Issuing:**
    *   **Credit Consumer Issuing:** Learn about the solution for creating and managing credit programs for your customers.
    *   **Manage Credit Terms:** Configure credit limits and terms for connected accounts.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Available Credit and Flow of Funds:** Understand how available credit changes and impacts authorizations.
    *   **Obligation Payments:** Learn how to collect repayments from connected accounts.
    *   **Report Credit Decisions:** Record application and decision details, including adverse actions.
    *   **Report Regulatory Data:** Understand requirements for reporting regulatory data for credit decisions.
    *   **Test Credit Integration:** Validate your automated platform funding in testing environments.

*   **Treasury for Platforms:**
    *   **Overview:** Understand the core functionality of Treasury for Platforms for embedding financial services.
    *   **Getting Started:** Access API documentation, eligibility requirements, and onboarding guides.
    *   **Account Management:** Learn about the account structure, connected accounts, and financial accounts.
    *   **Financial Account Features:** Explore the features available for financial accounts.
    *   **Working with Balances and Transactions:** Understand how financial account balances are affected by transactions.
    *   **Moving Money:** Learn how to move money into and out of financial accounts using various methods like ACH, wires, and Stripe network transfers.
    *   **Payouts and Top-ups:** Manage money movement between payments balance and financial account balances.
    *   **Bank Partners:** Integrate with banking partners like Fifth Third Bank.
    *   **Compliance:** Adhere to marketing, design, and compliance guidelines for Treasury for Platforms.
    *   **Fraud Management:** Implement best practices for managing fraud within your platform.
    *   **Sample Integrations:** Utilize sample applications and guides for common use cases.

*   **Specific Integration Guides:**
    *   **Embedded Finance:** Build embedded financial services integrations.
    *   **B2B Payments:** Create B2B payment integrations using Stripe Issuing.
    *   **Fleet:** Build fleet financial services integrations.

*   **Customer Support and Compliance:**
    *   **Customer Support:** Find information on resolving common Issuing and Treasury for Platforms questions.
    *   **Compliance Guidelines:** Understand product marketing, design, and compliance guidelines for both Issuing and Treasury for Platforms in the US and Europe/UK.
    *   **Regulated Customer Notices:** Learn about sending regulatory notifications to your customers.

*   **Sample App and Testing:**
    *   **Sample App:** Utilize the Issuing and Treasury for Platforms sample app to understand API usage.
    *   **Testing:** Learn how to test your Issuing and Treasury for Platforms integrations in a sandbox environment.

This documentation suite aims to provide a clear and comprehensive resource for developers and businesses looking to leverage Stripe's Issuing and Treasury for Platforms products.
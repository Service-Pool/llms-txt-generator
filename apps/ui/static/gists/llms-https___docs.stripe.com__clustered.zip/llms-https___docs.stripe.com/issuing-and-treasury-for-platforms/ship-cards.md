## Stripe Issuing: Card Issuance and Management

This documentation group provides comprehensive guidance on utilizing Stripe's Issuing product to create, manage, and distribute payment cards for businesses and their users. It covers various aspects of card programs, from initial setup and funding to advanced fraud controls and international expansion.

### Key Areas:

*   **Getting Started with Issuing:**
    *   **Overview:** Understand the core functionalities and benefits of Stripe Issuing. (`/issuing`)
    *   **How Issuing Works:** Learn the fundamental mechanics of building a card program. (`/issuing/how-issuing-works`)
    *   **Onboarding:** Navigate the process of getting your Issuing integration approved and live. (`/issuing/onboarding-overview`)
    *   **Integration Guides:** Explore specific use cases like Embedded Finance, B2B Payments, and Fleet management. (`/issuing/integration-guides`, `/issuing/integration-guides/embedded-finance`, `/issuing/integration-guides/b2b-payments`, `/issuing/integration-guides/fleet`)
    *   **Sample App:** Utilize a sample application to understand API integration. (`/issuing/sample-app`)
    *   **Customer Support:** Find resources for resolving common Issuing and Treasury for platforms issues. (`/issuing/customer-support`)
    *   **Global Availability:** Understand how to use Stripe Issuing in different countries. (`/issuing/global`)
    *   **Beta Migration:** Guide for migrating from the Issuing beta. (`/issuing/migration-from-beta`)

*   **Card Types and Customization:**
    *   **Choose Card Type:** Decide between physical and virtual cards. (`/issuing/choose-cards`)
    *   **Virtual Cards:** Learn about creating and managing virtual cards. (`/issuing/cards/virtual`, `/issuing/cards/virtual/issue-cards`)
    *   **Physical Cards:** Details on issuing and managing physical cards. (`/issuing/cards/physical`, `/issuing/cards/physical/issue-cards`)
    *   **Card Bundles:** Customize physical card bundles, including ordering custom options and using artwork templates. (`/issuing/cards/physical/card-bundle-selections`, `/issuing/cards/physical/order-custom-bundle`, `/issuing/cards/physical/create-design`, `/issuing/cards/physical/ship-cards`, `/issuing/cards/physical/address-validation`, `/issuing/cards/artwork-templates`, `/issuing/cards/choose-bundle`)
    *   **Replacement Cards:** Procedures for replacing expired, damaged, lost, or stolen cards. (`/issuing/cards/replacements`)
    *   **Customization:** Tailor your card program to specific business needs. (`/issuing/customize-your-program`)

*   **Funding and Balances:**
    *   **Issuing Balance:** Understand how to fund your Issuing balance for card spend. (`/issuing/funding/balance`)
    *   **Adding Funds:** Explore different funding options for your card program. (`/issuing/adding-funds-to-your-card-program`)
    *   **Post-Funding:** Learn about post-funding your integration with Stripe and Dynamic Reserves. (`/issuing/funding/post-fund`, `/issuing/funding/post-fund-with-dynamic-reserves`)

*   **Cardholder Management and Controls:**
    *   **Cardholder Types:** Select the appropriate cardholder type for your use case. (`/issuing/other/choose-cardholder`)
    *   **Cardholder Controls:** Understand how cardholder information is screened and managed. (`/issuing/connect/cardholders-controls`)
    *   **Spending Controls:** Implement rules to manage cardholder spending. (`/issuing/controls/spending-controls`)
    *   **Lifecycle Controls:** Control automatic usage-based cancellation of cards. (`/issuing/controls/lifecycle-controls`)
    *   **PIN Management:** Allow cardholders to manage their PINs. (`/issuing/cards/pin-management`)

*   **Fraud Management and Security:**
    *   **Manage Fraud:** Overview of fraud risks and how to combat them. (`/issuing/manage-fraud`)
    *   **Advanced Fraud Tools:** Utilize API signals and tooling to prevent transaction fraud. (`/issuing/controls/advanced-fraud-tools`)
    *   **Real-time Authorizations:** Approve or decline authorization requests in real time. (`/issuing/controls/real-time-authorizations`, `/issuing/controls/real-time-authorizations/quickstart`, `/issuing/controls/real-time-authorizations/direct-webhook-migration`)
    *   **Authorization Rules:** Limit authorization approvals with custom rules. (`/issuing/controls/authorization-rules`)
    *   **Fraud Challenges:** Implement additional verification steps for high-risk authorizations. (`/issuing/controls/fraud-challenges`)
    *   **3D Secure:** Understand cardholder authentication using 3D Secure. (`/issuing/3d-secure`)
    *   **Token Management:** Manage network tokens for secure payments. (`/issuing/controls/token-management`)
    *   **Issuing Watchlist:** Understand automatic screening against sanctions lists. (`/issuing/issuing-watchlist`)

*   **Transaction Management:**
    *   **Authorizations:** Handle authorization requests for card purchases. (`/issuing/purchases/authorizations`)
    *   **Transactions:** Understand the lifecycle of transactions after authorization. (`/issuing/purchases/transactions`)
    *   **Disputes:** Learn how to dispute transactions. (`/issuing/purchases/disputes`)
    *   **ATM Usage:** Enable and manage ATM cash withdrawals. (`/issuing/purchases/atm-usage`)
    *   **Enriched Merchant Data:** Use detailed merchant data for fraud prevention and controls. (`/issuing/purchases/enriched-merchant-data`)

*   **Stripe Connect Integration:**
    *   **Set up Issuing and Connect:** Integrate Stripe Issuing with Stripe Connect for issuing cards to third parties. (`/issuing/connect`)
    *   **Connected Accounts, Cardholders, and Cards:** Manage cardholders and cards within a Connect integration. (`/issuing/connect/cardholders-and-cards`)
    *   **Funding:** Fund Issuing balances for connected accounts. (`/issuing/connect/funding`)
    *   **Terms of Service Acceptance:** Update Issuing terms of service acceptance for connected accounts. (`/issuing/connect/tos_acceptance`)
    *   **Inactive Account Management:** Understand how inactivity affects connected accounts' Issuing capabilities. (`/issuing/connect/inactive-accounts-management`)
    *   **Embedded Components:** Embed Issuing card management into your website. (`/issuing/connect/embedded-components`)

*   **Consumer Issuing:**
    *   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards to users. (`/issuing/consumer-prepaid-debit-cards`)
    *   **Credit Consumer Issuing:** Learn about the consumer credit solution for launching credit programs. (`/issuing/consumer-issuing`, `/issuing/credit/manage-account-obligations/available-credit`, `/issuing/credit/manage-account-obligations`, `/issuing/credit/manage-account-obligations/obligation-payments`, `/issuing/credit/manage-account-obligations/obligations-transactions-adjustments`, `/issuing/credit/manage-credit-terms`, `/issuing/credit/report-credit-decisions-and-manage-aans`, `/issuing/credit/report-required-regulatory-data-for-credit-decisions`, `/issuing/credit/test-credit`, `/issuing/credit`, `/issuing/credit/connect-credit-setup`)

*   **Issuing for Specific Use Cases:**
    *   **Issuing for your business:** Programmatically create virtual cards for business purchases. (`/issuing/direct`)
    *   **Issuing for agents:** Provide programmable cards with built-in controls for agents. (`/issuing/agents`)

*   **Compliance and Guidelines:**
    *   **US Guidelines:** Product marketing, design, and compliance guidelines for Issuing and Treasury in the US. (`/issuing/compliance-us`, `/issuing/compliance-us/issuing-regulated-customer-notices`)
    *   **Europe/UK Marketing:** Marketing guidelines for Issuing programs in the UK and Europe. (`/issuing/marketing-guidance-europe-uk`)

*   **Stripe Treasury for Platforms Integration:**
    *   **Treasury for Platforms Overview:** Understand how to provide financial services to connected accounts. (`/treasury/connect`)
    *   **Getting Started:** Access API access and understand eligibility. (`/treasury/connect/access`, `/treasury/connect/requirements`)
    *   **Account Management:** Learn about account structures, connected accounts, and financial accounts. (`/treasury/connect/account-management/accounts-structure`, `/treasury/connect/account-management/connected-accounts`, `/treasury/connect/account-management/financial-accounts`, `/treasury/connect/account-management/financial-account-features`, `/treasury/connect/account-management/platform-financial-account`, `/treasury/connect/account-management/issuing-cards`, `/treasury/connect/account-management/supportability`)
    *   **Moving Money:** Comprehensive guides on moving money in and out of financial accounts, including ACH handling, transfers, payments, and payouts. (`/treasury/connect/moving-money/moving-money-into-financial-accounts`, `/treasury/connect/moving-money/into/inbound-transfers`, `/treasury/connect/moving-money/into/received-credits`, `/treasury/connect/moving-money/out`, `/treasury/connect/moving-money/out-of/outbound-payments`, `/treasury/connect/moving-money/out-of/outbound-transfers`, `/treasury/connect/moving-money/out-of/received-debits`, `/treasury/connect/moving-money/out-of/debit-reversals`, `/treasury/connect/moving-money/working-with-bankaccount-objects`, `/treasury/connect/moving-money/noc-sec-handling`, `/treasury/connect/moving-money/payouts`)
    *   **Timelines:** Understand the timelines for various money movement operations. (`/treasury/connect/money-movement/timelines`)
    *   **Sample Integrations and Apps:** Utilize sample applications and guides for setting up financial accounts, moving money, and onboarding users. (`/treasury/connect/examples/financial-accounts`, `/treasury/connect/examples/moving-money`, `/treasury/connect/examples/onboarding-guide`, `/treasury/connect/examples/fraud-guide`, `/treasury/connect/examples/sample-app`, `/treasury/connect/examples/webhooks`)
    *   **Marketing and Compliance:** Guidelines for marketing Treasury for platforms and handling complaints. (`/treasury/connect/compliance`, `/treasury/connect/handling-complaints`, `/treasury/connect/marketing-financial-accounts`, `/treasury/connect/moving-money/regulatory-receipts`)
    *   **Bank Partners:** Information on integrating with Fifth Third Bank. (`/treasury/connect/fifth-third`, `/treasury/connect/fifth-third-get-started`)

*   **Stablecoin-Backed Cards:**
    *   **Overview:** Issue prepaid or debit cards backed by stablecoin balances. (`/issuing/stablecoin-cards`)
    *   **Financial Accounts:** Stablecoin-backed cards for Stripe Stablecoin Financial Accounts. (`/issuing/stablecoin-cards-for-financial-accounts`)
    *   **Third-Party Wallets:** Integrate with Bridge, Privy, or other third-party wallets. (`/issuing/bridge-stablecoin-cards`)
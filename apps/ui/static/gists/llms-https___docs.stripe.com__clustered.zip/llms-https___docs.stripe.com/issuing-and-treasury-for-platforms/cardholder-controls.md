### Cardholder Controls for Stripe Issuing and Connect

This section outlines how to manage cardholder controls within your Stripe Issuing and Connect integration, ensuring compliance with legal and regulatory guidelines.

#### Key Concepts:

*   **Cardholder Screening:** Stripe is required to screen cardholder information in accordance with legal and regulatory guidelines. Your integration must handle potential errors arising from this screening process.
*   **Updated Cardholder Controls:** As of October 31, 2024, Stripe requires street addresses for all cardholders and has expanded the list of disallowed cardholder names. These validation requirements apply to both new cardholders and updates to existing ones.
*   **Cardholder Under Review:** In cases where a cardholder is flagged for review, certain actions may be restricted. For instance, you cannot update the name of a cardholder currently under review. Stripe will manage the review process and update the cardholder's status accordingly.

#### Handling Cardholder Errors:

When submitting new cardholder information or updating existing cardholders, you may encounter errors related to:

*   **First Name, Last Name:** Disallowed names or formatting issues.
*   **Date of Birth:** Invalid or missing date of birth.
*   **Billing Address:** Incomplete or invalid street address.

Your integration should be prepared to handle these errors gracefully and provide appropriate feedback to the user.

#### Error Codes and Messages:

When a cardholder is under review, you might receive specific error codes and messages. For example, you may be prevented from updating a cardholder's name if they are currently undergoing a review process.

#### Compliance and Best Practices:

*   Ensure your onboarding process collects accurate and complete cardholder information.
*   Implement logic to handle and display Stripe's error messages to users effectively.
*   Stay updated on Stripe's evolving cardholder validation requirements.
*   For detailed information on specific error codes and their resolutions, refer to the Stripe API documentation for cardholder management.
```markdown
# Stripe Issuing Marketing Guidelines for the UK and Europe

This document outlines the marketing guidelines for promoting Stripe Issuing products and services in the United Kingdom and European countries. These guidelines are crucial for ensuring compliance with financial regulations and maintaining clear, accurate communication with customers.

**Note:** These guidelines apply specifically when marketing Stripe's Issuing product and services. If you are using Stripe Issuing solely for your own business expenses and not to facilitate services for your customers, these marketing guidelines do not apply.

## Key Principles

*   **Regulatory Compliance:** All marketing materials and user interfaces must adhere to the financial regulations governing the messaging used to describe Stripe Issuing.
*   **Clear and Accurate Terminology:** Use precise language to describe the product and its features, avoiding terms that could be misinterpreted or draw regulatory scrutiny.
*   **Customer Communication:** Ensure that customer communications are transparent and comply with all applicable laws.

## Specific Guidelines

### Marketing Messaging

When promoting Stripe Issuing, it is important to use recommended terms and avoid those that could be problematic.

**Recommended Terms:**

*   Money management, or money management account or solution
*   Cash management, or cash management account or solution
*   [Your brand] account
*   Financial services
*   Financial account
*   Financial product
*   Financial service product
*   Store of funds
*   Wallet or open loop wallet
*   Stored-value account
*   Open-Loop stored-value account
*   Prepaid access account
*   Eligible for FDIC “pass-through” insurance (if applicable)
*   Funds held at [Partner Bank], Member FDIC (if applicable)

**Terms to Avoid:**

Avoid terms such as "banking," "banks," and "bank accounts" unless your entity is a state- or federally-chartered bank or credit union. Using these terms inaccurately can attract regulatory attention.

### User Interfaces and Advertising

Your user interfaces and advertising must clearly and accurately represent Stripe Issuing. This includes:

*   **Product Descriptions:** Provide clear descriptions of the features and benefits of Stripe Issuing.
*   **Branding:** Ensure that your branding is consistent and does not misrepresent the nature of the financial services offered.
*   **Disclosures:** Include all necessary terms, conditions, and disclosures as required by regulations.

### Customer Communications

Stripe Issuing platforms are required to send customer communications upon certain trigger events to comply with applicable laws.

*   **Regulated Customer Notices:** Stripe can assist in sending these notices automatically through a no-code solution, ensuring compliance.
*   **Preview and Test Emails:** You can preview and customize email templates to ensure your branding and email addresses are correctly configured.

### Legal Disclaimer

The information provided in these guidelines is for informational purposes only and does not constitute legal advice. Consult with your own legal counsel for advice regarding product branding and the use of Stripe products to offer financial services.

---

**Last Updated:** June 1, 2022
```
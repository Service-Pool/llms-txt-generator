## Stripe Issuing and Treasury for Platforms

This documentation outlines how to leverage Stripe's Issuing and Treasury for Platforms products to build and manage card programs and financial services for your business and your customers.

### Core Concepts

*   **Stripe Issuing:** Enables you to programmatically create, manage, and distribute payment cards (physical and virtual) for your business, employees, contractors, or agents. It offers robust controls for spending limits, fraud management, and real-time authorization decisions.
*   **Stripe Treasury for Platforms:** Provides a suite of APIs for Stripe Connect platforms to embed financial services into your product. This includes enabling connected accounts to hold funds, pay bills, earn cash back, and manage their cash flow through financial accounts.
*   **Stripe Connect:** The foundational infrastructure that allows platforms to manage funds flows and compliance requirements for their users (connected accounts). Issuing and Treasury for Platforms integrate with Connect to extend these capabilities to your customers.

### Key Features and Functionality

*   **Card Issuance:**
    *   **Virtual and Physical Cards:** Issue both virtual and physical cards with customizable designs and branding.
    *   **Cardholder Management:** Create and manage individual or company cardholders.
    *   **Digital Wallets:** Support for adding cards to digital wallets like Apple Pay and Google Pay.
    *   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers.
    *   **Replacement Cards:** Handle expired, damaged, lost, or stolen card replacements.
*   **Funding and Money Movement:**
    *   **Issuing Balance:** Fund your Issuing balance from external bank accounts or your Stripe acquiring balance.
    *   **Treasury Financial Accounts:** Enable connected accounts to hold funds, manage balances, and facilitate money movement (inbound and outbound transfers, payouts).
    *   **Stablecoin-backed Cards:** Issue cards backed by stablecoin balances for global reach.
    *   **Post-funding:** Accrue a negative Issuing balance on card spend and post-fund Stripe later, offering flexibility in capital management.
*   **Controls and Fraud Management:**
    *   **Spending Controls:** Set rules to limit card transactions by merchant category, country, merchant ID, or spending limits.
    *   **Real-time Authorizations:** Approve or decline authorization requests in real-time via webhooks.
    *   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud.
    *   **3D Secure:** Implement an additional layer of authentication for online transactions.
    *   **Fraud Challenges:** Allow cardholders to verify high-risk transactions via SMS.
    *   **Issuing Watchlist:** Automatic screening against sanctions lists for compliance.
*   **Integration and Customization:**
    *   **Integration Guides:** Specific guides for B2B Payments, Embedded Finance, and Fleet management.
    *   **Processor-Only Integration:** Manage your Issuing program including regulatory requirements, compliance, and licensing.
    *   **Customizable Card Programs:** Design your own card program with custom BINs, account ranges, and card artwork.
    *   **Embedded Components:** Use prebuilt UI components to embed Issuing card management into your website.
    *   **Sample App:** A Next.js sample app to help you get started with Issuing and Treasury for Platforms.
*   **Credit Solutions:**
    *   **Credit Consumer Issuing:** Launch a credit program for your consumers with BIN sponsorship.
    *   **Manage Credit Terms:** Configure credit limits and terms for connected accounts.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
*   **Compliance and Guidelines:**
    *   **Product Marketing, Design, and Compliance Guidelines:** Adhere to regulations for offering financial services.
    *   **Marketing Guidance (Europe/UK & US):** Specific guidelines for marketing Issuing programs in different regions.
    *   **Customer Communications:** Understand requirements for sending regulated customer notices.
    *   **Onboarding Overview:** Guides for getting your integration live, including use case approval and live mode access.
    *   **Cardholder Controls:** Ensure compliance with legal and regulatory guidelines for cardholder information.
    *   **Inactive Connected Accounts Offboarding:** Understand how inactivity impacts Issuing capabilities.

### Getting Started

*   **Sign Up:** Create a Stripe account.
*   **Activate in Sandbox:** Activate Issuing and Treasury for Platforms in a sandbox environment to test your integration.
*   **Read Integration Guides:** Explore specific guides relevant to your use case (e.g., B2B Payments, Embedded Finance).
*   **Utilize Sample App:** Refer to the Issuing and Treasury for Platforms sample app for practical examples.
*   **Consult Documentation:** Refer to the comprehensive documentation for detailed information on each feature and API.

This collection of documentation provides a comprehensive resource for developers and businesses looking to implement Stripe Issuing and Treasury for Platforms, enabling them to offer sophisticated financial services to their users.
This documentation section covers Stripe Issuing and Treasury for platforms, focusing on how to integrate these services to create and manage financial accounts and payment cards for your users.

Here's a breakdown of the key topics:

**Core Concepts and Getting Started:**

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing and how it can be used to create and distribute payment cards for your business.
*   **Treasury for Platforms Overview:** Learn how to offer financial services to your connected accounts by embedding financial services into your product.
*   **How Issuing Works:** Dive deeper into the mechanics of building and scaling a payment card program with Stripe Issuing.
*   **How Treasury for Platforms Works:** Understand the modular components for building financial services, including account creation, storing funds, moving money, and attaching payment cards.
*   **Get Started with API Access (Treasury for Platforms):** Learn how to test Treasury for Platforms in a sandbox environment before going live.
*   **Onboarding Overview:** Understand the steps required to develop and launch an Issuing or Treasury for platforms integration.
*   **Sample App:** Explore the Issuing and Treasury for platforms sample app to see how to onboard customers, issue cards, and make outbound payments.

**Issuing Specifics:**

*   **Choose Card Offering:** Decide between physical or virtual cards for your cardholders.
*   **Virtual Cards:** Learn how to create and display virtual card details.
*   **Physical Cards:** Understand how to issue physical cards, including customization options.
    *   **Artwork Templates:** Guidelines for creating card designs.
    *   **Customize Card Bundle:** Options for standard and custom physical card bundles.
    *   **Choose Your Physical Bundle:** Details on standard and custom bundle options.
    *   **Create a Design:** Steps to create and name your card design.
    *   **Issue Cards:** How to create physical cards for cardholders.
    *   **Ship Cards:** Options for individual and bulk card shipping.
    *   **Address Validation:** Ensuring accurate addresses for physical card delivery.
*   **Add Funds to Your Card Program:** Learn about different funding options for your Issuing balance.
*   **Issuing Balance:** Understand how to make funds available for your cards.
*   **Manage Fraud:** Discover how to combat transaction fraud using Stripe Issuing's controls and tools.
*   **Controls:** Explore various controls to manage card usage and prevent fraud.
    *   **Spending Controls:** Set rules for merchant categories, countries, and spending limits.
    *   **Lifecycle Controls:** Automatically cancel virtual cards after a specified number of payments.
    *   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud.
    *   **3D Secure:** Implement an additional layer of authentication for online transactions.
    *   **Fraud Challenges:** Allow cardholders to verify suspicious transactions.
    *   **Real-time Authorizations:** Approve or decline authorization requests in real time via webhooks.
    *   **PIN Management:** Enable cardholders to manage their personal identification numbers.
*   **Issuing Merchant Categories:** Understand how businesses are categorized and how to use these categories for spending controls.
*   **Issuing Authorizations:** Learn how to handle authorization requests for card purchases.
*   **Issuing Transactions:** Understand how authorizations become transactions and how they affect balances.
*   **Issuing Disputes:** Learn how to dispute transactions and the process involved.
*   **Enriched Merchant Data:** Utilize comprehensive merchant data for fraud prevention and insights.
*   **Replacement Cards:** How to replace expired, damaged, lost, or stolen cards.
*   **Use Digital Wallets with Issuing:** Integrate cards with digital wallets like Apple Pay and Google Pay.
*   **Token Management:** Manage network tokens for secure payments.
*   **Use Cards at ATMs:** Enable and manage ATM cash withdrawals.
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.
*   **Issuing Watchlist:** Understand automatic screening against sanctions lists.
*   **Issuing Beta Migration Guide:** Instructions for migrating from the Issuing beta.
*   **Customer Support for Issuing and Treasury for Platforms:** Find resources for resolving common Issuing and Treasury issues.

**Stripe Connect Integration for Issuing and Treasury:**

*   **Set up an Issuing and Connect Integration:** Learn how to issue cards on connected accounts.
*   **Connected Accounts, Cardholders, and Cards:** Understand how to create and manage cardholders and cards with Stripe Connect.
*   **Cardholder Controls:** Ensure your integration complies with legal and regulatory guidelines for cardholder information.
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity can affect connected accounts' Issuing capabilities.
*   **Embed Issuing Card Management:** Use prebuilt UI components to embed card management functionality into your website.
*   **Fund Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing.
*   **Update Issuing Terms of Service Acceptance:** Present accurate business information for connected accounts and accept terms.
*   **B2B Payments Integration Guide:** Build a B2B payments integration using Stripe Issuing.
*   **Embedded Finance Integration Guide:** Create an embedded financial services integration with Issuing and Treasury for platforms.
*   **Fleet Integration Guide:** Build a fleet financial services integration with Issuing.

**Treasury for Platforms Specifics:**

*   **Accounts Structure:** Understand the different account types within Treasury for platforms.
*   **Working with Connected Accounts:** Request the treasury capability and collect onboarding requirements.
*   **Working with Financial Accounts:** Use financial accounts to store, send, and receive funds.
*   **Financial Account Features:** Learn about features available for financial accounts.
*   **Platform Financial Accounts:** Understand the financial account automatically provisioned for your platform.
*   **Working with Balances and Transactions:** Learn about financial account balances and how transactions affect them.
*   **Moving Money:** Explore various methods for moving money within Treasury for platforms.
    *   **Payouts and Top-ups from Payments Balance:** Move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for platforms.
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated.
    *   **Moving Money into Financial Accounts:** Add money to your financial account using InboundTransfer and ReceivedCredit objects.
    *   **Moving Money Out of Treasury for Platforms:** Learn how to move funds from financial accounts to other accounts.
    *   **Moving Money using CreditReversal objects:** Reverse received credits.
    *   **Moving Money using InboundTransfer objects:** Transfer money from external accounts into financial accounts.
    *   **Moving Money using ReceivedCredit objects:** Move money into a financial account from another account.
    *   **Moving Money using DebitReversal objects:** Retrieve funds taken from a financial account.
    *   **Moving Money using OutboundPayment objects:** Create outbound payments to third parties.
    *   **Moving Money using OutboundTransfer objects:** Transfer money out of financial accounts to external accounts.
    *   **Moving Money using ReceivedDebit objects:** Learn how external account holders can pull funds.
*   **Money Movement Timelines:** Understand the timelines for various types of money movement.
*   **Integrate with Fifth Third Bank:** Add Fifth Third Bank to your existing Treasury for platforms integration.
*   **Build a New Treasury for Platforms Integration with Fifth Third Bank:** Get started with Treasury for platforms using Fifth Third Bank.
*   **Treasury for Platforms Requirements:** Understand the compliance requirements and restrictions for using Treasury for platforms.
*   **Treasury for Platforms Fraud Guide:** Learn best practices for managing fraud as a platform.
*   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines:** Ensure your Treasury for platforms program and marketing campaigns are compliant.
*   **Handling Complaints:** Learn how to properly handle complaints about Treasury for platforms or Stripe Issuing.
*   **Marketing Treasury for Platforms:** Create precise messaging for your users that complies with regulations.
*   **Regulatory Receipts:** Learn about hosted transaction receipts.
*   **Use Treasury for Platforms to Move Money:** Explore basic money movement using Treasury endpoints.
*   **Treasury for Platforms Connected Account Onboarding Guide:** Implement a Treasury for platforms onboarding process for your connected accounts.

**Credit Specifics:**

*   **Issuing Credit:** Apply your platform's Issuing account balance to cards issued to connected accounts.
*   **Credit Consumer Issuing:** Learn about the Stripe consumer credit solution.
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for your connected accounts.
*   **Available Credit and Flow of Funds:** Understand how funds flow and use the available credit amount.
*   **Obligation Payments:** Make payments to your FundingObligation.
*   **Obligation Amounts, Transactions, and Adjustments:** View details about a FundingObligation and make adjustments.
*   **Manage Credit Terms:** Update credit terms for connected accounts.
*   **Report Other Credit Decisions and Manage Adverse Action Notices:** Record application and decision details and send adverse action notices.
*   **Report Required Regulatory Data for Credit Decisions:** Report required regulatory data for credit decisions if your platform is subject to additional reporting.
*   **Test Credit Integration:** Validate your automated platform funding in testing environments.

**Compliance and Guidelines:**

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US):** Navigate financial regulations for product branding and offering financial services.
*   **Issuing Regulated Customer Notices:** Understand sending regulatory notifications to your customers.
*   **Stripe Issuing Marketing Guidelines (Europe/UK):** Learn about marketing guidelines for Issuing programs in the UK and Europe.
```markdown
## Post-funding with Dynamic Reserves

This section details how to use dynamic reserves to post-fund card spend, enabling platforms to adjust their own credit limits in real-time to manage cash flow between Stripe and available authorization funds.

**Key Benefits:**

*   **Control Capital Usage:** Minimize funding costs by optimizing capital allocation.
*   **Manage Authorization Availability:** Control limits that determine when authorizations can be approved.
*   **Handle Unexpected Volatility:** Utilize Stripe to manage unforeseen fluctuations in cash flow.

**How it Works:**

Connected accounts can accrue a negative Issuing balance on card spend and post-fund Stripe at a later time. This means you can fund your Issuing balance *after* card authorizations are captured by the network (typically one day after the authorization is created), rather than pre-funding your balance before any card spend occurs. Each day, Stripe will notify you of the amount owed, and you can send a same-day wire to fund Stripe before the specified deadline to avoid late fees and additional penalties.

**Accessing Dynamic Reserves:**

This API is currently in beta. To access the Dynamic Reserves APIs, you must include the following header in all API requests:

`Stripe-Version: <your stripe version>;issuing_credit_beta=v2;`

**Connect Platforms:**

If you are post-funding a Connect Platform, your Connected Account's balance will be affected.

**Note:** This feature is in beta, and field names or high-level concepts may change in future releases.
```
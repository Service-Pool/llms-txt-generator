## Stripe Issuing and Treasury for Platforms

This documentation set provides comprehensive guidance on utilizing Stripe's Issuing and Treasury for Platforms products. These products empower platforms to offer financial services, including card issuance and money management, to their connected accounts.

### Key Areas Covered:

*   **Issuing:** This section details how to create, manage, and distribute payment cards for businesses, employees, or agents. It covers various card types (physical and virtual), customization options, funding mechanisms, fraud management, and integration with digital wallets.
*   **Treasury for Platforms:** This section focuses on enabling platforms to provide financial services to their connected accounts. It explains how to set up financial accounts, manage money movement (inbound and outbound transfers, payouts), and integrate with banking partners like Fifth Third Bank.
*   **Connect Integration:** A significant portion of the documentation addresses how to integrate Issuing and Treasury for Platforms with Stripe Connect. This includes managing connected accounts, cardholders, funding flows, and compliance requirements for multi-account structures.
*   **Core Functionality:** The documentation delves into essential aspects like onboarding users, managing fraud, compliance guidelines, API access, and testing integrations.
*   **Specific Use Cases:** Guidance is provided for specialized scenarios such as B2B payments, fleet management, embedded finance, consumer prepaid cards, and stablecoin-backed cards.
*   **Credit Offerings:** Information on setting up and managing credit programs for connected accounts, including credit terms, obligations, and reporting.

### Core Concepts:

*   **Issuing:** Enables the creation and management of custom payment cards.
*   **Treasury for Platforms:** Provides APIs for platforms to offer financial accounts and money movement capabilities to their users.
*   **Stripe Connect:** The foundation for managing multiple accounts (platform and connected accounts) within the Stripe ecosystem.
*   **Financial Accounts:** Dedicated accounts within Treasury for Platforms that hold funds and can be linked to payment cards.
*   **Cardholders:** Individuals or entities authorized to use issued cards.
*   **Connected Accounts:** User accounts managed by the platform through Stripe Connect, which can be provisioned with financial services.

### Getting Started:

The documentation provides clear pathways for new users, including:

*   **Integration Guides:** Step-by-step instructions for specific use cases like B2B payments, embedded finance, and fleet management.
*   **Sample App:** A practical example to help developers understand how to implement Issuing and Treasury for Platforms.
*   **Sandbox Environment:** Guidance on testing integrations before going live.

This documentation suite is essential for platforms looking to leverage Stripe's Issuing and Treasury for Platforms to build robust financial services for their users.
# Stripe Issuing and Treasury for Platforms

This documentation group provides comprehensive guidance on integrating Stripe Issuing and Treasury for platforms. It covers everything from initial setup and core functionalities to advanced features, Connect integrations, and specific use cases.

## Core Concepts and Getting Started

*   **Issuing Overview** (`/issuing`): Provides a general introduction to Stripe Issuing, its capabilities, and how to get started.
*   **How Issuing Works** (`/issuing/how-issuing-works`): Explains the fundamental mechanics of Stripe Issuing, including partnerships with banks and card networks.
*   **Treasury for Platforms Overview** (`/treasury/connect`): Introduces Treasury for platforms as a suite of APIs for embedding financial services into your product.
*   **Get Started with API Access to Treasury for Platforms** (`/treasury/connect/access`): Guides users on obtaining API access and setting up sandbox environments.
*   **Onboarding Overview** (`/issuing/onboarding-overview`): Details the process of getting your Issuing or Treasury for platforms integration live, including use case approval and live mode access.
*   **Issuing Beta Migration Guide** (`/issuing/migration-from-beta`): Provides instructions for migrating from the Issuing beta to the generally available version.
*   **Customer Support for Issuing and Treasury for Platforms** (`/issuing/customer-support`): Offers guidance and example resolutions for common support issues.
*   **Issuing Watchlist** (`/issuing/issuing-watchlist`): Explains Stripe's automatic screening against sanctions lists and the manual review process.

## Integration Guides and Use Cases

*   **Integration Guides** (`/issuing/integration-guides`): A central hub for various integration guides.
*   **Embedded Finance Integration Guide** (`/issuing/integration-guides/embedded-finance`): Focuses on building embedded financial services with Issuing and Treasury for platforms.
*   **B2B Payments Integration Guide** (`/issuing/integration-guides/b2b-payments`): Guides on building B2B payment solutions using Stripe Issuing.
*   **Fleet Integration Guide** (`/issuing/integration-guides/fleet`): Details on creating fleet management solutions with Stripe Issuing.
*   **Issuing for Your Business** (`/issuing/direct`): How to issue cards programmatically for your own business needs.
*   **Issuing for Agents** (`/issuing/agents`): Enables programmable cards with built-in controls for agents in agentic commerce workflows.
*   **Consumer Prepaid Debit Cards** (`/issuing/consumer-prepaid-debit-cards`): Information on issuing prepaid debit cards for users to receive and spend money.
*   **Credit Consumer Issuing** (`/issuing/credit` and `/issuing/credit-consumer-issuing`): Details on launching a credit program for your customers (US only, private preview).
*   **Stablecoin-Backed Cards** (`/issuing/stablecoin-cards`): Information on issuing prepaid or debit cards backed by stablecoin balances.
    *   **Stablecoin-backed cards for Stripe Stablecoin Financial Accounts** (`/issuing/stablecoin-cards-for-financial-accounts`)
    *   **Stablecoin-backed cards for Bridge, Privy, or third-party wallets** (`/issuing/bridge-stablecoin-cards`)
*   **Use Stripe Issuing in Different Countries** (`/issuing/global`): Explains global issuing options, including local and cross-border issuing.

## Card Management and Customization

*   **Choose Which Type of Card to Issue** (`/issuing/choose-cards`): Helps decide between physical and virtual cards.
*   **Virtual Cards with Issuing** (`/issuing/cards/virtual`): An overview of virtual card capabilities.
    *   **Create Virtual Cards** (`/issuing/cards/virtual/issue-cards`): Steps to create virtual cards.
*   **Physical Cards** (`/issuing/cards/physical`): Information on issuing physical cards.
    *   **Choose Card Bundle** (`/issuing/cards/physical/choose-bundle`): Options for standard or custom physical bundles.
    *   **Order a Custom Bundle** (`/issuing/cards/physical/order-custom-bundle`): Process for ordering custom physical card bundles.
    *   **Customize Card Bundle** (`/issuing/cards/physical/card-bundle-selections`): Details on making selections for card bundles.
    *   **Artwork Templates** (`/issuing/cards/artwork-templates`): Design templates for cards, carriers, and envelopes.
    *   **Create a Design** (`/issuing/cards/physical/create-design`): Steps to create and name your card design.
    *   **Issue Cards** (`/issuing/cards/physical/issue-cards`): How to create physical cards for cardholders.
    *   **Ship Cards** (`/issuing/cards/physical/ship-cards`): Options for shipping cards (individual and bulk).
    *   **Address Validation** (`/issuing/cards/physical/address-validation`): Enabling and managing address validation for physical cards.
*   **Replacement Cards** (`/issuing/cards/replacements`): How to replace expired, damaged, lost, or stolen cards.
*   **PIN Management** (`/issuing/cards/pin-management`): Managing PINs for cardholders.
*   **Use Digital Wallets with Issuing** (`/issuing/cards/digital-wallets`): Integrating Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **Customize Your Card Program** (`/issuing/customize-your-program`): How to tailor your Stripe Issuing card program.
*   **Program Management** (`/issuing/program-management`): Choosing between Stripe program management and processor-only models.
*   **Integrate Processor-Only Issuing** (`/issuing/processor-only-integration-guide`): Setting up a processor-only Issuing integration.
*   **Processor-Only Issuing** (`/issuing/processor-only-issuing`): Managing your Issuing program with the processor-only model.

## Funding and Balances

*   **Fund Your Issuing Balance** (`/issuing/funding/balance`): How to make funds available for card spend.
*   **Add Funds to Your Card Program** (`/issuing/adding-funds-to-your-card-program`): Options for funding your Issuing balance.
*   **Postfund your integration with Stripe** (`/issuing/funding/post-fund`): Learn how to accrue a negative Issuing balance and postfund Stripe later.
*   **Post-fund your integration with Dynamic Reserves** (`/issuing/funding/post-fund-with-dynamic-reserves`): Using dynamic reserves to post-fund card spend.
*   **Connect Funding** (`/issuing/connect/funding`): How to fund connected accounts for Issuing.

## Controls and Fraud Management

*   **Manage Fraud with Stripe Issuing Controls and Tools** (`/issuing/manage-fraud`): Understanding and combating transaction fraud.
*   **Issuing Controls** (various pages under `/issuing/controls`):
    *   **Spending Controls** (`/issuing/controls/spending-controls`): Setting rules on cards and cardholders to control spending.
    *   **Lifecycle Controls** (`/issuing/controls/lifecycle-controls`): Automatically canceling virtual cards after a specified number of payments.
    *   **Advanced Fraud Tools** (`/issuing/controls/advanced-fraud-tools`): Using API signals and tooling to identify and prevent transaction fraud.
    *   **3D Secure** (`/issuing/3d-secure`): Cardholder authentication using 3D Secure for online transactions.
    *   **Fraud Challenges** (`/issuing/controls/fraud-challenges`): Additional verification for authorizations.
    *   **Real-time Authorizations** (`/issuing/controls/real-time-authorizations`): Approving or declining authorization requests in real time via webhooks.
        *   **Quickstart** (`/issuing/controls/real-time-authorizations/quickstart`)
        *   **Migrate to Direct Webhook Response** (`/issuing/controls/real-time-authorizations/direct-webhook-migration`)
    *   **Issuing Authorization Rules** (`/issuing/controls/authorization-rules`): Limiting authorization approvals using custom rules.
    *   **Token Management** (`/issuing/controls/token-management`): Managing network tokens on your cards.

## Stripe Connect Integrations

*   **Set Up an Issuing and Connect Integration** (`/issuing/connect`): Foundational infrastructure for managing funds flow and compliance in Connect integrations.
*   **Connected Accounts, Cardholders, and Cards** (`/issuing/connect/cardholders-and-cards`): Creating and managing cardholders and cards with Stripe Connect.
*   **Cardholder Controls** (`/issuing/connect/cardholders-controls`): Handling cardholder screening and compliance.
*   **Inactive Connected Accounts Offboarding** (`/issuing/connect/inactive-accounts-management`): How inactivity affects connected accounts' Issuing capabilities.
*   **Embed Issuing Card Management into Your Website** (`/issuing/connect/embedded-components`): Using prebuilt UI components for card management.
*   **Update the Issuing Terms of Service Acceptance** (`/issuing/connect/tos_acceptance`): Presenting business information and accepting terms of service for connected accounts.

## Treasury for Platforms Specifics

*   **Treasury for Platforms Requirements** (`/treasury/connect/requirements`): Compliance requirements and restrictions for using Treasury for platforms.
*   **Accounts Structure** (`/treasury/connect/account-management/accounts-structure`): Understanding the different account types in Treasury for platforms.
*   **Working with Connected Accounts** (`/treasury/connect/account-management/connected-accounts`): Requesting capabilities and collecting onboarding requirements.
*   **Working with Financial Accounts** (`/treasury/connect/account-management/financial-accounts`): Using financial accounts to store, send, and receive funds.
*   **Financial Account Features** (`/treasury/connect/account-management/financial-account-features`): Features available for financial accounts.
*   **Platform Financial Accounts** (`/treasury/connect/account-management/platform-financial-account`): Information about the financial account provisioned for your platform.
*   **Working with Balances and Transactions** (`/treasury/connect/account-management/working-with-balances-and-transactions`): Understanding financial account balances and transaction effects.
*   **Working with Stripe Issuing Cards** (`/treasury/connect/account-management/issuing-cards`): Integrating Stripe Issuing with Treasury for platforms.
*   **Money Movement** (various pages under `/treasury/connect/moving-money`):
    *   **Moving Money into Financial Accounts** (`/treasury/connect/moving-money/moving-money-into-financial-accounts`)
    *   **Moving Money Out of Treasury for Platforms** (`/treasury/connect/moving-money/moving-money-out`)
    *   **Money Movement Timelines** (`/treasury/connect/money-movement/timelines`): Timelines for various money movement types.
    *   **Payouts and Top-ups from Payments Balance** (`/treasury/connect/moving-money/payouts`)
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts** (`/treasury/connect/moving-money/working-with-bankaccount-objects`)
    *   **ACH NOC and SEC Handling** (`/treasury/connect/moving-money/noc-sec-handling`)
    *   **Moving Money Using InboundTransfer Objects** (`/treasury/connect/moving-money/into/inbound-transfers`)
    *   **Moving Money Using ReceivedCredit Objects** (`/treasury/connect/moving-money/into/received-credits`)
    *   **Moving Money Using CreditReversal Objects** (`/treasury/connect/moving-money/into/credit-reversals`)
    *   **Moving Money Using OutboundTransfer Objects** (`/treasury/connect/moving-money/out-of/outbound-transfers`)
    *   **Moving Money Using OutboundPayment Objects** (`/treasury/connect/moving-money/out-of/outbound-payments`)
    *   **Moving Money Using ReceivedDebit Objects** (`/treasury/connect/moving-money/out-of/received-debits`)
    *   **Moving Money Using DebitReversal Objects** (`/treasury/connect/moving-money/out-of/debit-reversals`)
*   **Sample Integrations** (various pages under `/treasury/connect/examples`):
    *   **Issuing and Treasury for Platforms Sample App** (`/treasury/connect/examples/sample-app`): A Next.js sample app for Issuing and Treasury for platforms.
    *   **Use Treasury for Platforms to Move Money** (`/treasury/connect/examples/moving-money`): Example of basic money movement using Treasury endpoints.
    *   **Use Treasury for Platforms and Issuing to Set Up Financial Accounts and Cards** (`/treasury/connect/examples/financial-accounts`): A sample integration for setting up financial accounts and cards.
    *   **Treasury for Platforms Connected Account Onboarding Guide** (`/treasury/connect/examples/onboarding-guide`): Implementing an onboarding process for connected accounts.
    *   **Treasury for Platforms Fraud Guide** (`/treasury/connect/examples/fraud-guide`): Best practices for managing fraud.
    *   **Webhooks for Stripe Issuing and Treasury for Platforms** (`/treasury/connect/examples/webhooks`): Understanding webhook events.
*   **Marketing and Compliance Guidelines** (`/treasury/connect/compliance`): Guidelines for compliant marketing and user interfaces.
*   **Handling Complaints** (`/treasury/connect/handling-complaints`): How to properly handle complaints related to Treasury for platforms or Issuing.
*   **Marketing Treasury for Platforms** (`/treasury/connect/marketing-financial-accounts`): Creating compliant messaging for your users.
*   **Regulatory Receipts** (`/treasury/connect/moving-money/regulatory-receipts`): Information on hosted transaction receipts.
*   **Integrate with Fifth Third Bank** (`/treasury/connect/fifth-third`): Integrating with Fifth Third Bank as a new partner.
*   **Build a New Treasury for Platforms Integration with Fifth Third Bank** (`/treasury/connect/fifth-third-get-started`): Getting started with Treasury for platforms using Fifth Third Bank.
*   **How Treasury for Platforms Works** (`/treasury/connect/how-financial-accounts-for-platforms-works`): Understanding connected accounts, financial accounts, and money movement.

## Transactions and Purchases

*   **Issuing Authorizations** (`/issuing/purchases/authorizations`): Handling authorization requests.
*   **Issuing Transactions** (`/issuing/purchases/transactions`): How transactions are created after authorization capture.
*   **Issuing Disputes** (`/issuing/purchases/disputes`): Submitting and monitoring transaction disputes.
*   **Enriched Merchant Data** (`/issuing/purchases/enriched-merchant-data`): Using comprehensive merchant data for fraud prevention and insights.
*   **Issuing Merchant Categories** (`/issuing/categories`): Understanding Merchant Category Codes (MCCs) for spending controls.
*   **Use Cards at Automated Teller Machines (ATMs)** (`/issuing/purchases/atm-usage`): Enabling and using US-issued cards for ATM cash withdrawals.

## Testing and Development

*   **Test Your Issuing Integration** (`/issuing/testing`): Simulating purchases and testing your integration in a sandbox environment.
*   **Test Credit Integration** (`/issuing/credit/test-credit`): Validating your automated platform funding in testing environments.
*   **Issuing and Treasury for Platforms Sample App** (`/issuing/sample-app`): A sample app to demonstrate Issuing and Treasury for platforms APIs.

## Compliance and Guidelines

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US)** (`/issuing/compliance-us`): Guidelines for launching and maintaining compliant Issuing and Treasury programs in the US.
*   **Issuing Regulated Customer Notices** (`/issuing/compliance-us/issuing-regulated-customer-notices`): Sending regulatory notifications to customers.
*   **Stripe Issuing Marketing Guidelines (UK and Europe)** (`/issuing/marketing-guidance-europe-uk`): Marketing guidelines for Issuing programs in the UK and Europe.

## Advanced Topics

*   **Issuing Credit** (`/issuing/credit`): Overview of the private preview credit APIs.
*   **Manage Account Obligations** (`/issuing/credit/manage-account-obligations`): Tracking credit spend, lifecycle, and balances for connected accounts.
    *   **Available Credit and Flow of Funds** (`/issuing/credit/manage-account-obligations/available-credit`)
    *   **Obligation Payments** (`/issuing/credit/manage-account-obligations/obligation-payments`)
    *   **Obligation Amounts, Transactions, and Adjustments** (`/issuing/credit/manage-account-obligations/obligations-transactions-adjustments`)
*   **Manage Credit Terms** (`/issuing/credit/manage-credit-terms`): Updating credit limits and terms for connected accounts.
*   **Report Other Credit Decisions and Manage Adverse Action Notices** (`/issuing/credit/report-credit-decisions-and-manage-aans`): Recording credit decisions and sending adverse action notices.
*   **Report Required Regulatory Data for Credit Decisions** (`/issuing/credit/report-required-regulatory-data-for-credit-decisions`): Reporting regulatory data for credit programs.
*   **Using Issuing Elements** (`/issuing/elements`): Displaying sensitive Issuing card data in a PCI-compliant way.
## Issuing Authorization Rules

Issuing rules help you prevent unauthorized activity by blocking authorizations that match custom conditions. For example, you can block card transactions outside of your geography, above a certain amount, or where certain fraud signals are present. You can access Issuing rules in the Rules tab in your Issuing Dashboard after enabling advanced fraud tools.

You can configure Issuing rules to decline, then follow up with an SMS sent to the cardholder to confirm it was them who was making the transaction. The cardholder can retry the transaction if they confirm the SMS prompt. These rules can prevent fraud losses by confirming the legitimate use of a card. Learn more about fraud challenges.

**Note:** In addition to Issuing rules that you configure, Stripe enforces a number of default behaviors to prevent fraud.

### Generate Default Rules

When you first log in to Issuing rules, you can generate a set of rules tailored to your use case by answering some questions. You can delete or disable any of these generated rules, the same as rules that you create. To answer the questions later, click Remind me later.

### Create a Rule

To create a rule, open the Rules tab in your Issuing Dashboard and complete the following steps:

1.  Select + New rule.
2.  If you’re a Connect platform, you can specify the connected accounts to apply the rule to. If you don’t define an audience, the rule applies to all of your connected accounts.
3.  Give the rule a descriptive name.
4.  Select the action for the rule. The action `Block` declines an authorization when the rule condition is met, and the action `Block and` sends an SMS to the cardholder to confirm the transaction.
5.  Select the conditions for the rule. You can add multiple conditions to a rule.
6.  Click Create rule.
## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite covers Stripe's Issuing and Treasury for Platforms products, providing comprehensive guides for developers and businesses looking to integrate and manage card programs and financial services.

### Core Concepts and Getting Started

*   **Issuing Overview**: Understand the fundamentals of Stripe Issuing, how it works, and its capabilities for creating, managing, and distributing payment cards.
*   **Treasury for Platforms Overview**: Learn how to embed financial services into your platform, enabling connected accounts to hold funds, pay bills, and manage cash flow.
*   **Integration Guides**:
    *   **Embedded Finance Integration Guide**: Build an integrated financial services offering.
    *   **B2B Payments Integration Guide**: Create cards for business purchases.
    *   **Fleet Integration Guide**: Build a fleet financial services integration.
*   **Onboarding Overview**: Understand the steps required to take your Issuing or Treasury for Platforms integration live, including use case approval and live mode access.
*   **Customer Support**: Find information and resolutions for common Issuing and Treasury for Platforms questions.

### Issuing Card Management

*   **Choosing Card Types**: Decide between physical and virtual cards for your cardholders.
    *   **Virtual Cards**: Learn about creating and managing virtual cards.
    *   **Physical Cards**: Details on issuing and managing physical cards.
*   **Issuing Cards**:
    *   **Create Physical Cards**: Guides for issuing standard and custom physical cards.
    *   **Issue Cards**: Create cardholders and issue cards through the Dashboard or API.
    *   **Create Virtual Cards**: Steps to issue virtual cards using the Dashboard or API.
*   **Card Customization**:
    *   **Customize Your Card Program**: Tailor your Issuing card program to business needs.
    *   **Artwork Templates**: Utilize provided design templates for cards, carriers, and envelopes.
    *   **Customize Card Bundle**: Make selections for your physical card bundle.
    *   **Choose Your Physical Bundle**: Set up standard or custom physical bundles.
*   **Cardholder Management**:
    *   **Choose a Cardholder Type**: Select the appropriate cardholder type (individual or company).
    *   **Cardholder Controls**: Understand how cardholder information screening impacts your integration.
*   **PIN Management**: Allow cardholders to manage their personal identification numbers.
*   **Replacement Cards**: Learn how to replace expired, damaged, lost, or stolen cards.
*   **Digital Wallets**: Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
*   **Token Management**: Manage network tokens for cards, enhancing payment security.

### Funding and Balances

*   **Issuing Balance**: Learn how to make funds available for your cards.
*   **Add Funds to Your Card Program**: Explore options for funding your Issuing balance.
    *   **Post-fund Your Integration with Stripe**: Accrue a negative Issuing balance and post-fund later.
    *   **Post-fund Your Integration with Dynamic Reserves**: Use dynamic reserves to post-fund card spend.

### Transactions and Authorizations

*   **Issuing Authorizations**: Handle authorization requests in real-time.
    *   **Issuing Real-Time Authorizations**: Approve or decline authorization requests synchronously.
    *   **Migrate to Direct Webhook Response**: Transition from deprecated API calls to direct webhook responses for authorizations.
    *   **Issuing Authorization Rules**: Limit authorization approvals using custom rules.
*   **Issuing Transactions**: Understand how authorizations become transactions.
*   **Issuing Disputes**: Learn how to dispute transactions and monitor their resolution.
*   **ATM Usage**: Enable and use US-issued cards for ATM cash withdrawals.
*   **Enriched Merchant Data**: Utilize comprehensive merchant data for fraud prevention and insights.

### Fraud Management and Controls

*   **Manage Fraud**: Understand transaction fraud risks and how to combat them with Stripe Issuing tools.
*   **Advanced Fraud Tools**: Identify and prevent transaction fraud using API signals and tooling.
*   **3D Secure**: Implement an additional layer of authentication for online transactions.
*   **Fraud Challenges**: Turn on additional verification for high-risk authorizations.
*   **Spending Controls**: Set rules on cards and cardholders to control spending by category, country, or amount.
*   **Lifecycle Controls**: Control automatic usage-based cancellation of virtual cards.

### Stripe Connect Integrations

*   **Set Up an Issuing and Connect Integration**: Issue cards on connected accounts for third parties.
*   **Connected Accounts, Cardholders, and Cards**: Create and manage cardholders and cards with Stripe Connect.
*   **Cardholder Controls**: Understand how Stripe screens cardholder information for compliance.
*   **Inactive Connected Accounts Offboarding**: Learn how inactivity affects Issuing capabilities on connected accounts.
*   **Embed Issuing Card Management**: Use prebuilt UI components to embed card management into your website.
*   **Fund Issuing Balances with Connect**: Learn how to fund connected accounts for Issuing.

### Treasury for Platforms Integrations

*   **Treasury for Platforms Overview**: A suite of APIs for Stripe Connect platforms to embed financial services.
*   **Get Started with API Access**: Test Treasury for Platforms functionality in a sandbox environment.
*   **Account Management**:
    *   **Accounts Structure**: Understand the interaction of account components in Treasury for Platforms.
    *   **Working with Connected Accounts**: Request treasury capabilities and collect onboarding requirements.
    *   **Working with Financial Accounts**: Use financial accounts to store, send, and receive funds.
    *   **Financial Account Features**: Learn about features available for financial accounts.
    *   **Platform Financial Accounts**: Understand the financial account provisioned for your platform.
*   **Working with Cards**: Integrate Stripe Issuing with Treasury for Platforms.
*   **Money Movement**:
    *   **Moving Money into Financial Accounts**: Add money using InboundTransfer and ReceivedCredit objects.
    *   **Moving Money Out of Treasury for Platforms**: Transfer funds using various methods like OutboundPayment and OutboundTransfer.
    *   **Money Movement Timelines**: Understand the timelines for various money movement types.
    *   **Payouts and Top-ups from Payments Balance**: Move money between payments and financial account balances.
    *   **Working with SetupIntents, PaymentMethods, and BankAccounts**: Set up money movements with Treasury for Platforms.
    *   **ACH NOC and SEC Handling**: Learn how external account information is updated.
    *   **Moving Money Using CreditReversal Objects**: Return funds from received credits.
    *   **Moving Money Using InboundTransfer Objects**: Transfer money from external accounts into financial accounts.
    *   **Moving Money Using ReceivedCredit Objects**: Move money into financial accounts from other accounts.
    *   **Moving Money Using DebitReversal Objects**: Retrieve funds taken from a financial account.
    *   **Moving Money Using OutboundPayment Objects**: Create outbound payments to third parties.
    *   **Moving Money Using OutboundTransfer Objects**: Transfer money out of financial accounts to external accounts.
    *   **Moving Money Using ReceivedDebit Objects**: Observe funds pulled from a financial account.
*   **Sample Integrations**:
    *   **Sample App**: Use the Next.js sample app for Issuing and Treasury for Platforms.
    *   **Set Up Financial Accounts and Cards**: Follow a sample integration to set up financial accounts and cards.
    *   **Using Treasury for Platforms to Move Money**: Learn basic money movement using treasury endpoints.
    *   **Treasury for Platforms Connected Account Onboarding Guide**: Implement an onboarding process for connected accounts.
    *   **Treasury for Platforms Fraud Guide**: Best practices for managing fraud as a platform.
*   **Compliance and Marketing**:
    *   **Marketing and Compliance Guidelines**: Keep your Treasury for Platforms program and marketing compliant.
    *   **Handling Complaints**: Properly handle complaints related to Treasury for Platforms or Issuing.
    *   **Marketing Treasury for Platforms**: Create compliant messaging for your users.
    *   **Regulatory Receipts**: Learn about hosted transaction receipts.
*   **Bank Partners**:
    *   **Integrate with Fifth Third Bank**: Add Fifth Third Bank to your Treasury for Platforms integration.
    *   **Build a New Treasury for Platforms Integration with Fifth Third Bank**: Get started with Treasury for Platforms using Fifth Third Bank.

### Credit Products

*   **Issuing Credit Overview**: Apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts.
*   **Credit Consumer Issuing**: Launch a credit program for your consumers.
*   **Manage Account Obligations**: Track credit spend, lifecycle, and balances for connected accounts.
    *   **Obligation Amounts, Transactions, and Adjustments**: View FundingObligation details and make adjustments.
    *   **Obligation Payments**: Make payments to your FundingObligation.
    *   **Available Credit and Flow of Funds**: Understand fund flow and available credit.
*   **Manage Credit Terms**: Update credit limits and terms for connected accounts.
*   **Report Other Credit Decisions and Manage Adverse Action Notices**: Record credit decisions and send adverse action notices.
*   **Report Required Regulatory Data for Credit Decisions**: Report regulatory data for credit decisions if your platform is subject to additional reporting.
*   **Test Credit Integration**: Validate your automated platform funding in testing environments.

### Global Availability and Compliance

*   **Use Stripe Issuing in Different Countries**: Explore integration options for issuing cards globally.
*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US)**: Launch and maintain compliant Issuing and Treasury programs.
*   **Issuing Regulated Customer Notices**: Understand sending regulatory notifications to customers.
*   **Stripe Issuing Marketing Guidelines (Europe/UK)**: Adhere to marketing guidelines for Issuing programs in the UK and Europe.
*   **Issuing Watchlist**: Understand the Issuing watchlist process and best practices for sanctions screening.
*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines**: Navigate financial regulations for offering Stripe products.

### Testing and Development

*   **Test Your Issuing Integration**: Issue cards and simulate purchases in a sandbox environment.
*   **Test Your Integration (Credit)**: Validate your credit integration in testing environments.
*   **Sample App**: Utilize the Issuing and Treasury for Platforms sample app for development.

### Other Resources

*   **Issuing for Agents**: Provide programmable cards with built-in controls for agents.
*   **Issuing Beta Migration Guide**: Migrate from the Issuing beta to the generally available version.
*   **Customer Support for Issuing and Treasury for Platforms**: Resolve common issues and questions.
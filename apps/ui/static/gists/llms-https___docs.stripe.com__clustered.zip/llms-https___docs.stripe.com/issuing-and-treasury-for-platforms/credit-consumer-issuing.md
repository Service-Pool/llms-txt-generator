```json
{
  "title": "Credit Consumer Issuing",
  "description": "Learn about the Stripe consumer credit solution to launch a credit program for your customers.",
  "path": "/issuing/consumer-issuing",
  "content": [
    {
      "type": "heading",
      "level": 1,
      "text": "Credit Consumer Issuing"
    },
    {
      "type": "paragraph",
      "text": "Private preview"
    },
    {
      "type": "paragraph",
      "text": "Learn about the Stripe consumer credit solution to launch a credit program for your customers."
    },
    {
      "type": "heading",
      "level": 2,
      "text": "Install skills"
    },
    {
      "type": "paragraph",
      "text": "Private preview"
    },
    {
      "type": "paragraph",
      "text": "Credit Consumer Issuing is currently in private preview and only available in the United States (US). To join the waitlist, submit your email."
    },
    {
      "type": "paragraph",
      "text": "Stripe provides the components to create, launch, and run a bank-sponsored credit program. Use Credit Consumer Issuing to:"
    },
    {
      "type": "list",
      "items": [
        "Onboard consumer accounts",
        "Issue bank-sponsored credit cards (both physical and virtual)",
        "Manage your credit program without needing your own sponsor bank or bank charter",
        "Move money between Stripe, your platform, and your consumers",
        "Customize how your consumers earn rewards"
      ]
    },
    {
      "type": "paragraph",
      "text": "Credit Consumer Issuing also automatically maintains a credit ledger to track customer payments, responds to disputes on behalf of the consumer, and reports to the Credit Bureau. To"
    }
  ]
}
```
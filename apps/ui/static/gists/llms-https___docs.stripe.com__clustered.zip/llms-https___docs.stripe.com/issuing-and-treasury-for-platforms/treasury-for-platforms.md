# Stripe Issuing and Treasury for Platforms

This documentation suite focuses on Stripe's Issuing and Treasury for Platforms products, providing comprehensive guides for developers and businesses looking to integrate and manage card programs and financial services.

The content covers a wide range of topics, from the fundamental workings of Stripe Issuing and Treasury for Platforms to advanced integration strategies, fraud management, and compliance. It details how to create and manage virtual and physical cards, fund Issuing balances, customize card programs, and leverage advanced fraud tools. For Treasury for Platforms, the documentation explains account structures, money movement capabilities, and how to embed financial services into your platform.

Key areas explored include:

*   **Issuing Core Functionality:** Understanding how Stripe Issuing works, choosing card types (virtual/physical), funding balances, and managing card programs.
*   **Integration Guides:** Specific guides for integrating Issuing for B2B payments, fleet management, and embedded finance.
*   **Card Management:** Detailed instructions on creating, issuing, and managing physical and virtual cards, including customization, artwork, and shipping.
*   **Controls and Fraud Prevention:** Implementing spending controls, lifecycle controls, real-time authorizations, 3D Secure, and advanced fraud tools to mitigate risks.
*   **Stripe Connect Integration:** Guidance on setting up Issuing and Connect integrations, managing connected accounts, cardholders, and cards, and handling funding with Connect.
*   **Treasury for Platforms:** An overview of Treasury for Platforms, eligibility requirements, API access, account structures, financial account features, and money movement capabilities (inbound/outbound transfers, payments, payouts).
*   **Compliance and Guidelines:** Information on product marketing, design, and compliance guidelines for both Issuing and Treasury for Platforms, including regulated customer notices and marketing best practices.
*   **Testing and Support:** Resources for testing integrations in sandbox environments, migrating from beta versions, and accessing customer support.
*   **Credit Functionality:** Details on Issuing Credit, managing account obligations, credit terms, and reporting credit decisions.
*   **Stablecoin-backed Cards:** Information on issuing cards backed by stablecoin balances for various wallet integrations.

This documentation aims to equip users with the knowledge and tools necessary to build robust and compliant financial products using Stripe's Issuing and Treasury for Platforms solutions.
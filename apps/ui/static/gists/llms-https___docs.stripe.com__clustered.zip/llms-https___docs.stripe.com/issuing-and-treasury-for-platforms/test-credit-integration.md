## Testing Your Stripe Issuing and Treasury for Platforms Integrations

This section of the documentation provides guidance on how to effectively test your Stripe Issuing and Treasury for platforms integrations. It covers the use of sandbox environments, simulating transactions, and validating your credit integration setup.

### Testing Issuing Integrations

Stripe Issuing allows you to test your integration thoroughly in a sandbox environment before going live. This enables you to simulate card issuance, purchases, and other core functionalities without using real funds.

*   **Sandbox Environment:** Utilize Stripe's sandbox environment to issue test cards and simulate purchases. These test cards are only valid within your Stripe account and cannot be used for external transactions.
*   **Test Issuing Balance:** Before simulating transactions, ensure you have added test funds to your Issuing balance. These funds are not real and are solely for testing purposes.
*   **Authorization Endpoint Testing:** When testing your authorization endpoint, ensure it is correctly configured in your Issuing settings. Test data can be viewed by switching to your sandbox environment.

### Testing Treasury for Platforms Integrations

Stripe Treasury for platforms also offers robust testing capabilities, allowing you to experiment with its features in a sandbox environment.

*   **Sandbox Environment:** Activate Issuing and Treasury for platforms in a sandbox environment through the Stripe Dashboard. This allows you to test functionality without impacting your live account.
*   **Test Access:** Obtain test access to Treasury for platforms and Issuing by enabling these capabilities on connected accounts within your sandbox environment.
*   **Sample Application:** Utilize the provided Issuing and Treasury for platforms sample application to experience a full integration flow, including onboarding, card creation, and transaction simulation.

### Testing Credit Integrations

For integrations involving credit functionalities, Stripe provides tools to validate your setup in testing environments.

*   **Sandbox Environment:** Test your credit integration using the Credit API within a sandbox environment. Follow the same steps as in live mode, including creating connected accounts, requesting capabilities, and updating credit policies.
*   **Credit API Testing:** Consider the following when testing the Credit API:
    *   **Minute Interval Support:** In testing environments, you can set the `credit_period_interval` to `minute` to generate Funding Obligations more frequently, streamlining your testing process.
    *   **Simulate Issuing Transactions:** Use the Dashboard or Issuing API in testing environments to simulate Issuing spend and disputes. Funding Obligation updates occur asynchronously.

By leveraging these testing resources, you can build and deploy your Stripe Issuing and Treasury for platforms solutions with confidence.
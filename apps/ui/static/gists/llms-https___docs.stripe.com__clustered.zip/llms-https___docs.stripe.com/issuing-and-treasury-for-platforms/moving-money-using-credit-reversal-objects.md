## Stripe Issuing and Treasury for Platforms: Building Embedded Financial Services

This documentation group focuses on Stripe's Issuing and Treasury for Platforms products, providing comprehensive guidance for developers and businesses looking to embed financial services into their own applications. It covers everything from initial setup and integration to advanced features like fraud management, credit programs, and international expansion.

### Key Areas Covered:

*   **Getting Started with Issuing:**
    *   Understanding how Stripe Issuing works and its core functionalities.
    *   Guides for specific use cases like B2B Payments, Fleet management, and Embedded Finance.
    *   Onboarding processes and requirements for launching an Issuing program.
    *   Utilizing the Issuing sample app for practical implementation.
*   **Card Management:**
    *   Creating and managing both virtual and physical cards.
    *   Customizing card programs, including design templates and bundle selections.
    *   Handling card replacements and PIN management.
    *   Integrating with digital wallets like Apple Pay and Google Pay.
*   **Funding and Money Movement:**
    *   Managing the Issuing balance and adding funds to card programs.
    *   Post-funding options with Stripe and Dynamic Reserves.
    *   Understanding fund flows and available credit for credit programs.
    *   Detailed guides on moving money into and out of financial accounts using Treasury for Platforms, including ACH, wires, and Stripe network transfers.
*   **Credit Programs:**
    *   Setting up and managing credit programs for consumers and connected accounts.
    *   Understanding credit terms, obligations, and available credit.
    *   Reporting credit decisions and managing adverse action notices.
*   **Connect Integrations:**
    *   Setting up and managing Issuing and Connect integrations for platforms.
    *   Handling connected accounts, cardholders, and cards within a Connect ecosystem.
    *   Embedding Issuing card management into your website using Connect components.
    *   Managing inactive connected accounts.
    *   Funding Issuing balances with Connect.
*   **Fraud Management and Controls:**
    *   Implementing advanced fraud tools and real-time authorization rules.
    *   Utilizing fraud challenges and 3D Secure for enhanced security.
    *   Managing spending controls and lifecycle controls for cards.
    *   Understanding token management for secure payments.
*   **Compliance and Guidelines:**
    *   Navigating product marketing, design, and compliance guidelines for Issuing and Treasury for Platforms in the US, Europe, and UK.
    *   Issuing regulated customer notices and handling complaints.
    *   Understanding regulatory receipts and ACH NOC/SEC handling.
*   **Testing and Migration:**
    *   Testing Issuing and Treasury for Platforms integrations in sandbox environments.
    *   Guides for migrating from Issuing beta versions.
*   **Treasury for Platforms Specifics:**
    *   Understanding the accounts structure and features of Treasury for Platforms.
    *   Working with financial accounts for platforms and connected accounts.
    *   Integrating with banking partners like Fifth Third Bank.
    *   Marketing Treasury for Platforms and its associated financial accounts.

This collection of documentation provides a robust resource for businesses aiming to leverage Stripe's Issuing and Treasury for Platforms to build sophisticated, embedded financial experiences for their users.
## Stripe Issuing and Treasury for Platforms

This documentation group provides comprehensive guidance on integrating Stripe Issuing and Treasury for Platforms. It covers everything from initial setup and card creation to advanced features like fraud management, credit programs, and international use.

### Key Areas Covered:

*   **Getting Started:**
    *   **Onboarding Overview:** Understand the steps required to launch your Issuing or Treasury for Platforms integration.
    *   **Integration Guides:** Specific guides for B2B Payments, Embedded Finance, and Fleet management.
    *   **Sample App:** A practical example to help you understand API usage for onboarding, card creation, and payments.
    *   **Customer Support:** Resources for resolving common Issuing and Treasury for Platforms issues.
    *   **Compliance Guidelines:** Essential information for marketing, design, and ensuring compliance with regulations in the US, Europe, and UK.

*   **Issuing Cards:**
    *   **Card Types:** Learn about the differences and use cases for virtual and physical cards.
    *   **Card Program Customization:** Customize your card program, including BIN setup and artwork templates.
    *   **Physical Card Management:** Details on ordering custom bundles, creating designs, issuing, shipping, and address validation.
    *   **Virtual Card Management:** How to create and display virtual card details.
    *   **Digital Wallets:** Integrating Issuing cards with Apple Pay and Google Pay.
    *   **PIN Management:** Allowing cardholders to manage their PINs.
    *   **Replacement Cards:** Procedures for replacing expired, damaged, lost, or stolen cards.

*   **Funding and Balances:**
    *   **Issuing Balance:** How to fund your Issuing balance for card spend.
    *   **Adding Funds:** Options for funding your card program, including pull-funded top-ups, push-funded top-ups, and balance transfers.
    *   **Post-funding:** Learn about post-funding your integration with Stripe and Dynamic Reserves.

*   **Fraud Management and Controls:**
    *   **Manage Fraud:** Understand transaction fraud risks and how to combat them with Stripe's tools.
    *   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud.
    *   **Real-time Authorizations:** Approve or decline authorization requests in real-time using webhooks.
    *   **Authorization Rules:** Limit authorization approvals with custom rules.
    *   **Fraud Challenges:** Implement additional verification steps for high-risk authorizations.
    *   **Spending Controls:** Set rules for card and cardholder spending, including limits and blocked categories.
    *   **Lifecycle Controls:** Automatically cancel virtual cards after a specified number of payments.
    *   **Token Management:** Manage network tokens for secure payments.

*   **Stripe Connect Integration:**
    *   **Set up Issuing and Connect:** Integrate Issuing with Stripe Connect for issuing cards to third parties.
    *   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between these entities in a Connect integration.
    *   **Cardholder Controls:** Manage cardholder information in compliance with regulations.
    *   **Inactive Connected Accounts Offboarding:** Handling inactivity for Issuing capabilities.
    *   **Connect Funding:** Learn how to fund Issuing balances for connected accounts.
    *   **Embedded Components:** Embed Issuing card management into your website using prebuilt UI components.

*   **Credit Programs:**
    *   **Issuing Credit Overview:** Understand how to apply platform balances or exposure limits to connected accounts.
    *   **Credit Consumer Issuing:** Launch credit programs for your customers.
    *   **Manage Credit Terms:** Configure credit limits and intervals for connected accounts.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Reporting Credit Decisions:** Report credit decisions and manage adverse action notices.
    *   **Test Credit Integration:** Validate your credit integration in testing environments.

*   **Treasury for Platforms:**
    *   **Treasury for Platforms Overview:** Embed financial services into your product for connected accounts.
    *   **Account Management:** Understand the account structure, working with connected accounts, financial accounts, and platform financial accounts.
    *   **Financial Account Features:** Features for moving money, attaching payment cards, and more.
    *   **Money Movement:** Comprehensive guides on moving money into and out of financial accounts, including using InboundTransfers, OutboundPayments, OutboundTransfers, and handling ACH NOCs.
    *   **Payouts and Top-ups:** Moving money between payments balance and financial account balances.
    *   **Bank Partners:** Information on integrating with Fifth Third Bank.
    *   **Compliance and Marketing:** Guidelines for compliant marketing and operations.
    *   **Handling Complaints:** Procedures for managing customer complaints.

*   **Advanced Topics:**
    *   **Processor-Only Issuing:** Integrate as a processor for Issuing programs.
    *   **Issuing Merchant Categories:** Understand MCCs for spending controls.
    *   **Issuing for Agents:** Provide programmable cards with built-in controls for agents.
    *   **Global Availability:** Issuing cards in different countries, including local and cross-border options.
    *   **Stablecoin-Backed Cards:** Issuing cards backed by stablecoin balances.
    *   **ATM Usage:** Using Issuing cards at ATMs.
    *   **Issuing Authorizations and Transactions:** Handling authorization requests and captured transactions.
    *   **Issuing Disputes:** Managing disputes for transactions.
    *   **Enriched Merchant Data:** Utilizing comprehensive merchant data for fraud prevention.
    *   **Beta Migration:** Guide for migrating from the Issuing beta.
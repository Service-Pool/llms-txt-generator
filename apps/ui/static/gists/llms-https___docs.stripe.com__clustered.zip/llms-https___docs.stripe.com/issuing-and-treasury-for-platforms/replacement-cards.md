## Stripe Issuing and Treasury for Platforms

This documentation suite provides comprehensive guidance on utilizing Stripe's Issuing and Treasury for Platforms products. These powerful tools allow businesses to create and manage custom payment card programs, facilitate seamless money movement, and embed financial services directly into their own platforms.

### Key Features and Functionality:

*   **Card Issuance:**
    *   **Virtual and Physical Cards:** Create and manage both virtual and physical cards for your users or employees. (Pages 12, 26, 28, 33, 34)
    *   **Customization:** Design and customize card programs, including card artwork and bundle selections. (Pages 16, 22, 23, 24, 25, 27, 28)
    *   **Cardholder Management:** Understand how to create and manage cardholders, including different cardholder types. (Pages 36, 39, 70)
    *   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers (PINs). (Page 30)
    *   **Replacement Cards:** Learn how to handle expired, damaged, lost, or stolen cards. (Page 32)
    *   **Digital Wallets:** Integrate with digital wallets like Apple Pay and Google Pay. (Page 17)
    *   **Consumer Issuing:** Explore options for consumer prepaid debit cards and credit programs. (Pages 13, 14, 15)
    *   **Agent Issuing:** Issue programmable cards with built-in controls for agents. (Page 69)

*   **Money Movement and Treasury:**
    *   **Financial Accounts:** Set up and manage financial accounts for your platform and connected accounts. (Pages 86, 87, 89, 93, 100, 106)
    *   **Fund Management:** Understand how to fund Issuing balances and manage money movement within financial accounts. (Pages 11, 61, 63, 64, 101, 108, 109, 111, 112, 116, 118)
    *   **Treasury for Platforms:** Leverage Stripe's Treasury for Platforms to embed financial services for your connected accounts. (Pages 85, 94, 95, 120)
    *   **Credit Programs:** Explore options for setting up and managing credit programs for connected accounts. (Pages 51, 52, 53, 54, 55, 56, 57, 58, 59, 60)
    *   **Stablecoin-Backed Cards:** Issue cards backed by stablecoin balances. (Pages 81, 82, 83)

*   **Integration and Management:**
    *   **Integration Guides:** Find specific guides for integrating with B2B payments, embedded finance, and fleet management solutions. (Pages 2, 3, 4, 5)
    *   **Connect Integration:** Learn how to set up Issuing and Connect integrations for managing funds flows and compliance. (Pages 37, 38, 39, 40, 41, 62)
    *   **Onboarding:** Understand the onboarding process for launching your Issuing or Treasury integration. (Page 6)
    *   **Testing:** Utilize sandbox environments and testing tools to validate your integration. (Pages 84, 85)
    *   **Sample App:** Explore the Issuing and Treasury for Platforms sample app for practical examples. (Pages 7, 104)
    *   **Webhooks:** Learn about webhook events for Issuing and Treasury for Platforms. (Page 105)

*   **Fraud and Security:**
    *   **Fraud Management:** Discover tools and controls to manage and prevent transaction fraud. (Pages 20, 42, 43, 45)
    *   **Real-time Authorizations:** Implement real-time authorization decisions for your card transactions. (Pages 9, 44, 48)
    *   **3D Secure:** Understand cardholder authentication using 3D Secure. (Page 10)
    *   **Token Management:** Learn how to manage network tokens for secure payments. (Page 50)
    *   **Issuing Watchlist:** Understand the process for screening Issuing users against sanctions lists. (Page 74)

*   **Compliance and Guidelines:**
    *   **Product Marketing and Compliance:** Adhere to guidelines for marketing and launching compliant Issuing and Treasury programs. (Pages 71, 75, 96)
    *   **Customer Communications:** Learn about sending regulated customer notices. (Page 72)
    *   **Customer Support:** Find information on customer support for Issuing and Treasury for Platforms. (Page 1)

*   **Purchases and Transactions:**
    *   **Authorizations:** Understand how authorization requests are handled. (Page 77)
    *   **Transactions:** Learn about transaction objects and their lifecycle. (Page 80)
    *   **Disputes:** Discover how to manage and dispute transactions. (Page 78)
    *   **Merchant Categories:** Explore Issuing merchant categories for spending controls. (Page 35)
    *   **ATM Usage:** Understand how to use cards at ATMs. (Page 76)
    *   **Enriched Merchant Data:** Utilize comprehensive merchant data for fraud prevention and insights. (Page 79)

This documentation suite is designed to guide developers and businesses through the process of integrating and leveraging Stripe's Issuing and Treasury for Platforms products to build robust financial solutions.
## Stripe Issuing and Treasury for Platforms

This documentation set provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. These products empower platforms to offer financial services, including card issuance and money management, to their connected accounts.

### Key Features and Functionality

*   **Stripe Issuing:** Enables the creation, management, and distribution of payment cards for businesses, employees, and agents. This includes options for both physical and virtual cards, with extensive customization capabilities.
*   **Treasury for Platforms:** Provides a suite of APIs for Stripe Connect platforms to embed financial services into their products. This allows connected accounts to hold funds, pay bills, earn cash back, and manage their cash flow through financial accounts.
*   **Integration with Stripe Connect:** Both Issuing and Treasury for Platforms are designed to work seamlessly with Stripe Connect, allowing platforms to manage funds flow and compliance for their connected accounts.

### Core Concepts and Workflows

*   **Card Issuance:**
    *   **Card Types:** Supports virtual and physical cards, with detailed guides on choosing card types, creating designs, ordering custom bundles, and shipping.
    *   **Cardholder Management:** Covers the creation and management of cardholders, including individual and company types.
    *   **Funding:** Explains how to fund Issuing balances through various methods like pull-funded top-ups, push-funded top-ups, and Stripe balance transfers.
    *   **Controls:** Details how to implement spending controls, lifecycle controls, and advanced fraud tools to manage card usage and mitigate risk.
    *   **Real-time Authorizations:** Provides information on handling authorization requests in real-time via webhooks.
    *   **Fraud Management:** Offers guidance on managing fraud risks, including advanced fraud tools, 3D Secure authentication, and fraud challenges.
    *   **PIN Management:** Explains how cardholders can manage their personal identification numbers.
    *   **Replacement Cards:** Outlines the process for replacing expired, damaged, lost, or stolen cards.
    *   **Digital Wallets:** Describes how to integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **Processor-Only Integration:** Details how to set up and manage an Issuing program where the platform handles more of the operational aspects.
*   **Treasury for Platforms:**
    *   **Account Structure:** Explains the interaction between platform accounts and connected accounts within the Treasury for Platforms framework.
    *   **Financial Accounts:** Covers the creation and management of financial accounts for platforms and connected accounts, including their features and balances.
    *   **Money Movement:** Provides comprehensive guides on moving money into and out of financial accounts using various methods like Inbound Transfers, Outbound Payments, Outbound Transfers, and Payouts.
    *   **Compliance and Marketing:** Offers guidelines on marketing, design, and compliance requirements for Treasury for Platforms and Issuing integrations, including regulatory receipts and handling complaints.
    *   **Bank Partnerships:** Details integration with bank partners like Fifth Third Bank.
*   **Credit Features:**
    *   **Credit Consumer Issuing:** Explains how to create and manage credit programs for consumers.
    *   **Credit for Connected Accounts:** Covers setting up credit terms, managing account obligations, and available credit for connected accounts.
    *   **Stablecoin-Backed Cards:** Details how to issue cards backed by stablecoin balances, integrating with wallets like Bridge and Privy.

### Integration Guides and Resources

*   **Integration Guides:** Specific guides are available for B2B payments, Embedded Finance, and Fleet management use cases.
*   **Sample App:** A sample application is provided to demonstrate how to use Issuing and Treasury for Platforms APIs.
*   **Testing:** Comprehensive guides on testing Issuing and credit integrations in sandbox environments.
*   **Onboarding:** Information on the onboarding process for Issuing and Treasury for Platforms, including compliance requirements.
*   **Customer Support:** Guidance on customer support for Issuing and Treasury for Platforms.

This documentation set is intended for developers and businesses looking to leverage Stripe's Issuing and Treasury for Platforms to build innovative financial products and services.
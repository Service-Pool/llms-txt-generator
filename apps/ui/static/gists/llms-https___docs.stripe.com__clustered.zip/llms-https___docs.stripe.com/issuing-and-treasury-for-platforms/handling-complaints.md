## Handling Complaints with Stripe Treasury for Platforms

This section of the Stripe documentation provides guidance on how to properly handle customer complaints related to Stripe Treasury for Platforms and Stripe Issuing.

**Key Takeaways:**

*   **Definition of a Complaint:** Any expression of dissatisfaction with a product, service, policy, or employee related to Treasury for Platforms or Issuing, excluding those from your company's employees.
*   **Accessibility:** You must provide customers with an easily identifiable and accessible way to submit complaints. This should be placed near your customer support contact information or another obvious location.
*   **Responsibility:** While Stripe can offer guidance and support, you are ultimately responsible for resolving complaints.
*   **Timelines:** Stripe expects you to acknowledge all operational (standard) complaints within 5 business days and resolve them within 15 business days of submission.
*   **Record Keeping:** You must maintain records of all complaints and their resolutions in accordance with applicable laws. Upon request, you must provide Stripe with reasonable access to these records.

**Key Actions:**

*   Ensure clear and accessible complaint submission channels for your customers.
*   Establish internal processes for timely complaint acknowledgment and resolution.
*   Maintain comprehensive records of all complaint-related activities.
*   Be prepared to provide Stripe with access to complaint records upon request.
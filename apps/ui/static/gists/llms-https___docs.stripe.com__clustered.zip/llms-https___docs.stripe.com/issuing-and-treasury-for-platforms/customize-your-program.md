## Customize Your Card Program

Stripe Issuing offers extensive customization options to tailor your card program to your specific business needs. This section details how to configure various aspects of your card program, from BIN setup to advanced design elements.

### Bank Identification Number (BIN) Setup

A Bank Identification Number (BIN) is the initial set of digits on a card number that identifies the card network and the issuing bank. Stripe licenses a BIN for you when you create your card program. Typically, you will have one BIN per Issuing setup.

### Account Ranges

Account ranges are the digits immediately following the BIN on a card number. For 6-digit BINs, these are the seventh to ninth digits; for 8-digit BINs, they are the eleventh to thirteenth digits.

### Customization Options

Stripe Issuing allows you to customize your card program through various settings available in the Dashboard's Issuing section. This includes:

*   **Card Design:** Personalize your cards with your company logo and specific branding.
*   **Card Types:** Choose between physical and virtual cards to suit different use cases.
*   **Bundles:** Customize the physical card bundle, including the card, carrier, and envelope.
*   **Spending Controls:** Implement rules to manage how and where cards can be used, including setting spending limits and blocking specific merchant categories or countries.
*   **Lifecycle Controls:** Automate card cancellation based on usage, suitable for single-use or limited-use scenarios.
*   **Program Management:** Select between Stripe-managed programs or a processor-only model, each with different responsibilities for compliance and operations.

By leveraging these customization features, you can create a card program that precisely meets your business objectives and enhances the user experience for your cardholders.
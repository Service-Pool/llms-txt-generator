## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite provides comprehensive guidance on integrating and utilizing Stripe's Issuing and Treasury for Platforms products. It covers everything from initial setup and card program customization to advanced fraud management and money movement strategies.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing, how it works, and its capabilities for creating and managing payment cards. (Page 66, 67)
*   **Treasury for Platforms Overview:** Learn how to leverage Stripe Treasury for Platforms to embed financial services into your product, enabling connected accounts to hold funds, pay bills, and manage cash flow. (Page 120, 106)
*   **Integration Guides:** Access specific guides for common use cases:
    *   **Embedded Finance:** Build embedded financial services with Issuing and Treasury for Platforms. (Page 3, 5)
    *   **B2B Payments:** Create cards for business expenses using Stripe Issuing. (Page 2, 5)
    *   **Fleet:** Develop fleet management solutions with Stripe Issuing. (Page 4, 5)
*   **Onboarding Overview:** Navigate the process of getting your Issuing or Treasury for Platforms integration live, including use case approval and live mode access. (Page 6)
*   **Customer Support:** Find resources for resolving common Issuing and Treasury for Platforms questions. (Page 1)
*   **Sample App:** Utilize the Issuing and Treasury for Platforms sample app to understand API usage for onboarding, card creation, and payments. (Page 7, 104)
*   **Testing Your Integration:** Learn how to test your Issuing integration in a sandbox environment. (Page 84)
*   **API Access:** Get started with API access to Treasury for Platforms, including sandbox testing. (Page 85)

### Card Program Management

*   **Choosing Card Types:** Decide between physical and virtual cards for your cardholders. (Page 12, 33, 26, 34)
*   **Physical Cards:** Detailed information on issuing and managing physical cards, including custom bundles and artwork. (Page 28, 23, 24, 25, 27, 21, 29)
*   **Virtual Cards:** Understand how to create and display virtual card details securely. (Page 33, 34)
*   **Adding Funds:** Learn about the different methods for funding your Issuing balance. (Page 11, 61)
*   **Customizing Your Program:** Tailor your Stripe Issuing card program to meet specific business needs. (Page 16)
*   **Program Management Models:** Compare Stripe program management with processor-only options. (Page 31)
*   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers. (Page 30)
*   **Replacement Cards:** Understand the process for replacing expired, damaged, lost, or stolen cards. (Page 32)
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay. (Page 17)
*   **Artwork Templates:** Utilize provided templates for card design. (Page 22)

### Stripe Connect Integrations

*   **Setting up Issuing and Connect:** Integrate Stripe Issuing with Stripe Connect for issuing cards to third parties. (Page 41)
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and the cards issued to them. (Page 39)
*   **Funding Issuing Balances with Connect:** Learn how to fund the Issuing balances of connected accounts. (Page 40)
*   **Cardholder Controls:** Manage cardholder information in accordance with legal and regulatory guidelines. (Page 36)
*   **Inactive Connected Accounts:** Understand how inactivity affects connected accounts and their Issuing capabilities. (Page 38)
*   **Embedding Card Management:** Use prebuilt UI components to embed Issuing card management into your website. (Page 37)

### Treasury for Platforms Specifics

*   **Account Management:**
    *   **Accounts Structure:** Understand the different account types within Treasury for Platforms. (Page 86)
    *   **Working with Connected Accounts:** Request capabilities and manage onboarding for connected accounts. (Page 92)
    *   **Working with Financial Accounts:** Learn about the features and management of financial accounts. (Page 93, 87)
    *   **Platform Financial Accounts:** Understand the financial account provisioned for your platform. (Page 89)
*   **Moving Money:**
    *   **Timelines:** Understand the processing and cutoff times for various money movement methods. (Page 110)
    *   **Moving Money Into Financial Accounts:** Learn about InboundTransfers and ReceivedCredits. (Page 111, 108, 109)
    *   **Moving Money Out of Financial Accounts:** Explore OutboundPayments, OutboundTransfers, and ReceivedDebits. (Page 112, 115, 116, 117)
    *   **Payouts and Top-ups:** Manage money movement between payments and financial account balances. (Page 118)
    *   **ACH NOC and SEC Handling:** Learn how external account information is updated. (Page 113)
*   **Credit Features:**
    *   **Issuing Credit Overview:** Apply your platform's Issuing balance or exposure limit to connected account cards. (Page 53)
    *   **Credit Consumer Issuing:** Create and manage credit programs for your consumers. (Page 14, 15)
    *   **Managing Credit Terms:** Configure credit limits and intervals for connected accounts. (Page 55)
    *   **Managing Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts. (Page 54, 57, 56)
    *   **Available Credit and Flow of Funds:** Understand how transactions affect available credit. (Page 51)
    *   **Reporting Credit Decisions:** Record underwriting decisions and manage adverse action notices. (Page 58, 59)
    *   **Testing Credit Integrations:** Validate your automated platform funding in sandbox environments. (Page 60)
*   **Fifth Third Bank Integration:** Integrate with Fifth Third Bank for Treasury for Platforms. (Page 94, 95)
*   **Compliance and Marketing:**
    *   **Marketing and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant. (Page 96, 71, 75)
    *   **Handling Complaints:** Properly address complaints related to Treasury for Platforms or Issuing. (Page 97)
    *   **Regulatory Receipts:** Understand hosted transaction receipts for regulated transactions. (Page 99)
    *   **Marketing Treasury for Platforms:** Create compliant messaging for your users. (Page 98)

### Fraud Management and Controls

*   **Manage Fraud:** Understand transaction fraud risks and how to combat them with Stripe Issuing tools. (Page 20)
*   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud. (Page 42)
*   **Issuing Authorization Rules:** Limit authorization approvals with custom rules. (Page 43)
*   **Real-time Authorizations:** Approve or decline authorization requests in real time using webhooks. (Page 48, 9, 44)
*   **Fraud Challenges:** Implement additional verification for high-risk authorizations. (Page 45)
*   **3D Secure:** Learn about cardholder authentication using 3D Secure for online transactions. (Page 10)
*   **Spending Controls:** Set rules on cards and cardholders to control spending by category, country, or amount. (Page 49)
*   **Lifecycle Controls:** Automatically cancel virtual cards after a specified number of payments. (Page 47)
*   **Token Management:** Manage network tokens for secure payments. (Page 50)
*   **Issuing Watchlist:** Understand how Stripe screens users against sanctions lists. (Page 74)

### Purchases and Transactions

*   **Issuing Authorizations:** Handle authorization requests when a card is used for a purchase. (Page 77)
*   **Issuing Transactions:** Understand how authorizations become closed transactions. (Page 80)
*   **Issuing Disputes:** Learn how to dispute transactions and the process for resolution. (Page 78)
*   **ATM Usage:** Enable and use US-issued cards for ATM cash withdrawals. (Page 76)
*   **Enriched Merchant Data:** Utilize comprehensive merchant data for fraud prevention and spending analysis. (Page 79)

### Specific Use Cases and Features

*   **B2B Payments:** Build B2B payment integrations with Issuing. (Page 2)
*   **Embedded Finance:** Create embedded financial services with Issuing and Treasury for Platforms. (Page 3)
*   **Fleet:** Build fleet financial services integrations with Issuing. (Page 4)
*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for rewards, disbursements, or branded programs. (Page 13)
*   **Stablecoin-Backed Cards:** Issue cards backed by stablecoin balances in partnership with Bridge. (Page 81, 82, 83)
*   **Issuing for Agents:** Provide programmable cards with built-in controls for agents. (Page 69)
*   **Processor-Only Issuing:** Integrate Issuing where you manage regulatory requirements, compliance, and licensing. (Page 18, 19)
*   **Global Availability:** Understand how integration options vary by country for Stripe Issuing. (Page 65)
*   **Customer Support:** Resolve common Issuing and Treasury for Platforms questions. (Page 1)
*   **Compliance Guidelines (US):** Adhere to marketing, design, and compliance guidelines for Issuing and Treasury. (Page 71, 72)
*   **Marketing Guidelines (Europe/UK):** Follow marketing guidelines for Issuing programs in the UK and Europe. (Page 75)
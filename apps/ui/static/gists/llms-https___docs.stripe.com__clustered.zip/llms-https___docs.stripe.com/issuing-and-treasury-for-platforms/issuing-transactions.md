## Stripe Issuing: Transactions

This section details how to manage transactions within Stripe Issuing, covering the lifecycle from authorization to capture and the creation of `Transaction` objects.

### Understanding Transaction Objects

When an authorization request is approved and subsequently captured by the acquiring business, the authorization status is set to `closed`, and a `Transaction` object is created. This process typically occurs within 24 hours. However, for certain industries like hotels, airlines, and car rentals, the capture window can extend up to 31 days after the authorization is created.

Upon capture, two key events occur:

1.  **Authorization Closure**: The `closed` status is applied to the authorization, releasing the amount that was initially held. A `balance_transaction` of type `issuing_authorization_release` is generated to reflect this.
2.  **Transaction Object Creation**: A new `Transaction` object of type `capture` is created. This deducts the purchase amount from the balance designated for Issuing.

It's important to note that spending controls, real-time authorization controls, and the card's active status do not apply to captured transactions.
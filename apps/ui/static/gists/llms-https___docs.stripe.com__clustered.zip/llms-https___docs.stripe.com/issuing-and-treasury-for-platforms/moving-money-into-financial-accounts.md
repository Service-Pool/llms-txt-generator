## Stripe Issuing and Treasury for Platforms Documentation

This documentation suite provides comprehensive guidance on leveraging Stripe Issuing and Treasury for Platforms to build and manage card programs and financial services for your business and your customers. It covers everything from initial setup and integration to advanced features like fraud management, credit, and international expansion.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing and how it enables you to create, manage, and distribute payment cards. (**/issuing**)
*   **How Issuing Works:** Dive deeper into the mechanics of Stripe Issuing, including partnerships with banks and card networks. (**/issuing/how-issuing-works**)
*   **Treasury for Platforms Overview:** Learn how Treasury for Platforms allows you to embed financial services into your product, enabling connected accounts to hold funds, pay bills, and manage cash flow. (**/treasury/connect**)
*   **Treasury for Platforms Requirements:** Understand the compliance and operational requirements for using Treasury for Platforms. (**/treasury/connect/requirements**)
*   **Onboarding Overview:** Get a comprehensive guide to the onboarding process for launching your Issuing or Treasury for Platforms integration. (**/issuing/onboarding-overview**)
*   **Get Started with API Access to Treasury for Platforms:** Learn how to gain API access and set up sandbox environments for testing. (**/treasury/connect/access**)
*   **Integration Guides:** Explore specific integration guides for various use cases, including Embedded Finance, B2B Payments, and Fleet management. (**/issuing/integration-guides**)
*   **Issuing and Treasury for Platforms Sample App:** Utilize a sample application to understand how to onboard customers, issue cards, and make outbound payments. (**/issuing/sample-app**, **/treasury/connect/examples/sample-app**)
*   **Customer Support for Issuing and Treasury for Platforms:** Find resources and guidance for resolving common support issues. (**/issuing/customer-support**)

### Card Issuance and Management

*   **Choose Card Offering:** Decide between physical and virtual cards for your cardholders. (**/issuing/choose-cards**)
*   **Virtual Cards:** Learn how to create and manage virtual cards for immediate use. (**/issuing/cards/virtual**, **/issuing/cards/virtual/issue-cards**)
*   **Physical Cards:** Explore options for issuing physical cards, from standard to fully custom designs. (**/issuing/cards/physical**, **/issuing/cards/physical/issue-cards**)
    *   **Choose Card Bundle:** Select standard or custom physical card bundles. (**/issuing/cards/physical/card-bundle-selections**, **/issuing/cards/physical/choose-bundle**)
    *   **Create a Design:** Customize your card artwork and branding. (**/issuing/cards/physical/create-design**)
    *   **Artwork Templates:** Access design templates for card customization. (**/issuing/cards/artwork-templates**)
    *   **Order a Custom Bundle:** Learn the process for ordering uniquely designed physical card bundles. (**/issuing/cards/physical/order-custom-bundle**)
    *   **Address Validation:** Ensure successful delivery of physical cards with address normalization and validation. (**/issuing/cards/physical/address-validation**)
    *   **Ship Cards:** Understand the options for individual and bulk card shipping. (**/issuing/cards/physical/ship-cards**)
*   **Replacement Cards:** Manage the process of replacing expired, damaged, lost, or stolen cards. (**/issuing/cards/replacements**)
*   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers. (**/issuing/cards/pin-management**)
*   **Use Digital Wallets with Issuing:** Integrate cards with digital wallets like Apple Pay and Google Pay. (**/issuing/cards/digital-wallets**)
*   **Token Management:** Understand how to manage network tokens for enhanced security. (**/issuing/controls/token-management**)

### Funding and Balances

*   **Issuing Balance:** Learn how to make funds available for card spend by funding your Issuing balance. (**/issuing/funding/balance**)
*   **Add Funds to Your Card Program:** Explore various funding options, including pull-funded, push-funded, and balance transfers. (**/issuing/adding-funds-to-your-card-program**)
*   **Postfund Your Integration with Stripe:** Understand how to accrue a negative Issuing balance and postfund later. (**/issuing/funding/post-fund**)
*   **Post-fund Your Integration with Dynamic Reserves:** Utilize dynamic reserves to manage cash flow and minimize funding costs. (**/issuing/funding/post-fund-with-dynamic-reserves**)

### Stripe Connect Integrations

*   **Set Up an Issuing and Connect Integration:** Learn how to issue cards on connected accounts using Stripe Connect. (**/issuing/connect**)
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and issued cards. (**/issuing/connect/cardholders-and-cards**)
*   **Fund Issuing Balances with Connect:** Discover how to fund connected accounts for Issuing. (**/issuing/connect/funding**)
*   **Update the Issuing Terms of Service Acceptance:** Ensure compliance by presenting accurate business information and accepting terms. (**/issuing/connect/tos_acceptance**)
*   **Cardholder Controls:** Manage cardholder information and ensure compliance with legal and regulatory guidelines. (**/issuing/connect/cardholders-controls**)
*   **Inactive Connected Accounts Offboarding:** Understand how inactivity affects Issuing capabilities on connected accounts. (**/issuing/connect/inactive-accounts-management**)
*   **Embed Issuing Card Management into Your Website:** Utilize prebuilt UI components to embed card management functionality. (**/issuing/connect/embedded-components**)

### Treasury for Platforms Money Movement

*   **How Treasury for Platforms Works:** Gain a comprehensive understanding of connected accounts, financial accounts, and money movement. (**/treasury/connect/how-financial-accounts-for-platforms-works**)
*   **Accounts Structure:** Learn how platform and connected accounts interact within Treasury for Platforms. (**/treasury/connect/account-management/accounts-structure**)
*   **Working with Connected Accounts:** Understand how to request capabilities and collect onboarding requirements for connected accounts. (**/treasury/connect/account-management/connected-accounts**)
*   **Working with Financial Accounts:** Learn how to provision and manage financial accounts for your platform and connected accounts. (**/treasury/connect/account-management/financial-accounts**)
*   **Financial Account Features:** Explore the features available for financial accounts, such as moving money and attaching cards. (**/treasury/connect/account-management/financial-account-features**)
*   **Platform Financial Accounts:** Understand the financial account provisioned for your platform. (**/treasury/connect/account-management/platform-financial-account**)
*   **Working with Balances and Transactions:** Learn about financial account balances and how transactions affect them. (**/treasury/connect/account-management/working-with-balances-and-transactions**)
*   **Moving Money into Financial Accounts:** Discover methods for adding funds to financial accounts using InboundTransfers and ReceivedCredits. (**/treasury/connect/moving-money/moving-money-into-financial-accounts**)
    *   **Moving money using InboundTransfer objects:** Transfer funds from an external US bank account into a financial account. (**/treasury/connect/moving-money/into/inbound-transfers**)
    *   **Moving money using ReceivedCredit objects:** Understand how funds move into a financial account and are represented by ReceivedCredit objects. (**/treasury/connect/moving-money/into/received-credits**)
    *   **Moving money using CreditReversal objects:** Learn how to reverse ReceivedCredits to return funds. (**/treasury/connect/moving-money/into/credit-reversals**)
*   **Moving Money out of Treasury for Platforms:** Explore methods for moving funds from financial accounts to other accounts. (**/treasury/connect/moving-money/moving-money-out**)
    *   **Moving money using OutboundTransfer objects:** Transfer funds from a financial account to an external bank account owned by the same connected account. (**/treasury/connect/moving-money/out-of/outbound-transfers**)
    *   **Moving money using OutboundPayment objects:** Create outbound payments to move money from financial accounts to third parties. (**/treasury/connect/moving-money/out-of/outbound-payments**)
    *   **Moving money using ReceivedDebit objects:** Observe how funds are pulled from a financial account through processes like card spending or ACH debits. (**/treasury/connect/moving-money/out-of/received-debits**)
    *   **Moving money using DebitReversal objects:** Learn how to retrieve funds taken from a financial account via a ReceivedDebit. (**/treasury/connect/moving-money/out-of/debit-reversals**)
*   **Payouts and Top-ups from Payments Balance:** Understand how to move money between payments account balances and financial account balances. (**/treasury/connect/moving-money/payouts**)
*   **Working with SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms using these objects. (**/treasury/connect/moving-money/working-with-bankaccount-objects**)
*   **ACH NOC and SEC Handling:** Learn how external account information is updated via ACH Notifications of Change (NOC). (**/treasury/connect/moving-money/noc-sec-handling**)
*   **Money Movement Timelines:** Understand the processing and cutoff times for various money movement methods. (**/treasury/connect/money-movement/timelines**)
*   **Integrate with Fifth Third Bank:** Learn how to integrate with Fifth Third Bank for Treasury for Platforms. (**/treasury/connect/fifth-third**)
*   **Build a New Treasury for Platforms Integration with Fifth Third Bank:** A step-by-step guide for new integrations. (**/treasury/connect/fifth-third-get-started**)

### Credit and Lending Features

*   **Issuing Credit Overview:** Explore how to apply your platform's Issuing account balance or exposure limit to cards issued to connected accounts. (**/issuing/credit**)
*   **Credit Consumer Issuing:** Learn about the solution for launching a credit program for your customers (US only). (**/issuing/credit/consumer-issuing**, **/issuing/consumer-prepaid-debit-cards**, **/issuing/consumer-issuing/how-it-works**)
*   **Set Up Credit for Connected Accounts:** Configure credit terms for your connected accounts and fund their spend from your platform. (**/issuing/credit/connect-credit-setup**)
*   **Manage Credit Terms:** Update credit limits and intervals for connected accounts. (**/issuing/credit/manage-credit-terms**)
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for your connected accounts. (**/issuing/credit/manage-account-obligations**)
    *   **Obligation amounts, transactions, and adjustments:** View details about FundingObligations and make adjustments. (**/issuing/credit/manage-account-obligations/obligations-transactions-adjustments**)
    *   **Obligation payments:** Learn how to collect repayment from connected accounts. (**/issuing/credit/manage-account-obligations/obligation-payments**)
    *   **Available credit and flow of funds:** Understand how available credit changes with transactions and adjustments. (**/issuing/credit/manage-account-obligations/available-credit**)
*   **Report Other Credit Decisions and Manage Adverse Action Notices:** Record credit decisions and send adverse action notice emails. (**/issuing/credit/report-credit-decisions-and-manage-aans**)
*   **Report Required Regulatory Data for Credit Decisions:** Understand how to report regulatory data for credit programs. (**/issuing/credit/report-required-regulatory-data-for-credit-decisions**)
*   **Test Credit Integration:** Validate your automated platform funding in testing environments. (**/issuing/credit/test-credit**)

### Fraud Management and Security

*   **Manage Fraud:** Understand transaction fraud and how to combat it using Stripe Issuing controls and tools. (**/issuing/manage-fraud**)
*   **Advanced Fraud Tools:** Leverage API signals and tooling to identify and prevent transaction fraud. (**/issuing/controls/advanced-fraud-tools**)
*   **Issuing Authorization Rules:** Limit authorization approvals by setting custom conditions to prevent unauthorized activity. (**/issuing/controls/authorization-rules**)
*   **Real-time Authorizations:** Approve or decline authorization requests in real time using synchronous webhooks. (**/issuing/controls/real-time-authorizations**, **/issuing/controls/real-time-authorizations/quickstart**, **/issuing/controls/real-time-authorizations/direct-webhook-migration**)
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations to minimize accidental blocks. (**/issuing/controls/fraud-challenges**)
*   **3D Secure:** Learn about 3D Secure, an additional layer of authentication for online transactions. (**/issuing/3d-secure**)
*   **Issuing Watchlist:** Understand how Stripe screens Issuing users against sanctions lists. (**/issuing/issuing-watchlist**)

### Customization and Program Management

*   **Program Management:** Choose between Stripe program management and processor-only models for your Issuing program. (**/issuing/program-management**)
*   **Integrate Processor-Only Issuing:** Set up a processor-only Issuing integration where you manage your program's compliance and licensing. (**/issuing/processor-only-integration-guide**, **/issuing/processor-only-issuing**)
*   **Customize Your Card Program:** Tailor your Stripe Issuing card program to meet your specific business needs. (**/issuing/customize-your-program**)

### Specific Use Cases and Features

*   **B2B Payments Integration Guide:** Build a B2B payments integration using Stripe Issuing. (**/issuing/integration-guides/b2b-payments**)
*   **Embedded Finance Integration Guide:** Create an embedded financial services integration with Issuing and Treasury for Platforms. (**/issuing/integration-guides/embedded-finance**)
*   **Fleet Integration Guide:** Build a fleet financial services integration with Issuing. (**/issuing/integration-guides/fleet**)
*   **Issuing for your business:** Programmatically create virtual cards for your business, employees, or contractors. (**/issuing/direct**)
*   **Issuing for agents:** Provide programmable cards with built-in controls for agents to use in transactions. (**/issuing/agents**)
*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for users to instantly receive and spend money. (**/issuing/consumer-prepaid-debit-cards**)
*   **Stablecoin-Backed Cards:** Issue prepaid or debit cards backed by stablecoin balances. (**/issuing/stablecoin-cards**, **/issuing/stablecoin-cards-for-financial-accounts**, **/issuing/bridge-stablecoin-cards**)
*   **Use Stripe Issuing in Different Countries:** Explore options for global card issuing. (**/issuing/global**)
*   **Issuing Merchant Categories:** Understand how businesses are categorized and use this for spending controls. (**/issuing/categories**)
*   **Use Cards at Automated Teller Machines (ATMs):** Enable and manage ATM cash withdrawals for US-issued cards. (**/issuing/purchases/atm-usage**)
*   **Issuing Authorizations:** Learn how to handle authorization requests for card purchases. (**/issuing/purchases/authorizations**)
*   **Issuing Transactions:** Understand how authorizations are captured and become transaction objects. (**/issuing/purchases/transactions**)
*   **Issuing Disputes:** Learn how to dispute transactions through the Dashboard or API. (**/issuing/purchases/disputes**)
*   **Enriched Merchant Data:** Utilize comprehensive merchant data for improved fraud prevention and spending controls. (**/issuing/purchases/enriched-merchant-data**)
*   **Issuing Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards. (**/issuing/controls/lifecycle-controls**)

### Compliance and Marketing

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US):** Navigate financial regulations for marketing and user interfaces. (**/issuing/compliance-us**)
*   **Issuing Regulated Customer Notices:** Understand how to send regulatory notifications to your customers. (**/issuing/compliance-us/issuing-regulated-customer-notices**)
*   **Stripe Issuing Marketing Guidelines (UK/Europe):** Adhere to guidelines for marketing Issuing products in the UK and Europe. (**/issuing/marketing-guidance-europe-uk**)
*   **Treasury for Platforms Product Marketing, Design, and Compliance Guidelines:** Ensure your Treasury for Platforms program and marketing campaigns are compliant. (**/treasury/connect/compliance**)
*   **Marketing Treasury for Platforms:** Create compliant messaging for your users regarding Treasury for Platforms. (**/treasury/connect/marketing-financial-accounts**)
*   **Handling Complaints:** Learn how to properly handle complaints related to Treasury for Platforms or Stripe Issuing. (**/treasury/connect/handling-complaints**)
*   **Regulatory Receipts:** Understand hosted transaction receipts for regulated money movements. (**/treasury/connect/moving-money/regulatory-receipts**)

### Testing and Migration

*   **Test Your Issuing Integration:** Learn how to test your integration and simulate purchases in a sandbox environment. (**/issuing/testing**)
*   **Issuing Beta Migration Guide:** Migrate from the Issuing beta to the generally available version. (**/issuing/migration-from-beta**)
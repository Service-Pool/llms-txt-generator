### Issuing Spending Controls

You can use spending controls to block merchant categories (for example, bakeries), countries, merchant IDs, or card presence, and to set spending limits per authorization or per month. You can apply them to both Cards and Cardholders either by setting their `spending_controls` parameters when you create them or by updating them later.

**Private preview**
Merchant ID spending controls is in private preview. You must be an Issuing user to participate. To learn more or request access, contact Stripe.

You can set the following `spending_controls` parameters:

| Parameter           | Type  | Description                                                                                             |
| :------------------ | :---- | :------------------------------------------------------------------------------------------------------ |
| `allowed_categories` | array | List of categories of authorizations to allow. All other categories will be blocked.                    |
| `blocked_categories` | array | List of categories of authorizations to decline. All other categories will be blocked. |
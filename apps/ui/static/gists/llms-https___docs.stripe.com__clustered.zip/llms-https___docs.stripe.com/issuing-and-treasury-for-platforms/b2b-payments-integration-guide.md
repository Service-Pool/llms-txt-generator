## Stripe Issuing and Treasury for Platforms Documentation

This documentation group provides comprehensive guidance on integrating and utilizing Stripe Issuing and Treasury for Platforms. It covers everything from initial setup and integration to advanced features like fraud management, credit programs, and global availability.

### Key Areas Covered:

*   **Getting Started:**
    *   [Onboarding overview](/issuing/onboarding-overview)
    *   [Issuing beta migration guide](/issuing/migration-from-beta)
    *   [Customer support for Issuing and Treasury for platforms](/issuing/customer-support)
    *   [Issuing and Treasury for platforms sample app](/issuing/sample-app)
    *   [Get started with API access to Treasury for platforms](/treasury/connect/access)
    *   [Treasury for platforms connected account onboarding guide](/treasury/connect/examples/onboarding-guide)
    *   [Build a new Treasury for platforms integration with Fifth Third Bank](/treasury/connect/fifth-third-get-started)

*   **Core Issuing Features:**
    *   [Issuing](/issuing)
    *   [How Issuing works](/issuing/how-issuing-works)
    *   [Choose your card type](/issuing/choose-cards) (Virtual vs. Physical)
    *   [Fund your Issuing balance](/issuing/funding/balance)
    *   [Add funds to your card program](/issuing/adding-funds-to-your-card-program)
    *   [Program management](/issuing/program-management) (Stripe-managed vs. Processor-only)
    *   [Customize your card program](/issuing/customize-your-program)
    *   [PIN management](/issuing/cards/pin-management)

*   **Specific Issuing Integrations & Use Cases:**
    *   [Integration guides](/issuing/integration-guides) (Overview)
    *   [Embedded Finance integration guide](/issuing/integration-guides/embedded-finance)
    *   [B2B payments integration guide](/issuing/integration-guides/b2b-payments)
    *   [Fleet integration guide](/issuing/integration-guides/fleet)
    *   [Issuing for your business](/issuing/direct) (Direct integration)
    *   [Consumer prepaid debit cards](/issuing/consumer-prepaid-debit-cards)
    *   [Credit Consumer Issuing](/issuing/credit)
    *   [Issuing for agents](/issuing/agents)

*   **Physical Cards:**
    *   [Physical cards](/issuing/cards/physical)
    *   [Choose your physical bundle](/issuing/cards/physical/choose-bundle)
    *   [Customize card bundle](/issuing/cards/physical/card-bundle-selections)
    *   [Artwork templates](/issuing/cards/artwork-templates)
    *   [Create a design](/issuing/cards/physical/create-design)
    *   [Issue cards](/issuing/cards/physical/issue-cards)
    *   [Ship cards](/issuing/cards/physical/ship-cards)
    *   [Address validation](/issuing/cards/physical/address-validation)
    *   [Replacement cards](/issuing/cards/replacements)

*   **Virtual Cards:**
    *   [Virtual cards with Issuing](/issuing/cards/virtual)
    *   [Create virtual cards](/issuing/cards/virtual/issue-cards)
    *   [Use digital wallets with Issuing](/issuing/cards/digital-wallets)

*   **Fraud Management & Controls:**
    *   [Manage fraud with Stripe Issuing controls and tools](/issuing/manage-fraud)
    *   [Advanced fraud tools](/issuing/controls/advanced-fraud-tools)
    *   [Issuing authorization rules](/issuing/controls/authorization-rules)
    *   [Issuing real-time authorizations](/issuing/controls/real-time-authorizations)
    *   [Migrate to direct webhook response](/issuing/controls/real-time-authorizations/direct-webhook-migration)
    *   [Fraud challenges](/issuing/controls/fraud-challenges)
    *   [Issuing lifecycle controls](/issuing/controls/lifecycle-controls)
    *   [Issuing spending controls](/issuing/controls/spending-controls)
    *   [Token management](/issuing/controls/token-management)

*   **Purchases & Transactions:**
    *   [Issuing authorizations](/issuing/purchases/authorizations)
    *   [Issuing transactions](/issuing/purchases/transactions)
    *   [Issuing disputes](/issuing/purchases/disputes)
    *   [Use cards at automated teller machines (ATMs)](/issuing/purchases/atm-usage)
    *   [Enriched merchant data](/issuing/purchases/enriched-merchant-data)

*   **Stripe Connect Integration:**
    *   [Set up an Issuing and Connect integration](/issuing/connect)
    *   [Connected accounts, cardholders, and cards](/issuing/connect/cardholders-and-cards)
    *   [Fund Issuing balances with Connect](/issuing/connect/funding)
    *   [Update the Issuing terms of service acceptance](/issuing/connect/tos_acceptance)
    *   [Cardholder controls](/issuing/connect/cardholders-controls)
    *   [Embed Issuing card management into your website](/issuing/connect/embedded-components)
    *   [Inactive connected accounts offboarding](/issuing/connect/inactive-accounts-management)

*   **Treasury for Platforms:**
    *   [Treasury for platforms](/treasury/connect)
    *   [How Treasury for platforms works](/treasury/connect/how-financial-accounts-for-platforms-works)
    *   [Treasury for platforms requirements](/treasury/connect/requirements)
    *   [Accounts structure](/treasury/connect/account-management/accounts-structure)
    *   [Working with connected accounts](/treasury/connect/account-management/connected-accounts)
    *   [Working with financial accounts](/treasury/connect/account-management/financial-accounts)
    *   [Financial account features](/treasury/connect/account-management/financial-account-features)
    *   [Platform financial accounts](/treasury/connect/account-management/platform-financial-account)
    *   [Working with Stripe Issuing cards](/treasury/connect/account-management/issuing-cards)
    *   [Working with balances and transactions](/treasury/connect/account-management/working-with-balances-and-transactions)
    *   [Set up financial accounts and cards](/treasury/connect/examples/financial-accounts)
    *   [Using Treasury for platforms to move money](/treasury/connect/examples/moving-money)
    *   [Webhooks for Stripe Issuing and Treasury for platforms](/treasury/connect/examples/webhooks)
    *   [Treasury for platforms fraud guide](/treasury/connect/examples/fraud-guide)
    *   [Issuing and Treasury for platforms sample app](/treasury/connect/examples/sample-app)
    *   [Integrate with Fifth Third Bank](/treasury/connect/fifth-third)
    *   [Marketing and compliance guidelines](/treasury/connect/compliance)
    *   [Handling complaints](/treasury/connect/handling-complaints)
    *   [Marketing Treasury for platforms](/treasury/connect/marketing-financial-accounts)
    *   [Regulatory receipts](/treasury/connect/moving-money/regulatory-receipts)
    *   [Moving money into financial accounts](/treasury/connect/moving-money/moving-money-into-financial-accounts)
    *   [Moving money out of Treasury for platforms](/treasury/connect/moving-money/moving-money-out)
    *   [ACH NOC and SEC handling](/treasury/connect/moving-money/noc-sec-handling)
    *   [Moving money using CreditReversal objects](/treasury/connect/moving-money/into/credit-reversals)
    *   [Moving money with using InboundTransfer objects](/treasury/connect/moving-money/into/inbound-transfers)
    *   [Moving money using ReceivedCredit objects](/treasury/connect/moving-money/into/received-credits)
    *   [Moving money using DebitReversal objects](/treasury/connect/moving-money/out-of/debit-reversals)
    *   [Moving money using OutboundPayment objects](/treasury/connect/moving-money/out-of/outbound-payments)
    *   [Moving money using OutboundTransfer objects](/treasury/connect/moving-money/out-of/outbound-transfers)
    *   [Moving money using ReceivedDebit objects](/treasury/connect/moving-money/out-of/received-debits)
    *   [Payouts and top-ups from payments balance](/treasury/connect/moving-money/payouts)
    *   [Working with SetupIntents, PaymentMethods, and BankAccounts](/treasury/connect/moving-money/working-with-bankaccount-objects)
    *   [Money movement timelines](/treasury/connect/money-movement/timelines)

*   **Credit Programs:**
    *   [Issuing Credit](/issuing/credit)
    *   [Manage credit terms](/issuing/credit/manage-credit-terms)
    *   [Manage account obligations](/issuing/credit/manage-account-obligations)
    *   [Obligation amounts, transactions, and adjustments](/issuing/credit/manage-account-obligations/obligations-transactions-adjustments)
    *   [Obligation payments](/issuing/credit/manage-account-obligations/obligation-payments)
    *   [Available credit and flow of funds](/issuing/credit/manage-account-obligations/available-credit)
    *   [Report other credit decisions and manage adverse action notices](/issuing/credit/report-credit-decisions-and-manage-aans)
    *   [Report required regulatory data for credit decisions](/issuing/credit/report-required-regulatory-data-for-credit-decisions)
    *   [Test your integration](/issuing/credit/test-credit)
    *   [Set up credit for connected accounts](/issuing/credit/connect-credit-setup)

*   **Stablecoin-Backed Cards:**
    *   [Stablecoin-backed cards for Stripe Stablecoin Financial Accounts](/issuing/stablecoin-cards-for-financial-accounts)
    *   [Stablecoin-backed cards for Bridge, Privy, or third-party wallets](/issuing/bridge-stablecoin-cards)
    *   [Stablecoin-backed card issuing](/issuing/stablecoin-cards)

*   **Global Issuing:**
    *   [Use Stripe Issuing in different countries](/issuing/global)
    *   [Issuing and Treasury product marketing, design, and compliance guidelines](/issuing/compliance-us)
    *   [Stripe Issuing marketing guidelines](/issuing/marketing-guidance-europe-uk)

*   **Testing:**
    *   [Test your Issuing integration](/issuing/testing)
    *   [Test your integration](/treasury/connect/test-credit) (for Credit)

*   **Compliance & Guidelines:**
    *   [Issuing and Treasury product marketing, design, and compliance guidelines](/issuing/compliance-us)
    *   [Issuing regulated customer notices](/issuing/compliance-us/issuing-regulated-customer-notices)
    *   [Treasury for platforms product marketing, design, and compliance guidelines](/treasury/connect/compliance)
    *   [Issuing watchlist](/issuing/issuing-watchlist)

*   **Other:**
    *   [Choose a cardholder type](/issuing/other/choose-cardholder)
    *   [Issuing merchant categories](/issuing/categories)
    *   [Postfund your integration with Stripe](/issuing/funding/post-fund)
    *   [Post-fund your integration with Dynamic Reserves](/issuing/funding/post-fund-with-dynamic-reserves)
    *   [Using Issuing Elements](/issuing/elements)
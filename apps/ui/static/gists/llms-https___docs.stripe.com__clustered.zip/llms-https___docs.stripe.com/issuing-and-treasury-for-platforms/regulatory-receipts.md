## Stripe Issuing and Treasury for Platforms

This documentation suite provides comprehensive guidance on integrating Stripe Issuing and Treasury for platforms. It covers everything from initial setup and integration to advanced features like fraud management, credit programs, and money movement.

### Key Areas:

*   **Getting Started:**
    *   [Onboarding overview](/issuing/onboarding-overview)
    *   [Issuing beta migration guide](/issuing/migration-from-beta)
    *   [Customer support for Issuing and Treasury for platforms](/issuing/customer-support)
    *   [Issuing and Treasury product marketing, design, and compliance guidelines (US)](/issuing/compliance-us)
    *   [Stripe Issuing marketing guidelines (UK/Europe)](/issuing/marketing-guidance-europe-uk)
    *   [Treasury for platforms product marketing, design, and compliance guidelines](/treasury/connect/compliance)
    *   [Treasury for platforms connected account onboarding guide](/treasury/connect/examples/onboarding-guide)
    *   [Get started with API access to Treasury for platforms](/treasury/connect/access)
    *   [Build a new Treasury for platforms integration with Fifth Third Bank](/treasury/connect/fifth-third-get-started)
    *   [Integrate with Fifth Third Bank](/treasury/connect/fifth-third)

*   **Issuing Core Functionality:**
    *   [Issuing overview](/issuing)
    *   [How Issuing works](/issuing/how-issuing-works)
    *   [Choose your card type](/issuing/choose-cards) (Virtual vs. Physical)
    *   [Fund your Issuing balance](/issuing/funding/balance)
    *   [Add funds to your card program](/issuing/adding-funds-to-your-card-program)
    *   [Issuing balance](/issuing/funding/balance)
    *   [Post-fund your integration with Stripe](/issuing/funding/post-fund)
    *   [Post-fund your integration with Dynamic Reserves](/issuing/funding/post-fund-with-dynamic-reserves)

*   **Integration Guides:**
    *   [Integration guides](/issuing/integration-guides) (Overview)
    *   [Embedded Finance integration guide](/issuing/integration-guides/embedded-finance)
    *   [B2B payments integration guide](/issuing/integration-guides/b2b-payments)
    *   [Fleet integration guide](/issuing/integration-guides/fleet)
    *   [Integrate processor-only Issuing](/issuing/processor-only-integration-guide)
    *   [Processor-only Issuing](/issuing/processor-only-issuing)
    *   [Sample app for Issuing and Treasury for platforms](/issuing/sample-app)
    *   [Issuing and Treasury for platforms sample app (Next.js)](/treasury/connect/examples/sample-app)

*   **Card Management:**
    *   [Manage cards](/issuing/cards) (Overview)
    *   [Virtual cards with Issuing](/issuing/cards/virtual)
    *   [Create virtual cards](/issuing/cards/virtual/issue-cards)
    *   [Physical cards](/issuing/cards/physical)
    *   [Create physical cards](/issuing/cards/physical/issue-cards)
    *   [Address validation for physical cards](/issuing/cards/physical/address-validation)
    *   [Artwork templates](/issuing/cards/physical/artwork-templates)
    *   [Customize card bundle](/issuing/cards/physical/card-bundle-selections)
    *   [Choose your physical bundle](/issuing/cards/physical/choose-bundle)
    *   [Order a custom bundle](/issuing/cards/physical/order-custom-bundle)
    *   [Ship cards](/issuing/cards/physical/ship-cards)
    *   [Replacement cards](/issuing/cards/replacements)
    *   [PIN management](/issuing/cards/pin-management)
    *   [Use digital wallets with Issuing](/issuing/cards/digital-wallets)
    *   [Token management](/issuing/controls/token-management)

*   **Issuing with Stripe Connect:**
    *   [Set up an Issuing and Connect integration](/issuing/connect)
    *   [Connected accounts, cardholders, and cards](/issuing/connect/cardholders-and-cards)
    *   [Fund Issuing balances with Connect](/issuing/connect/funding)
    *   [Update the Issuing terms of service acceptance](/issuing/connect/tos_acceptance)
    *   [Cardholder controls](/issuing/connect/cardholders-controls)
    *   [Inactive connected accounts offboarding](/issuing/connect/inactive-accounts-management)
    *   [Embed Issuing card management into your website](/issuing/connect/embedded-components)

*   **Treasury for Platforms Core Functionality:**
    *   [Treasury for platforms overview](/treasury/connect)
    *   [How Treasury for platforms works](/treasury/connect/how-financial-accounts-for-platforms-works)
    *   [Treasury for platforms requirements](/treasury/connect/requirements)
    *   [Get started with API access to Treasury for platforms](/treasury/connect/access)
    *   [Accounts structure](/treasury/connect/account-management/accounts-structure)
    *   [Working with connected accounts](/treasury/connect/account-management/connected-accounts)
    *   [Working with financial accounts](/treasury/connect/account-management/financial-accounts)
    *   [Financial account features](/treasury/connect/account-management/financial-account-features)
    *   [Platform financial accounts](/treasury/connect/account-management/platform-financial-account)
    *   [Working with Stripe Issuing cards](/treasury/connect/account-management/issuing-cards)

*   **Money Movement with Treasury for Platforms:**
    *   [Use Treasury for platforms to move money](/treasury/connect/moving-money/examples)
    *   [Moving money into financial accounts](/treasury/connect/moving-money/into)
        *   [Moving money using InboundTransfer objects](/treasury/connect/moving-money/into/inbound-transfers)
        *   [Moving money using ReceivedCredit objects](/treasury/connect/moving-money/into/received-credits)
        *   [Moving money using CreditReversal objects](/treasury/connect/moving-money/into/credit-reversals)
    *   [Moving money out of Treasury for platforms](/treasury/connect/moving-money/moving-money-out)
        *   [Moving money using OutboundTransfer objects](/treasury/connect/moving-money/out-of/outbound-transfers)
        *   [Moving money using OutboundPayment objects](/treasury/connect/moving-money/out-of/outbound-payments)
        *   [Moving money using ReceivedDebit objects](/treasury/connect/moving-money/out-of/received-debits)
        *   [Moving money using DebitReversal objects](/treasury/connect/moving-money/out-of/debit-reversals)
    *   [Payouts and top-ups from payments balance](/treasury/connect/moving-money/payouts)
    *   [Working with SetupIntents, PaymentMethods, and BankAccounts](/treasury/connect/moving-money/working-with-bankaccount-objects)
    *   [ACH NOC and SEC handling](/treasury/connect/moving-money/noc-sec-handling)
    *   [Money movement timelines](/treasury/connect/money-movement/timelines)
    *   [Working with balances and transactions](/treasury/connect/account-management/working-with-balances-and-transactions)

*   **Credit Programs:**
    *   [Issuing Credit overview](/issuing/credit)
    *   [Credit Consumer Issuing](/issuing/credit/consumer-issuing)
    *   [How Credit Consumer Issuing works](/issuing/credit/consumer-issuing/how-it-works)
    *   [Consumer prepaid debit cards](/issuing/consumer-prepaid-debit-cards)
    *   [Set up credit for connected accounts](/issuing/credit/connect-credit-setup)
    *   [Manage credit terms](/issuing/credit/manage-credit-terms)
    *   [Manage account obligations](/issuing/credit/manage-account-obligations)
        *   [Available credit and flow of funds](/issuing/credit/manage-account-obligations/available-credit)
        *   [Obligation payments](/issuing/credit/manage-account-obligations/obligation-payments)
        *   [Obligation amounts, transactions, and adjustments](/issuing/credit/manage-account-obligations/obligations-transactions-adjustments)
    *   [Report other credit decisions and manage adverse action notices](/issuing/credit/report-credit-decisions-and-manage-aans)
    *   [Report required regulatory data for credit decisions](/issuing/credit/report-required-regulatory-data-for-credit-decisions)
    *   [Test your credit integration](/issuing/credit/test-credit)

*   **Controls and Fraud Management:**
    *   [Manage fraud with Stripe Issuing controls and tools](/issuing/manage-fraud)
    *   [Issuing controls overview](/issuing/controls)
    *   [Spending controls](/issuing/controls/spending-controls)
    *   [Lifecycle controls](/issuing/controls/lifecycle-controls)
    *   [Advanced fraud tools](/issuing/controls/advanced-fraud-tools)
    *   [Issuing authorization rules](/issuing/controls/authorization-rules)
    *   [Real-time authorizations](/issuing/controls/real-time-authorizations)
    *   [Migrate to direct webhook response](/issuing/controls/real-time-authorizations/direct-webhook-migration)
    *   [Fraud challenges](/issuing/controls/fraud-challenges)
    *   [3D Secure](/issuing/3d-secure)
    *   [Issuing watchlist](/issuing/issuing-watchlist)

*   **Purchases and Transactions:**
    *   [Issuing authorizations](/issuing/purchases/authorizations)
    *   [Issuing transactions](/issuing/purchases/transactions)
    *   [Issuing disputes](/issuing/purchases/disputes)
    *   [Use cards at automated teller machines (ATMs)](/issuing/purchases/atm-usage)
    *   [Enriched merchant data](/issuing/purchases/enriched-merchant-data)
    *   [Issuing merchant categories](/issuing/categories)

*   **Advanced Features:**
    *   [Customize your card program](/issuing/customize-your-program)
    *   [Program management](/issuing/program-management) (Stripe vs. Processor-only)
    *   [Issuing for agents](/issuing/agents)
    *   [Stablecoin-backed cards](/issuing/stablecoin-cards)
    *   [Stablecoin-backed cards for financial accounts](/issuing/stablecoin-cards-for-financial-accounts)
    *   [Stablecoin-backed cards for Bridge, Privy, or third-party wallets](/issuing/bridge-stablecoin-cards)
    *   [Use Stripe Issuing in different countries](/issuing/global)

*   **Testing and Support:**
    *   [Test your Issuing integration](/issuing/testing)
    *   [Test your credit integration](/issuing/credit/test-credit)
    *   [Customer support for Issuing and Treasury for platforms](/issuing/customer-support)

This documentation suite is designed to guide developers and businesses through the process of building and managing sophisticated payment and financial service solutions using Stripe Issuing and Treasury for platforms.
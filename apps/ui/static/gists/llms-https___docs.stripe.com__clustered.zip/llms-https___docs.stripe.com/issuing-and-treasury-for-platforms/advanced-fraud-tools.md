## Stripe Issuing and Treasury for Platforms: Managing Transactions, Fraud, and Financial Accounts

This documentation suite provides comprehensive guidance on utilizing Stripe Issuing and Treasury for Platforms to create and manage payment card programs, handle financial transactions, and implement robust fraud prevention measures. It caters to developers and businesses looking to embed financial services into their platforms.

### Core Concepts and Integration Guides

*   **Issuing Overview:** Understand the fundamental capabilities of Stripe Issuing for creating, managing, and distributing payment cards for your business or users. (Page 66)
*   **How Issuing Works:** Delve into the mechanics of building a card program with Stripe Issuing, including partnerships with banks and card networks. (Page 67)
*   **Integration Guides:** Access specific guides for integrating Issuing into various use cases, including:
    *   **Embedded Finance:** Build embedded financial services with Issuing and Treasury for platforms. (Page 3)
    *   **B2B Payments:** Create cards for business, employee, or contractor purchases. (Page 2)
    *   **Fleet:** Develop fleet card programs for customer businesses. (Page 4)
*   **Treasury for Platforms Overview:** Learn how to provide financial services to connected accounts using Stripe Treasury for Platforms, enabling them to hold funds, pay bills, and manage cash flow. (Page 120)
*   **Treasury for Platforms Integration:** Guides on getting started with Treasury for Platforms, including API access, onboarding users, and sample integrations. (Pages 85, 100, 101, 104)

### Card Management and Customization

*   **Card Types:** Decide between physical and virtual cards, understanding their use cases and tradeoffs. (Page 12)
*   **Virtual Cards:** Learn how to create and display virtual card details in a PCI-compliant manner. (Pages 33, 34)
*   **Physical Cards:** Comprehensive guidance on issuing physical cards, including design, ordering custom bundles, and shipping. (Pages 21, 22, 23, 24, 25, 26, 27, 28, 29)
*   **Replacement Cards:** Understand the process for replacing expired, damaged, lost, or stolen cards. (Page 32)
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay. (Page 17)
*   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers. (Page 30)
*   **Customization:** Customize your card program with BIN setup and account ranges. (Page 16)

### Funding and Financial Accounts

*   **Issuing Balance:** Learn how to fund your Issuing balance to make funds available for card spend. (Page 61)
*   **Adding Funds:** Explore various funding options, including pull-funded, push-funded, and balance transfers. (Page 11)
*   **Post-funding:** Understand how to post-fund your integration with Stripe or Dynamic Reserves, allowing for negative balances before settlement. (Pages 63, 64)
*   **Treasury Financial Accounts:** Learn about financial accounts for platforms and connected accounts, including their features, balances, and transactions. (Pages 87, 89, 91, 93, 100, 101)
*   **Money Movement:** Detailed guides on moving money into and out of financial accounts using various transfer objects and methods. (Pages 101, 107, 108, 109, 110, 111, 112, 114, 115, 116, 117, 118)

### Fraud Management and Controls

*   **Manage Fraud:** Understand transaction fraud risks and Stripe's tools and controls to combat them. (Page 20)
*   **Advanced Fraud Tools:** Utilize API signals and tooling to identify and prevent transaction fraud. (Page 42)
*   **Real-time Authorizations:** Approve or decline authorization requests in real-time using synchronous webhooks. (Pages 9, 44, 48)
*   **Issuing Authorization Rules:** Limit authorization approvals by configuring custom rules. (Page 43)
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations to minimize accidental blocks. (Page 45)
*   **3D Secure:** Learn about 3D Secure for cardholder authentication in online transactions. (Page 10)
*   **Spending Controls:** Set rules on cards and cardholders to control spending by blocking categories, countries, or setting limits. (Page 49)
*   **Lifecycle Controls:** Automatically cancel virtual cards after a specified number of payments. (Page 47)
*   **Token Management:** Manage network tokens for secure payments in digital wallets and online storefronts. (Page 50)
*   **Issuing Watchlist:** Understand Stripe's automatic screening against sanctions lists and the manual review process. (Page 74)

### Stripe Connect Integration

*   **Issuing and Connect:** Set up an integration to issue cards on connected accounts. (Page 41)
*   **Connected Accounts, Cardholders, and Cards:** Learn how to create and manage cardholders and cards within a Connect integration. (Page 39)
*   **Cardholder Controls:** Understand how Stripe screens cardholder information and the implications for your integration. (Page 36)
*   **Inactive Connected Accounts:** Manage the offboarding of inactive connected accounts to mitigate risk. (Page 38)
*   **Connect Funding:** Fund Issuing balances for connected accounts. (Page 40)
*   **Embedded Components:** Embed Issuing card management functionality into your website using prebuilt UI components. (Page 37)

### Credit Programs

*   **Issuing Credit:** Explore Stripe's private preview credit solution for platforms to offer credit programs to their customers. (Page 53)
*   **Credit Consumer Issuing:** Learn about creating, launching, and managing credit programs for consumers. (Pages 14, 15)
*   **Manage Credit Terms:** Configure credit limits and terms for connected accounts. (Page 55)
*   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts. (Pages 51, 54, 56, 57)
*   **Reporting Credit Decisions:** Record credit underwriting scenarios and manage adverse action notices. (Page 58)
*   **Regulatory Reporting:** Report required regulatory data for credit decisions. (Page 59)
*   **Test Credit Integration:** Validate your automated platform funding in testing environments. (Page 60)

### Compliance and Guidelines

*   **US Compliance:** Understand product marketing, design, and compliance guidelines for Issuing and Treasury for Platforms in the US. (Page 71)
*   **EU/UK Marketing Guidance:** Adhere to marketing guidelines for Issuing programs in the UK and Europe. (Page 75)
*   **Treasury for Platforms Compliance:** Navigate marketing, design, and compliance guidelines for Treasury for Platforms. (Page 96)
*   **Regulated Customer Notices:** Learn about sending regulatory notifications to your customers. (Page 72)
*   **Customer Support:** Find information on customer support for Issuing and Treasury for Platforms. (Page 1)

### Other Resources

*   **Sample App:** Explore the Issuing and Treasury for Platforms sample app to see API usage in action. (Page 7)
*   **Onboarding Overview:** Understand the steps required to take your integration live. (Page 6)
*   **Merchant Categories:** Learn about Merchant Category Codes (MCCs) and their use in spending controls. (Page 35)
*   **ATM Usage:** Understand how to use Issuing cards at ATMs for cash withdrawals. (Page 76)
*   **Transactions:** Learn how to handle transactions after authorizations are approved and captured. (Page 80)
*   **Disputes:** Manage transaction disputes through the Dashboard or API. (Page 78)
*   **Global Availability:** Explore options for issuing cards in different countries. (Page 65)
*   **Beta Migration:** Guide for migrating from the Issuing beta to the generally available version. (Page 68)
*   **Issuing for Agents:** Issue programmable cards with built-in controls for agents. (Page 69)
*   **Consumer Prepaid Debit Cards:** Learn how to issue prepaid debit cards for users to receive and spend money. (Page 13)
*   **Stablecoin-Backed Cards:** Issue cards backed by stablecoin balances for financial accounts or third-party wallets. (Pages 81, 82, 83)
*   **Testing:** Learn how to test your Issuing integration in a sandbox environment. (Page 84)
*   **Customer Support:** Resolve common Issuing and Treasury for Platforms questions and issues. (Page 1)
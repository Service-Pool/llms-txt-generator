# Stripe Issuing and Treasury for Platforms

This documentation group focuses on Stripe's Issuing and Treasury for Platforms products, providing comprehensive guidance for developers and businesses looking to integrate and manage card programs and financial services.

## Key Areas Covered:

*   **Issuing Core Functionality:**
    *   **Card Types:** Guidance on choosing between virtual and physical cards, including details on their use cases and tradeoffs.
    *   **Card Management:** Information on creating, issuing, and managing cards, including PIN management, replacement cards, and digital wallet integration.
    *   **Funding:** Instructions on how to fund your Issuing balance using various methods like pull-funded top-ups, push-funded top-ups, and balance transfers.
    *   **Customization:** Details on customizing card programs, including BIN setup, account ranges, and designing card artwork and bundles.
    *   **Fraud Management:** Strategies and tools for managing transaction fraud, including advanced fraud tools, real-time authorizations, fraud challenges, and authorization rules.
    *   **Transactions and Authorizations:** Understanding how authorizations are handled, the lifecycle of transactions, and enriched merchant data for better insights.
    *   **Merchant Categories:** Information on Merchant Category Codes (MCCs) and how they can be used for spending controls.
    *   **ATM Usage:** How to enable and use Stripe Issuing cards for ATM cash withdrawals.

*   **Stripe Connect Integration:**
    *   **Setting Up Issuing with Connect:** Comprehensive guides on integrating Issuing with Stripe Connect to issue cards to third-party users represented as connected accounts.
    *   **Connected Accounts, Cardholders, and Cards:** Managing the relationships between connected accounts, cardholders, and the cards issued to them.
    *   **Funding Issuing Balances with Connect:** Methods for funding the Issuing balances of connected accounts.
    *   **Cardholder Controls:** Understanding and implementing controls for cardholders within a Connect integration.
    *   **Inactive Account Management:** Policies and procedures for handling inactive connected accounts.
    *   **Embedded Components:** Utilizing pre-built UI components to embed Issuing card management functionality into your website.

*   **Treasury for Platforms:**
    *   **Core Functionality:** Understanding how Treasury for Platforms enables platforms to embed financial services for their connected accounts, including holding funds, paying bills, and managing cash flow.
    *   **Account Structure:** Details on the platform account and connected account structure within Treasury for Platforms.
    *   **Financial Accounts:** Managing financial accounts for both platforms and connected accounts, including their features and balances.
    *   **Money Movement:** Comprehensive guides on moving money into and out of financial accounts using various methods like ACH, wire transfers, and the Stripe network. This includes details on `InboundTransfer`, `OutboundPayment`, `OutboundTransfer`, `ReceivedCredit`, `CreditReversal`, `ReceivedDebit`, and `DebitReversal` objects.
    *   **Payouts and Top-ups:** Managing money movement between payments balances and financial account balances.
    *   **Bank Partnerships:** Information on integrating with bank partners like Fifth Third Bank.
    *   **Compliance and Marketing:** Guidelines for marketing, design, and compliance when offering Treasury for Platforms and Issuing products, including handling complaints and regulatory receipts.
    *   **Sample Integrations and Apps:** Resources like sample applications and integration guides to help developers get started.

*   **Credit Offerings:**
    *   **Consumer Credit Issuing:** Information on launching credit programs for consumers, including BIN sponsorship and managing credit ledgers.
    *   **Credit for Connected Accounts:** Setting up and managing credit terms, obligations, and available credit for connected accounts.
    *   **Reporting and Testing:** Guidelines for reporting credit decisions, managing adverse action notices, and testing credit integrations.

*   **Stablecoin-Backed Cards:**
    *   **Issuing with Stablecoins:** Details on issuing prepaid or debit cards backed by stablecoin balances, integrating with partners like Bridge, Privy, and third-party wallets.

*   **Onboarding and Testing:**
    *   **Onboarding Overview:** General guidance on the onboarding process for Issuing and Treasury for Platforms integrations.
    *   **Testing Integrations:** Instructions on how to test Issuing and Treasury for Platforms integrations in sandbox environments.

*   **Customer Support and Compliance:**
    *   **Customer Support:** Information on how to get customer support for Issuing and Treasury for Platforms.
    *   **Compliance Guidelines:** Specific guidance for product marketing, design, and compliance in the US, UK, and Europe.
    *   **Regulated Customer Notices:** Understanding and sending regulatory notifications to customers.
    *   **Issuing Watchlist:** Information on Stripe's automatic screening against sanctions lists.

This collection of pages provides a deep dive into the capabilities and implementation details of Stripe Issuing and Treasury for Platforms, enabling users to build sophisticated financial products and manage card programs effectively.
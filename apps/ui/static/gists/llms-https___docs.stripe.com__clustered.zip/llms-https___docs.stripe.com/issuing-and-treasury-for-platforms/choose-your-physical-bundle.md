## Stripe Issuing and Treasury for Platforms: Comprehensive Guide

This documentation suite provides a detailed overview of Stripe's Issuing and Treasury for Platforms products, empowering developers to build and manage sophisticated financial services for their users.

### Core Concepts and Getting Started

*   **Issuing Overview:** Understand the fundamentals of Stripe Issuing, how it works, and its capabilities for creating and managing payment cards. (Page 66, Page 67)
*   **Treasury for Platforms Overview:** Learn how Treasury for Platforms enables platforms to embed financial services for their connected accounts, including holding funds, paying bills, and managing cash flow. (Page 120, Page 106)
*   **Integration Guides:** Access specific guides for integrating Issuing into various use cases, including Embedded Finance, B2B Payments, and Fleet management. (Page 5, Page 2, Page 3, Page 4)
*   **Onboarding Overview:** Navigate the process of getting your Issuing or Treasury for Platforms integration live, including use case approval and live mode access. (Page 6)
*   **Sample App:** Explore a sample application to understand how to onboard customers, issue cards, and make outbound payments using Issuing and Treasury for Platforms APIs. (Page 7, Page 104)
*   **Customer Support:** Find resources for resolving common Issuing and Treasury for Platforms questions and issues. (Page 1)
*   **Beta Migration Guide:** Understand how to migrate from the Issuing beta to the generally available product. (Page 68)

### Issuing: Card Creation and Management

*   **Choosing Card Types:** Decide between issuing physical or virtual cards for your cardholders, understanding the use cases and trade-offs for each. (Page 12, Page 33)
*   **Virtual Cards:** Learn how to create and manage virtual cards, including displaying card details in a PCI-compliant manner. (Page 33, Page 34)
*   **Physical Cards:** Discover options for issuing physical cards, from standard designs to fully custom solutions. (Page 28)
    *   **Card Bundles:** Customize your physical card bundles, including choosing card materials and designs. (Page 23, Page 24)
    *   **Artwork Templates:** Utilize provided templates for designing your custom cards. (Page 22)
    *   **Address Validation:** Ensure successful delivery of physical cards with built-in address normalization and validation. (Page 21)
    *   **Issuing Cards:** Learn the process of creating physical cards for your cardholders. (Page 26)
    *   **Shipping Cards:** Understand the options for shipping physical cards, including individual and bulk shipments. (Page 29)
*   **Replacement Cards:** Manage the process of replacing expired, damaged, lost, or stolen cards. (Page 32)
*   **PIN Management:** Allow cardholders to manage their personal identification numbers for physical and virtual cards. (Page 30)
*   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay. (Page 17)

### Funding and Balances

*   **Issuing Balance:** Understand how to fund your Issuing balance to make funds available for card spend. (Page 61)
*   **Adding Funds to Card Programs:** Explore various funding options, including pull-funded top-ups, push-funded top-ups, and balance transfers. (Page 11)
*   **Post-funding:** Learn about post-funding your integration with Stripe, allowing for negative Issuing balances with later settlement. (Page 64, Page 63)

### Program Management and Customization

*   **Program Management:** Choose between Stripe program management and processor-only models for managing your Issuing program. (Page 31)
*   **Customize Your Card Program:** Tailor your Stripe Issuing card program to meet your specific business needs. (Page 16)
*   **Processor-Only Issuing:** Integrate Issuing as a processor, managing regulatory requirements, compliance, and licensing. (Page 18, Page 19)

### Controls and Fraud Management

*   **Manage Fraud:** Understand transaction fraud risks and learn how to combat them using Stripe Issuing's controls and tools. (Page 20)
*   **Advanced Fraud Tools:** Leverage API signals and tooling to identify and prevent transaction fraud. (Page 42)
*   **Issuing Authorization Rules:** Limit authorization approvals by configuring custom rules to block transactions based on specific conditions. (Page 43)
*   **Real-time Authorizations:** Approve or decline authorization requests in real time using synchronous webhooks. (Page 48, Page 9, Page 44)
*   **Fraud Challenges:** Implement an additional layer of verification for authorizations to minimize accidental blocks and verify high-risk transactions. (Page 45)
*   **Spending Controls:** Set rules on cards and cardholders to control spending by blocking merchant categories, countries, or setting spending limits. (Page 49)
*   **Lifecycle Controls:** Automatically cancel virtual cards after a specified number of payments for single-use or n-use card scenarios. (Page 47)
*   **3D Secure:** Implement 3D Secure for enhanced cardholder authentication in online transactions. (Page 10)
*   **Token Management:** Understand how to manage network tokens for cards, which are virtual representations used for secure payments. (Page 50)
*   **Issuing Watchlist:** Learn about Stripe's automatic screening against sanctions lists and the manual review process. (Page 74)

### Specific Use Cases and Features

*   **B2B Payments:** Build a B2B payments integration using Stripe Issuing to create cards for business purchases. (Page 2)
*   **Embedded Finance:** Develop an embedded financial services integration with Issuing and Treasury for Platforms. (Page 3)
*   **Fleet:** Create a fleet financial services integration with Issuing for managing customer business expenses. (Page 4)
*   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for users to instantly receive and spend money. (Page 13)
*   **Credit Consumer Issuing:** Create, launch, and manage a credit program for your consumers. (Page 14, Page 15)
*   **Issuing for Agents:** Provide agents with programmable cards and built-in controls for autonomous discovery and sourcing. (Page 69)
*   **Issuing Merchant Categories:** Understand Merchant Category Codes (MCCs) and how they are used for spending controls. (Page 35)
*   **Global Availability:** Explore options for using Stripe Issuing in different countries, including local and cross-border issuing. (Page 65)
*   **Stablecoin-backed Cards:** Issue prepaid or debit cards backed by stablecoin balances, integrating with Bridge or third-party wallets. (Page 81, Page 82, Page 83)
*   **ATM Usage:** Enable and use US-issued cards for ATM cash withdrawals. (Page 76)

### Stripe Connect and Treasury for Platforms Integration

*   **Set up Issuing and Connect:** Integrate Stripe Issuing with Stripe Connect to manage funds flows and compliance for connected accounts. (Page 41)
*   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and the cards issued to them. (Page 39)
*   **Cardholder Controls:** Ensure compliance with legal and regulatory guidelines for screening cardholder information. (Page 36)
*   **Inactive Connected Accounts Offboarding:** Learn how inactivity affects Issuing capabilities on connected accounts. (Page 38)
*   **Embed Card Management:** Use prebuilt UI components to embed Issuing card management functionality into your website. (Page 37)
*   **Fund Issuing Balances with Connect:** Learn how to fund connected accounts for Issuing. (Page 40)
*   **Treasury for Platforms Requirements:** Understand the compliance requirements and restrictions for using Treasury for Platforms. (Page 121)
*   **Accounts Structure:** Learn how the account components of Treasury for Platforms interact. (Page 86)
*   **Financial Account Features:** Discover the features available for financial accounts, enabling money movement and card attachment. (Page 87)
*   **Working with Issuing Cards:** Integrate Stripe Issuing with Treasury for Platforms to create physical and virtual cards. (Page 88)
*   **Platform Financial Accounts:** Understand the financial account provisioned for your platform. (Page 89)
*   **Working with Balances and Transactions:** Learn about financial account balances and how transactions affect them. (Page 91)
*   **Working with Connected Accounts:** Request the treasury capability and collect onboarding requirements for your connected accounts. (Page 92)
*   **Working with Financial Accounts:** Use financial accounts to store, send, and receive funds. (Page 93)
*   **Fifth Third Bank Integration:** Integrate with Fifth Third Bank for Treasury for Platforms. (Page 94, Page 95)
*   **Treasury for Platforms Compliance:** Adhere to marketing, design, and compliance guidelines for your Treasury for Platforms program. (Page 96)
*   **Handling Complaints:** Learn how to properly handle complaints related to Treasury for Platforms or Issuing. (Page 97)
*   **Marketing Treasury for Platforms:** Create compliant messaging for your users regarding Treasury for Platforms. (Page 98)
*   **Regulatory Receipts:** Understand hosted transaction receipts for regulated money movement. (Page 99)
*   **Moving Money:** Explore various methods for moving money into and out of financial accounts, including Inbound Transfers, Outbound Payments, and Outbound Transfers. (Page 101, Page 108, Page 115, Page 116, Page 111, Page 112)
*   **ACH NOC and SEC Handling:** Learn how external account information is updated via ACH Notifications of Change. (Page 113)
*   **Payouts and Top-ups:** Understand how to move money between payments balance and financial account balances. (Page 118)
*   **SetupIntents, PaymentMethods, and BankAccounts:** Set up money movements with Treasury for Platforms. (Page 119)

### Compliance and Guidelines

*   **Issuing and Treasury Product Marketing, Design, and Compliance Guidelines (US):** Adhere to guidelines for launching and maintaining compliant Issuing and Treasury programs in the US. (Page 71)
*   **Issuing Regulated Customer Notices:** Understand how to send regulatory notifications to your customers. (Page 72)
*   **Marketing Guidance (Europe/UK):** Follow marketing guidelines for Issuing programs in the UK and Europe. (Page 75)

### Testing and Support

*   **Test Your Issuing Integration:** Learn how to test your integration and simulate purchases in a sandbox environment. (Page 84)
*   **Test Your Credit Integration:** Validate your automated platform funding in testing environments for credit integrations. (Page 60)
*   **Customer Support for Issuing and Treasury for Platforms:** Resolve common Issuing and Treasury for Platforms questions and issues. (Page 1)
## Stripe Issuing and Treasury for Platforms

This documentation suite covers Stripe's Issuing and Treasury for Platforms products, offering comprehensive guidance on building and managing card programs and financial services for your business and your customers.

### Key Areas Covered:

*   **Issuing Overview:** Understand the core functionalities of Stripe Issuing, including how it works, its global availability, and how to get started.
*   **Integration Guides:** Detailed guides for integrating Issuing into specific use cases such as Embedded Finance, B2B Payments, and Fleet management.
*   **Card Management:** Learn how to choose between physical and virtual cards, customize card programs, manage card artwork, and handle card replacements and PINs.
*   **Funding and Balances:** Understand how to fund your Issuing balance, including options like pull-funded top-ups, push-funded top-ups, and Stripe balance transfers.
*   **Controls and Fraud Management:** Implement spending controls, lifecycle controls, advanced fraud tools, 3D Secure, and real-time authorization rules to manage risk and prevent fraud.
*   **Stripe Connect Integration:** Discover how to set up Issuing and Connect integrations, manage connected accounts, cardholders, and cards, and handle funding with Connect.
*   **Treasury for Platforms:** Explore how to use Treasury for Platforms to move money, set up financial accounts, manage balances and transactions, and integrate with bank partners like Fifth Third Bank.
*   **Credit Issuing:** Learn about Consumer Credit Issuing and how to manage credit programs for your customers, including credit terms, obligations, and reporting.
*   **Compliance and Guidelines:** Access essential information on product marketing, design, and compliance guidelines for both Issuing and Treasury for Platforms in the US, Europe, and UK.
*   **Testing and Support:** Find resources for testing your integration, accessing sample apps, and understanding customer support options.

### Core Concepts:

*   **Issuing:** Enables you to programmatically create, manage, and distribute payment cards for your business or your users.
*   **Treasury for Platforms:** A suite of APIs for Stripe Connect platforms that allows you to embed financial services, such as financial accounts and money movement capabilities, into your product.
*   **Connected Accounts:** Represent your users (businesses or individuals) within a Stripe Connect integration, allowing them to utilize Issuing and Treasury for Platforms features.
*   **Financial Accounts:** Separate account balances within Treasury for Platforms that hold funds for your connected accounts, enabling various money movement and card-spending functionalities.

This documentation aims to provide developers and businesses with the necessary information to leverage Stripe Issuing and Treasury for Platforms effectively, from initial setup to advanced fraud management and credit program implementation.
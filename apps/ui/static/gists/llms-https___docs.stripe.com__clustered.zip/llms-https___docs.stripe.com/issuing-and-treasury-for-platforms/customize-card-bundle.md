## Stripe Issuing and Treasury for Platforms: Card Program Management and Financial Services

This documentation suite provides comprehensive guidance on leveraging Stripe Issuing and Treasury for Platforms to create and manage sophisticated card programs and embedded financial services. It caters to developers and businesses looking to issue cards, manage funds, and build custom financial solutions for their users.

**Key Areas Covered:**

*   **Getting Started with Issuing and Treasury:**
    *   **Onboarding Overview:** Understand the essential steps and requirements to launch your Issuing or Treasury for Platforms integration.
    *   **Integration Guides:** Explore tailored guides for specific use cases like B2B Payments, Embedded Finance, and Fleet management.
    *   **Sample App:** Utilize a sample application to quickly understand and implement Issuing and Treasury for Platforms APIs.
    *   **Customer Support:** Find resources and guidance for resolving common Issuing and Treasury for Platforms issues.

*   **Card Program Management:**
    *   **Card Types:** Decide between physical and virtual cards, understanding their use cases and tradeoffs.
    *   **Card Customization:** Learn to customize your card program, including BIN setup, artwork templates, and choosing physical card bundles.
    *   **Issuing Cards:** Detailed instructions on creating and issuing both physical and virtual cards.
    *   **PIN Management:** Understand how cardholders can manage their Personal Identification Numbers.
    *   **Replacement Cards:** Procedures for handling expired, damaged, lost, or stolen cards.
    *   **Digital Wallets:** Integrate Issuing cards with digital wallets like Apple Pay and Google Pay.
    *   **Program Management Models:** Compare Stripe program management with processor-only integration to choose the best fit for your business.

*   **Funding and Financial Accounts:**
    *   **Issuing Balance:** Learn how to fund your Issuing balance to enable card spending.
    *   **Adding Funds:** Explore various funding options, including pull-funded top-ups, push-funded top-ups, and balance transfers.
    *   **Post-funding:** Understand how to post-fund your integration with Stripe, including the use of Dynamic Reserves.
    *   **Treasury for Platforms:** Set up and manage financial accounts for your platform and connected accounts, including understanding account structures and features.
    *   **Money Movement:** Comprehensive guides on moving money into and out of financial accounts using various methods like ACH, wires, and Stripe network transfers.

*   **Connect Integrations:**
    *   **Issuing and Connect:** Learn how to set up and manage Issuing integrations with Stripe Connect to issue cards on behalf of connected accounts.
    *   **Connected Accounts, Cardholders, and Cards:** Understand the relationship between connected accounts, cardholders, and the cards issued to them.
    *   **Funding Issuing Balances with Connect:** Specific guidance on funding Issuing balances for connected accounts.
    *   **Embedded Components:** Utilize pre-built UI components to embed Issuing card management into your website.
    *   **Inactive Connected Accounts:** Understand the process for offboarding inactive connected accounts.

*   **Credit Programs:**
    *   **Credit Consumer Issuing:** Explore the private preview of Stripe's consumer credit solution for launching credit programs.
    *   **Manage Credit Terms:** Learn how to configure and manage credit limits and terms for connected accounts.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for your connected accounts.
    *   **Available Credit and Flow of Funds:** Understand how credit and funds flow within your credit programs.
    *   **Test Credit Integration:** Validate your automated platform funding in testing environments.

*   **Fraud Management and Controls:**
    *   **Manage Fraud:** Understand transaction fraud risks and how to combat them using Stripe Issuing's tools.
    *   **Advanced Fraud Tools:** Leverage API signals and tooling to identify and prevent transaction fraud.
    *   **Issuing Authorization Rules:** Implement custom rules to limit authorization approvals and prevent unauthorized activity.
    *   **Real-time Authorizations:** Handle authorization requests in real-time using synchronous webhooks.
    *   **Fraud Challenges:** Enable additional verification steps for high-risk authorizations.
    *   **3D Secure:** Implement cardholder authentication for online transactions.
    *   **Spending Controls:** Set rules and limits for card and cardholder spending.
    *   **Lifecycle Controls:** Control automatic usage-based cancellation of virtual cards.
    *   **Token Management:** Manage network tokens for enhanced security in digital wallets.
    *   **Issuing Watchlist:** Understand Stripe's automatic screening against sanctions lists.

*   **Compliance and Guidelines:**
    *   **Product Marketing, Design, and Compliance Guidelines:** Adhere to essential guidelines for launching compliant Issuing and Treasury programs.
    *   **Marketing Guidance (Europe/UK):** Specific marketing guidelines for Issuing programs in the UK and Europe.
    *   **Regulated Customer Notices:** Understand how to send regulatory notifications to your customers.

*   **Transactions and Purchases:**
    *   **Issuing Authorizations:** Learn how authorization requests are handled.
    *   **Issuing Transactions:** Understand the lifecycle of transactions after authorization.
    *   **Issuing Disputes:** Manage transaction disputes through the Dashboard or API.
    *   **ATM Usage:** Enable and manage ATM cash withdrawals for US-issued cards.
    *   **Enriched Merchant Data:** Utilize comprehensive merchant data for fraud prevention and insights.

*   **Specific Use Cases and Features:**
    *   **Consumer Prepaid Debit Cards:** Issue prepaid debit cards for rewards, disbursements, or branded card programs.
    *   **Stablecoin-backed Cards:** Explore issuing cards backed by stablecoin balances for global reach and flexible money movement.
    *   **Issuing for Agents:** Provide programmable cards with built-in controls for agents to make purchases on your behalf.
    *   **Processor-only Issuing:** Integrate as a processor to manage your Issuing program's regulatory requirements.
    *   **Global Availability:** Understand options for issuing cards in different countries, including local and cross-border solutions.
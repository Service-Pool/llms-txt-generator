## Stripe Issuing and Treasury for Platforms

This documentation suite covers Stripe's Issuing and Treasury for Platforms products, offering comprehensive guides on creating and managing payment cards, handling financial accounts, and facilitating money movement for businesses and their connected accounts.

### Key Features and Functionality:

*   **Issuing Cards:**
    *   **Card Types:** Create and manage both virtual and physical cards for various use cases, including B2B payments, fleet management, and consumer prepaid programs.
    *   **Customization:** Design custom card programs with options for card body, artwork, and bundles.
    *   **Controls:** Implement spending controls, lifecycle controls, and advanced fraud tools to manage card usage and mitigate risk.
    *   **Real-time Authorizations:** Handle authorization requests in real-time through webhooks for immediate decision-making.
    *   **Fraud Management:** Utilize Stripe's tools and controls to combat transaction fraud and protect against unauthorized use.
    *   **Digital Wallets:** Support adding Issuing cards to digital wallets like Apple Pay and Google Pay.
    *   **PIN Management:** Allow cardholders to manage their Personal Identification Numbers.
    *   **3D Secure:** Implement an additional layer of authentication for online transactions.
    *   **Address Validation:** Ensure accurate delivery of physical cards with built-in address normalization and validation.
    *   **Replacement Cards:** Manage the process of replacing expired, damaged, lost, or stolen cards.
    *   **Merchant Categories:** Understand and utilize Merchant Category Codes (MCCs) for spending controls.
    *   **ATM Usage:** Enable and manage ATM cash withdrawals for US-issued cards.
    *   **Disputes:** Handle transaction disputes through the Dashboard or API.
    *   **Enriched Merchant Data:** Leverage detailed merchant data for improved fraud prevention and insights.
    *   **Issuing Watchlist:** Understand the automatic screening process against sanctions lists.
    *   **Marketing Guidelines:** Adhere to specific marketing guidelines for Issuing programs in the UK and Europe.
    *   **Consumer Issuing:** Explore options for consumer prepaid debit cards and credit programs.
    *   **Agent Issuing:** Provide programmable cards with built-in controls for agents.
    *   **Stablecoin-backed Cards:** Issue cards backed by stablecoin balances, integrated with third-party wallets.
    *   **Testing:** Simulate card programs and purchases in a sandbox environment.

*   **Treasury for Platforms:**
    *   **Financial Accounts:** Set up and manage financial accounts for your platform and connected accounts to store funds.
    *   **Money Movement:** Facilitate inbound and outbound transfers, including ACH, wire transfers, and Stripe network transfers.
    *   **Account Management:** Understand the structure of platform and connected accounts, and manage their capabilities.
    *   **Bank Partnerships:** Integrate with banking partners like Fifth Third Bank.
    *   **Compliance:** Navigate regulatory requirements, marketing guidelines, and complaint handling.
    *   **Fraud Management:** Implement best practices for managing fraud within Treasury for Platforms.
    *   **Sample Integrations:** Utilize sample applications and guides to build your integration.

*   **Issuing and Connect Integration:**
    *   **Onboarding:** Set up and onboard connected accounts for Issuing and Treasury for Platforms.
    *   **Cardholder Management:** Create and manage cardholders and their associated cards.
    *   **Funding:** Fund Issuing balances for connected accounts using various methods.
    *   **Embedded Components:** Embed Issuing card management functionality into your website.
    *   **Inactive Account Management:** Understand how inactivity affects connected accounts' Issuing capabilities.
    *   **Terms of Service:** Ensure acceptance of Issuing terms of service for connected accounts.

*   **Credit Features:**
    *   **Credit Consumer Issuing:** Launch credit programs for your consumers.
    *   **Manage Credit Terms:** Configure credit limits and intervals for connected accounts.
    *   **Manage Account Obligations:** Track credit spend, lifecycle, and balances for connected accounts.
    *   **Report Credit Decisions:** Record application and decision details for credit underwriting.
    *   **Test Credit Integration:** Validate your credit integration in testing environments.

### Integration Guides and Examples:

*   **B2B Payments Integration Guide:** Build a B2B payments integration with Issuing.
*   **Embedded Finance Integration Guide:** Create an embedded financial services integration with Issuing and Treasury for Platforms.
*   **Fleet Integration Guide:** Build a fleet financial services integration with Issuing.
*   **Sample App:** Use the Issuing and Treasury for Platforms sample app to onboard customers, issue cards, and make outbound payments.
*   **Connect Integrations:** Set up Issuing and Connect integrations, fund Issuing balances with Connect, and manage cardholder controls.

### Support and Compliance:

*   **Customer Support:** Access resources for customer support for Issuing and Treasury for Platforms.
*   **Compliance Guidelines:** Understand product marketing, design, and compliance guidelines for both Issuing and Treasury for Platforms in the US and Europe/UK.
*   **Regulated Customer Notices:** Learn about sending regulatory notifications to your customers.

This documentation suite provides a comprehensive resource for developers and businesses looking to leverage Stripe's Issuing and Treasury for Platforms products to build innovative financial solutions.
## Stripe Connect: Managing Connected Accounts and Platform Integrations

This documentation set provides comprehensive guidance for platforms and marketplaces looking to integrate with Stripe Connect. It covers everything from initial setup and account management to payment processing, risk management, and tax reporting for connected accounts.

### Core Concepts and Account Management

*   **Understanding Connect Account Types:** Explore the different types of connected accounts (Standard, Express, Custom) and their implications for your platform's responsibilities and user experience.
*   **Creating and Managing Connected Accounts:** Learn how to create, onboard, and manage connected accounts, including the use of Accounts v2 API for flexible configurations and centralized identity data.
*   **Account Capabilities and Configurations:** Understand how to enable specific functionalities for connected accounts by requesting and configuring capabilities.
*   **Identity Verification and Compliance:** Delve into the requirements for identity verification, including additional verifications and handling verification updates to maintain compliance.
*   **Dashboard Access and Customization:** Learn how to provide connected accounts with access to Stripe-hosted or custom dashboards, and how to customize the Express Dashboard for a branded experience.

### Payment Processing and Financial Operations

*   **Charges in Connect:** Understand the different charge types (Direct, Destination, Separate Charges and Transfers) and how they affect fund flow, fees, and customer statements.
*   **Handling Multiple Currencies:** Learn how to manage currency conversions, use Adaptive Pricing, and leverage the FX Quotes API for localized pricing.
*   **Account Balances and Payouts:** Gain insights into how account balances work in Connect, and manage payouts to connected accounts, including instant payouts and multi-currency settlement.
*   **Application Fees and Monetization:** Discover how to collect application fees and implement various monetization strategies, such as SaaS subscriptions.
*   **Debit Connected Accounts:** Learn how to collect funds from connected accounts to cover expenses or adjustments.
*   **Setting Reserves:** Understand how to temporarily reserve a portion of a connected account's funds to cover potential refunds and disputes.

### Risk Management and Compliance

*   **Risk and Liability Management:** Understand how to manage risk and liability for your platform, including options for negative balance liability and best practices for fraud prevention.
*   **Managed Risk:** Learn how Stripe can manage risk for your connected accounts, reducing your platform's liability for negative balances.
*   **Disputes on Connect:** Understand how disputes are handled for different charge types and your platform's responsibilities.
*   **Tax Reporting:** Navigate the complexities of tax reporting, including 1099 forms, state requirements, and platform tax reporting for international regulations.

### Integration and Development

*   **Designing Your Integration:** Explore different integration strategies, including building fully embedded experiences, using embedded components, and migrating from Accounts v1 to v2.
*   **Making API Calls:** Learn how to make API calls for connected accounts using the `Stripe-Account` header.
*   **Testing Stripe Connect:** Understand how to effectively test your Connect integration in sandbox environments.
*   **Webhooks:** Learn how to use Connect webhooks to receive real-time notifications of Stripe activity.
*   **Embedded Components:** Discover the range of supported embedded components that allow you to integrate Stripe functionality directly into your platform's UI.

This documentation suite aims to empower developers and businesses to build robust and compliant payment solutions using Stripe Connect.
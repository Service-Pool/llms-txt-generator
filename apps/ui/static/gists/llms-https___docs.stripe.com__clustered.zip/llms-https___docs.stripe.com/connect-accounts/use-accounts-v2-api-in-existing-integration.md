## Stripe Connect: Managing Connected Accounts and Payments

This documentation suite provides comprehensive guidance on utilizing Stripe Connect to build and manage platforms, marketplaces, and SaaS applications. It covers essential aspects of connected account management, payment processing, onboarding, risk management, and tax reporting.

### Key Areas of Focus:

*   **Connected Account Management:**
    *   **Account Types:** Understand the differences between Standard, Express, and Custom account types and choose the best fit for your platform.
    *   **Onboarding:** Learn about various onboarding strategies, including Stripe-hosted, embedded, and API-based onboarding, to efficiently bring users onto your platform.
    *   **Account Capabilities:** Configure and manage the functionalities available to your connected accounts, such as payment processing, payouts, and tax reporting.
    *   **Verification:** Understand the identity verification requirements and how to handle them through API calls, tokens, or Stripe-hosted flows.
    *   **Dashboard Access:** Configure how connected accounts access their Stripe services, whether through the full Stripe Dashboard, the Express Dashboard, or custom interfaces.

*   **Payment Processing:**
    *   **Charge Types:** Explore direct charges, destination charges, and separate charges and transfers to determine the most suitable method for your platform's needs.
    *   **Application Fees:** Learn how to collect application fees to monetize your platform and offset Stripe processing costs.
    *   **Payment Methods:** Enable and manage various payment methods for your connected accounts, including dynamic payment methods and localized options.
    *   **Subscriptions:** Integrate Stripe Billing to manage recurring subscription fees for your connected accounts.
    *   **Invoices:** Create invoices for connected accounts, with options for taking application fees.

*   **Financial Management:**
    *   **Account Balances:** Understand how account balances work in Connect, including pending and available funds.
    *   **Payouts:** Manage payouts to connected accounts, including scheduling automatic payouts, performing manual payouts, and enabling instant payouts.
    *   **Account Debits and Reserves:** Learn how to debit connected accounts for services or to recover funds, and how to set reserves to mitigate risk.
    *   **Platform Pricing Tools:** Configure custom pricing strategies, including application fees and network cost passthrough, for your connected accounts.

*   **Risk and Compliance:**
    *   **Managed Risk:** Leverage Stripe's Managed Risk solution to offload financial risk and liability for negative balances on connected accounts.
    *   **Dispute Management:** Understand how disputes are handled in Connect and your responsibilities for managing them.
    *   **Tax Reporting:** Comply with tax reporting obligations by generating, filing, and delivering tax forms (e.g., 1099-K, 1099-MISC, 1099-NEC) for your connected accounts.

*   **API and Integration:**
    *   **Accounts v2 API:** Utilize the Accounts v2 API for a unified approach to managing connected accounts and customers.
    *   **Embedded Components:** Integrate pre-built UI components into your platform to provide connected accounts with a seamless experience for managing their finances, payments, and compliance.
    *   **Webhooks:** Implement webhooks to receive real-time notifications of events related to your connected accounts and platform.
    *   **Testing:** Utilize Stripe's testing tools and sandboxes to thoroughly test your Connect integration before going live.

This documentation suite aims to empower developers and businesses to build robust and scalable platforms using Stripe Connect, ensuring efficient payment processing, streamlined operations, and compliance with financial regulations.
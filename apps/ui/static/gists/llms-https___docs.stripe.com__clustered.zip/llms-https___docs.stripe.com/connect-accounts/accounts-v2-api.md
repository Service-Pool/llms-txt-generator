## Stripe Connect: Managing Connected Accounts and Platform Functionality

This documentation set focuses on Stripe Connect, a platform that enables businesses to manage payments and move money between multiple parties, such as sellers, customers, and service providers. It covers the core aspects of setting up and managing connected accounts, processing payments, handling payouts, and leveraging various Stripe features to build robust SaaS platforms and marketplaces.

### Key Concepts and Features:

*   **Connected Accounts:** Understand the different types of connected accounts (Standard, Express, Custom) and how to create, onboard, and manage them. This includes leveraging the Accounts v2 API for flexible account configurations and centralized identity data.
*   **Payment Processing:** Learn about various charge types (Direct, Destination, Separate Charges and Transfers) and how they impact fund flow, statement descriptors, and dispute handling. Explore capabilities for handling multiple currencies, creating payment links, and integrating with Stripe Billing for subscriptions.
*   **Onboarding and Verification:** Discover options for onboarding connected accounts, including Stripe-hosted onboarding, embedded onboarding, and API-based onboarding. Understand the importance of identity verification, additional verifications, and handling upcoming requirement updates to maintain compliance.
*   **Account Management and Dashboard:** Explore how to manage connected accounts through the Stripe Dashboard, including filtering, reviewing, and taking action on accounts. Learn about customizing the Express Dashboard and providing platform controls for connected accounts with full Stripe Dashboard access.
*   **Risk and Liability Management:** Understand how to manage risk and liability for your platform, including options for negative balance liability, using Stripe Radar for fraud detection, and implementing Managed Risk solutions.
*   **Tax Reporting:** Get started with tax reporting obligations, including understanding 1099 forms (K, MISC, NEC), managing tax form settings, filing with states, and delivering tax forms to connected accounts.
*   **Embedded Components:** Utilize Connect embedded components to seamlessly integrate Stripe functionality into your own website or application, allowing connected accounts to manage payments, disputes, payouts, and more without leaving your platform.
*   **Platform Pricing and Monetization:** Learn how to set platform processing fees, collect application fees, and implement various monetization strategies using the Platform Pricing Tool.

### Core Tasks and Workflows:

*   **Building a Marketplace:** Step-by-step guidance on creating a marketplace, from setting up connected accounts and handling payments to managing payouts and disputes.
*   **Building a SaaS Platform:** Instructions on how to build a SaaS platform, enabling merchants to accept direct payments, collect platform fees, and manage their businesses through Stripe.
*   **Handling Payments:** Detailed explanations on accepting payments using different charge types, creating invoices, and utilizing payment links.
*   **Managing Payouts:** Learn how to manage payouts to connected accounts, including scheduling automatic payouts, performing manual payouts, and offering instant payouts.
*   **Handling Disputes and Refunds:** Understand the process of managing disputes and refunds, including responsibilities based on charge types and platform configurations.
*   **Testing and Integration:** Guidance on testing Stripe Connect integrations, including account creation, identity verification, payouts, and using Sandboxes.

This documentation set provides a comprehensive resource for developers and businesses looking to leverage Stripe Connect to build powerful and compliant financial solutions.
## Documentation Plan: Stripe Connect

This documentation plan outlines a comprehensive set of resources for developers building with Stripe Connect, focusing on platform and marketplace integrations. The goal is to provide clear, actionable guidance on managing connected accounts, processing payments, handling finances, and ensuring compliance.

---

### **I. Getting Started with Stripe Connect**

This section provides foundational information for new users of Stripe Connect, covering the core concepts and initial setup.

*   **Overview of Stripe Connect:**
    *   [Platforms and marketplaces with Stripe Connect](/connect)
    *   [How Connect works](/connect/how-connect-works)
    *   [Introduction to SaaS platforms and marketplaces with Connect](/connect/saas-platforms-and-marketplaces)
*   **Choosing Your Integration Type:**
    *   [SaaS platform quickstart](/connect/saas/quickstart)
    *   [Marketplace quickstart](/connect/marketplace/quickstart)
    *   [Interactive platform guide](/connect/interactive-platform-guide)
*   **Account Types:**
    *   [Connect account types](/connect/account-types)
    *   [Using Connect with Standard connected accounts](/connect/standard-accounts)
    *   [Using Connect with Express connected accounts](/connect/express-accounts)
    *   [Using Connect with Custom connected accounts](/connect/custom-accounts)
*   **Onboarding Connected Accounts:**
    *   [Choose your onboarding configuration](/connect/onboarding)
    *   [Stripe-hosted onboarding](/connect/hosted-onboarding)
    *   [Embedded onboarding](/connect/embedded-onboarding)
    *   [API onboarding](/connect/api-onboarding)
    *   [Migrate your onboarding and requirement update flows to Stripe-hosted or embedded onboarding](/connect/migrate-from-api-onboarding)
    *   [Standard accounts guide](/connect/required-updates/standard-accounts-guide)
    *   [Onboarding solutions for Custom accounts](/connect/custom/onboarding)
    *   [Stripe-hosted onboarding for Custom accounts](/connect/custom/hosted-onboarding)
*   **Account Capabilities and Configurations:**
    *   [Account capabilities and configurations](/connect/account-capabilities)
    *   [Configure the behavior of connected accounts](/connect/accounts-v2/connected-account-configuration)
    *   [Connect and the Accounts v2 API](/connect/accounts-v2)
    *   [Migrate your Connect integration to use controller properties instead of account types](/connect/migrate-to-controller-properties)
    *   [Service agreement types](/connect/service-agreement-types)
*   **Testing Stripe Connect:**
    *   [Testing Stripe Connect](/connect/testing)
    *   [Testing account verification during API onboarding](/connect/testing-verification)

---

### **II. Core Connect Functionality**

This section details the essential features for managing payments, finances, and user experiences within a Connect integration.

*   **Account Management:**
    *   [Account management](/connect/supported-embedded-components/account-management)
    *   [Manage connected accounts with the Dashboard](/connect/dashboard)
    *   [View all accounts](/connect/dashboard/viewing-all-accounts)
    *   [Review connected accounts](/connect/dashboard/review-actionable-accounts)
    *   [Manage individual accounts](/connect/dashboard/managing-individual-accounts)
    *   [Connected account filters](/connect/dashboard/filters)
    *   [Change the owner of a connected account](/connect/dashboard/change-connected-account-owner)
    *   [Represent customers using Account objects](/connect/use-accounts-as-customers)
*   **Payments:**
    *   [Understand how charges work in a Connect integration](/connect/charges)
    *   [Create direct charges](/connect/direct-charges)
    *   [Create destination charges](/connect/destination-charges)
    *   [Create separate charges and transfers](/connect/separate-charges-and-transfers)
    *   [Create invoices with Connect](/connect/invoices)
    *   [Create payment links with Connect](/connect/payment-links)
    *   [Use Radar with Connect](/connect/radar)
    *   [Fee behavior on connected accounts](/connect/direct-charges-fee-payer-behavior)
    *   [Set merchant category codes](/connect/setting-mcc)
    *   [Payment method support for platforms and marketplaces](/payments/payment-methods/payment-method-connect-support)
    *   [Enable payment methods for connected accounts](/connect/payment-methods)
    *   [Multiple payment method configurations](/connect/multiple-payment-method-configurations)
    *   [Embed the payment methods settings component](/connect/embed-payment-method-settings)
    *   [Update to use dynamic payment methods](/connect/dynamic-payment-methods)
    *   [Accept titres-restaurant payments with Connect](/connect/accept-titres-restaurant-payments-with-connect)
    *   [SCA migration guide for Connect platforms](/strong-customer-authentication/connect-platforms)
*   **Payouts and Balances:**
    *   [Understanding Connect account balances](/connect/account-balances)
    *   [Payouts to connected accounts](/connect/payouts-connected-accounts)
    *   [Instant Payouts for Connect](/connect/instant-payouts)
    *   [Add funds to your platform balance](/connect/top-ups)
    *   [Debit connected accounts](/connect/account-debits)
    *   [Set reserves on your connected accounts](/connect/connected-account-reserves)
    *   [Payout statement descriptors](/connect/payout-statement-descriptors)
    *   [Manage payout accounts for connected accounts](/connect/payouts-bank-accounts)
    *   [Multi-currency settlement for Connect platforms and marketplaces](/connect/multicurrency-settlement)
    *   [Work with multiple currencies](/connect/currencies)
    *   [Use the FX Quotes API in Connect](/connect/currencies/fx-quotes-api)
    *   [Use Adaptive Pricing with Connect](/connect/currencies/adaptive-pricing)
*   **Disputes:**
    *   [Disputes on Connect platforms](/connect/disputes)
    *   [Disputes for a payment](/connect/supported-embedded-components/disputes-for-a-payment)
    *   [Disputes list](/connect/supported-embedded-components/disputes-list)
    *   [Smart Disputes fee passthrough](/connect/smart-disputes-fee-passthrough)
*   **Tax Reporting:**
    *   [Get started with tax reporting](/connect/get-started-tax-reporting)
    *   [US tax reporting for Connect platforms](/connect/tax-reporting)
    *   [1099-K form state requirements](/connect/1099-K)
    *   [1099-MISC form state requirements](/connect/1099-MISC)
    *   [1099-NEC form state requirements](/connect/1099-NEC)
    *   [File your 1099 tax forms](/connect/file-tax-forms)
    *   [File tax forms with states](/connect/tax-forms-state-requirements)
    *   [Update and create 1099 tax forms](/connect/modify-tax-forms)
    *   [Correct tax forms](/connect/correct-tax-forms)
    *   [Split tax forms](/connect/split-tax-forms)
    *   [Deliver your 1099 tax forms](/connect/deliver-tax-forms)
    *   [Deliver tax forms with an interface built by Stripe](/connect/express-dashboard-taxes)
    *   [1099 Tax Reporting embedded components walkthrough](/connect/platform-embedded-taxes-walkthrough)
    *   [1099 Tax Reporting Express Dashboard walkthrough](/connect/platform-express-dashboard-taxes-walkthrough)
    *   [1099 tax support and communication guide](/connect/platform-express-dashboard-taxes)
    *   [Required Verification Information for Taxes](/connect/required-verification-information-taxes)
    *   [Tax ID Additional Verification](/connect/connect-tax-id-onboarding)
    *   [Connect W-8 and W-9](/connect/connect-w8-w9-onboarding)
    *   [Platform tax reporting for Connect platforms](/connect/platform-tax-reporting)
    *   [Configure tax form settings](/connect/tax-form-settings)
    *   [Tax year changeover](/connect/tax-year-changeover)

---

### **III. Advanced Integrations and Customization**

This section covers more advanced topics, including customizing the user experience, handling complex scenarios, and leveraging specific Stripe features.

*   **Embedded Components:**
    *   [Get started with Connect embedded components](/connect/get-started-connect-embedded-components)
    *   [Supported Connect embedded components](/connect/supported-embedded-components)
    *   [Customize Connect embedded components](/connect/customize-connect-embedded-components)
    *   [Support dark mode](/connect/embedded-appearance-support-dark-mode)
    *   [Supported appearance options](/connect/embedded-appearance-options)
    *   [Account management](/connect/supported-embedded-components/account-management)
    *   [Account onboarding](/connect/supported-embedded-components/account-onboarding)
    *   [App install](/connect/supported-embedded-components/app-install)
    *   [App viewport](/connect/supported-embedded-components/app-viewport)
    *   [Balances](/connect/supported-embedded-components/balances)
    *   [Balance report](/connect/supported-embedded-components/balance-report)
    *   [Payout reconciliation report](/connect/supported-embedded-components/payout-reconciliation-report)
    *   [Documents](/connect/supported-embedded-components/documents)
    *   [Export tax transactions](/connect/supported-embedded-components/export-tax-transactions)
    *   [Financial account](/connect/supported-embedded-components/financial-account)
    *   [Financial account transactions](/connect/supported-embedded-components/financial-account-transactions)
    *   [Instant payouts promotion](/connect/supported-embedded-components/instant-payouts-promotion)
    *   [Issuing card](/connect/supported-embedded-components/issuing-card)
    *   [Issuing cards list](/connect/supported-embedded-components/issuing-cards-list)
    *   [Network cost passthrough report](/connect/supported-embedded-components/network-cost-passthrough-report)
    *   [Notification banner](/connect/supported-embedded-components/notification-banner)
    *   [Payment details](/connect/supported-embedded-components/payment-details)
    *   [Payment method settings](/connect/supported-embedded-components/payment-method-settings)
    *   [Payments](/connect/supported-embedded-components/payments)
    *   [Payout details](/connect/supported-embedded-components/payout-details)
    *   [Payouts](/connect/supported-embedded-components/payouts)
    *   [Payouts list](/connect/supported-embedded-components/payouts-list)
    *   [Product tax code selector](/connect/supported-embedded-components/product-tax-code-selector)
    *   [Reporting chart](/connect/supported-embedded-components/reporting-chart)
    *   [Tax registrations](/connect/supported-embedded-components/tax-registrations)
    *   [Tax settings](/connect/supported-embedded-components/tax-settings)
    *   [Tax threshold monitoring](/connect/supported-embedded-components/tax-threshold-monitoring)
*   **Platform Administration and Monetization:**
    *   [Platform pricing tool](/connect/platform-pricing-tools)
    *   [Create pricing groups](/connect/platform-pricing-tools/pricing-groups)
    *   [Define a custom pricing strategy](/connect/platform-pricing-tools/pricing-schemes)
    *   [Test pricing schemes](/connect/platform-pricing-tools/testing)
    *   [Card product codes in platform pricing tools](/connect/platform-pricing-tools/card-product-codes)
    *   [Connect margin reports](/connect/margin-reports)
    *   [Platform earnings report](/connect/platform-earnings-report)
    *   [Network cost passthrough](/connect/network-cost-passthrough-platforms)
    *   [Charge SaaS fees to your connected accounts](/connect/integrate-billing-connect)
*   **Risk and Liability Management:**
    *   [Risk and liability management with Connect](/connect/risk-management)
    *   [Managed Risk](/connect/risk-management/managed-risk)
    *   [API-based Managed Risk](/connect/risk-management/api-managed-risk)
    *   [Embedded Managed Risk](/connect/embedded-risk)
    *   [Best practices for risk management](/connect/risk-management/best-practices)
    *   [Pause payments and payouts on connected accounts](/connect/pausing-payments-or-payouts-on-connected-accounts)
    *   [Understand the merchant of record in a Connect integration](/connect/merchant-of-record)
*   **Verification and Compliance:**
    *   [Identity verification for connected accounts](/connect/identity-verification)
    *   [Handle verification updates](/connect/handle-verification-updates)
    *   [Handle verification with the API](/connect/handling-api-verification)
    *   [Handle verification with tokens](/connect/account-tokens)
    *   [Additional verifications](/connect/additional-verifications)
    *   [Identity Document Additional Verifications](/connect/additional-verifications/identity-document)
    *   [Upcoming requirements updates](/connect/upcoming-requirements-updates)
*   **Email Communications:**
    *   [Connected account email configuration](/connect/account-emails-config)
    *   [Email communications in embedded Connect integrations](/connect/embedded-comms)
*   **API and SDK Usage:**
    *   [Making API calls for connected accounts](/connect/authentication)
    *   [Connect webhooks](/connect/webhooks)
    *   [Connect OAuth reference](/connect/oauth-reference)
    *   [OAuth changes for platform-controlled Standard accounts](/connect/oauth-changes-for-standard-platforms)
    *   [Using OAuth with Standard accounts](/connect/oauth-standard-accounts)
    *   [Accounts API Argument Changes](/connect/required-updates/accounts-arguments)
    *   [Connect platforms using the Sources API](/sources/connect)
*   **Dashboard Customization:**
    *   [Stripe Dashboard customization](/connect/stripe-dashboard)
    *   [Platform controls in the Stripe Dashboard](/connect/platform-controls-for-stripe-dashboard-accounts)
    *   [Express Dashboard](/connect/express-dashboard)
    *   [Integrate the Express Dashboard in your platform](/connect/integrate-express-dashboard)
    *   [Customize the Express Dashboard](/connect/customize-express-dashboard)

---

### **IV. Specific Business Models**

This section provides tailored guidance for different platform types.

*   **SaaS Platforms:**
    *   [Build a SaaS platform](/connect/saas)
    *   [Build a SaaS platform with Accounts v1](/connect/saas/tasks/create)
    *   [SaaS platform essential integration tasks](/connect/saas/essential-tasks)
    *   [Enable merchants on your platform to accept payments directly](/connect/saas/tasks/accept-payment)
    *   [Collect platform fees](/connect/saas/tasks/app-fees)
    *   [Charge SaaS fees to your connected accounts](/connect/saas/tasks/service-fee)
    *   [Pay out to connected accounts](/connect/saas/tasks/payout)
    *   [Handle refunds and disputes](/connect/saas/tasks/refunds-disputes)
    *   [Enable in-context shopping on AI agents](/connect/saas/tasks/enable-in-context-selling-on-ai-agents)
*   **Marketplaces:**
    *   [Build a marketplace](/connect/marketplace)
    *   [Build a marketplace](/connect/end-to-end-marketplace)
    *   [Marketplace essential integration tasks](/connect/marketplace/essential-tasks)
    *   [Create connected accounts for your marketplace](/connect/marketplace/tasks/create)
    *   [Set up Dashboard access](/connect/marketplace/tasks/dashboard)
    *   [Onboard your connected account](/connect/marketplace/tasks/onboard)
    *   [Accept a payment](/connect/marketplace/tasks/accept-payment)
    *   [Accept a payment using destination charges](/connect/marketplace/tasks/accept-payment/destination-charges)
    *   [Accept a payment using separate charges and transfers](/connect/marketplace/tasks/accept-payment/separate-charges-and-transfers)
    *   [Enable payment methods](/connect/marketplace/tasks/enable-payment-methods)
    *   [Collect application fees](/connect/marketplace/tasks/app-fees)
    *   [Pay out to connected accounts](/connect/marketplace/tasks/payout)
    *   [Handle refunds and disputes](/connect/marketplace/tasks/refunds-disputes)

---

### **V. Additional Resources**

This section includes supplementary information and best practices.

*   **Capital:**
    *   [Capital components](/connect/supported-embedded-components/capital)
*   **Financial Services:**
    *   [Financial Account](/connect/supported-embedded-components/financial-account)
    *   [Financial account transactions](/connect/supported-embedded-components/financial-account-transactions)
*   **Issuing:**
    *   [Issuing card](/connect/supported-embedded-components/issuing-card)
    *   [Issuing cards list](/connect/supported-embedded-components/issuing-cards-list)
*   **General Best Practices:**
    *   [Integration recommendations](/connect/integration-recommendations)
    *   [Migrate to a supported Connect configuration](/connect/configuration-migration-guide)
    *   [Embedded managed risk](/connect/embedded-risk)
    *   [Embedded Connect Support](/connect/embedded-support)
    *   [Connect embedded components](/connect/connect-embedded-components/quickstart)

---
## Stripe Connect: Managing Your Platform and Connected Accounts

This documentation suite provides a comprehensive guide to leveraging Stripe Connect for building robust platforms and marketplaces. It covers everything from initial setup and account management to payment processing, risk management, and tax reporting.

### Core Concepts and Setup

*   **Understanding Stripe Connect:** An overview of how Stripe Connect facilitates multiparty integrations, enabling businesses to manage payments and move money between various entities.
*   **Connect Account Types:** Explore the different account types (Standard, Express, Custom) and their implications for platform liability, integration effort, and user experience.
*   **Accounts v2 API:** Learn about the benefits of the Accounts v2 API for creating unified identities, flexible account configurations, and a single API for managing both connected accounts and customers.
*   **Onboarding Configurations:** Understand the various onboarding options available, including Stripe-hosted onboarding, embedded onboarding, and API-based onboarding, to choose the best fit for your platform.
*   **Service Agreement Types:** Learn how service agreements (full vs. recipient) establish the relationship between Stripe and your platform's users, impacting account capabilities.

### Payment Processing and Money Movement

*   **Charge Types:** Understand the different charge types (Direct, Destination, Separate Charges and Transfers) and how they affect fund distribution, statement descriptors, and dispute handling.
*   **Collecting Application Fees:** Learn how to monetize your platform by collecting application fees from transactions using the Platform Pricing Tool or directly in PaymentIntents.
*   **Handling Multiple Currencies:** Manage currency conversions and present prices in local currencies using Adaptive Pricing and the FX Quotes API.
*   **Payouts:** Configure automatic or manual payouts, manage external accounts, and offer instant payouts to your connected accounts.
*   **Account Balances:** Understand how pending and available balances work for both platform and connected accounts.
*   **Debit Connected Accounts:** Learn how to collect funds from connected accounts to cover refunds, service charges, or other adjustments.
*   **Set Reserves:** Utilize reserves to mitigate the risk of negative connected account balances by temporarily holding funds.
*   **Add Funds to Platform Balance:** Learn how platforms can add funds to their balance to cover payouts or other operational needs.

### Managing Connected Accounts and User Experience

*   **Account Management:** Utilize embedded components for account management, allowing connected accounts to view and edit their details.
*   **Customizing Embedded Components:** Customize the appearance and behavior of embedded components to match your platform's branding.
*   **Dashboard Access:** Configure Dashboard access for connected accounts, offering them the Express Dashboard or a custom interface built with embedded components or the API.
*   **Embedded Onboarding:** Provide a seamless onboarding experience for connected accounts within your platform's UI.
*   **Handle Verification Updates:** Stay compliant by managing changes to verification requirements and guiding connected accounts through the process.
*   **API Onboarding:** Build your own custom onboarding flows using Stripe's APIs for complete control.
*   **Handle Verification with Tokens:** Securely collect account details using tokens to ensure PII doesn't touch your servers.

### Risk Management and Compliance

*   **Risk and Liability Management:** Understand how to manage risk and liability for your platform, including options for negative balance responsibility.
*   **Managed Risk:** Leverage Stripe's end-to-end business risk management solution to monitor, mitigate, and recover negative balances.
*   **Understand the Merchant of Record:** Clarify the merchant of record's role and responsibilities in Connect integrations to comply with payment network rules.
*   **Additional Verifications:** Implement identity verification checks, such as government-issued ID document verification, to reduce fraud and meet compliance requirements.
*   **Upcoming Requirements Updates:** Stay informed about changes to verification requirements and their impact on your integration.
*   **Pause Payments and Payouts:** Control the flow of funds for connected accounts to support risk management efforts.

### Tax Reporting

*   **Get Started with Tax Reporting:** Utilize Stripe's 1099 tax reporting product to create, file, and deliver tax forms for your connected accounts.
*   **File Tax Forms:** Learn how to file 1099 forms with the IRS and state tax authorities, ensuring accuracy and compliance.
*   **Deliver Tax Forms:** Understand the requirements for delivering tax forms to payees, including e-delivery and postal delivery options.
*   **Tax Form Settings:** Configure settings for 1099 forms, including default form types and delivery preferences.
*   **Required Verification Information for Taxes:** Identify the necessary account information for US federal 1099 tax reporting.
*   **Platform Tax Reporting:** Prepare reports for regulations like DAC7 and other OECD requirements for sellers in various countries.

### Testing and Migration

*   **Testing Stripe Connect:** Utilize Sandboxes and test API keys to simulate live mode and test various Connect integration flows.
*   **Migrate to a Supported Configuration:** Learn how to update your Connect integration to leverage new features and configurations.
*   **Migrate from API Onboarding:** Transition your API-based onboarding flows to Stripe-hosted or embedded onboarding to reduce maintenance effort.
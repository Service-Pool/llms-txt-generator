```markdown
## Handle verification with tokens

Connect platforms can use Stripe.js, the API, or mobile client libraries to securely collect account details from their users.

### Before we can enable charges and payouts for connected accounts, you must fulfill Know Your Customer (KYC) requirements. To do so, provide identity verification information about your accounts to Stripe, which we then verify. You can perform this task with Account Tokens and Person Tokens. Tokens ensure that personally identifiable information (PII) doesn’t touch your servers, so your integration can operate securely. These tokens also allow Stripe to more accurately detect potential fraud.

You can only use tokens for:
* Legal entity details (information about the business or individual)
* Person details
* Indicating acceptance of the Stripe Connected Account Agreement

You can’t use tokens for any other account information, including:
* Configuration settings on the account (for example, payout schedules)
* Non-sensitive information on the account (for example, support url, support phone number)
* The country of the connected account

You create tokens using Stripe.js, the API, or one of the mobile client libraries. The process is effectively the same as tokenizing payment details or external accounts. Your connected account’s information is sent directly to Stripe and exchanged for a token that you can use in create and update API calls.

### Regional considerations
* France

French platforms must use account tokens, which are an alternative to
```
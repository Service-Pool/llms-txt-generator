## Account Capabilities and Configurations

Capabilities represent functionality that you can request for your connected accounts, such as accepting card payments or receiving transferred funds from your platform account. A capability must be active for a connected account to perform actions associated with that capability.

### Testing Capabilities

Sandboxes might not enforce some capabilities. In certain cases, they can allow an account to perform capability-dependent actions even when the associated capability’s status isn’t active.

### Capability Requirements

Most capabilities require verification of certain information about the connected account’s business before Stripe enables them for that account. The capabilities you request for a connected account determine the information you’re required to collect for that account. To reduce onboarding effort, only request the capabilities that your accounts need. Requesting more capabilities means the onboarding flow must verify more information.

You can start by completing the platform profile to understand which capabilities might be appropriate for your platform.

**Note:** For some capabilities, requesting them enables them permanently. Attempting to remove or unrequest a permanent capability returns an error.

After creating an account, you can request additional capabilities and remove existing non-permanent capabilities. For connected accounts that other platforms control, you can’t unrequest capabilities.

### Supported Capabilities

Following is a list of available capabilities. Click an item to expand or collapse it.

*   Transfers
*   Card payments
*   US tax reporting
*   Payment methods
*   India international payments
*   Multiple
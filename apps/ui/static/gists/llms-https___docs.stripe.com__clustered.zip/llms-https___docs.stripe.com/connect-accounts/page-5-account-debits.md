## Stripe Connect: Managing Connected Accounts and Platform Operations

This documentation set provides comprehensive guidance for platforms and marketplaces leveraging Stripe Connect to manage their connected accounts, process payments, and handle financial operations. It covers essential aspects from initial account setup and onboarding to advanced features like custom branding, risk management, and tax reporting.

### Core Concepts and Account Management:

*   **Understanding Connected Accounts:** Learn about the different types of connected accounts (Standard, Express, Custom) and how to choose the right one for your business model. (Page 12, Page 80, Page 55, Page 157)
*   **Account Creation and Onboarding:** Explore various onboarding methods, including Stripe-hosted, embedded, and API-based flows, to create and verify connected accounts. (Page 16, Page 52, Page 56, Page 73, Page 87, Page 98, Page 109, Page 141, Page 152)
*   **Account Capabilities and Configurations:** Understand how to enable and manage specific capabilities for connected accounts, such as payments, payouts, and tax reporting, using configurations. (Page 4, Page 8, Page 7, Page 9, Page 11)
*   **Representing Customers with Accounts:** Discover how to use Account objects as customers in the Accounts v2 API for a unified approach. (Page 1, Page 10)
*   **Managing Account Balances:** Gain insights into how Stripe account balances work for both platform and connected accounts. (Page 3)
*   **Account Management and Dashboard Access:** Learn how to manage individual connected accounts, set up Dashboard access (Express or full Stripe Dashboard), and utilize connected account filters. (Page 24, Page 58, Page 60, Page 137, Page 149, Page 196)
*   **Changing Account Ownership:** Understand the process for transferring ownership of a connected account. (Page 59)
*   **Handling Verification Updates:** Learn how to manage changes in verification requirements and ensure compliance. (Page 6, Page 86, Page 89, Page 90, Page 188, Page 194)

### Payment Processing and Monetization:

*   **Charge Types in Connect:** Explore the different charge types (Direct, Destination, Separate Charges and Transfers) and their implications for fund flows, statement descriptors, and dispute handling. (Page 20, Page 68, Page 130, Page 134, Page 138, Page 144, Page 198)
*   **Collecting Application Fees:** Learn how to monetize your platform by collecting application fees from transactions. (Page 135, Page 147)
*   **Platform Pricing Tools:** Utilize the platform pricing tool to set custom processing fees and application fees for your connected accounts. (Page 121, Page 122, Page 123, Page 124)
*   **Handling Multiple Currencies:** Manage currency conversions and leverage features like Adaptive Pricing and the FX Quotes API. (Page 13, Page 84, Page 101, Page 100)
*   **Payment Method Management:** Configure and enable various payment methods for your connected accounts and allow them to manage their payment method settings. (Page 41, Page 102, Page 112, Page 114, Page 115, Page 139, Page 204)
*   **Creating Invoices and Subscriptions:** Integrate Stripe Billing to create invoices and subscriptions for connected accounts. (Page 95, Page 160)
*   **Payment Links with Connect:** Create payment links for connected accounts, with the option to collect application fees. (Page 111)

### Payouts and Financial Operations:

*   **Managing Payouts:** Understand how to manage payouts to connected accounts, including scheduling automatic payouts, performing manual payouts, and enabling instant payouts. (Page 18, Page 43, Page 44, Page 45, Page 92, Page 117, Page 142, Page 153)
*   **Account Balances and Top-Ups:** Learn about managing account balances and adding funds to your platform balance. (Page 190, Page 207, Page 208)
*   **Setting Reserves:** Temporarily reserve a portion of a connected account's funds to cover potential refunds and disputes. (Page 54)
*   **Debiting Connected Accounts:** Understand how to collect funds from connected accounts by debiting their Stripe balance. (Page 5)
*   **Payout Statement Descriptors:** Manage how Stripe payouts appear on connected accounts' bank statements. (Page 116)

### Risk Management and Compliance:

*   **Managed Risk:** Leverage Stripe's Managed Risk solution to offload financial risk and liability for negative balances to Stripe. (Page 77, Page 96, Page 209)
*   **Best Practices for Risk Management:** Implement best practices to prevent, mitigate, and respond to payment risks. (Page 127, Page 128)
*   **Understanding Merchant of Record:** Learn how to comply with payment network rules regarding the merchant of record. (Page 97)
*   **Pausing Payments and Payouts:** Control the flow of funds for connected accounts to manage risk. (Page 110)
*   **Disputes on Connect Platforms:** Understand dispute responsibilities and how to handle them based on charge types and liability configurations. (Page 198)
*   **Radar for Connect:** Utilize Stripe Radar to identify and mitigate financial risk on connected accounts and charges. (Page 195)
*   **Additional Verifications:** Implement extra identity verification checks to reduce fraud and meet compliance requirements. (Page 14, Page 15)

### Tax Reporting:

*   **Getting Started with Tax Reporting:** Utilize Stripe's 1099 tax reporting product to manage tax forms for your connected accounts. (Page 170)
*   **1099 Forms and State Requirements:** Understand the requirements for 1099-K, 1099-MISC, and 1099-NEC forms across different states. (Page 163, Page 164, Page 165)
*   **Filing and Delivering Tax Forms:** Learn how to file and deliver 1099 tax forms to the appropriate authorities and your connected accounts. (Page 166, Page 167, Page 169, Page 186)
*   **Configuring Tax Form Settings:** Customize settings for 1099 forms, including default form types and delivery preferences. (Page 173, Page 185)
*   **Platform Tax Reporting:** Prepare reports for regulations like DAC7 for sellers in various countries. (Page 171)
*   **Tax ID Verification:** Collect and verify Tax IDs for your users to ensure accurate 1099 reporting. (Page 174, Page 175)

### Embedded Components and UI Customization:

*   **Supported Embedded Components:** Explore the range of available embedded components for building custom dashboards and user experiences. (Page 23, Page 29, Page 30, Page 31, Page 32, Page 33, Page 34, Page 35, Page 36, Page 37, Page 39, Page 40, Page 41, Page 42, Page 43, Page 44, Page 45, Page 46, Page 47, Page 48, Page 49, Page 50, Page 161)
*   **Getting Started with Embedded Components:** Integrate embedded components into your website to provide connected account dashboard functionality. (Page 85, Page 200)
*   **Customizing Embedded Components:** Learn how to customize the appearance and behavior of embedded components, including support for dark mode. (Page 71, Page 72)
*   **Fully Embedded Integrations:** Build a seamless user experience by embedding all Connect features within your platform's interface. (Page 76, Page 78)
*   **Capital Components:** Utilize embedded components for Stripe Capital to promote financing offers and provide payment tracking. (Page 2)

### Platform Administration and Reporting:

*   **Managing Connected Accounts with the Dashboard:** Utilize the Stripe Dashboard to find, manage, and support your connected accounts. (Page 58, Page 60, Page 137, Page 149, Page 196)
*   **Connect Margin Reports:** Analyze payment volumes, fees, and revenue to calculate margins and set fees. (Page 61)
*   **Platform Earnings Report:** Get a comprehensive view of your platform's financial performance across all connected accounts. (Page 62)
*   **Network Cost Passthrough:** Pass network costs to your connected accounts to offer IC+ pricing. (Page 38, Page 104)
*   **Smart Disputes Fee Passthrough:** Automatically contest disputes and monetize Smart Disputes by passing fees to connected accounts. (Page 133)

### API and Integration:

*   **Making API Calls for Connected Accounts:** Learn how to authenticate and make API calls on behalf of your connected accounts. (Page 17)
*   **Accounts v2 API:** Understand the benefits and features of the Accounts v2 API for managing connected accounts. (Page 7, Page 10, Page 11)
*   **Migrating Integrations:** Find guidance on migrating from Accounts v1 to Accounts v2 or to controller properties. (Page 10, Page 22, Page 191)
*   **Connect Webhooks:** Implement webhooks to receive notifications about Stripe activity related to your connected accounts. (Page 197)
*   **Testing Stripe Connect:** Utilize sandboxes and test API keys to ensure your integration functions correctly. (Page 189)
*   **OAuth for Connect:** Understand the OAuth flow for connecting users to your platform. (Page 106, Page 107, Page 108)

This documentation suite provides a robust foundation for building and managing sophisticated payment integrations with Stripe Connect.
## Exporting Stripe Data to Cloud Storage

This section details how to leverage Stripe's Data Pipeline to export your Stripe data to various cloud storage destinations. This process allows for centralized data management, enabling deeper business insights and streamlined financial closing.

### Overview of Cloud Storage Export

Stripe's Data Pipeline facilitates the automated export of your complete Stripe data to cloud storage services. This eliminates the need for manual ETL processes or custom API integrations. By syncing your Stripe data with other business data in your chosen cloud storage, you can gain a more comprehensive view of your operations.

### Supported Cloud Storage Destinations

Stripe Data Pipeline supports the following cloud storage destinations:

*   **Amazon S3 Storage:** Automate recurring data exports from Stripe to your AWS S3 bucket.
*   **Azure Blob Storage:** Automate recurring data exports from Stripe to your Azure Blob Storage container.
*   **Google Cloud Storage:** Automate recurring data exports from Stripe to your Google Cloud Storage.

### How Data Pipeline Exports to Cloud Storage

When you configure Data Pipeline for a cloud storage destination, Stripe sends your data as Parquet files directly to your owned cloud storage location. After an initial load, your Stripe data is refreshed regularly, with new full loads provided on a recurring basis.

For each successful data transfer, a `SUCCESS` file is created, confirming the validation of all files for a specific set of tables. Additionally, a `data_load_times.json` file is updated with the timestamp and location of the most recent successful data load for each table.

### Key Features and Considerations

*   **Data Format:** Data is exported in Parquet file format.
*   **Refresh Cadence:** Data is typically updated every 3 hours.
*   **File Organization:** Data is organized into directories based on the dataset and mode (live or test). Specific `SUCCESS` files are generated for different datasets to verify loading.
*   **Data Freshness:** Understand the timelines for data availability. Metrics like Freshness P50, Freshness P90, and Max delay provide insights into how quickly data becomes available after an event occurs.
*   **Customization:** You can customize your data exports by pausing table syncing, setting custom schedules for data loads, or pausing the entire pipeline.
*   **Dashboard Report Exports:** Standard Stripe dashboard reports (e.g., Revenue Recognition, Balance Summary) can also be exported as CSV files to your data warehouses via Data Pipeline.

### Getting Started with Cloud Storage Export

1.  **Navigate to Data Pipeline:** In your Stripe Dashboard, go to **Reporting > Data management**.
2.  **Initiate Onboarding:** Follow the onboarding steps for Data Pipeline.
3.  **Select Cloud Storage Destination:** Choose your preferred cloud storage provider (Amazon S3, Azure Blob Storage, or Google Cloud Storage).
4.  **Configure Credentials and Permissions:** Provide the necessary credentials and ensure Stripe has the required permissions to write to your chosen cloud storage bucket or container. This typically involves creating service accounts or IAM roles.
5.  **Complete Onboarding:** Finalize the setup process.

### Diagnosing Connection Issues

If you encounter issues connecting Data Pipeline to your cloud storage, consult the documentation on diagnosing connection issues for specific troubleshooting steps related to Google Cloud Storage and Azure.

### Related Topics

*   [Export data to Amazon S3 Storage](/stripe-data/access-data-in-warehouse/cloud-storage/aws-s3-storage)
*   [Export data to Azure Blob Storage](/stripe-data/access-data-in-warehouse/cloud-storage/azure-blob-storage)
*   [Export data to Google Cloud Storage](/stripe-data/access-data-in-warehouse/cloud-storage/google-cloud-storage)
*   [Cloud storage file organization](/stripe-data/access-data-in-warehouse/cloud-storage/file-organization)
*   [Data Pipeline data freshness](/stripe-data/data-pipeline/data-freshness)
*   [Customize your data exports](/stripe-data/export-customizations)
*   [Diagnose connection issues with cloud storage](/stripe-data/access-data-in-warehouse/cloud-storage/connection)
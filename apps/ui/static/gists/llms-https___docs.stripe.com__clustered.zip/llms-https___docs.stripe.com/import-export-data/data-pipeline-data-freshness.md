## Data Pipeline & Export

This section covers Stripe's Data Pipeline and related export functionalities, enabling you to move your Stripe data to various destinations for analysis and reporting.

### Importing External Data

Stripe provides no-code connectors to automatically import data from external sources into your Stripe account. This is useful for enriching your Stripe data or for specific reporting needs.

*   **Overview of Importing External Data**: Learn about the general process and supported use cases for importing data.
*   **Connectors for External Data**:
    *   **Amazon S3 Stripe Connector**: Automate recurring file imports from your Amazon S3 buckets.
    *   **Apple App Store Stripe Connector**: Automate recurring file imports from the Apple App Store to keep your Stripe products up-to-date.
    *   **Google Play Store Stripe Connector**: Automate recurring file imports from the Google Play Store to keep your Stripe products up-to-date.

### Exporting Stripe Data with Data Pipeline

The Data Pipeline product allows you to automatically export your complete Stripe data to various destinations, eliminating the need for third-party ETL pipelines or custom API integrations.

*   **Data Pipeline Overview**: Understand how Data Pipeline works and its benefits for centralizing and analyzing your Stripe data.
*   **How Data Pipeline Works**: Detailed explanation of the Data Pipeline process and its capabilities.
*   **Next Generation Data Pipeline**: Access real-time Stripe data with a direct mapping to the Stripe API, currently supporting Google Sheets as a destination.
*   **Data Pipeline Destinations**:
    *   **Export data to a data warehouse**: Automate exports to Snowflake, Amazon Redshift, or Databricks.
    *   **Export data to cloud storage**: Sync your Stripe data to cloud storage destinations like Google Cloud Storage, Azure Blob Storage, or Amazon S3.
        *   **Export data to Google Cloud Storage**: Automate recurring data exports to your Google Cloud Storage.
        *   **Export data to Amazon S3**: Automate recurring data exports to your Amazon S3 Storage bucket.
        *   **Export data to Azure Blob Storage**: Automate recurring data exports to your Azure Blob Storage container.
*   **Data Pipeline Data Freshness**: Understand the data availability timelines for Data Pipeline exports, including cadence, P50, P90 freshness, and maximum delay.
*   **Cloud Storage File Organization**: Learn how your files are structured within cloud storage destinations, including directory structures for live and test data, and SUCCESS files for each dataset.
*   **Customize your data exports**: Configure various options for your data exports, such as pausing table syncing, setting custom schedules, pausing the entire pipeline, and exporting dashboard reports.
*   **Diagnose connection issues with cloud storage**: Troubleshoot common configuration points if you encounter issues with your Stripe Data Pipeline connection to cloud storage.
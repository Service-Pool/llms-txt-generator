# Data Pipeline and External Data Integration

This section details how to leverage Stripe's Data Pipeline and external data connectors to integrate your Stripe data with other systems and import external data into Stripe for enhanced reporting and analysis.

## Importing External Data

Stripe provides no-code connectors to automatically import data from various external sources into Stripe's data management platform. This allows you to enrich your Stripe data and power features like Revenue Recognition reports.

### Supported Connectors

*   **Amazon S3 Stripe Connector:** Automate recurring file imports from your Amazon S3 bucket to Stripe.
*   **Apple App Store Stripe Connector:** Automate recurring file imports of subscriber data from Apple App Store to Stripe.
*   **Google Play Store Stripe Connector:** Automate recurring file imports of financial reports from Google Play Store to Stripe.

### Use Cases

*   Importing Apple App Store subscriber reports for Revenue Recognition.
*   Importing Google Play reports for Revenue Recognition.
*   Importing JSON files of bulk metered events for usage-based billing.
*   Manually uploading files for one-time imports.
*   Importing third-party transaction data to Stripe Tax for comprehensive tax reporting.

## Data Pipeline: Exporting Stripe Data

Stripe's Data Pipeline is a no-code product that allows you to automatically export your complete Stripe data to various destinations. This enables you to centralize your Stripe data with other business data for comprehensive insights and financial closing.

### How Data Pipeline Works

Data Pipeline syncs your Stripe data to your chosen destination on a recurring schedule. Data is exported in Parquet files and refreshed regularly.

### Supported Destinations

*   **Data Warehouses:**
    *   Snowflake (AWS, Azure, or Google Cloud)
    *   Amazon Redshift
    *   Databricks
*   **Cloud Storage:**
    *   Google Cloud Storage
    *   Azure Blob Storage
    *   Amazon S3 Storage

### Data Freshness

Data Pipeline provides insights into data availability timelines. Key metrics include:

*   **Cadence:** How frequently data is shared to your destination (e.g., every 3 hours).
*   **Freshness P50 (hours):** The time within which 50% of data is available from event creation.
*   **Freshness P90 (hours):** The time within which 90% of data is available from event creation.
*   **Max delay (hours):** The maximum expected time from event creation to data availability.

You can view data landing and "data as of" times in your Stripe Dashboard.

### Customizing Data Exports

Data Pipeline offers several customization options:

*   **Pause Table Syncing:** Stop future syncs for specific tables.
*   **Set a Custom Schedule:** Define specific times for data loads, rather than adhering to the default cadence.
*   **Pause Your Pipeline:** Temporarily halt all data exports.
*   **Dashboard Report Exports:** Automatically deliver standard dashboard reports (e.g., Revenue Recognition, Balance Summary) to your data warehouses as CSV files.

### Cloud Storage File Organization

Data exported to cloud storage is organized into `livemode` and `testmode` directories. Specific `SUCCESS` files are generated for each dataset to confirm successful loading.

### Diagnosing Connection Issues

A guide is available to help diagnose common connection issues with cloud storage destinations, covering configurations for Google Cloud Storage and Azure.
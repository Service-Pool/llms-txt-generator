# Exporting Stripe Data to Data Warehouses

This section covers how to export your Stripe data to various data warehouse destinations, enabling you to centralize your financial information with other business data for comprehensive analysis and reporting.

## Overview of Data Pipeline

Stripe's Data Pipeline is a no-code product designed to automatically export your complete Stripe data to a variety of destinations. This eliminates the need for third-party ETL pipelines or custom API integrations, streamlining your data management process. Data Pipeline allows you to combine data from all your Stripe accounts into a single data warehouse and integrate it with your other business data for deeper insights.

*   **Note:** Due to data localization requirements, Stripe does not offer Data Pipeline services to customers, businesses, or users in India.

## Supported Destinations

Data Pipeline supports two primary categories of destinations:

*   **Data Warehouses:** Snowflake, Amazon Redshift, and Databricks.
*   **Cloud Storage:** Google Cloud Storage, Azure Blob Storage, and Amazon S3.

### Exporting to Data Warehouses

Data Pipeline can automate data exports directly to Snowflake, Amazon Redshift, or Databricks.

*   **Snowflake:** Supports Snowflake accounts deployed on AWS, Azure, or Google Cloud.
*   **Amazon Redshift:** Supports RA3 instances with encryption.
*   **Databricks:** Supported across various AWS regions.

**Onboarding Process:**

1.  Navigate to **Reporting > Data management** in your Stripe Dashboard.
2.  Follow the onboarding steps.
3.  After accepting the data share and completing onboarding, your core Stripe data will be accessible in your chosen data warehouse within 12 hours.
4.  After the initial load, your Stripe data refreshes regularly, with a full data load delivered every 3 hours.

**Linking Your Snowflake Account:**

1.  On the Data Pipeline settings page in the Dashboard, click **Sign up**.
2.  Select **Snowflake** from the drawer and click **Continue**.
3.  Enter your Snowflake Account Identifier and select the cloud provider (AWS, Azure, or GCP) where your Snowflake account is deployed.
4.  Select your region and click **Next**.
5.  Copy the provided SQL code and run it in a SQL worksheet within your Snowflake warehouse.

*   **Note:** You can only connect one warehouse account to your Stripe account.

## Data Freshness

Data Pipeline shares your Stripe data to your destination on a recurring schedule. The time it takes for data to arrive can vary by dataset.

*   **Cadence:** How frequently Stripe shares data (e.g., every 3 hours).
*   **Freshness P50 (hours):** The duration within which 50% of the data is available from event creation.
*   **Freshness P90 (hours):** The duration within which 90% of the data is available from event creation.
*   **Max delay (hours):** The maximum expected time from event creation to data availability.

You can view data landing and "data as of" times by dataset within your Stripe Dashboard.

## Customizing Data Exports

Data Pipeline offers several customization options for your data exports:

*   **Pause Table Syncing:** Stop future syncs for specific tables.
*   **Set a Custom Schedule:** Choose specific times for data loads, rather than adhering to the default cadence.
*   **Pause Your Pipeline:** Temporarily halt all data syncing.
*   **Dashboard Report Exports:** Automatically deliver standard dashboard reports (e.g., Revenue Recognition, Balance Summary) to your data warehouses as CSV files.
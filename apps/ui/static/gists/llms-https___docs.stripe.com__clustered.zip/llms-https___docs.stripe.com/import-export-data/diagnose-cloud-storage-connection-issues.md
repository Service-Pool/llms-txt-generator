## Importing and Exporting Data with Stripe

This section covers how to manage your Stripe data by importing external information or exporting your Stripe data to various destinations. This includes using Stripe's data management platform and Data Pipeline to gain deeper insights and streamline your financial reporting.

### Importing External Data

Stripe offers no-code connectors to automatically import data from external sources into your Stripe account. This allows you to enrich your Stripe data with information from other platforms, enabling more comprehensive reporting and analysis.

*   **Overview of Importing External Data:** Learn about the capabilities and supported use cases for importing data into Stripe.
*   **Connectors for Data Import:**
    *   **Amazon S3 Stripe Connector:** Automate recurring file imports from your Amazon S3 bucket to Stripe.
    *   **Apple App Store Stripe Connector:** Automate recurring file imports from the Apple App Store to Stripe for subscriber data.
    *   **Google Play Store Stripe Connector:** Automate recurring file imports from the Google Play Store to Stripe for financial reports.
*   **Manual File Uploads:** Manually upload files for one-time imports.
*   **Third-Party Transaction Data Imports:** Import transaction data to Stripe Tax for comprehensive tax reporting.

### Exporting Data with Data Pipeline

Stripe's Data Pipeline is a no-code product that allows you to automatically export your complete Stripe data to various destinations. This enables you to centralize your Stripe data with other business data for enhanced analysis, financial closing, and business insights.

*   **Data Pipeline Overview:** Understand how Data Pipeline works and its benefits for syncing Stripe data.
*   **Data Destinations:**
    *   **Data Warehouses:** Export Stripe data to Snowflake, Amazon Redshift, or Databricks.
        *   [Export data to a data warehouse](/stripe-data/access-data-in-warehouse/data-warehouses)
    *   **Cloud Storage:** Export Stripe data as Parquet files to cloud storage providers.
        *   [Export data to cloud storage](/stripe-data/access-data-in-warehouse/cloud-storage)
        *   [Export data to Amazon S3](/stripe-data/access-data-in-warehouse/cloud-storage/aws-s3-storage)
        *   [Export data to Google Cloud Storage](/stripe-data/access-data-in-warehouse/cloud-storage/google-cloud-storage)
        *   [Export data to Azure Blob Storage](/stripe-data/access-data-in-warehouse/cloud-storage/azure-blob-storage)
*   **Data Freshness:** Understand the timelines for data availability in your chosen destination.
    *   [Data Pipeline data freshness](/stripe-data/data-pipeline/data-freshness)
*   **File Organization:** Learn how your exported files are structured within cloud storage.
    *   [Cloud storage file organization](/stripe-data/access-data-in-warehouse/cloud-storage/file-organization)
*   **Customizing Exports:** Configure and customize your data exports and delivery options.
    *   [Customize your data exports](/stripe-data/export-customizations)
*   **Next Generation Data Pipeline:** Access real-time Stripe data with a direct mapping to the Stripe API.
    *   [Next generation Data Pipeline](/stripe-data/data-pipeline-next-gen)
*   **Troubleshooting:** Diagnose and resolve common connection issues with cloud storage.
    *   [Diagnose connection issues with cloud storage](/stripe-data/access-data-in-warehouse/cloud-storage/connection)
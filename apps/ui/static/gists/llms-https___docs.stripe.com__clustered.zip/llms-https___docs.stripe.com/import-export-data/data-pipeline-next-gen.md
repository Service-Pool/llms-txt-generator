## Data Management and Export

This section details how to manage and export your Stripe data, enabling you to integrate it with external systems, perform advanced analytics, and ensure comprehensive reporting.

### Importing External Data

Stripe provides no-code connectors to automatically import data from various external sources into the Stripe Dashboard. This facilitates data synchronization and enhances reporting capabilities.

*   **Overview of Importing External Data:** Learn about the general process and supported use cases for importing data.
*   **Connectors:**
    *   **Amazon S3 Connector:** Automate recurring file imports from your Amazon S3 buckets to Stripe.
    *   **Apple App Store Connector:** Automate recurring file imports from the Apple App Store to Stripe, useful for subscriber data.
    *   **Google Play Store Connector:** Automate recurring file imports from the Google Play Store to Stripe.
*   **Supported Use Cases:**
    *   Importing Apple App Store subscriber reports for Revenue Recognition.
    *   Importing Google Play reports for Revenue Recognition.
    *   Importing JSON files of bulk metered events for usage-based billing.
    *   Manually uploading files for one-time imports.
    *   Importing third-party transaction data for Stripe Tax reporting.
    *   Private preview for Data Management API and recurring imports with connectors like Amazon S3.

### Data Pipeline: Exporting Stripe Data

Stripe Data Pipeline is a no-code product that allows you to automatically export your complete Stripe data to various destinations for centralization and in-depth business insights.

*   **Overview of Data Pipeline:** Understand how Data Pipeline works and its benefits, such as eliminating the need for third-party ETL pipelines or custom API integrations.
*   **How Data Pipeline Works:** Detailed explanation of the Data Pipeline process and its capabilities.
*   **Destinations:**
    *   **Data Warehouses:**
        *   **Snowflake, Amazon Redshift, Databricks:** Automate data exports to these data warehouse platforms. Stripe sends a data share that refreshes regularly.
    *   **Cloud Storage:**
        *   **Google Cloud Storage:** Automate recurring data exports to your Google Cloud Storage bucket in Parquet file format.
        *   **Amazon S3 Storage:** Automate recurring data exports to your Amazon S3 storage bucket in Parquet file format.
        *   **Azure Blob Storage:** Automate recurring data exports to your Azure Blob Storage account in Parquet file format.
*   **Data Freshness:** Understand the timelines for data availability in your chosen destination, including cadence, P50, P90 freshness, and maximum delay.
*   **File Organization:** Learn how your exported data files are structured within cloud storage, including `livemode` and `testmode` directories and `SUCCESS` files for each dataset.
*   **Customizing Data Exports:**
    *   **Pause Table Syncing:** Temporarily stop syncing specific tables.
    *   **Set Custom Schedules:** Define custom data load schedules instead of the default cadence.
    *   **Pause Your Pipeline:** Pause the entire data pipeline.
    *   **Dashboard Report Exports:** Automatically deliver standard dashboard reports (e.g., Revenue Recognition, Balance Summary) to your data warehouses as CSV files.
*   **Diagnose Connection Issues with Cloud Storage:** Troubleshoot common configuration points for Google Cloud Storage, Azure, and Amazon S3 connections.
*   **Next Generation Data Pipeline:** Access real-time Stripe data with a direct mapping to the Stripe API, currently supporting Google Sheets as a destination.
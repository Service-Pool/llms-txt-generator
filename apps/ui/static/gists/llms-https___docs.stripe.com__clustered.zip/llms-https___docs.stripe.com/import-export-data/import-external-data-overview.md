## Importing External Data into Stripe

This section covers how to import external data into Stripe, enabling richer reporting and more comprehensive data management. Stripe offers no-code connectors and the ability to manually upload files for various use cases.

### Supported Data Sources and Use Cases

Stripe provides connectors for several external data sources, allowing you to automatically import and map data into Stripe's data management platform.

*   **Apple App Store:** Import subscriber data to power Revenue Recognition reports.
*   **Google Play Store:** Import reports to power Revenue Recognition reports.
*   **Amazon S3:** Automate recurring file imports from your Amazon S3 bucket.
*   **JSON Files:** Import bulk metered events to power usage-based billing.
*   **Third-Party Transaction Data:** Import data for comprehensive tax reporting with Stripe Tax.
*   **Manual Uploads:** Manually upload files for one-time imports.

### Connectors

Stripe offers specific connectors to facilitate the import of data from various platforms:

*   **Stripe Connector for Amazon S3:** Automates recurring file imports from your Amazon S3 bucket to Stripe.
*   **Stripe Connector for Apple App Store®:** Automates recurring file imports from the Apple App Store to Stripe.
*   **Stripe Connector for Google Play Store:** Automates recurring file imports from the Google Play Store to Stripe.

These connectors streamline the process of keeping your Stripe products up-to-date by importing necessary files into Stripe's data management platform.

### Data Management Platform Features

When importing data, you can leverage the Stripe Dashboard's Data Management features to:

*   Connect your data sources.
*   View the processing status of your Import Sets.
*   Access detailed information on file processing after completion.
*   Download and resolve Import Set errors.
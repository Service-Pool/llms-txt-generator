# Importing and Exporting Data with Stripe

This section details how to import external data into Stripe and export your Stripe data to various destinations. This functionality is primarily managed through Stripe's Data Management platform and Data Pipeline.

## Importing External Data

Stripe allows you to import external data from various sources to keep your Stripe products up-to-date and to power reporting.

### Connectors for Data Import

Stripe offers no-code connectors to automatically import data from common platforms:

*   **Amazon S3 Stripe Connector:** Automate recurring file imports from your Amazon S3 bucket to Stripe.
*   **Apple App Store Stripe Connector:** Automate recurring file imports from the Apple App Store to Stripe. This is useful for importing subscriber data to power Revenue Recognition reports.
*   **Google Play Store Stripe Connector:** Automate recurring file imports from the Google Play Store to Stripe. This can also be used to power Revenue Recognition reports.

For manual imports or more advanced use cases, you can also upload files directly through the Stripe Dashboard.

## Exporting Stripe Data

Stripe's Data Pipeline product enables you to export your complete Stripe data to various destinations for centralized analysis and business insights.

### Data Pipeline Overview

Data Pipeline is a no-code product that syncs your Stripe data to external destinations. It offers a reliable and fast way to export your data, eliminating the need for third-party ETL pipelines or custom API integrations.

### Supported Destinations

Data Pipeline supports the following types of destinations:

*   **Data Warehouses:**
    *   Snowflake (deployed on AWS, Azure, or Google Cloud)
    *   Amazon Redshift
    *   Databricks
*   **Cloud Storage:**
    *   Google Cloud Storage
    *   Azure Blob Storage
    *   Amazon S3 Storage

### Data Export Customizations

You can customize your data exports to suit your specific needs:

*   **Pause Table Syncing:** Stop future syncs for individual tables.
*   **Set Custom Schedules:** Define specific times for data loads, rather than relying on the default cadence.
*   **Pause Your Pipeline:** Temporarily halt all data exports.
*   **Dashboard Report Exports:** Automatically deliver standard Stripe dashboard reports (e.g., Revenue Recognition, Balance Summary) to your data warehouses as CSV files.

### Data Freshness

Data Pipeline shares your Stripe data to your destination on a recurring schedule. The time it takes for data to arrive can vary. You can monitor data availability timelines, including cadence, P50/P90 freshness, and maximum delay, within your Stripe Dashboard.

### Cloud Storage File Organization

When exporting to cloud storage, data is organized into `livemode` and `testmode` directories. Specific `SUCCESS` files are generated for each dataset to confirm successful loading.

### Diagnosing Connection Issues

If you encounter issues connecting Data Pipeline to your cloud storage, consult the documentation for specific troubleshooting steps for Google Cloud Storage and Azure.

### Next Generation Data Pipeline

The next generation of Data Pipeline offers real-time access to Stripe data with a direct mapping to the Stripe API, currently supporting Google Sheets as a destination.
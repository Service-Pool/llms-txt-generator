# Importing and Exporting Data with Stripe

This section covers how to import external data into Stripe and export your Stripe data to various destinations for analysis and warehousing.

## Importing External Data

Stripe provides no-code connectors to automatically import data from external sources into your Stripe account. This is useful for keeping your Stripe products up-to-date and for enriching your reporting.

### Connectors for Data Import

*   **Apple App Store Connector**: Automate recurring file imports from the Apple App Store to Stripe to keep your Stripe products up-to-date. This requires an Apple Developer and App Store Connect account with specific API key permissions.
*   **Google Play Store Connector**: Automate recurring file imports from the Google Play Store to Stripe. This requires a Google Cloud and Play Console account with necessary API and service account configurations.
*   **Amazon S3 Connector**: Automate recurring file imports from your Amazon S3 bucket to Stripe. This requires an active AWS account and S3 bucket with appropriate permissions.

### Supported Use Cases for Data Import

*   Importing Apple App Store subscriber reports for Revenue Recognition.
*   Importing Google Play reports for Revenue Recognition.
*   Importing JSON files of bulk metered events for usage-based billing.
*   Manually uploading files for one-time imports.
*   Importing third-party transaction data to Stripe Tax for comprehensive tax reporting.

## Exporting Data with Data Pipeline

Stripe Data Pipeline is a no-code product that allows you to automatically export your complete Stripe data to various destinations. This enables you to centralize your Stripe data with other business data for improved financial closing and deeper business insights.

### Data Pipeline Destinations

Data Pipeline supports two main types of destinations:

*   **Data Warehouses**:
    *   Snowflake (AWS, Azure, or Google Cloud)
    *   Amazon Redshift
    *   Databricks
    Stripe sends a data share to your data warehouse, making your core Stripe data accessible within 12 hours. Data refreshes regularly with a full load every 3 hours.

*   **Cloud Storage**:
    *   Google Cloud Storage (GCS)
    *   Azure Blob Storage
    *   Amazon S3 Storage
    Stripe sends your data as Parquet files directly to your owned cloud storage location. Data is updated every 3 hours.

### Data Pipeline Features and Considerations

*   **Data Freshness**: Understand the timelines for data availability in your destination. This includes cadence (how frequently data is shared), P50/P90 freshness (time to data availability), and maximum delay. You can view actual delivery times and "data as of" times in your Stripe Dashboard.
*   **File Organization**: Data is organized into `livemode` and `testmode` directories. Specific `SUCCESS` files are generated for each dataset after loading, indicating successful data transfer.
*   **Customizations**:
    *   **Pause Table Syncing**: Stop future syncs for individual tables.
    *   **Custom Schedule**: Set specific times for data loads, rather than relying on the default cadence.
    *   **Pause Entire Pipeline**: Temporarily halt all data exports.
    *   **Dashboard Report Exports**: Automatically deliver standard dashboard reports (e.g., Revenue Recognition, Balance Summary) to your data warehouses as CSV files.
*   **Next Generation Data Pipeline**: This offers real-time access to Stripe data with a direct mapping to the Stripe API, currently supporting Google Sheets as a destination.

### Diagnosing Connection Issues

If you encounter problems connecting Data Pipeline to your cloud storage, consult the documentation for specific troubleshooting steps for Google Cloud Storage and Azure. This includes verifying bucket/container names, project IDs, and ensuring correct roles and permissions for your service accounts or app registrations.
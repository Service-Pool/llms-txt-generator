# Importing and Exporting Data with Stripe

This section covers how to import external data into Stripe and export your Stripe data to various destinations.

## Importing External Data

Stripe allows you to import external data to enrich your Stripe products and reporting. This is primarily achieved through **no-code connectors** that automate the process of uploading data from other sources into Stripe's Data Management Platform.

### Supported Connectors

*   **Amazon S3 Stripe Connector**: Automate recurring file imports from your Amazon S3 bucket to Stripe.
*   **Apple App Store Stripe Connector**: Automate recurring file imports from the Apple App Store to Stripe, enabling you to import subscriber data.
*   **Google Play Store Stripe Connector**: Automate recurring file imports from the Google Play Store to Stripe.

### Use Cases

*   Importing Apple App Store subscriber reports for Revenue Recognition.
*   Importing Google Play reports for Revenue Recognition.
*   Importing JSON files of bulk metered events for usage-based billing.
*   Manually uploading files for one-time imports.
*   Importing third-party transaction data to Stripe Tax for comprehensive tax reporting.

## Exporting Stripe Data

Stripe provides a **Data Pipeline** product that allows you to export your Stripe data to various destinations for centralized analysis and business insights.

### How Data Pipeline Works

Data Pipeline is a no-code product that sends your complete Stripe data to a variety of data storage destinations. This enables you to:

*   Automatically export your Stripe data reliably and efficiently.
*   Eliminate the need for third-party ETL pipelines or custom API integrations.
*   Consolidate data from all your Stripe accounts into a single data warehouse.
*   Integrate Stripe data with other business data for more comprehensive insights.

**Note:** Due to data localization requirements, Stripe does not offer Data Pipeline services to customers in India.

### Supported Destinations

Data Pipeline supports two main categories of destinations:

*   **Data Warehouses**:
    *   Snowflake (deployed on AWS, Azure, or Google Cloud)
    *   Amazon Redshift
    *   Databricks
    Stripe sends a data share to your data warehouse. After accepting the data share, your core Stripe data will be accessible within 12 hours. Data refreshes regularly, with a full load every 3 hours.

*   **Cloud Storage**:
    *   Google Cloud Storage (GCS)
    *   Azure Blob Storage
    *   Amazon S3 Storage
    Stripe sends your data as Parquet files directly to your cloud storage location. Data is delivered and updated every 3 hours.

### Data Freshness

Data freshness refers to the timeliness of your data in the destination. Key terms include:

*   **Cadence**: How frequently Stripe shares data to your destination (e.g., every 3 hours).
*   **Freshness P50 (hours)**: The time within which 50% of the data is available from event creation.
*   **Freshness P90 (hours)**: The time within which 90% of the data is available from event creation.
*   **Max delay (hours)**: The maximum expected time from event creation to data availability.

You can view data landing and "data as of" times in your Stripe Dashboard.

### Customizing Data Exports

Data Pipeline offers several customization options:

*   **Pause Table Syncing**: Stop future syncs for specific tables.
*   **Set a Custom Schedule**: Choose when data loads occur, for example, once a day instead of every 3 hours.
*   **Pause Your Pipeline**: Temporarily halt all data syncing.
*   **Dashboard Report Exports**: Automatically deliver standard dashboard reports (e.g., Revenue Recognition, Balance Summary) to your data warehouse as CSV files.

### Cloud Storage File Organization

Data is organized into `livemode` and `testmode` directories. Specific files, such as `coreapi_SUCCESS`, are generated to confirm successful data loading for different datasets.

### Diagnosing Connection Issues

If you encounter problems connecting Data Pipeline to your cloud storage, consult the documentation for specific troubleshooting steps for Google Cloud Storage, Azure, and Amazon S3. Common checks include verifying bucket/container names, project IDs, and correct service account roles and permissions.
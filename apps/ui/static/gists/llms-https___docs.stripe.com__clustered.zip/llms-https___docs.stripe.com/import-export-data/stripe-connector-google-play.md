## Importing External Data into Stripe

This section details how to import external data into Stripe, enabling richer reporting and more up-to-date product information. Stripe offers no-code connectors to automate data imports from various sources.

### Supported Connectors

Stripe provides connectors for the following services:

*   **Amazon S3:** Automate recurring file imports from your Amazon S3 buckets into Stripe.
*   **Apple App Store:** Automate recurring file imports of subscriber data from the Apple App Store into Stripe.
*   **Google Play Store:** Automate recurring file imports of financial reports from the Google Play Store into Stripe.

### Use Cases

The ability to import external data supports several key use cases:

*   **Revenue Recognition:** Import Apple App Store subscriber reports or Google Play reports to power Stripe's Revenue Recognition reports.
*   **Usage-Based Billing:** Import JSON files containing bulk metered events to facilitate usage-based billing.
*   **Manual Imports:** Manually upload files for one-time data imports.
*   **Stripe Tax:** Import third-party transaction data for comprehensive tax reporting.
*   **Data Management:** View the processing status of your import sets, get detailed file processing information, and download/resolve Import Set errors.

### Getting Started with Connectors

To set up an automated job for importing data and ensure your Stripe products remain up-to-date, you can import files from supported platforms into Stripe's Data Management Platform.

**Before you begin, ensure you have:**

*   The necessary account access to the external platform (e.g., Apple Developer and App Store Connect, Google Cloud and Play Console, AWS account).
*   Admin account access to the Stripe Dashboard.
*   Specific API keys or service account credentials as required by each connector.

Detailed setup instructions for each connector are available in their respective documentation.
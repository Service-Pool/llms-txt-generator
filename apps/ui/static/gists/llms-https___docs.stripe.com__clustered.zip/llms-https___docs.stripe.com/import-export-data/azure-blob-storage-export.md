## Importing and Exporting Stripe Data

This section details how to import external data into Stripe and export your Stripe data to various destinations for analysis and warehousing.

### Importing External Data

Stripe offers no-code connectors to automatically import data from external sources into your Stripe account. This is particularly useful for enriching your Stripe data with information from other platforms.

*   **Overview of Importing External Data**: Learn the general process and supported use cases for importing data.
*   **Connectors for Data Import**:
    *   **Amazon S3 Stripe Connector**: Automate recurring file imports from your Amazon S3 bucket.
    *   **Apple App Store Stripe Connector**: Automate recurring file imports of subscriber data from the Apple App Store.
    *   **Google Play Store Stripe Connector**: Automate recurring file imports of financial reports from the Google Play Store.
*   **Manual File Uploads**: Manually upload files for one-time imports.
*   **Third-Party Transaction Data Imports**: Import transaction data for comprehensive tax reporting with Stripe Tax.

### Exporting Stripe Data with Data Pipeline

Stripe Data Pipeline is a no-code product that allows you to automatically export your complete Stripe data to various destinations. This enables you to centralize your Stripe data with other business data for enhanced reporting and insights.

*   **Data Pipeline Overview**: Understand how Data Pipeline works and its benefits.
*   **Data Destinations**:
    *   **Data Warehouses**: Export data to Snowflake, Amazon Redshift, or Databricks.
        *   Export data to a data warehouse
        *   Onboarding Snowflake
        *   Onboarding Amazon Redshift RA3
    *   **Cloud Storage**: Export data to cloud storage providers.
        *   Export data to cloud storage
        *   Export data to Amazon S3
        *   Export data to Azure Blob Storage
        *   Export data to Google Cloud Storage
*   **Data Freshness**: Understand the timelines for data availability in your chosen destination.
*   **File Organization**: Learn how your exported files are structured within cloud storage.
*   **Customizing Data Exports**: Configure your data exports, including pausing table syncing, setting custom schedules, and pausing the entire pipeline.
*   **Next Generation Data Pipeline**: Access real-time Stripe data with a direct mapping to the Stripe API.
*   **Diagnosing Connection Issues**: Troubleshoot common connection problems when exporting data to cloud storage.
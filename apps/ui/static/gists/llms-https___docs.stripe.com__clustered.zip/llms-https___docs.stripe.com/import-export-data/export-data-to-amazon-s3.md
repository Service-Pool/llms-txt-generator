## Importing and Exporting Data with Stripe

This section covers how to manage your Stripe data by importing external data and exporting your Stripe data to various destinations.

### Importing External Data

Stripe provides no-code connectors to automatically import data from external sources into Stripe. This helps keep your Stripe products up-to-date and enriches your reporting capabilities.

*   **Connectors:**
    *   **Amazon S3:** Automate recurring file imports from your Amazon S3 bucket to Stripe.
    *   **Apple App Store:** Automate recurring file imports from the Apple App Store to Stripe, allowing you to import subscriber data.
    *   **Google Play Store:** Automate recurring file imports from the Google Play Store to Stripe.
*   **Supported Use Cases:**
    *   Importing Apple App Store subscriber reports for Revenue Recognition.
    *   Importing Google Play reports for Revenue Recognition.
    *   Importing JSON files of bulk metered events for usage-based billing.
    *   Manually uploading files for one-time imports.
    *   Importing third-party transaction data to Stripe Tax for comprehensive tax reporting.

### Exporting Data with Data Pipeline

Stripe Data Pipeline is a no-code product that allows you to sync your Stripe data to various destinations, enabling you to centralize your Stripe data with other business data for enhanced insights and easier financial closing.

*   **How Data Pipeline Works:**
    *   Automatically exports your complete Stripe data in a fast and reliable manner.
    *   Eliminates the need for third-party ETL pipelines or custom API integrations.
    *   Allows you to combine data from all your Stripe accounts into one data warehouse.
    *   Integrates Stripe data with your other business data for more comprehensive insights.

*   **Destinations:**
    *   **Data Warehouses:** Stripe supports Snowflake, Amazon Redshift, and Databricks. Stripe sends a data share to your data warehouse, which is accessible within 12 hours after onboarding. Data refreshes every 3 hours.
    *   **Cloud Storage:** Stripe sends Parquet files directly to your owned cloud storage locations. Supported destinations include:
        *   **Amazon S3:** Automate recurring data exports from Stripe to your AWS S3 Storage bucket.
        *   **Azure Blob Storage:** Automate recurring data exports from Stripe to your Azure Blob Storage container.
        *   **Google Cloud Storage:** Automate recurring data exports from Stripe to your Google Cloud Storage bucket.

*   **Data Freshness:** Data Pipeline shares your Stripe data to your destination on a recurring schedule. You can monitor data availability timelines, including cadence, P50/P90 freshness, and maximum delay, in your Stripe Dashboard.

*   **Customizations:**
    *   **Pause Table Syncing:** Stop future syncs for specific tables.
    *   **Set Custom Schedules:** Define specific times for data loads, such as once a day instead of every 3 hours.
    *   **Pause Entire Pipeline:** Temporarily halt all data exports.
    *   **Dashboard Report Exports:** Automatically deliver standard dashboard reports (e.g., Revenue Recognition, Balance Summary) to your data warehouses as CSV files.

*   **File Organization:** Data is organized into `livemode` and `testmode` directories. Specific `SUCCESS` files are generated for each dataset to verify successful loading, with different datasets having varying freshness requirements and refresh intervals.

*   **Diagnosing Connection Issues:** Guides are available to help troubleshoot common configuration points for Google Cloud Storage and Azure Blob Storage connections.
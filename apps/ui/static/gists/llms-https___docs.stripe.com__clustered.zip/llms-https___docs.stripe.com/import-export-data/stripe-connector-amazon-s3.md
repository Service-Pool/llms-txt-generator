## Importing and Exporting Data with Stripe

This section details how to manage and transfer your Stripe data, both into and out of the Stripe platform. It covers importing external data from various sources and exporting your Stripe data to different destinations for analysis and reporting.

### Importing External Data

Stripe offers no-code connectors to automatically import data from external sources into the Stripe Dashboard. This allows you to enrich your Stripe data and power various reporting and billing functionalities.

*   **Overview of Importing External Data:** Understand the general process and supported use cases for importing data.
*   **Connectors for Data Import:**
    *   **Amazon S3 Stripe Connector:** Automate recurring file imports from your Amazon S3 bucket to Stripe.
    *   **Apple App Store Stripe Connector:** Automate recurring file imports of subscriber data from the Apple App Store to Stripe.
    *   **Google Play Store Stripe Connector:** Automate recurring file imports of financial reports from the Google Play Store to Stripe.
*   **Supported Use Cases:**
    *   Importing Apple App Store subscriber reports for Revenue Recognition.
    *   Importing Google Play reports for Revenue Recognition.
    *   Importing JSON files of bulk metered events for usage-based billing.
    *   Manually uploading files for one-time imports.
    *   Importing third-party transaction data for Stripe Tax.

### Exporting Data with Data Pipeline

Stripe Data Pipeline is a no-code product that enables you to automatically export your complete Stripe data to various destinations. This facilitates centralizing your Stripe data with other business data for enhanced insights and financial closing.

*   **Data Pipeline Overview:** Learn how Data Pipeline works and its benefits for data centralization and analysis.
*   **Data Pipeline Destinations:**
    *   **Data Warehouses:**
        *   **Export to Snowflake, Amazon Redshift, or Databricks:** Automate data exports from Stripe to these popular data warehouse platforms.
    *   **Cloud Storage:**
        *   **Export to Google Cloud Storage:** Automate recurring data exports from Stripe to your Google Cloud Storage.
        *   **Export to Amazon S3 Storage:** Automate recurring data exports from Stripe to your Amazon S3 bucket.
        *   **Export to Azure Blob Storage:** Automate recurring data exports from Stripe to your Azure Blob Storage.
*   **Next Generation Data Pipeline:** Access real-time Stripe data with a direct mapping to the Stripe API, currently supporting Google Sheets as a destination.
*   **Data Freshness:** Understand the data availability timelines for Data Pipeline exports, including cadence, P50, P90, and max delay.
*   **File Organization:** Learn how your exported files are structured within cloud storage destinations, including live vs. test mode data and SUCCESS files.
*   **Customizing Data Exports:** Configure your data exports by pausing table syncing, setting custom schedules, pausing the entire pipeline, and exporting dashboard reports.
*   **Diagnosing Connection Issues:** Troubleshoot common configuration points if you encounter issues connecting Data Pipeline to your cloud storage.